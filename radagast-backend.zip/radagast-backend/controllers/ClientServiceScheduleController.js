const ClientSchedule  = require('./../models').client_service_schedule;

const Sequelize = require('sequelize');
const Op = Sequelize.Op;
const Authorized = require('./../models').authorized;
const authService   = require('./../services/AuthService');

/**
* @api {post} /clients/:id/schedules Add Client Service Schedule
* @apiName AddClientServiceSchedule
* @apiGroup Client Service Schedule
*
* @apiParam {String} id Client Account Number.
*
* @apiParam (Body Params) {Timestammp} pick_up_time  Date and Time of Pick-up.
* @apiParam (Body Params) {Timestammp} delivery_time  Date and Time of Delivery.
* @apiParam (Body Params) {String} type  Type of transaction.
*
* @apiSuccess {Timestammp} pick_up_time  Date and Time of Pick-up.
* @apiSuccess {Timestammp} delivery_time  Date and Time of Delivery.
* @apiSuccess {String} type  Type of transaction.
* @apiSuccess {String} client_account_number  Client Account Number referenced from Client.
* @apiSuccess {Timestamp} created  Date and Time the Schedule is created.
* @apiSuccess {Timestamp} updated  Date and Time the Schedule is updated.
* @apiSuccess {Timestamp} deleted  Date and Time the Schedule is deleted.
Client.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
        "message": "successfully created new client service schedule",
        "client service schedule": {
            "id": "dea8f6af-28fd-46f1-8012-fb6ce2f6400d",
            "created": {
                "val": "NOW()"
            },
            "updated": null,
            "client_account_number": "59e631e0-a9e8-40b9-a995-7d03cb608e52",
            "delivery_time" : null,
            "pick_up_time": "2018-07-01T22:05:17.000Z",
            "type": "pickup"
        },
        "success": true
    }
*
*/

const create = async (req, res) => {
     ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    const client_account_number = req.params.id;
    const {
        pick_up_time,
        delivery_time,
        type
    } = req.body;
    let client_service_schedule;
    [err, client_service_schedule] = await to(ClientSchedule.create({
        'client_account_number' : client_account_number,
        'pick_up_time'  : pick_up_time,
        'delivery_time' : delivery_time,
        'type' : type
    }));
    if (err) {
        return ReE(res, err, 422);
    }
    return ReS(res, {'message':'successfully created new client service schedule', 'client service schedule': client_service_schedule.toWeb()}, 201);
};

/**
* @api {get} /clients/:id/schedules Get Client Service Schedules By Client Account Number
* @apiName GetClientServiceSchedulesByClientAccountNumber
* @apiGroup Client Service Schedule
*
* @apiParam {String} id Client Account Number.
*
* @apiSuccess {Timestammp} pick_up_time  Date and Time of Pick-up.
* @apiSuccess {Timestammp} delivery_time  Date and Time of Delivery.
* @apiSuccess {String} type  Type of transaction.
* @apiSuccess {String} client_account_number  Client Account Number referenced from Client.
* @apiSuccess {Timestamp} created  Date and Time the Schedule is created.
* @apiSuccess {Timestamp} updated  Date and Time the Schedule is updated.
* @apiSuccess {Timestamp} deleted  Date and Time the Schedule is deleted.
Client.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
*        "client service schedules": {
*            "id": "dea8f6af-28fd-46f1-8012-fb6ce2f6400d",
*            "created": {
*                "val": "NOW()"
*            },
*            "updated": null,
*            "client_account_number": "59e631e0-a9e8-40b9-a995-7d03cb608e52",
*            "delivery_time" : null,
*            "pick_up_time": "2018-07-01T22:05:17.000Z",
*            "type": "pickup"
*        },
*        "success": true
*  }
*
*/

const get_client_schedule = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const client_account_number = req.params.id;

    [err, client_service_schedule] = await to(ClientSchedule.findAll({
            where: {
                'client_account_number' : client_account_number
            }
    }));
    return ReS(res, {'client service schedules': client_service_schedule});
};

/**
* @api {get} /schedules/:id Get Client Service Schedules
* @apiName GetClientServiceSchedules
* @apiGroup Client Service Schedule
*
* @apiParam {String} id Client Service Schedule ID.
*
* @apiSuccess {Timestammp} pick_up_time  Date and Time of Pick-up.
* @apiSuccess {Timestammp} delivery_time  Date and Time of Delivery.
* @apiSuccess {String} type  Type of transaction.
* @apiSuccess {String} client_account_number  Client Account Number referenced from Client.
* @apiSuccess {Timestamp} created  Date and Time the Schedule is created.
* @apiSuccess {Timestamp} updated  Date and Time the Schedule is updated.
* @apiSuccess {Timestamp} deleted  Date and Time the Schedule is deleted.
Client.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
        "client service schedules": {
            "id": "dea8f6af-28fd-46f1-8012-fb6ce2f6400d",
            "created": {
                "val": "NOW()"
            },
            "updated": null,
            "client_account_number": "59e631e0-a9e8-40b9-a995-7d03cb608e52",
            "delivery_time" : null,
            "pick_up_time": "2018-07-01T22:05:17.000Z",
            "type": "pickup"
        },
        "success": true
    }
*
*/

const getOne = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const id = req.params.id;
    [err, client_service_schedule] = await to(ClientSchedule.findById(id))
    return ReS(res, {'client service schedule': client_service_schedule.toWeb()});
};

/**
* @api {put} /schedules/:id Update Client Service Schedule
* @apiName UpdateClientServiceScheduleByID
* @apiGroup Client Service Schedule
*
* @apiParam {String} id Client Service Schedule ID.
*
* @apiParam (Body Params) {Timestammp} pick_up_time  Date and Time of Pick-up.
* @apiParam (Body Params) {Timestammp} delivery_time  Date and Time of Delivery.
* @apiParam (Body Params) {String} type  Type of transaction.
*
* @apiSuccess {Timestammp} pick_up_time  Date and Time of Pick-up.
* @apiSuccess {Timestammp} delivery_time  Date and Time of Delivery.
* @apiSuccess {String} type  Type of transaction.
* @apiSuccess {String} client_account_number  Client Account Number referenced from Client.
* @apiSuccess {Timestamp} created  Date and Time the Schedule is created.
* @apiSuccess {Timestamp} updated  Date and Time the Schedule is updated.
* @apiSuccess {Timestamp} deleted  Date and Time the Schedule is deleted.
Client.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
        "client service schedule": {
            "id": "dea8f6af-28fd-46f1-8012-fb6ce2f6400d",
            "created": {
                "val": "NOW()"
            },
            "updated": "2018-07-01T23:06:15.000Z",
            "client_account_number": "59e631e0-a9e8-40b9-a995-7d03cb608e52",
            "delivery_time" : null,
            "pick_up_time": "2018-07-01T22:05:17.000Z",
            "type": "pickup"
        },
        "message": "updated price: dea8f6af-28fd-46f1-8012-fb6ce2f6400d",
        "success": true
    }
*
*/

const update = async (req, res) => {
     ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let client_service_schedule;
    const id = req.params.id;
    const {
        client_account_number,
        delivery_time,
        pick_up_time,
        type
    } = req.body;
    [err, client_service_schedule] = await to(ClientSchedule.update({
            'client_account_number' : client_account_number,
            'delivery_time' : delivery_time,
            'pick_up_time'  : pick_up_time,
            'type' : type,
            updated : Sequelize.fn('NOW')
        }, {
            'where': {
                'id': id
            }
        }
    ));
    if (err) {
        return ReE(res, err);
    }
    [err, client_service_schedule] = await to(ClientSchedule.findById(id))
    return ReS(res, {'client service schedule': client_service_schedule.toWeb(), 'message': 'updated client service schedule: ' + id});
};

/**
* @api {delete} /schedules/:id Delete Client Service Schedule By ID
* @apiName DeleteClientServiceScheduleByID
* @apiGroup Client Service Schedule
*
* @apiParam {String} id Client Service Schedule ID.
*
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
         "message": "deleted client service schedule",
         "success": true
    }
*
*/

const remove = async (req, res) => {
     ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let client_service_schedule;
    const id = req.params.id;
    [err, client_service_schedule] = await to(ClientSchedule.destroy({
        'where': {
            'id': id
        }}
    ));
    if (err) {
        return ReE(res, 'error occured trying to delete client service schedule');
    }
    return ReS(res, {'message': 'deleted client service schedule'});
};

module.exports = {
    'create' : create,
    'get_client_schedule' : get_client_schedule,
    'getOne': getOne,
    'update' : update,
    'remove' : remove
}