const Assignment = require('./../models').assignment;
const Booking = require('./../models').booking;
const Log = require('./../models').log;
const Courier = require('./../models').Courier;
const Authorized = require('./../models').authorized;
const authService   = require('./../services/AuthService');

/**
 * @api {get} /assignments getAssignments
 * @apiGroup Assignment
 * @apiName getAssignments
 *
 * @apiSuccess {UUID} id ID of the assignment
 * @apiSuccess {String} status status of assignment
 * @apiSuccess {String} remarks remarks when failed assignment
 * @apiSuccess {String} name_of_receiver name of receiver of assignment
 * @apiSuccess  {String} relationship_to_shipper relationship to shipper (for receiver details)
 * @apiSuccess {Timestamp} check_in_time check in time of assignment
 * @apiSuccess {Timestamp} check_out_time check out time of assignment
 * @apiSuccess {Timestamp} timestamp_of_unassignment_from_booking Timestamp of unassignment from booking
 * @apiSuccess {Timestamp} timestamp_of_completion Timestamp of completion
 * @apiSuccess {Timestamp} created Date and Time the barangay is created
 * @apiSuccess {UUID} booking_id id of booking
 * @apiSuccess {UUID} courier_id id of courier
 * @apiSuccess {UUID} dispatcher_id id of dispatcher
 * @apiSuccess {String} shipper_name shipper_name of booking 
 * @apiSuccess {String} pick_up_address pick_up_address of booking
 * @apiSuccess {String} contact_number contact_number of booking
 * @apiSuccess {String} email email of booking
 * @apiSuccess {String} product_type product_type of booking
 * @apiSuccess {String} cargo_type cargo_type of booking
 * @apiSuccess {String} mode_of_payment mode_of_payment of booking
 * @apiSuccess {String} client_account_number
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *      "assignments": [
 *          {
 *              "id": "309c888d-67eb-40ff-9828-aff5de15e47b",
 *              "created": "2018-07-12T05:52:20.000Z",
 *              "timestamp_of_completion": null,
 *              "status": "Pending",
 *              "check_in_time": null,
 *              "check_out_time": null,
 *              "remarks": null,
 *              "name_of_receiver": null,
 *              "relationship_to_shipper": null,
 *              "timestamp_of_unassignment_from_booking": "2018-07-12T05:58:23.000Z",
 *              "booking_id": "490e0c2b-138b-4770-b18f-235b0dc8f4b1",
 *              "courier_id": null,
 *              "dispatcher_id": null,
 *              "booking": {
 *                  "shipper_name": "Lazada",
 *                  "pick_up_address": "Ilag's Compound, ",
 *                  "contact_number": "09168679865",
 *                  "email": "ahabulan@gmail.com",
 *                  "product_type": "Apparel",
 *                  "cargo_type": "Dry bulk",
 *                  "mode_of_payment": "visa"
 *                  "client_account_number" : null
 *              }
 *          },
 *          {
 *              "id": "44097751-364e-422a-91de-0b4ce99c59be",
 *              "created": "2018-07-12T03:53:26.000Z",
 *              "timestamp_of_completion": null,
 *              "status": "Pending",
 *              "check_in_time": null,
 *              "check_out_time": null,
 *              "remarks": null,
 *              "name_of_receiver": null,
 *              "relationship_to_shipper": null,
 *              "timestamp_of_unassignment_from_booking": "2018-07-12T05:50:36.000Z",
 *              "booking_id": "c5318d95-964a-4973-856f-a81da63c6320",
 *              "courier_id": null,
 *              "dispatcher_id": null,
 *              "booking": {
 *                  "shipper_name": "Lazada",
 *                  "pick_up_address": "Ilag's Compound, ",
 *                  "contact_number": "09168679812",
 *                  "email": "ahabulan@gmail.com",
 *                  "product_type": "Apparel",
 *                  "cargo_type": "Dry bulk",
 *                  "mode_of_payment": "visa",,
 *                  "client_account_number" : null
 *              }
 *          }
 *      ],
 *      "success": true
 *  }  
 */

const get = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    let err, assignment;
    [err, assignment] = await to(Assignment.findAll({
        include : [{
            model : Booking,
            attributes : ['shipper_name', 'pick_up_address', 'contact_number', 'email', 'product_type', 'cargo_type', 'mode_of_payment', 'client_account_number'],
            required : true
        }]
    }));
    return ReS(res, {'assignments' : assignment});
}

/**
 * @api {getOne} /assignments/:id getOneAssignment
 * @apiGroup Assignment
 * @apiName getOneAssignment
 *
 * @apiSuccess {UUID} id ID of the assignment
 * @apiSuccess {String} status status of assignment
 * @apiSuccess {String} remarks remarks when failed assignment
 * @apiSuccess {String} name_of_receiver name of receiver of assignment
 * @apiSuccess {String} relationship_to_shipper relationship to shipper (for receiver details)
 * @apiSuccess {Timestamp} check_in_time check in time of assignment
 * @apiSuccess {Timestamp} check_out_time check out time of assignment
 * @apiSuccess {Timestamp} timestamp_of_unassignment_from_booking Timestamp of unassignment from booking
 * @apiSuccess {Timestamp} timestamp_of_completion Timestamp of completion
 * @apiSuccess {Timestamp} created Date and Time the barangay is created
 * @apiSuccess {UUID} booking_id id of booking
 * @apiSuccess {UUID} courier_id id of courier
 * @apiSuccess {UUID} dispatcher_id id of dispatcher
 * @apiSuccess {String} shipper_name shipper_name of booking 
 * @apiSuccess {String} pick_up_address pick_up_address of booking
 * @apiSuccess {String} contact_number contact_number of booking
 * @apiSuccess {String} email email of booking
 * @apiSuccess {String} product_type product_type of booking
 * @apiSuccess {String} cargo_type cargo_type of booking
 * @apiSuccess {String} mode_of_payment mode_of_payment of booking 
 * @apiSuccess {String} client_account_number
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *      "assignments": [
 *          {
 *              "id": "309c888d-67eb-40ff-9828-aff5de15e47b",
 *              "created": "2018-07-12T05:52:20.000Z",
 *              "timestamp_of_completion": null,
 *              "status": "Pending",
 *              "check_in_time": null,
 *              "check_out_time": null,
 *              "remarks": null,
 *              "name_of_receiver": null,
 *              "relationship_to_shipper": null,
 *              "timestamp_of_unassignment_from_booking": "2018-07-12T05:58:23.000Z",
 *              "booking_id": "490e0c2b-138b-4770-b18f-235b0dc8f4b1",
 *              "courier_id": null,
 *              "dispatcher_id": null,
 *              "booking": {
 *                  "shipper_name": "Lazada",
 *                  "pick_up_address": "Ilag's Compound, ",
 *                  "contact_number": "09168679865",
 *                  "email": "ahabulan@gmail.com",
 *                  "product_type": "Apparel",
 *                  "cargo_type": "Dry bulk",
 *                  "mode_of_payment": "visa",
 *                  "client_account_number" : null
 *              }
 *          }
 *      ],
 *      "success": true
 *  }  
 */

const getOne = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const id = req.params.id;
    let err, assignment;
    [err, assignment] = await to(Assignment.find({
        include : [{
            model : Booking,
            attributes : ['shipper_name', 'pick_up_address', 'contact_number', 'email', 'product_type', 'cargo_type', 'mode_of_payment'],
            required : true
        }]
    }));
    return ReS(res, {'assignment' : assignment});
}

/**
 * @api {put} /assignments/:id updateAssignment
 * @apiGroup Assignment
 * @apiName updateAssignment
 *
 * @apiParam (Body Params) {String} status status of assignment
 * @apiParam (Body Params) {String} remarks remarks when failed assignment
 * @apiParam (Body Params) {String} name_of_receiver name of receiver of assignment
 * @apiParam (Body Params) {String} relationship_to_shipper relationship to shipper (for receiver details)
 * @apiParam (Body Params) {Timestamp} check_in_time check in time of assignment
 * @apiParam (Body Params) {Timestamp} check_out_time check out time of assignment
 * @apiParam (Body Params) {Timestamp} timestamp_of_unassignment_from_booking Timestamp of unassignment from booking
 * @apiParam (Body Params) {Timestamp} timestamp_of_completion Timestamp of completion
 * @apiParam (Body Params) {Timestamp} created Date and Time the barangay is created
 * @apiParam (Body Params) {UUID} booking_id id of booking
 * @apiParam (Body Params) {UUID} courier_id id of courier
 * @apiParam (Body Params) {UUID} dispatcher_id id of dispatcher
 *
 * @apiSuccess {UUID} id ID of the assignment
 * @apiSuccess {String} status status of assignment
 * @apiSuccess {String} remarks remarks when failed assignment
 * @apiSuccess {String} name_of_receiver name of receiver of assignment
 * @apiSuccess {String} relationship_to_shipper relationship to shipper (for receiver details)
 * @apiSuccess {Timestamp} check_in_time check in time of assignment
 * @apiSuccess {Timestamp} check_out_time check out time of assignment
 * @apiSuccess {Timestamp} timestamp_of_unassignment_from_booking Timestamp of unassignment from booking
 * @apiSuccess {Timestamp} timestamp_of_completion Timestamp of completion
 * @apiSuccess {Timestamp} created Date and Time the barangay is created
 * @apiSuccess {UUID} booking_id id of booking
 * @apiSuccess {UUID} courier_id id of courier
 * @apiSuccess {UUID} dispatcher_id id of dispatcher
 * @apiSuccess {String} Message update assignment + id
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *      "assignment": {
 *          "id": "309c888d-67eb-40ff-9828-aff5de15e47b",
 *          "created": "2018-07-12T05:52:20.000Z",
 *          "timestamp_of_completion": null,
 *          "status": "Served",
 *          "check_in_time": null,
 *          "check_out_time": null,
 *          "remarks": null,
 *          "name_of_receiver": null,
 *          "relationship_to_shipper": null,
 *          "timestamp_of_unassignment_from_booking": "2018-07-12T05:58:23.000Z",
 *          "booking_id": "490e0c2b-138b-4770-b18f-235b0dc8f4b1",
 *          "courier_id": null,
 *          "dispatcher_id": null
 *      },
 *      "message": "update assignment: 309c888d-67eb-40ff-9828-aff5de15e47b",
 *      "success": true
 *  }  
 *
 */
const update = async (req, res) => {
     ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let assignment;
    let user = req.user;
    const id = req.params.id;
    const {
        status,
        check_in_time,
        check_out_time,
        remarks,
        name_of_receiver,
        relationship_to_shipper,
        booking_id,
        courier_id,
        dispatcher_id
    } = req.body;
    [err, assignment] = await to(Assignment.update({
        'status' : status,
        'check_in_time' : check_in_time,
        'check_out_time' : check_out_time,
        'remarks' : remarks,
        'name_of_receiver' : name_of_receiver,
        'relationship_to_shipper' : relationship_to_shipper,
        'booking_id' : booking_id,
        'courier_id' : courier_id,
        'dispatcher_id' : dispatcher_id
    }, 
    {
        'where' : {
            'id' : id
        }
    }));
    if (err) {
        return ReE(res, err);
    }
    [err, assignment] = await to(Assignment.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : assignment,
        'result' : '201',
        'actor' : user.id
    }));
    return ReS(res, {'assignment' : assignment.toWeb(),
                    'log' : log,
                    'message' : 'update assignment: ' + id});
}

/**
 * @api {assign} /assignments/:id/assign assignAssignment
 * @apiGroup Assignment
 * @apiName assignAssignment
 * 
 * @apiParam (Body Params) {UUID} courier_id id of courier
 * @apiParam (Body Params) {UUID} dispatcher_id id of dispatcher
 *
 * @apiSuccess {UUID} id ID of the assignment
 * @apiSuccess {String} status status of assignment
 * @apiSuccess {String} remarks remarks when failed assignment
 * @apiSuccess {String} name_of_receiver name of receiver of assignment
 * @apiSuccess {String} relationship_to_shipper relationship to shipper (for receiver details)
 * @apiSuccess {Timestamp} check_in_time check in time of assignment
 * @apiSuccess {Timestamp} check_out_time check out time of assignment
 * @apiSuccess {Timestamp} timestamp_of_unassignment_from_booking Timestamp of unassignment from booking
 * @apiSuccess {Timestamp} timestamp_of_completion Timestamp of completion
 * @apiSuccess {Timestamp} created Date and Time the barangay is created
 * @apiSuccess {UUID} booking_id id of booking
 * @apiSuccess {UUID} courier_id id of courier
 * @apiSuccess {UUID} dispatcher_id id of dispatcher
 * @apiSuccess {String} Message assigned booking + id
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *       "assignment": {
 *           "id": "309c888d-67eb-40ff-9828-aff5de15e47b",
 *           "created": "2018-07-12T05:52:20.000Z",
 *           "timestamp_of_completion": null,
 *           "status": "Served",
 *           "check_in_time": null,
 *           "check_out_time": null,
 *           "remarks": null,
 *           "name_of_receiver": null,
 *           "relationship_to_shipper": null,
 *           "timestamp_of_unassignment_from_booking": null,
 *           "booking_id": "490e0c2b-138b-4770-b18f-235b0dc8f4b1",
 *           "courier_id": "9frb12fge-653a-44e6-87d9-7eeab7c818c",
 *           "dispatcher_id": "13e7c5a8-6b49-49f5-9bb0-7ed0b25c1164"
 *       },
 *       "message": "assigned booking: 309c888d-67eb-40ff-9828-aff5de15e47b",
 *       "success": true
 *   }
 */
const assign = async (req, res) => {
     ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    const id = req.params.id;
    let user = req.user;
    const {
        courier_id,
        dispatcher_id
    } = req.body;
    [err, booking] = await to(Assignment.update({
        'courier_id' : courier_id,
        'dispatcher_id' : dispatcher_id
    },
    {
        'where' : {
            'id' : id
        }
    }));
    [err, assignment] = await to(Assignment.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : assignment,
        'result' : '201',
        'actor' : user.id
    }));
    return ReS(res, {'assignment' : assignment.toWeb(),
                    'log' : log,
                    'message' : 'assigned booking: ' + id});
}
/**
 * @api {unassign} /assignments/:id/unassign unassignAssignment
 * @apiGroup Assignment
 * @apiName unassignAssignment
 * 
 * @apiParam (Body Params) {UUID} dispatcher_id id of dispatcher
 *
 * @apiSuccess {UUID} id ID of the assignment
 * @apiSuccess {String} status status of assignment
 * @apiSuccess {String} remarks remarks when failed assignment
 * @apiSuccess {String} name_of_receiver name of receiver of assignment
 * @apiSuccess {String} relationship_to_shipper relationship to shipper (for receiver details)
 * @apiSuccess {Timestamp} check_in_time check in time of assignment
 * @apiSuccess {Timestamp} check_out_time check out time of assignment
 * @apiSuccess {Timestamp} timestamp_of_unassignment_from_booking Timestamp of unassignment from booking
 * @apiSuccess {Timestamp} timestamp_of_completion Timestamp of completion
 * @apiSuccess {Timestamp} created Date and Time the barangay is created
 * @apiSuccess {UUID} booking_id id of booking
 * @apiSuccess {UUID} courier_id id of courier
 * @apiSuccess {UUID} dispatcher_id id of dispatcher
 * @apiSuccess {String} Message assigned booking + id
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *       "assignment": {
 *           "id": "309c888d-67eb-40ff-9828-aff5de15e47b",
 *           "created": "2018-07-12T05:52:20.000Z",
 *           "timestamp_of_completion": null,
 *           "status": "Served",
 *           "check_in_time": null,
 *           "check_out_time": null,
 *           "remarks": null,
 *           "name_of_receiver": null,
 *           "relationship_to_shipper": null,
 *           "timestamp_of_unassignment_from_booking": "2018-07-12T05:58:23.000Z",
 *           "booking_id": "490e0c2b-138b-4770-b18f-235b0dc8f4b1",
 *           "courier_id": null
 *           "dispatcher_id": "13e7c5a8-6b49-49f5-9bb0-7ed0b25c1164"
 *       },
 *       "message": "assigned booking: 309c888d-67eb-40ff-9828-aff5de15e47b",
 *       "success": true
 *   }
 */
const unassign = async (req, res) => {
     ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    const id = req.params.id;
    let user = req.user;
    const {
        dispatcher_id
    } = req.body;
    [err, booking] = await to(Assignment.update({
        'courier_id' : null,
        'dispatcher_id' : dispatcher_id
    },
    {
        'where' : {
            'id' : id
        }
    }));
    [err, assignment] = await to(Assignment.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : assignment,
        'result' : '201',
        'actor' : user.id
    }));
    return ReS(res, {'assignment' : assignment.toWeb(),
                    'log' : log,
                    'message' : 'unassigned booking: ' + id});
}

module.exports = {
    'get' : get,
    'getOne' : getOne,
    'update' : update,
    'assign' : assign,
    'unassign' : unassign
}
