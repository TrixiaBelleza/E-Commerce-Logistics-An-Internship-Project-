const Item  = require('./../models').item;
const Log = require('./../models').log;
const Sequelize = require('sequelize');
const Op = Sequelize.Op;
const Authorized = require('./../models').authorized;
const authService   = require('./../services/AuthService');

/**
* @api {get} /items Retrieve Items
* @apiName GetItems
* @apiGroup Item
*
* @apiSuccess {String} id Item ID.
* @apiSuccess {String} consignee_address  Address of the Consignee.
* @apiSuccess {String} consignee_country  Country of the Consignee.
* @apiSuccess {String} consignee_region  Region of the Consignee.
* @apiSuccess {String} consignee_province  Province of the Consignee.
* @apiSuccess {String} consignee_district  District of the Consignee.
* @apiSuccess {String} consignee_sub_district  Subdistrict of the Consignee.
* @apiSuccess {String} consignee_barangay  Barangay of the Consignee.
* @apiSuccess {String} consignee_first_name  First name of the Consignee.
* @apiSuccess {String} consignee_last_name  Last name the Consignee.
* @apiSuccess {String} consignee_contact_number  Contact number of the Consignee.
* @apiSuccess {String} consignee_email  email of the Consignee.
* @apiSuccess {String} weight  Weight of the Item.
* @apiSuccess {String} height  Height of the Item.
* @apiSuccess {String} length  Length the Item.
* @apiSuccess {String} width  Width of the Item.
* @apiSuccess {String} package_type   Package Type of the Item.
* @apiSuccess {String} tracking_number   Tracking Number of the Item.
* @apiSuccess {String} airway_bill Airway Bill of the Item.
* @apiSuccess {Timestamp} timestamp_of_receiving Date and Time the Item is received by the Inbound Officer.
* @apiSuccess {Timestamp} updated  Date and time the Item is updated.
* @apiSuccess {String} courier_id  Courier ID referenced to Courier.
* @apiSuccess {String} inbound_officer_id  Inbound Officer ID referenced to Inbound Officer.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
         "items": [
            {
                "id": "5e1fafc0-ed0f-4446-a4df-0e09f2d2466c",
                "consignee_address": "51 Kanlaon St. Palar Village Brgy. Southside Makati City",
                "consignee_country": "Philippines",
                "consignee_region": "National Capital Region",
                "consignee_province": "",
                "consignee_district": "",
                "consignee_sub_district": "",
                "consignee_barangay": "Southside",
                "consignee_first_name": "Juan",
                "consignee_last_name": "Dela Cruz",
                "consignee_contact_number": "Dela Cruz",
                "consignee_email": "jdelacruz@gmail.com",
                "weight": 30.5,
                "height": 0.5,
                "length": 1.5,
                "width": 2,
                "package_type": "Medium Box",
                "tracking_number": "swsde35-posnwh",
                "airway_bill": "ddcr45-plkm87u",
                "status": "Pending",
                "value": 900,
                "timestamp_of_receiving": "2018-07-11T01:46:28.000Z",
                "updated": null,
                "courier_id": null,
                "inbound_officer_id": "67956a52-c9d5-495a-8cca-2a5d00e19b6c"
            }
        ],
        "success": true
    }
*
* @apiErrorExample {json} Error-Response:
*   HTTP/1.1 500 Internal Server Error
*   {
*     "status": 500,
*     "message": "Internal server error"
*   }
*/

const get = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    [err, items] = await to(Item.findAll())
    return ReS(res, {'items': items});
};



/**
* @api {get} /items/:id Retrieve Item By ID
* @apiName GetItemByID
* @apiGroup Item
*
* @apiParam {String} id Item unique ID.
*
* @apiSuccess {String} id Item ID.
* @apiSuccess {String} consignee_address  Address of the Consignee.
* @apiSuccess {String} consignee_country  Country of the Consignee.
* @apiSuccess {String} consignee_region  Region of the Consignee.
* @apiSuccess {String} consignee_province  Province of the Consignee.
* @apiSuccess {String} consignee_district  District of the Consignee.
* @apiSuccess {String} consignee_sub_district  Subdistrict of the Consignee.
* @apiSuccess {String} consignee_barangay  Barangay of the Consignee.
* @apiSuccess {String} consignee_first_name  First name of the Consignee.
* @apiSuccess {String} consignee_last_name  Last name the Consignee.
* @apiSuccess {String} consignee_contact_number  Contact number of the Consignee.
* @apiSuccess {String} consignee_email  email of the Consignee.
* @apiSuccess {String} weight  Weight of the Item.
* @apiSuccess {String} height  Height of the Item.
* @apiSuccess {String} length  Length the Item.
* @apiSuccess {String} width  Width of the Item.
* @apiSuccess {String} package_type   Package Type of the Item.
* @apiSuccess {String} tracking_number   Tracking Number of the Item.
* @apiSuccess {String} airway_bill Airway Bill of the Item.
* @apiSuccess {Timestamp} timestamp_of_receiving Date and Time the Item is received by the Inbound Officer.
* @apiSuccess {Timestamp} updated  Date and time the Item is updated.
* @apiSuccess {String} courier_id  Courier ID referenced to Courier.
* @apiSuccess {String} inbound_officer_id  Inbound Officer ID referenced to Inbound Officer.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
         "items": [
            {
                "id": "5e1fafc0-ed0f-4446-a4df-0e09f2d2466c",
                "consignee_address": "51 Kanlaon St. Palar Village Brgy. Southside Makati City",
                "consignee_country": "Philippines",
                "consignee_region": "National Capital Region",
                "consignee_province": "",
                "consignee_district": "",
                "consignee_sub_district": "",
                "consignee_barangay": "Southside",
                "consignee_first_name": "Juan",
                "consignee_last_name": "Dela Cruz",
                "consignee_contact_number": "Dela Cruz",
                "consignee_email": "jdelacruz@gmail.com",
                "weight": 30.5,
                "height": 0.5,
                "length": 1.5,
                "width": 2,
                "package_type": "Medium Box",
                "tracking_number": "swsde35-posnwh",
                "airway_bill": "ddcr45-plkm87u",
                "status": "Pending",
                "value": 900,
                "timestamp_of_receiving": "2018-07-11T01:46:28.000Z",
                "updated": null,
                "courier_id": null,
                "inbound_officer_id": "67956a52-c9d5-495a-8cca-2a5d00e19b6c"
            }
        ],
        "success": true
    }
*
* @apiErrorExample {json} Error-Response:
*   HTTP/1.1 500 Internal Server Error
*   {
*     "status": 500,
*     "message": "Internal server error"
*   }
*/

const getOne = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const id = req.params.id;
    [err, item] = await to(Item.findById(id))
    return ReS(res, {'item': item.toWeb()});
};

/**
* @api {post} /items Add Item
* @apiName AddItem
* @apiGroup Item
*
* @apiParam (System Generated) {String} id Item unique ID.
* @apiParam (Body Params) {String} id Item ID.
* @apiParam (Body Params) {String} consignee_address  Address of the Consignee.
* @apiParam (Body Params) {String} consignee_country  Country of the Consignee.
* @apiParam (Body Params) {String} consignee_region  Region of the Consignee.
* @apiParam (Body Params) {String} consignee_province  Province of the Consignee.
* @apiParam (Body Params) {String} consignee_district  District of the Consignee.
* @apiParam (Body Params) {String} consignee_sub_district  Subdistrict of the Consignee.
* @apiParam (Body Params) {String} consignee_barangay  Barangay of the Consignee.
* @apiParam (Body Params) {String} consignee_first_name  First name of the Consignee.
* @apiParam (Body Params) {String} consignee_last_name  Last name the Consignee.
* @apiParam (Body Params) {String} consignee_contact_number  Contact number of the Consignee.
* @apiParam (Body Params) {String} consignee_email  email of the Consignee.
* @apiParam (Body Params) {String} weight  Weight of the Item.
* @apiParam (Body Params) {String} height  Height of the Item.
* @apiParam (Body Params) {String} length  Length the Item.
* @apiParam (Body Params) {String} width  Width of the Item.
* @apiParam (Body Params) {String} package_type   Package Type of the Item.
* @apiParam (Body Params) {String} tracking_number   Tracking Number of the Item.
* @apiParam (Body Params) {String} airway_bill Airway Bill of the Item.
* @apiParam (Body Params) {String} courier_id  Courier ID referenced to Courier.
* @apiParam (Body Params) {String} inbound_officer_id  Inbound Officer ID referenced to Inbound Officer.
*
* @apiSuccess {String} id Item ID.
* @apiSuccess {String} consignee_address  Address of the Consignee.
* @apiSuccess {String} consignee_country  Country of the Consignee.
* @apiSuccess {String} consignee_region  Region of the Consignee.
* @apiSuccess {String} consignee_province  Province of the Consignee.
* @apiSuccess {String} consignee_district  District of the Consignee.
* @apiSuccess {String} consignee_sub_district  Subdistrict of the Consignee.
* @apiSuccess {String} consignee_barangay  Barangay of the Consignee.
* @apiSuccess {String} consignee_first_name  First name of the Consignee.
* @apiSuccess {String} consignee_last_name  Last name the Consignee.
* @apiSuccess {String} consignee_contact_number  Contact number of the Consignee.
* @apiSuccess {String} consignee_email  email of the Consignee.
* @apiSuccess {String} weight  Weight of the Item.
* @apiSuccess {String} height  Height of the Item.
* @apiSuccess {String} length  Length the Item.
* @apiSuccess {String} width  Width of the Item.
* @apiSuccess {String} package_type   Package Type of the Item.
* @apiSuccess {String} tracking_number   Tracking Number of the Item.
* @apiSuccess {String} airway_bill Airway Bill of the Item.
* @apiSuccess {Timestamp} timestamp_of_receiving Date and Time the Item is received by the Inbound Officer.
* @apiSuccess {Timestamp} updated  Date and time the Item is updated.
* @apiSuccess {String} courier_id  Courier ID referenced to Courier.
* @apiSuccess {String} inbound_officer_id  Inbound Officer ID referenced to Inbound Officer.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
        "message": "successfully created new item",
        "item": {
            "id": "17f6b912-e99a-49be-9a5d-bd7da5c5c552",
            "timestamp_of_receiving": {
                "val": "NOW()"
            },
            "updated": null,
            "courier_id": null,
            "consignee_address": "51 Kanlaon St. Palar Village Brgy. Southside Makati City",
            "consignee_country": "Philippines",
            "consignee_region": "National Capital Region",
            "consignee_province": "",
            "consignee_district": "",
            "consignee_sub_district": "",
            "consignee_barangay": "Southside",
            "consignee_first_name": "Juan",
            "consignee_last_name": "Dela Cruz",
            "consignee_contact_number": "Dela Cruz",
            "consignee_email": "jdelacruz@gmail.com",
            "weight": "30.5",
            "height": "0.5",
            "length": "1.5",
            "width": "2",
            "package_type": "Medium Box",
            "tracking_number": "swsde35-posnwh",
            "airway_bill": "ddcr45-plkm87u",
            "status": "Pending",
            "value": "800.00",
            "inbound_officer_id": "67956a52-c9d5-495a-8cca-2a5d00e19b6c"
        },
        "success": true
    }
*
* @apiErrorExample {json} Error-Response:
*   HTTP/1.1 500 Internal Server Error
*   {
*     "status": 500,
*     "message": "Internal server error"
*   }
*/

const create = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    const {
        consignee_address,
        consignee_country,
        consignee_region,
        consignee_province,
        consignee_district,
        consignee_sub_district,
        consignee_barangay,
        consignee_first_name,
        consignee_last_name,
        consignee_contact_number,
        consignee_email,
        weight,
        height,
        length,
        width,
        package_type,
        tracking_number,
        airway_bill,
        status,
        value,
        courier_id,
        inbound_officer_id
    } = req.body;
    let item;
    [err, item] = await to(Item.create({
        'consignee_address' : consignee_address,
        'consignee_country' : consignee_country,
        'consignee_region' : consignee_region,
        'consignee_province' : consignee_province,
        'consignee_district' : consignee_district,
        'consignee_sub_district' : consignee_sub_district,
        'consignee_barangay' : consignee_barangay,
        'consignee_first_name' : consignee_first_name,
        'consignee_last_name' : consignee_last_name,
        'consignee_contact_number' : consignee_contact_number,
        'consignee_email' : consignee_email,
        'weight' : weight,
        'height' : height,
        'length' : length,
        'width' : width,
        'package_type' : package_type,
        'tracking_number' : tracking_number,
        'airway_bill' : airway_bill,
        'status' : status,
        'value' : value,
        //'courier_id' : courier_id,
        'inbound_officer_id' : inbound_officer_id
    }));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : item,
        'result' : '201',
        'actor' : req.user.id
    }));
    return ReS(res, {'message':'successfully created new item', 
                    'item': item.toWeb(),
                    'log' : log}, 201);
};

/**
* @api {put} /items/:id Update Item
* @apiName UpdateItem
* @apiGroup Item
*
* @apiParam {String} id Item unique ID.
*
* @apiParam (Body Params) {String} id Item ID.
* @apiParam (Body Params) {String} consignee_address  Address of the Consignee.
* @apiParam (Body Params) {String} consignee_country  Country of the Consignee.
* @apiParam (Body Params) {String} consignee_region  Region of the Consignee.
* @apiParam (Body Params) {String} consignee_province  Province of the Consignee.
* @apiParam (Body Params) {String} consignee_district  District of the Consignee.
* @apiParam (Body Params) {String} consignee_sub_district  Subdistrict of the Consignee.
* @apiParam (Body Params) {String} consignee_barangay  Barangay of the Consignee.
* @apiParam (Body Params) {String} consignee_first_name  First name of the Consignee.
* @apiParam (Body Params) {String} consignee_last_name  Last name the Consignee.
* @apiParam (Body Params) {String} consignee_contact_number  Contact number of the Consignee.
* @apiParam (Body Params) {String} consignee_email  email of the Consignee.
* @apiParam (Body Params) {String} weight  Weight of the Item.
* @apiParam (Body Params) {String} height  Height of the Item.
* @apiParam (Body Params) {String} length  Length the Item.
* @apiParam (Body Params) {String} width  Width of the Item.
* @apiParam (Body Params) {String} package_type   Package Type of the Item.
* @apiParam (Body Params) {String} tracking_number   Tracking Number of the Item.
* @apiParam (Body Params) {String} airway_bill Airway Bill of the Item.
* @apiParam (Body Params) {String} courier_id  Courier ID referenced to Courier.
* @apiParam (Body Params) {String} inbound_officer_id  Inbound Officer ID referenced to Inbound Officer.
*
* @apiSuccess {String} id Item ID.
* @apiSuccess {String} consignee_address  Address of the Consignee.
* @apiSuccess {String} consignee_country  Country of the Consignee.
* @apiSuccess {String} consignee_region  Region of the Consignee.
* @apiSuccess {String} consignee_province  Province of the Consignee.
* @apiSuccess {String} consignee_district  District of the Consignee.
* @apiSuccess {String} consignee_sub_district  Subdistrict of the Consignee.
* @apiSuccess {String} consignee_barangay  Barangay of the Consignee.
* @apiSuccess {String} consignee_first_name  First name of the Consignee.
* @apiSuccess {String} consignee_last_name  Last name the Consignee.
* @apiSuccess {String} consignee_contact_number  Contact number of the Consignee.
* @apiSuccess {String} consignee_email  email of the Consignee.
* @apiSuccess {String} weight  Weight of the Item.
* @apiSuccess {String} height  Height of the Item.
* @apiSuccess {String} length  Length the Item.
* @apiSuccess {String} width  Width of the Item.
* @apiSuccess {String} package_type   Package Type of the Item.
* @apiSuccess {String} tracking_number   Tracking Number of the Item.
* @apiSuccess {String} airway_bill Airway Bill of the Item.
* @apiSuccess {Timestamp} timestamp_of_receiving Date and Time the Item is received by the Inbound Officer.
* @apiSuccess {Timestamp} updated  Date and time the Item is updated.
* @apiSuccess {String} courier_id  Courier ID referenced to Courier.
* @apiSuccess {String} inbound_officer_id  Inbound Officer ID referenced to Inbound Officer.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
        "item": {
            "id": "5e1fafc0-ed0f-4446-a4df-0e09f2d2466c",
            "consignee_address": "51 Kanlaon St. Palar Village Brgy. Southside Makati City",
            "consignee_country": "Philippines",
            "consignee_region": "National Capital Region",
            "consignee_province": "",
            "consignee_district": "",
            "consignee_sub_district": "",
            "consignee_barangay": "Southside",
            "consignee_first_name": "Juan",
            "consignee_last_name": "Dela Cruz",
            "consignee_contact_number": "Dela Cruz",
            "consignee_email": "jdelacruz@gmail.com",
            "weight": 30.5,
            "height": 0.5,
            "length": 1.5,
            "width": 2,
            "package_type": "Medium Box",
            "tracking_number": "swsde35-posnwh",
            "airway_bill": "ddcr45-plkm87u",
            "status": "Pending",
            "value": 900,
            "timestamp_of_receiving": "2018-07-11T01:46:28.000Z",
            "updated": "2018-07-11T01:49:18.000Z",
            "courier_id": null,
            "inbound_officer_id": "67956a52-c9d5-495a-8cca-2a5d00e19b6c"
        },
        "message": "updated item: 5e1fafc0-ed0f-4446-a4df-0e09f2d2466c",
        "success": true
    }
*
* @apiErrorExample {json} Error-Response:
*   HTTP/1.1 500 Internal Server Error
*   {
*     "status": 500,
*     "message": "Internal server error"
*   }
*/

const update = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let item;
    const id = req.params.id;
    const {
        consignee_address,
        consignee_country,
        consignee_region,
        consignee_province,
        consignee_district,
        consignee_sub_district,
        consignee_barangay,
        consignee_first_name,
        consignee_last_name,
        consignee_contact_number,
        consignee_email,
        weight,
        height,
        length,
        width,
        package_type,
        tracking_number,
        airway_bill,
        status,
        value,
        courier_id,
        inbound_officer_id
    } = req.body;
    [err, item] = await to(Item.update({
        'consignee_address' : consignee_address,
        'consignee_country' : consignee_country,
        'consignee_region' : consignee_region,
        'consignee_province' : consignee_province,
        'consignee_district' : consignee_district,
        'consignee_sub_district' : consignee_sub_district,
        'consignee_barangay' : consignee_barangay,
        'consignee_first_name' : consignee_first_name,
        'consignee_last_name' : consignee_last_name,
        'consignee_contact_number' : consignee_contact_number,
        'consignee_email' : consignee_email,
        'weight' : weight,
        'height' : height,
        'length' : length,
        'width' : width,
        'package_type' : package_type,
        'tracking_number' : tracking_number,
        'airway_bill' : airway_bill,
        'status' : status,
        'value' : value,
        'courier_id' : courier_id,
        'inbound_officer_id' : inbound_officer_id,
        updated : Sequelize.fn('NOW')
        }, {
            'where': {
                'id': id
            }
        }
    ));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : item,
        'result' : '201',
        'actor' : req.user.id
    }));
    [err, item] = await to(Item.findById(id))
    return ReS(res, {'item': item.toWeb(), 
                    'message': 'updated item: ' + id,
                    'log' : log});
};

/**
* @api {delete} /items/:id Delete Item By ID
* @apiName DeleteItemByID
* @apiGroup Item
*
* @apiParam {String} id Item unique ID.
*
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
         "message": "deleted item",
         "success": true
    }
*
* @apiErrorExample {json} Error-Response:
*   HTTP/1.1 500 Internal Server Error
*   {
*     "status": 500,
*     "message": "Internal server error"
*   }
*/

const remove = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let item;
    const id = req.params.id;
    [err, item] = await to(Item.destroy({
        'where': {
            'id': id
        }}
    ));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : item,
        'result' : '201',
        'actor' : req.user.id
    }));
    return ReS(res, {'message': 'deleted item',
                    'log' : log});
};

/**
* @api {get} /items/search Search Item
* @apiName SearchItem
* @apiGroup Item
*
* @apiParam (Query Params) {String} consignee_address  Address of the Consignee.
* @apiParam (Query Params) {String} consignee_country  Country of the Consignee.
* @apiParam (Query Params) {String} consignee_region  Region of the Consignee.
* @apiParam (Query Params) {String} consignee_province  Province of the Consignee.
* @apiParam (Query Params) {String} consignee_district  District of the Consignee.
* @apiParam (Query Params) {String} consignee_sub_district  Subdistrict of the Consignee.
* @apiParam (Query Params) {String} consignee_barangay  Barangay of the Consignee.
* @apiParam (Query Params) {String} consignee_first_name  First name of the Consignee.
* @apiParam (Query Params) {String} consignee_last_name  Last name the Consignee.
* @apiParam (Query Params) {String} consignee_contact_number  Contact number of the Consignee.
* @apiParam (Query Params) {String} consignee_email  email of the Consignee.
* @apiParam (Query Params) {String} weight  Weight of the Item.
* @apiParam (Query Params) {String} height  Height of the Item.
* @apiParam (Query Params) {String} length  Length the Item.
* @apiParam (Query Params) {String} width  Width of the Item.
* @apiParam (Query Params) {String} package_type   Package Type of the Item.
* @apiParam (Query Params) {String} tracking_number   Tracking Number of the Item.
* @apiParam (Query Params) {String} airway_bill Airway Bill of the Item.
* @apiParam (Query Params) {String} courier_id  Courier ID referenced to Courier.
* @apiParam (Query Params) {String} inbound_officer_id  Inbound Officer ID referenced to Inbound Officer.
*
* @apiSuccess {String} id Item ID.
* @apiSuccess {String} consignee_address  Address of the Consignee.
* @apiSuccess {String} consignee_country  Country of the Consignee.
* @apiSuccess {String} consignee_region  Region of the Consignee.
* @apiSuccess {String} consignee_province  Province of the Consignee.
* @apiSuccess {String} consignee_district  District of the Consignee.
* @apiSuccess {String} consignee_sub_district  Subdistrict of the Consignee.
* @apiSuccess {String} consignee_barangay  Barangay of the Consignee.
* @apiSuccess {String} consignee_first_name  First name of the Consignee.
* @apiSuccess {String} consignee_last_name  Last name the Consignee.
* @apiSuccess {String} consignee_contact_number  Contact number of the Consignee.
* @apiSuccess {String} consignee_email  email of the Consignee.
* @apiSuccess {String} weight  Weight of the Item.
* @apiSuccess {String} height  Height of the Item.
* @apiSuccess {String} length  Length the Item.
* @apiSuccess {String} width  Width of the Item.
* @apiSuccess {String} package_type   Package Type of the Item.
* @apiSuccess {String} tracking_number   Tracking Number of the Item.
* @apiSuccess {String} airway_bill Airway Bill of the Item.
* @apiSuccess {Timestamp} timestamp_of_receiving Date and Time the Item is received by the Inbound Officer.
* @apiSuccess {Timestamp} updated  Date and time the Item is updated.
* @apiSuccess {String} courier_id  Courier ID referenced to Courier.
* @apiSuccess {String} inbound_officer_id  Inbound Officer ID referenced to Inbound Officer.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
         "items": [
            {
                "id": "5e1fafc0-ed0f-4446-a4df-0e09f2d2466c",
                "consignee_address": "51 Kanlaon St. Palar Village Brgy. Southside Makati City",
                "consignee_country": "Philippines",
                "consignee_region": "National Capital Region",
                "consignee_province": "",
                "consignee_district": "",
                "consignee_sub_district": "",
                "consignee_barangay": "Southside",
                "consignee_first_name": "Juan",
                "consignee_last_name": "Dela Cruz",
                "consignee_contact_number": "Dela Cruz",
                "consignee_email": "jdelacruz@gmail.com",
                "weight": 30.5,
                "height": 0.5,
                "length": 1.5,
                "width": 2,
                "package_type": "Medium Box",
                "tracking_number": "swsde35-posnwh",
                "airway_bill": "ddcr45-plkm87u",
                "status": "Pending",
                "value": 900,
                "timestamp_of_receiving": "2018-07-11T01:46:28.000Z",
                "updated": "2018-07-11T01:49:18.000Z",
                "courier_id": null,
                "inbound_officer_id": "67956a52-c9d5-495a-8cca-2a5d00e19b6c"
            }
        ],
        "success": true
    }
*
* @apiErrorExample {json} Error-Response:
*   HTTP/1.1 500 Internal Server Error
*   {
*     "status": 500,
*     "message": "Internal server error"
*   }
*/

const search = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const {
        consignee_address,
        consignee_country,
        consignee_region,
        consignee_province,
        consignee_district,
        consignee_sub_district,
        consignee_barangay,
        consignee_first_name,
        consignee_last_name,
        consignee_contact_number,
        consignee_email,
        weight,
        height,
        length,
        width,
        package_type,
        tracking_number,
        airway_bill,
        status,
        value,
        courier_id,
        inbound_officer_id,
        updated,
        timestamp_of_receiving
    } = req.query;

    [err, items] = await to(Item.findAll({
            where: {
                [Op.or]: [{'consignee_address': consignee_address},
                        {'consignee_country': consignee_country}, 
                        {'consignee_region': consignee_region}, 
                        {'consignee_province': consignee_province}, 
                        {'consignee_district': consignee_district},
                        {'consignee_sub_district': consignee_sub_district},
                        {'consignee_barangay': consignee_barangay},
                        {'consignee_first_name': consignee_first_name},
                        {'consignee_last_name': consignee_last_name},
                        {'consignee_contact_number': consignee_contact_number},
                        {'consignee_email': consignee_email},
                        {'weight': weight},
                        {'height': height},
                        {'length': length},
                        {'width': width},
                        {'package_type': package_type},
                        {'tracking_number': tracking_number},
                        {'airway_bill': airway_bill},
                        {'status': status},
                        {'value': value},
                        {'courier_id': courier_id},
                        {'inbound_officer_id': inbound_officer_id},
                        {'updated': updated},
                        {'timestamp_of_receiving': timestamp_of_receiving}]
            }
    }));
    return ReS(res, {'items': items});
};

module.exports = {
    'get'   : get,
    'getOne' : getOne,
    'create' : create,
    'update' : update,
    'remove' : remove,
    'search' : search
}
