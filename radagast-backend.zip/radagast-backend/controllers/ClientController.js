const Client   = require('./../models').client;
const User     = require('./../models').User;
const Log = require('./../models').log;
const Sequelize = require('sequelize');
const Op = Sequelize.Op;
const Authorized = require('./../models').authorized;
const authService   = require('./../services/AuthService');

/**
* @api {get} /v1/clients Get Clients
* @apiGroup Client
* @apiName Get Clients
*
* @apiSuccess {Object[]} clients array of clients
* @apiSuccess {UUID} clients.client_account_number account number of client
* @apiSuccess {String} clients.pick_up_address pick_up_address of client
* @apiSuccess {String} clients.ftp_address ftp_address of client
* @apiSuccess {Integer} clienst.credit_term credit_term of client
* @apiSuccess {String} clients.mode_of_paymment mode_of_paymment of client
* @apiSuccess {String} clients.user_id user_id of client
* @apiSuccess {Timestamp} clients.created timestamp of creation
* @apiSuccess {Timestamp} clients.updated timestamp when updated
* @apiSuccess {Timestamp} clients.deleted timestamp of deletion
* @apiSuccess {Object} clients.user more information about the client
*
* @apiSuccessExample {json} Success-Response:
{
    "client": [
        {
            "client_account_number": "d20060b1-6899-40d0-a299-d28fe0d862b0",
            "pick_up_address": "Gatid Santa Cruz, Laguna",
            "ftp_address": "",
            "credit_term": 15,
            "mode_of_payment": "cash",
            "created": "2018-07-12T03:04:07.000Z",
            "updated": null,
            "deleted": null,
            "user_id": 3,
            "User": {
                "id": 3,
                "email": "jdelacruz@gmail.com",
                "first_name": "jose",
                "middle_name": "reyes",
                "last_name": "delacruz",
                "contact_number": "09123456789"
            }
        },
        {
            "client_account_number": "ba65f79c-bcf1-4cc9-8e3b-6bd597531af6",
            "pick_up_address": "Calios Santa Cruz, Laguna",
            "ftp_address": "",
            "credit_term": 30,
            "mode_of_payment": "cash",
            "created": "2018-07-12T03:11:38.000Z",
            "updated": null,
            "deleted": null,
            "user_id": 4,
            "User": {
                "id": 4,
                "email": "aporca@gmail.com",
                "first_name": "antonette",
                "middle_name": "middle",
                "last_name": "porca",
                "contact_number": "09987654321"
            }
        }
    ],
    "success": true
}
*
*/
const get = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    [err, client] = await to(Client.findAll({
        include: [{
            model: User,
            attributes: ['email','first_name','middle_name','last_name','contact_number'],
            required: true
        }]

    }));
    if (err) { return ReE(res, err, 422);}

    return ReS(res, {'client': client});
};
/**
* @api {get} /v1/clients/:id Get Client by ID
* @apiGroup Client
* @apiName Get Client by ID
* @apiParam {UUID} id Client's unique account number.
*
* @apiSuccess {Object} client client
* @apiSuccess {UUID} client.client_account_number account number of client
* @apiSuccess {String} client.pick_up_address pick_up_address of client
* @apiSuccess {String} client.ftp_address ftp_address of client
* @apiSuccess {Integer} clienst.credit_term credit_term of client
* @apiSuccess {String} client.mode_of_paymment mode_of_paymment of client
* @apiSuccess {String} client.user_id user_id of client
* @apiSuccess {Timestamp} client.created timestamp of creation
* @apiSuccess {Timestamp} client.updated timestamp when updated
* @apiSuccess {Timestamp} client.deleted timestamp of deletion
* @apiSuccess {Object} client.user more information about the client
*
* @apiSuccessExample {json} Success-Response:
{
    "client": {
        "client_account_number": "d20060b1-6899-40d0-a299-d28fe0d862b0",
        "pick_up_address": "Gatid Santa Cruz, Laguna",
        "ftp_address": "",
        "credit_term": 15,
        "mode_of_payment": "cash",
        "created": "2018-07-12T03:04:07.000Z",
        "updated": null,
        "deleted": null,
        "user_id": 3,
        "User": {
            "id": 3,
            "email": "jdelacruz@gmail.com",
            "first_name": "jose",
            "middle_name": "reyes",
            "last_name": "delacruz",
            "contact_number": "09123456789"
        }
    },
    "success": true
}
*
*/

const getOne = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const id = req.params.id;
    [err, client] = await to(Client.find(
        {
            include: [{
                model: User,
                attributes: ['email','first_name','middle_name','last_name','contact_number'],
                required: true
            }]
        },{
            where: {

                'client_account_number': id
            }
        }


    ));
    if (err) { return ReE(res, err, 422);}

    return ReS(res, {'client': client.toWeb()});
};
/**
* @api {post} /v1/clients Add Client
* @apiGroup Client
* @apiName Add Client
*
* @apiParam (Body Params) {String} pick_up_address pick_up_address
* @apiParam (Body Params) {String} ftp_address ftp_address 
* @apiParam (Body Params) {Integer} credit_term credit_term 
* @apiParam (Body Params) {String} mode_of_payment mode_of_payment 
* @apiParam (Body Params) {String} user_id client's user id (foreign key) 
*
* @apiSuccess {Object} client new client
* @apiSuccess {UUID} client.client_account_number account number of client
* @apiSuccess {String} client.pick_up_address pick_up_address of client
* @apiSuccess {String} client.ftp_address ftp_address of client
* @apiSuccess {Integer} client.credit_term credit_term of client
* @apiSuccess {String} client.mode_of_paymment mode_of_paymment of client
* @apiSuccess {String} client.user_id user_id of client
* @apiSuccess {Timestamp} client.created timestamp of creation
* @apiSuccess {Timestamp} client.updated timestamp when updated
* @apiSuccess {Timestamp} client.deleted timestamp of deletion
*
* @apiSuccessExample {json} Success-Response:
{
    "client": {
        "client_account_number": "d20060b1-6899-40d0-a299-d28fe0d862b0",
        "created": {
            "val": "NOW()"
        },
        "updated": null,
        "deleted": null,
        "pick_up_address": "Gatid Santa Cruz, Laguna",
        "ftp_address": "",
        "credit_term": "15",
        "mode_of_payment": "cash",
        "user_id": "3"
    },
    "message": "successfully created new client",
    "success": true
}
*
*/
const create = async (req, res) => {
    const header = req.headers.authorization;

    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}

    res.setHeader('Content-Type', 'application/json');
    const {
        pick_up_address,
        ftp_address,
        credit_term,
        mode_of_payment,
        user_id
    } = req.body;

    [err, client] = await to(Client.create({
       'pick_up_address': pick_up_address,
       'ftp_address' : ftp_address,
       'credit_term' : credit_term,
       'mode_of_payment' : mode_of_payment,
       'user_id' : user_id
    }));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : client,
        'result' : '201',
        'actor' : req.user.id
    }));
    return ReS(res, {'client': client.toWeb(),
                    'message':'successfully created new client', 
                    'log' : log}, 201);
};
/**
* @api {put} /v1/clients/:id Update Client
* @apiGroup Client
* @apiName Update Client
*
* @apiParam (Body Params) {String} pick_up_address pick_up_address
* @apiParam (Body Params) {String} ftp_address ftp_address 
* @apiParam (Body Params) {Integer} credit_term credit_term 
* @apiParam (Body Params) {String} mode_of_payment mode_of_payment 
* @apiParam (Body Params) {String} user_id client's user id (foreign key) 
*
* @apiSuccess {Object} client client
* @apiSuccess {UUID} client.client_account_number account number of client
* @apiSuccess {String} client.pick_up_address pick_up_address of client
* @apiSuccess {String} client.ftp_address ftp_address of client
* @apiSuccess {Integer} client.credit_term credit_term of client
* @apiSuccess {String} client.mode_of_paymment mode_of_paymment of client
* @apiSuccess {String} client.user_id user_id of client
* @apiSuccess {Timestamp} client.created timestamp of creation
* @apiSuccess {Timestamp} client.updated timestamp when updated
* @apiSuccess {Timestamp} client.deleted timestamp of deletion
*
* @apiSuccessExample {json} Success-Response:
{
    "client": {
        "client_account_number": "d20060b1-6899-40d0-a299-d28fe0d862b0",
        "pick_up_address": "Gatid Santa Cruz, Laguna",
        "ftp_address": "",
        "credit_term": 90,
        "mode_of_payment": "cash",
        "created": "2018-07-12T03:04:07.000Z",
        "updated": "2018-07-12T03:45:42.000Z",
        "deleted": null,
        "user_id": 3
    },
    "message": "update client: d20060b1-6899-40d0-a299-d28fe0d862b0",
    "success": true
}
*
*/

const update = async (req, res) => {

    const header = req.headers.authorization;

    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}

    res.setHeader('Content-Type', 'application/json');
 
    const id = req.params.id;
    const {
        pick_up_address,
        ftp_address,
        credit_term,
        mode_of_payment,
    } = req.body;
    [err, client] = await to(Client.update({
       'pick_up_address' : pick_up_address,
       'ftp_address' : ftp_address,
       'credit_term' : credit_term,
       'mode_of_payment' : mode_of_payment,
        updated : Sequelize.fn('NOW')
        
        }, {
            'where': {
                'client_account_number': id
            }
        }
    ));
    [err, client] = await to(Client.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : client,
        'result' : '201',
        'actor' : req.user.id
    }));
    return ReS(res, {'client': client.toWeb(), 
                    'message': 'update client: ' + id,
                    'log' : log});
};
/**
* @api {get} /v1/clients Search Clients
* @apiGroup Client
* @apiName Search Clients
* @apiParam (Params) {String} client_account_number client_account_number
* @apiParam (Params) {String} pick_up_address pick_up_address
* @apiParam (Params) {String} ftp_address ftp_address 
* @apiParam (Params) {Integer} credit_term credit_term 
* @apiParam (Params) {String} mode_of_payment mode_of_payment 
* @apiParam (Params) {String} user_id client's user id (foreign key) 
*
* @apiSuccess {Object[]} clients array of clients
* @apiSuccess {UUID} clients.client_account_number account number of client
* @apiSuccess {String} clients.pick_up_address pick_up_address of client
* @apiSuccess {String} clients.ftp_address ftp_address of client
* @apiSuccess {Integer} clienst.credit_term credit_term of client
* @apiSuccess {String} clients.mode_of_paymment mode_of_paymment of client
* @apiSuccess {String} clients.user_id user_id of client
* @apiSuccess {Timestamp} clients.created timestamp of creation
* @apiSuccess {Timestamp} clients.updated timestamp when updated
* @apiSuccess {Timestamp} clients.deleted timestamp of deletion
* @apiSuccess {Object} clients.user more information about the client
*
* @apiSuccessExample {json} Success-Response:
{
    "client": [
        {
            "client_account_number": "d20060b1-6899-40d0-a299-d28fe0d862b0",
            "pick_up_address": "Gatid Santa Cruz, Laguna",
            "ftp_address": "",
            "credit_term": 15,
            "mode_of_payment": "cash",
            "created": "2018-07-12T03:04:07.000Z",
            "updated": null,
            "deleted": null,
            "user_id": 3
        }
    ],
    "success": true
}
*
*/
const search = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const {
        client_account_number,
        pick_up_address,
        ftp_address,
        credit_term,
        mode_of_payment,
        created,
        updated,
        deleted,
        user_id,
        first_name
    } = req.query;

    [err, client] = await to(Client.findAll({
            include: [{
                model: User,
                attributes: ['email','first_name','middle_name','last_name','contact_number'],
                required: true
            }],
            'where': {
                [Op.or]: [{'client_account_number':client_account_number}, {'pick_up_address':pick_up_address},
                {'ftp_address':ftp_address}, {'credit_term':credit_term}, {'mode_of_payment':mode_of_payment}, {'user_id':user_id},
               {'created': created}, {'updated': updated}, {'deleted': deleted}]
            }
    }));
    return ReS(res, {'client': client});
};
/**
* @api {post} /v1/clients/:id/deactivate Deactivate Client by ID
* @apiGroup Client
* @apiName Deactivate Client by ID
* @apiParam {UUID} id Client's unique account number.
*
* @apiSuccess {Object} client client
* @apiSuccess {UUID} client.client_account_number account number of client
* @apiSuccess {String} client.pick_up_address pick_up_address of client
* @apiSuccess {String} client.ftp_address ftp_address of client
* @apiSuccess {Integer} clienst.credit_term credit_term of client
* @apiSuccess {String} client.mode_of_paymment mode_of_paymment of client
* @apiSuccess {String} client.user_id user_id of client
* @apiSuccess {Timestamp} client.created timestamp of creation
* @apiSuccess {Timestamp} client.updated timestamp when updated
* @apiSuccess {Timestamp} client.deleted timestamp of deletion
*
* @apiSuccessExample {json} Success-Response:
{
    "message": "deactivated client",
    "client": {
        "client_account_number": "d20060b1-6899-40d0-a299-d28fe0d862b0",
        "pick_up_address": "Gatid Santa Cruz, Laguna",
        "ftp_address": "",
        "credit_term": 15,
        "mode_of_payment": "cash",
        "created": "2018-07-12T03:04:07.000Z",
        "updated": null,
        "deleted": "2018-07-12T03:39:28.000Z",
        "user_id": 3
    },
    "success": true
}
*
*/
const deactivate = async (req, res) => {

    const header = req.headers.authorization;

    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}

    res.setHeader('Content-Type', 'application/json');

    const id = req.params.id;
    [err, client] = await to(Client.update({
            deleted : Sequelize.fn('NOW')
        },
        {
            'where': {
                'client_account_number': id
            }
        }
    ));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }

    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : client,
        'result' : '201',
        'actor' : req.user.id
    }));
    [err, client] = await to(Client.findById(id));
    return ReS(res, {'message': 'deactivated client',
                    'client': client.toWeb(),
                    'log' : log});

};
/**
* @api {post} /v1/clients/:id/reactivate Reactivate Client by ID
* @apiGroup Client
* @apiName Reactivate Client by ID
* @apiParam {UUID} id Client's unique account number.
*
* @apiSuccess {Object} client client
* @apiSuccess {UUID} client.client_account_number account number of client
* @apiSuccess {String} client.pick_up_address pick_up_address of client
* @apiSuccess {String} client.ftp_address ftp_address of client
* @apiSuccess {Integer} clienst.credit_term credit_term of client
* @apiSuccess {String} client.mode_of_paymment mode_of_paymment of client
* @apiSuccess {String} client.user_id user_id of client
* @apiSuccess {Timestamp} client.created timestamp of creation
* @apiSuccess {Timestamp} client.updated timestamp when updated
* @apiSuccess {Timestamp} client.deleted timestamp of deletion
*
* @apiSuccessExample {json} Success-Response:
{
    "message": "reactivated client",
    "client": {
        "client_account_number": "d20060b1-6899-40d0-a299-d28fe0d862b0",
        "pick_up_address": "Gatid Santa Cruz, Laguna",
        "ftp_address": "",
        "credit_term": 15,
        "mode_of_payment": "cash",
        "created": "2018-07-12T03:04:07.000Z",
        "updated": null,
        "deleted": null,
        "user_id": 3
    },
    "success": true
}
*
*/

const reactivate = async (req, res) => {

    const header = req.headers.authorization;

    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    
    res.setHeader('Content-Type', 'application/json');

    const id = req.params.id;
    [err, client] = await to(Client.update({
            deleted : null
        },
        {
            'where': {
                'client_account_number': id
            }
        }
    ));
     if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : client,
        'result' : '201',
        'actor' : req.user.id
    }));
    [err, client] = await to(Client.findById(id));
    return ReS(res, {'message': 'reactivated client',
                    'client': client.toWeb(),
                    'log' : log});
};

module.exports = {
    'get'   : get,
   'getOne' : getOne,
    'create' : create,
    'update' : update,
    'search' : search,
    'deactivate' : deactivate,
    'reactivate' : reactivate
}



