const ZoneBarangay = require('./../models').zone_barangay;
const Zone = require('./../models').zone;
const Barangay = require('./../models').barangay;
const Log = require('./../models').log;
const Sequelize = require('sequelize');
const Op = Sequelize.Op;
const Authorized = require('./../models').authorized;
const authService   = require('./../services/AuthService');

/**
 * @api {get} /zone-barangays getZoneBarangays
 * @apiGroup ZoneBarangay
 * @apiName getZoneBarangays
 *
 * @apiSuccess {UUID} id ID of zone barangay
 * @apiSuccess {String} zone_id zone_id of zone barangay referenced from zone
 * @apiSuccess {String} barangay_id barangay_id of zone barangay referenced from barangay
 * @apiSuccess {String} code code of zone
 * @apiSuccess {String} name name of zone
 * @apiSuccess {String} address address of zone
 * @apiSuccess {String} country country of zone
 * @apiSuccess {String} region region of zone
 * @apiSuccess {String} province province of zone
 * @apiSuccess {String} district district of zone
 * @apiSuccess {String} sub_district sub_district of zone
 * @apiSuccess {Stirng} barangay barangay of zone
 * @apiSuccess {String} code code of barangay
 * @apiSuccess {String} name name of barangay
 * @apiSuccess {Timestamp} created Date and Time the zone barangay is created.
 * @apiSuccess {Timestamp} updated Date and Time the zone barangay is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the zone barangay is deleted.
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *      "zone_barangays": [
 *          {
 *              "id": "258b59b7-7907-4d7e-a3bf-961bbdb97a3a",
 *              "created": "2018-07-12T03:20:34.000Z",
 *              "updated": null,
 *              "deleted": null,
 *              "zone_id": "2c933419-6a70-4139-b399-7930ad72ee10",
 *              "barangay_id": "89fc14b8-d853-4cb2-9f66-4cc8c08fc767",
 *              "zone": {
 *                  "code": "z1",
 *                  "name": "Zone 1",
 *                  "address": "Ilag's Compound, Los Banos, Laguna",
 *                  "country": "Philippines",
 *                  "region": "Calabarzon",
 *                  "province": "Laguna",
 *                  "district": "District 2",
 *                  "sub_district": "Los Banos",
 *                  "barangay": "Batong Malake"
 *              },
 *              "barangay": {
 *                  "code": "MA",
 *                  "name": "MAAHAS"
 *              }
 *          },
 *          {
 *              "id": "2638120d-2080-4705-b440-8cf71c255cb6",
 *              "created": "2018-07-12T03:17:43.000Z",
 *              "updated": null,
 *              "deleted": null,
 *              "zone_id": "2c933419-6a70-4139-b399-7930ad72ee10",
 *              "barangay_id": "31f39813-9592-433c-ab93-d35de4b69c38",
 *              "zone": {
 *                  "code": "z1",
 *                  "name": "Zone 1",
 *                  "address": "Ilag's Compound, Los Banos, Laguna",
 *                  "country": "Philippines",
 *                  "region": "Calabarzon",
 *                  "province": "Laguna",
 *                  "district": "District 2",
 *                  "sub_district": "Los Banos",
 *                  "barangay": "Batong Malake"
 *              },
 *              "barangay": {
 *                  "code": "BM",
 *                  "name": "batong malake"
 *              }
 *          }
 *      ],
 *      "success": true
 *  }
 */
const get = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    [err, zone_barangay] = await to(ZoneBarangay.findAll({
        include: [
            {
                model : Zone,
                attributes : ['code', 'name', 'address', 'country', 'region', 'province', 'district', 'sub_district', 'barangay'],
                required : true
            },
            {
                model : Barangay,
                attributes : ['code', 'name'],
                required : true
            }
        ]
    }));
    return ReS(res, {'zone_barangays' : zone_barangay});
};

/**
 * @api {getOne} /zone-barangays/:id getOneZoneBarangay
 * @apiGroup ZoneBarangay
 * @apiName getOneZoneBarangay
 *
 * @apiSuccess {UUID} id ID of zone barangay
 * @apiSuccess {String} zone_id zone_id of zone barangay referenced from zone
 * @apiSuccess {String} barangay_id barangay_id of zone barangay referenced from barangay
 * @apiSuccess {String} code code of zone
 * @apiSuccess {String} name name of zone
 * @apiSuccess {String} address address of zone
 * @apiSuccess {String} country country of zone
 * @apiSuccess {String} region region of zone
 * @apiSuccess {String} province province of zone
 * @apiSuccess {String} district district of zone
 * @apiSuccess {String} sub_district sub_district of zone
 * @apiSuccess {Stirng} barangay barangay of zone
 * @apiSuccess {String} code code of barangay
 * @apiSuccess {String} name name of barangay
 * @apiSuccess {Timestamp} created Date and Time the zone barangay is created.
 * @apiSuccess {Timestamp} updated Date and Time the zone barangay is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the zone barangay is deleted.
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *      "zone_barangays": [
 *          {
 *              "id": "258b59b7-7907-4d7e-a3bf-961bbdb97a3a",
 *              "created": "2018-07-12T03:20:34.000Z",
 *              "updated": null,
 *              "deleted": null,
 *              "zone_id": "2c933419-6a70-4139-b399-7930ad72ee10",
 *              "barangay_id": "89fc14b8-d853-4cb2-9f66-4cc8c08fc767",
 *              "zone": {
 *                  "code": "z1",
 *                  "name": "Zone 1",
 *                  "address": "Ilag's Compound, Los Banos, Laguna",
 *                  "country": "Philippines",
 *                  "region": "Calabarzon",
 *                  "province": "Laguna",
 *                  "district": "District 2",
 *                  "sub_district": "Los Banos",
 *                  "barangay": "Batong Malake"
 *              },
 *              "barangay": {
 *                  "code": "MA",
 *                  "name": "MAAHAS"
 *              }
 *          }
 *      ],
 *      "success": true
 *  }
 */
const getOne = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const id = req.params.id;
    [err, zone_barangay] = await to(ZoneBarangay.find({
        'where' : {
            'id' : id
        },
        include: [
            {
                model : Zone,
                attributes : ['code', 'name', 'address', 'country', 'region', 'province', 'district', 'sub_district', 'barangay'],
                required : true
            },
            {
                model : Barangay,
                attributes : ['code', 'name'],
                required : true
            }
        ]
    }));
    return ReS(res, {'zone_barangay' : zone_barangay});
}

/**
 * @api {post} /zone-barangays addZoneBarangay
 * @apiGroup Barangay
 * @apiName addZoneBarangay
 *
 * @apiParam (System Generated) {UUID} id ID of zone barangay
 * @apiParam (Body Params) {String} zone_id zone_id of zone barangay referenced from zone
 * @apiParam (Body Params) {String} barangay_id barangay_id of zone barangay referenced from barangay
 *
 * @apiSuccess {UUID} id ID of zone barangay
 * @apiSuccess {String} zone_id zone_id of zone barangay referenced from zone
 * @apiSuccess {String} barangay_id barangay_id of zone barangay referenced from barangay
 * @apiSuccess {Timestamp} created Date and Time the zone barangay is created.
 * @apiSuccess {Timestamp} updated Date and Time the zone barangay is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the zone barangay is deleted.
 * @apiSuccess {String} Message Successfully created new zone barangay
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *      "message": "Successfully created new zone barangay",
 *      "zone_barangay": {
 *          "id": "2638120d-2080-4705-b440-8cf71c255cb6",
 *          "created": {
 *              "val": "NOW()"
 *          },
 *          "zone_id": "2c933419-6a70-4139-b399-7930ad72ee10",
 *          "barangay_id": "31f39813-9592-433c-ab93-d35de4b69c38"
 *      },
 *      "success" : true
 *   }
 *
 */

const create = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    const {
        zone_id,
        barangay_id
    } = req.body;
    let zone_barangay;
    let user = req.user;
    [err, zone_barangay] = await to(ZoneBarangay.create({
        'zone_id': zone_id,
        'barangay_id': barangay_id
    }));
    if(err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : zone_barangay,
        'result' : '201',
        'actor' : user.id
    }));
    return ReS(res, {'message': 'Successfully created new zone barangay',
                    'zone_barangay' : zone_barangay,
                    'log' : log}, 201);
};

/**
 * @api {put} /zone-barangays/:id updateZoneBarangay
 * @apiGroup Barangay
 * @apiName updateZoneBarangay
 *
 * @apiParam (Body Params) {String} zone_id zone_id of zone barangay referenced from zone
 * @apiParam (Body Params) {String} barangay_id barangay_id of zone barangay referenced from barangay
 *
 * @apiSuccess {UUID} id ID of zone barangay
 * @apiSuccess {String} zone_id zone_id of zone barangay referenced from zone
 * @apiSuccess {String} barangay_id barangay_id of zone barangay referenced from barangay
 * @apiSuccess {Timestamp} created Date and Time the zone barangay is created.
 * @apiSuccess {Timestamp} updated Date and Time the zone barangay is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the zone barangay is deleted.
 * @apiSuccess {String} Message update zone barangay + id
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *       "zone_barangay": {
 *           "id": "2638120d-2080-4705-b440-8cf71c255cb6",
 *           "created": "2018-07-12T03:17:43.000Z",
 *           "updated": "2018-07-12T03:26:28.000Z",
 *           "deleted": null,
 *           "zone_id": "2c933419-6a70-4139-b399-7930ad72ee10",
 *           "barangay_id": "31f39813-9592-433c-ab93-d35de4b69c38"
 *       },
 *       "message": "update zone_barangay: 2638120d-2080-4705-b440-8cf71c255cb6",
 *       "success": true
 *   }
 *
 */

const update = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let zone_barangay;
    let user = req.user;
    const id = req.params.id;
    const {
        zone_id,
        barangay_id
    } = req.body;
    [err, zone_barangay] = await to(ZoneBarangay.update({
        'zone_id' : zone_id,
        'barangay_id' : barangay_id,
        'updated' : Sequelize.fn('NOW')
    }, {
        'where' : {
            'id' : id
        }
    }));
    [err, zone_barangay] = await to(ZoneBarangay.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : zone_barangay,
        'result' : '201',
        'actor' : user.id
    }));
    return ReS(res, {'zone_barangay' : zone_barangay,
                    'message' : 'update zone_barangay: ' + id,
                    'log' : log}); 
};

/**
 * @api {deactivate} /zone-barangays/:id/deactivate deactivateZoneBarangay
 * @apiGroup Barangay
 * @apiName deactivateZoneBarangay
 *
 * @apiSuccess {UUID} id ID of zone barangay
 * @apiSuccess {String} zone_id zone_id of zone barangay referenced from zone
 * @apiSuccess {String} barangay_id barangay_id of zone barangay referenced from barangay
 * @apiSuccess {Timestamp} created Date and Time the zone barangay is created.
 * @apiSuccess {Timestamp} updated Date and Time the zone barangay is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the zone barangay is deleted.
 * @apiSuccess {String} Message deactivated zone barangay + id
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *      "zone_barangay": {
 *          "id": "2638120d-2080-4705-b440-8cf71c255cb6",
 *          "created": "2018-07-12T03:17:43.000Z",
 *          "updated": "2018-07-12T03:26:28.000Z",
 *          "deleted": "2018-07-12T03:28:42.000Z",
 *          "zone_id": "2c933419-6a70-4139-b399-7930ad72ee10",
 *          "barangay_id": "31f39813-9592-433c-ab93-d35de4b69c38"
 *      },
 *      "message": "deactivated zone barangay: 2638120d-2080-4705-b440-8cf71c255cb6",
 *      "success": true
 *  }
 *
 */
const deactivate = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let zone_barangay;
    const id = req.params.id;
    [err, zone_barangay] = await to(ZoneBarangay.update({
        'deleted' : Sequelize.fn('NOW')
    }, {
        'where' : {
            'id' : id
        }
    }));
    [err, zone_barangay] = await to(ZoneBarangay.findById(id));
    if(err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : zone_barangay,
        'result' : '201',
        'actor' : req.user.id
    }));
    return ReS(res, {'zone_barangay' : zone_barangay,
                    'message' : 'deactivated zone barangay: ' + id,
                    'log' : log});
};

/**
 * @api {reactivate} /zone-barangays/:id/reactivate reactivateZoneBarangay
 * @apiGroup Barangay
 * @apiName reactivateZoneBarangay
 *
 * @apiSuccess {UUID} id ID of zone barangay
 * @apiSuccess {String} zone_id zone_id of zone barangay referenced from zone
 * @apiSuccess {String} barangay_id barangay_id of zone barangay referenced from barangay
 * @apiSuccess {Timestamp} created Date and Time the zone barangay is created.
 * @apiSuccess {Timestamp} updated Date and Time the zone barangay is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the zone barangay is deleted.
 * @apiSuccess {String} Message deactivated zone barangay + id
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *      "zone_barangay": {
 *          "id": "2638120d-2080-4705-b440-8cf71c255cb6",
 *          "created": "2018-07-12T03:17:43.000Z",
 *          "updated": "2018-07-12T03:26:28.000Z",
 *          "deleted": null,
 *          "zone_id": "2c933419-6a70-4139-b399-7930ad72ee10",
 *          "barangay_id": "31f39813-9592-433c-ab93-d35de4b69c38"
 *      },
 *      "message": "reactivated zone barangay: 2638120d-2080-4705-b440-8cf71c255cb6",
 *      "success": true
 *  }
 *
 */
const reactivate = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let zone_barangay;
    const id = req.params.id;
    [err, zone_barangay] = await to(ZoneBarangay.update({
        'deleted' : null
    },
    {
        'where' : {
            'id' : id
        }
    }));
    [err, zone_barangay] = await to(ZoneBarangay.findById(id));
    if(err) { 
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : zone_barangay,
        'result' : '201',
        'actor' : req.user.id
    }));
    return ReS(res, {'zone_barangay' : zone_barangay,
                    'message' : 'reactivated zone_barangay: ' + id,
                    'log' : log});
};

/**
 * @api {search} /zone-barangays/search searchZoneBarangay
 * @apiGroup Barangay
 * @apiName searchZoneBarangay
 *
 * @apiParam (Query Params) {UUID} id ID of zone barangay
 * @apiParam (Query Params) {String} zone_id zone_id of zone barangay referenced from zone
 * @apiParam (Query Params) {String} barangay_id barangay_id of zone barangay referenced from barangay
 *
 * @apiSuccess {UUID} id ID of zone barangay
 * @apiSuccess {String} zone_id zone_id of zone barangay referenced from zone
 * @apiSuccess {String} barangay_id barangay_id of zone barangay referenced from barangay
 * @apiSuccess {Timestamp} created Date and Time the zone barangay is created.
 * @apiSuccess {Timestamp} updated Date and Time the zone barangay is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the zone barangay is deleted.
 * @apiSuccess {String} Message Successfully created new zone barangay
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *      "zone_barangays": [
 *          {
 *              "id": "258b59b7-7907-4d7e-a3bf-961bbdb97a3a",
 *              "created": "2018-07-12T03:20:34.000Z",
 *              "updated": null,
 *              "deleted": null,
 *              "zone_id": "2c933419-6a70-4139-b399-7930ad72ee10",
 *              "barangay_id": "89fc14b8-d853-4cb2-9f66-4cc8c08fc767"
 *          },
 *          {
 *              "id": "2638120d-2080-4705-b440-8cf71c255cb6",
 *              "created": "2018-07-12T03:17:43.000Z",
 *              "updated": "2018-07-12T03:26:28.000Z",
 *              "deleted": "2018-07-12T03:37:18.000Z",
 *              "zone_id": "2c933419-6a70-4139-b399-7930ad72ee10",
 *              "barangay_id": "31f39813-9592-433c-ab93-d35de4b69c38"
 *          }
 *      ],
 *      "success": true
 *  }
 *
 */

const search = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const {
        zone_id,
        barangay_id,
        created,
        updated,
        deleted
    } = req.query;
    [err, zone_barangay] = await to(ZoneBarangay.findAll({
            where: {
                [Op.or]: [{'zone_id': zone_id}, 
                        {'barangay_id': barangay_id}, 
                        {'created': created}, 
                        {'updated': updated}, 
                        {'deleted': deleted}]
            }
    }));
    return ReS(res, {'zone_barangays': zone_barangay});
};

module.exports = {
    'get' : get,
    'create' : create,
    'getOne' : getOne,
    'deactivate' : deactivate,
    'reactivate' : reactivate,
    'update' : update,
    'search' : search
}