const Price  = require('./../models').price;

const Sequelize = require('sequelize');
const Op = Sequelize.Op;
const Authorized = require('./../models').authorized;
const authService   = require('./../services/AuthService');

/**
* @api {get} /prices Retrieve Prices
* @apiName GetPrices
* @apiGroup Price
*
* @apiSuccess {String} id Price ID.
* @apiSuccess {String} package_type  Package Type of Item.
* @apiSuccess {String} origin  Origin of the Item.
* @apiSuccess {String} destination  Destination of the Item.
* @apiSuccess {Float} price  Price for the transaction.
* @apiSuccess {Timestamp} created  Date and Time the Price is created.
* @apiSuccess {Timestamp} updated  Date and Time the Price is updated.
* @apiSuccess {Timestamp} deleted  Date and Time the Price is deleted.
* @apiSuccess {String} client_account_number  Client ID referenced from Client.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
        "prices": [
            {
                "id": "ad478f28-09c3-49af-86bb-210ed6ae3309",
                "package_type": "Small Box",
                "origin": "LB",
                "destination": "MNL",
                "price": 234.75,
                "created": "2018-07-11T03:04:58.000Z",
                "updated": null,
                "deleted": null,
                "client_account_number": "59e631e0-a9e8-40b9-a995-7d03cb608e52"
            },
            {
                "id": "d63e324f-aa0e-4627-878e-99fd6fda069a",
                "package_type": "Large Box",
                "origin": "MKT",
                "destination": "PSG",
                "price": 550,
                "created": "2018-07-10T08:03:43.000Z",
                "updated": null,
                "deleted": null,
                "client_account_number": "59e631e0-a9e8-40b9-a995-7d03cb608e52"
            }
        ],
        "success": true
    }
*
*/

const get = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    [err, prices] = await to(Price.findAll())
    return ReS(res, {'prices': prices});
};

/**
* @api {get} /prices/:id Retrieve Price By ID
* @apiName GetPriceByID
* @apiGroup Price
*
* @apiParam {String} id Price unique ID.
*
* @apiSuccess {String} package_type  Package Type of Item.
* @apiSuccess {String} origin  Origin of the Item.
* @apiSuccess {String} destination  Destination of the Item.
* @apiSuccess {Float} price  Price for the transaction.
* @apiSuccess {Timestamp} created  Date and Time the Price is created.
* @apiSuccess {Timestamp} updated  Date and Time the Price is updated.
* @apiSuccess {Timestamp} deleted  Date and Time the Price is deleted.
* @apiSuccess {String} client_account_number  Client ID referenced from Client.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
        "price":
        {
            "id": "ad478f28-09c3-49af-86bb-210ed6ae3309",
            "package_type": "Small Box",
            "origin": "LB",
            "destination": "MNL",
            "price": 234.75,
            "created": "2018-07-11T03:04:58.000Z",
            "updated": null,
            "deleted": null,
            "client_account_number": "59e631e0-a9e8-40b9-a995-7d03cb608e52"
        }
        "success": true
    }
*
*/

const getOne = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const id = req.params.id;
    [err, prices] = await to(Price.findById(id))
    return ReS(res, {'price': prices.toWeb()});
};

/**
* @api {post} /prices Add Price
* @apiName AddPrice
* @apiGroup Price
*
* @apiParam (System Generated) {String} id Price ID.
*
* @apiParam (Body Params) {String} package_type  Package Type of Item.
* @apiParam (Body Params) {String} origin  Origin of the Item.
* @apiParam (Body Params) {String} destination  Destination of the Item.
* @apiParam (Body Params) {Float} price  Price for the transaction.
* @apiParam (Body Params) {String} client_account_number  Client ID.
*
* @apiSuccess {String} package_type  Package Type of Item.
* @apiSuccess {String} origin  Origin of the Item.
* @apiSuccess {String} destination  Destination of the Item.
* @apiSuccess {Float} price  Price for the transaction.
* @apiSuccess {Timestamp} created  Date and Time the Price is created.
* @apiSuccess {Timestamp} updated  Date and Time the Price is updated.
* @apiSuccess {Timestamp} deleted  Date and Time the Price is deleted.
* @apiSuccess {String} client_account_number  Client ID referenced from Client.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
        "message": "successfully created new price",
        "price": {
            "id": "ad478f28-09c3-49af-86bb-210ed6ae3309",
            "created": {
                "val": "NOW()"
            },
            "updated": null,
            "deleted": null,
            "client_account_number": "59e631e0-a9e8-40b9-a995-7d03cb608e52",
            "package_type": "Small Box",
            "origin": "LB",
            "destination": "MNL",
            "price": "234.75"
        },
        "success": true
    }
*
*/

const create = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    const {
        client_account_number,
        package_type,
        origin,
        destination,
        price
    } = req.body;
    let prices;
    [err, prices] = await to(Price.create({
        'client_account_number' : client_account_number,
        'package_type'  : package_type,
        'origin' : origin,
        'destination' : destination,
        'price' : price
    }));
    if (err) {
        return ReE(res, err, 422);
    }
    return ReS(res, {'message':'successfully created new price', 'price': prices.toWeb()}, 201);
};

/**
* @api {put} /prices/:id Update Price
* @apiName UpdatePriceByID
* @apiGroup Price
*
* @apiParam {String} id Price unique ID.
*
* @apiParam (Body Params) {String} package_type  Package Type of Item.
* @apiParam (Body Params) {String} origin  Origin of the Item.
* @apiParam (Body Params) {String} destination  Destination of the Item.
* @apiParam (Body Params) {Float} price  Price for the transaction.
* @apiParam (Body Params) {String} client_account_number  Client ID.
*
* @apiSuccess {String} package_type  Package Type of Item.
* @apiSuccess {String} origin  Origin of the Item.
* @apiSuccess {String} destination  Destination of the Item.
* @apiSuccess {Float} price  Price for the transaction.
* @apiSuccess {Timestamp} created  Date and Time the Price is created.
* @apiSuccess {Timestamp} updated  Date and Time the Price is updated.
* @apiSuccess {Timestamp} deleted  Date and Time the Price is deleted.
* @apiSuccess {String} client_account_number  Client ID referenced from Client.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
        "price": {
            "id": "ad478f28-09c3-49af-86bb-210ed6ae3309",
            "package_type": "Medium Box",
            "origin": "MNL",
            "destination": "LB",
            "price": 450,
            "created": "2018-07-11T03:04:58.000Z",
            "updated": "2018-07-11T03:20:37.000Z",
            "deleted": null,
            "client_account_number": "59e631e0-a9e8-40b9-a995-7d03cb608e52"
        },
        "message": "updated price: ad478f28-09c3-49af-86bb-210ed6ae3309",
        "success": true
    }
*
*/

const update = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let prices;
    const id = req.params.id;
    const {
        client_account_number,
        package_type,
        origin,
        destination,
        price
    } = req.body;
    [err, prices] = await to(Price.update({
            'client_account_number' : client_account_number,
            'package_type'  : package_type,
            'origin' : origin,
            'destination' : destination,
            'price' : price,
            updated : Sequelize.fn('NOW')
        }, {
            'where': {
                'id': id
            }
        }
    ));
    if (err) {
        return ReE(res, err);
    }
    [err, prices] = await to(Price.findById(id))
    return ReS(res, {'price': prices.toWeb(), 'message': 'updated price: ' + id});
};

/**
* @api {post} /prices/:id/deactivate Deactivate Price
* @apiName DeactivatePrice
* @apiGroup Price
*
* @apiParam {String} id Price unique ID.
*
* @apiSuccess {String} package_type  Package Type of Item.
* @apiSuccess {String} origin  Origin of the Item.
* @apiSuccess {String} destination  Destination of the Item.
* @apiSuccess {Float} price  Price for the transaction.
* @apiSuccess {Timestamp} created  Date and Time the Price is created.
* @apiSuccess {Timestamp} updated  Date and Time the Price is updated.
* @apiSuccess {Timestamp} deleted  Date and Time the Price is deleted.
* @apiSuccess {String} client_account_number  Client ID referenced from Client.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
        "price": {
            "id": "ad478f28-09c3-49af-86bb-210ed6ae3309",
            "package_type": "Medium Box",
            "origin": "MNL",
            "destination": "LB",
            "price": 450,
            "created": "2018-07-11T03:04:58.000Z",
            "updated": "2018-07-11T03:20:37.000Z",
            "deleted": "2018-07-11T03:22:34.000Z",
            "client_account_number": "59e631e0-a9e8-40b9-a995-7d03cb608e52"
        },
        "message": "deactivated price: ad478f28-09c3-49af-86bb-210ed6ae3309",
        "success": true
    }
*
*/

const deactivate = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let price;
    const id = req.params.id;
    [err, price] = await to(Price.update({
            deleted : Sequelize.fn('NOW')
        },
        {
            'where': {
                'id': id
            }
        }
    ));
    if (err) {
        return ReE(res, 'error occured trying to deactivate price');
    }
    [err, price] = await to(Price.findById(id))
    return ReS(res, {'price' : price.toWeb(), 'message' : 'deactivated price: ' + id});
};

/**
* @api {post} /prices/:id/reactivate Reactivate Price
* @apiName ReactivatePrice
* @apiGroup Price
*
* @apiParam {String} id Price unique ID.
*
* @apiSuccess {String} package_type  Package Type of Item.
* @apiSuccess {String} origin  Origin of the Item.
* @apiSuccess {String} destination  Destination of the Item.
* @apiSuccess {Float} price  Price for the transaction.
* @apiSuccess {Timestamp} created  Date and Time the Price is created.
* @apiSuccess {Timestamp} updated  Date and Time the Price is updated.
* @apiSuccess {Timestamp} deleted  Date and Time the Price is deleted.
* @apiSuccess {String} client_account_number  Client ID referenced from Client.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
        "price": {
            "id": "ad478f28-09c3-49af-86bb-210ed6ae3309",
            "package_type": "Medium Box",
            "origin": "MNL",
            "destination": "LB",
            "price": 450,
            "created": "2018-07-11T03:04:58.000Z",
            "updated": "2018-07-11T03:20:37.000Z",
            "deleted": null,
            "client_account_number": "59e631e0-a9e8-40b9-a995-7d03cb608e52"
        },
        "message": "reactivated price: ad478f28-09c3-49af-86bb-210ed6ae3309",
        "success": true
    }
*
*/

const reactivate = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let price;
    const id = req.params.id;
    [err, price] = await to(Price.update({
            deleted : null
        },
        {
            'where': {
                'id': id
            }
        }
    ));
    if (err) {
        return ReE(res, 'error occured trying to reactivate price');
    }
    [err, price] = await to(Price.findById(id))
    return ReS(res, {'price' : price.toWeb(), 'message' : 'reactivated price: ' + id});
};

module.exports = {
    'get'   : get,
    'create' : create,
    'getOne' : getOne,
    'update' : update,
    'deactivate' : deactivate,
    'reactivate' : reactivate
}