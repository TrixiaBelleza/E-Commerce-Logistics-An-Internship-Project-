const Country   = require('./../models').country;
const Log = require('./../models').log;
const Sequelize = require('sequelize');
const Op = Sequelize.Op;
const Authorized = require('./../models').authorized;
const authService   = require('./../services/AuthService');

/**
* @api {get} /countries Retrieve Countries
* @apiName GetCountries
* @apiGroup Country
*
* @apiSuccess {String} id Country ID.
* @apiSuccess {String} code  Code of the Country.
* @apiSuccess {String} name  Name of the Country.
* @apiSuccess {Timestamp} created  Date and Time the Country is created.
* @apiSuccess {Timestamp} updated  Date and Time the Country is updated.
* @apiSuccess {Timestamp} deleted  Date and Time the Country is deleted.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
        "countries": [
            {
                "id": "2fca2d08-a11b-4ad2-bc2d-79d4a4e6c796",
                "code": "USA",
                "name": "United States of America",
                "created": "2018-07-10T07:17:39.000Z",
                "updated": null,
                "deleted": null
            },
            {
                "id": "406405a2-8255-48d0-86c6-7f1109d10e30",
                "code": "PH",
                "name": "Philippines",
                "created": "2018-07-09T01:58:14.000Z",
                "updated": null,
                "deleted": null
            }
        ],
        "success": true
    }
*
*/
const get = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    [err, country] = await to(Country.findAll());
    return ReS(res, {'countries': country});
};

/**
* @api {get} /countries/:id Retrieve Country By ID
* @apiName GetCountryByID
* @apiGroup Country
*
* @apiParam {String} id Country unique ID.
*
* @apiSuccess {String} id Country ID.
* @apiSuccess {String} code  Code of the Country.
* @apiSuccess {String} name  Name of the Country.
* @apiSuccess {Timestamp} created  Date and Time the Country is created.
* @apiSuccess {Timestamp} updated  Date and Time the Country is updated.
* @apiSuccess {Timestamp} deleted  Date and Time the Country is deleted.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
        "country": {
            "id": "0682ed71-3229-4fb6-b6a8-b515994a70b8",
            "code": "PH",
            "name": "Philippines",
            "created": "2018-07-10T06:54:10.000Z",
            "updated": null,
            "deleted": null
        },
        "success": true
    }
*
*/
const getOne = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const id = req.params.id;
    [err, country] = await to(Country.findById(id));
    return ReS(res, {'country': country.toWeb()});
};

/**
* @api {get} /countries/search Search Country
* @apiName SearchCountry
* @apiGroup Country
*
* @apiParam (Query Params) {String} code code of the Country
* @apiParam (Query Params) {String} name name of the Country
* @apiParam (Query Params) {Timestamp} created Date and Time the Country is created.
* @apiParam (Query Params) {Timestamp} updated Date and Time the Country is updated.
* @apiParam (Query Params) {Timestamp} deleted Date and Time the Country is deleted.
*
* @apiSuccess {String} id Country ID.
* @apiSuccess {String} code  Code of the Country.
* @apiSuccess {String} name  Name of the Country.
* @apiSuccess {Timestamp} created  Date and Time the Country is created.
* @apiSuccess {Timestamp} updated  Date and Time the Country is updated.
* @apiSuccess {Timestamp} deleted  Date and Time the Country is deleted.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
        "countries": [
            {
                "id": "2fca2d08-a11b-4ad2-bc2d-79d4a4e6c796",
                "code": "UK",
                "name": "United Kingdom",
                "created": "2018-07-10T07:17:39.000Z",
                "updated": "2018-07-10T07:25:56.000Z",
                "deleted": null
            }
        ],
        "success": true
    }
*
*/

const search = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const {
        code,
        name,
        created,
        updated,
        deleted
    } = req.query;

    [err, country] = await to(Country.findAll({
    		where: {
                [Op.or]: [{'code': code},
                        {'name': name}, 
                        {'created': created}, 
                        {'updated': updated}, 
                        {'deleted': deleted}]
			}
    }));
    return ReS(res, {'countries': country});
};

/**
* @api {post} /countries Add Country
* @apiName AddCountry
* @apiGroup Country
*
* @apiParam (System Generated) {String} id Country unique ID
* @apiParam (Body Params) {String} code code of the Country
* @apiParam (Body Params) {String} name name of the Country
*
* @apiSuccess {String} id Country ID.
* @apiSuccess {String} code  Code of the Country.
* @apiSuccess {String} name  Name of the Country.
* @apiSuccess {Timestamp} created  Date and Time the Country is created.
* @apiSuccess {Timestamp} updated  Date and Time the Country is updated.
* @apiSuccess {Timestamp} deleted  Date and Time the Country is deleted.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
        "message": "successfully created new country",
        "country": {
            "id": "0682ed71-3229-4fb6-b6a8-b515994a70b8",
            "updated": null,
            "deleted": null,
            "code": "PH",
            "name": "Philippines",
            "created": {
                "fn": "NOW",
                "args": []
        }
    }
*
*/

const create = async (req, res) => {
     ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    const {
        code,
        name
    } = req.body;
    let country;
    let user = req.user;
    [err, country] = await to(Country.create({
        'code'  : code,
        'name' : name,
        'created' : Sequelize.fn('NOW')
    }));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422'
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : country,
        'result' : '201',
        'actor' : user.id
    }));
    return ReS(res, {'message':'successfully created new country', 
                    'country': country.toWeb(),
                    'log' : log}, 201);
};

/**
* @api {put} /countries/:id Update Country
* @apiName UpdateCountryByID
* @apiGroup Country
*
* @apiParam {String} id Country unique ID.
* @apiParam (Body Params) {String} code code of the Country
* @apiParam (Body Params) {String} name name of the Country
*
* @apiSuccess {String} id Country ID.
* @apiSuccess {String} code  Code of the Country.
* @apiSuccess {String} name  Name of the Country.
* @apiSuccess {Timestamp} created  Date and Time the Country is created.
* @apiSuccess {Timestamp} updated  Date and Time the Country is updated.
* @apiSuccess {Timestamp} deleted  Date and Time the Country is deleted.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
        "country": {
            "id": "2fca2d08-a11b-4ad2-bc2d-79d4a4e6c796",
            "code": "UK",
            "name": "United Kingdom",
            "created": "2018-07-10T07:17:39.000Z",
            "updated": "2018-07-10T07:25:56.000Z",
            "deleted": null
        },
        "message": "update country: 2fca2d08-a11b-4ad2-bc2d-79d4a4e6c796"
    }
*
*/

const update = async (req, res) => {
     ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let country;
    const id = req.params.id;
    let user = req.user;
    const {
        code,
        name
    } = req.body;
    [err, country] = await to(Country.update({
        'code'  : code,
        'name' : name,
        updated : Sequelize.fn('NOW')
        }, {
            'where': {
                'id': id
            }
        }
    ));
    [err, country] = await to(Country.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : country,
        'result' : '201',
        'actor' : user.id
    }));
    return ReS(res, {'country': country.toWeb(), 
                    'message': 'update country: ' + id,
                    'log' : log});
};

/**
* @api {post} /countries/:id/deactivate Deactivate Country
* @apiName DeactivateCountry
* @apiGroup Country
*
* @apiParam {String} id Country unique ID.
*
* @apiSuccess {String} id Country ID.
* @apiSuccess {String} code  Code of the Country.
* @apiSuccess {String} name  Name of the Country.
* @apiSuccess {Timestamp} created  Date and Time the Country is created.
* @apiSuccess {Timestamp} updated  Date and Time the Country is updated.
* @apiSuccess {Timestamp} deleted  Date and Time the Country is deleted.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
        "country": {
            "id": "2fca2d08-a11b-4ad2-bc2d-79d4a4e6c796",
            "code": "UK",
            "name": "United Kingdom",
            "created": "2018-07-10T07:17:39.000Z",
            "updated": "2018-07-10T07:25:56.000Z",
            "deleted": "2018-07-10T07:30:28.000Z"
        },
        "message": "deactivated country: 2fca2d08-a11b-4ad2-bc2d-79d4a4e6c796"
    }
*
*/

const deactivate = async (req, res) => {
     ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let country;
    let user = req.user;
    const id = req.params.id;
    [err, country] = await to(Country.update({
            deleted : Sequelize.fn('NOW')
        },
        {
            'where': {
                'id': id
            }
        }
    ));
    [err, country] = await to(Country.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : country,
        'result' : '201',
        'actor' : user.id
    }));
    return ReS(res, {'country' : country.toWeb(), 
                    'message' : 'deactivated country: ' + id,
                    'log' : log});
};

/**
* @api {post} /countries/:id/reactivate Reactivate Country
* @apiName ReactivateCountry
* @apiGroup Country
*
* @apiParam {String} id Country unique ID.
*
* @apiSuccess {String} id Country ID.
* @apiSuccess {String} code  Code of the Country.
* @apiSuccess {String} name  Name of the Country.
* @apiSuccess {Timestamp} created  Date and Time the Country is created.
* @apiSuccess {Timestamp} updated  Date and Time the Country is updated.
* @apiSuccess {Timestamp} deleted  Date and Time the Country is deleted.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
        "country": {
            "id": "2fca2d08-a11b-4ad2-bc2d-79d4a4e6c796",
            "code": "UK",
            "name": "United Kingdom",
            "created": "2018-07-10T07:17:39.000Z",
            "updated": "2018-07-10T07:25:56.000Z",
            "deleted": null
        },
        "message": "reactivated country: 2fca2d08-a11b-4ad2-bc2d-79d4a4e6c796"
    }
*
*/

const reactivate = async (req, res) => {
     ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let country;
    const id = req.params.id;
    let user = req.user;
    [err, country] = await to(Country.update({
            deleted : null
        },
        {
            'where': {
                'id': id
            }
        }
    ));
    [err, country] = await to(Country.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : country,
        'result' : '201',
        'actor' : user.id
    }));
    return ReS(res, {'country' : country.toWeb(), 
                    'message' : 'reactivated country: ' + id,
                    'log' : log});
};

module.exports = {
    'get'   : get,
    'getOne' : getOne,
    'create' : create,
    'update' : update,
    'deactivate' : deactivate,
    'reactivate' : reactivate,
    'search' : search
}