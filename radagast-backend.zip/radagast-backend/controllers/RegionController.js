const Region  = require('./../models').region;
const Country = require('./../models').country;
const Log = require('./../models').log;
const Sequelize = require('sequelize');
const Op = Sequelize.Op;
const Authorized = require('./../models').authorized;
const authService   = require('./../services/AuthService');

/**
* @api {get} /regions Retrieve Regions
* @apiName GetRegions
* @apiGroup Region
*
* @apiSuccess {String} id Region ID.
* @apiSuccess {String} code  Code of the Region.
* @apiSuccess {String} name  Name of the Region.
* @apiSuccess {Timestamp} created  Date and Time the Region is created.
* @apiSuccess {Timestamp} updated  Date and Time the Region is updated.
* @apiSuccess {Timestamp} deleted  Date and Time the Region is deleted.
* @apiSuccess {String} country_id  Country ID referenced from Country.
* @apiSuccess {String} country_id.id  Country ID.
* @apiSuccess {String} country_id.code  Code of the Country.
* @apiSuccess {String} country_id.name  Code of the Country.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
        "regions": [
            {
                "id": "b157ed7b-1060-4a35-ae24-67aa0a14e20f",
                "code": "NCR",
                "name": "National Capital Region",
                "created": "2018-07-09T01:58:49.000Z",
                "updated": null,
                "deleted": null,
                "country_id": "406405a2-8255-48d0-86c6-7f1109d10e30",
                "country": {
                    "id": "406405a2-8255-48d0-86c6-7f1109d10e30",
                    "code": "PH",
                    "name": "Philippines"
                }
            }
        ],
        "success": true
    }
*
*/

const get = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    [err, region] = await to(Region.findAll({
        include: [{
            model: Country,
            attributes: ['id', 'code', 'name'],
            required: true
        }]
    }));
    return ReS(res, {'regions': region});
};

/**
* @api {get} /regions/:id Retrieve Region By ID
* @apiName GetRegionByID
* @apiGroup Region
*
* @apiParam {String} id Region unique ID.
*
* @apiSuccess {String} id Region ID.
* @apiSuccess {String} code  Code of the Region.
* @apiSuccess {String} name  Name of the Region.
* @apiSuccess {Timestamp} created  Date and Time the Region is created.
* @apiSuccess {Timestamp} updated  Date and Time the Region is updated.
* @apiSuccess {Timestamp} deleted  Date and Time the Region is deleted.
* @apiSuccess {String} country_id  Country ID referenced from Country.
* @apiSuccess {String} country_id.id  Country ID.
* @apiSuccess {String} country_id.code  Code of the Country.
* @apiSuccess {String} country_id.name  Code of the Country.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
        "region": [
            {
                "id": "b157ed7b-1060-4a35-ae24-67aa0a14e20f",
                "code": "NCR",
                "name": "National Capital Region",
                "created": "2018-07-09T01:58:49.000Z",
                "updated": null,
                "deleted": null,
                "country_id": "406405a2-8255-48d0-86c6-7f1109d10e30",
                "country": {
                    "id": "406405a2-8255-48d0-86c6-7f1109d10e30",
                    "code": "PH",
                    "name": "Philippines"
                }
            }
        ],
        "success": true
    }
*
*/

const getOne = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const id = req.params.id;
    [err, region] = await to(Region.find({
            include: [{
                model: Country,
                attributes: ['id', 'code', 'name'],
                required: true
            }],

            'where' : {
                'id' : id
            }
    }));
    return ReS(res, {'region': region});
};

/**
* @api {post} /regions Add Region
* @apiName AddRegion
* @apiGroup Region
*
* @apiParam (System Generated) {String} id Region unique ID.
* @apiParam (Body Params) {String} code Code of the Region.
* @apiParam (Body Params) {String} name Name of the Region.
* @apiParam (Body Params) {String} country_id Country ID.
*
* @apiSuccess {String} id Region ID.
* @apiSuccess {String} code  Code of the Region.
* @apiSuccess {String} name  Name of the Region.
* @apiSuccess {Timestamp} created  Date and Time the Region is created.
* @apiSuccess {Timestamp} updated  Date and Time the Region is updated.
* @apiSuccess {Timestamp} deleted  Date and Time the Region is deleted.
* @apiSuccess {String} country_id  Country ID referenced from Country.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
        "message": "successfully created new region",
        "region": {
            "id": "8c0d476e-ed0b-4e8f-9f6c-fe54ba4d6be4",
            "created": {
                "val": "NOW()"
            },
            "updated": null,
            "deleted": null,
            "country_id": "cb86f578-06b9-4298-9256-1a5552854435",
            "code": "NCR",
            "name": "National Capital Region"
        }
    }
*
*/

const create = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    const {
        country_id,
        code,
        name
    } = req.body;
    let region;
    [err, region] = await to(Region.create({
        'country_id' : country_id,
        'code'  : code,
        'name' : name
    }));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : region,
        'result' : '201',
        'actor' : req.user.id
    }));
    return ReS(res, {'message':'successfully created new region', 
                    'region': region.toWeb(),
                    'log' : log}, 201);
};

/**
* @api {put} /regions/:id Update Region
* @apiName UpdateRegionByID
* @apiGroup Region
*
* @apiParam {String} id Region unique ID.
* @apiParam (Body Params) {String} code code of the Country.
* @apiParam (Body Params) {String} name name of the Country.
* @apiParam (Body Params) {String} country_id Country ID.
*
* @apiSuccess {String} id Region ID.
* @apiSuccess {String} code  Code of the Region.
* @apiSuccess {String} name  Name of the Region.
* @apiSuccess {Timestamp} created  Date and Time the Region is created.
* @apiSuccess {Timestamp} updated  Date and Time the Region is updated.
* @apiSuccess {Timestamp} deleted  Date and Time the Region is deleted.
* @apiSuccess {String} country_id  Country ID referenced from Country.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
       "region": {
            "id": "8c0d476e-ed0b-4e8f-9f6c-fe54ba4d6be4",
            "code": "CAL",
            "name": "Calabarzon",
            "created": "2018-07-10T08:09:27.000Z",
            "updated": "2018-07-10T08:14:29.000Z",
            "deleted": null,
            "country_id": "cb86f578-06b9-4298-9256-1a5552854435"
        },
        "message": "updated region: 8c0d476e-ed0b-4e8f-9f6c-fe54ba4d6be4"
    }
*
*/

const update = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let region;
    const id = req.params.id;
    const {
    	country_id,
        code,
        name
    } = req.body;
    [err, region] = await to(Region.update({
    	'country_id' : country_id,
        'code'  : code,
        'name' : name,
        updated : Sequelize.fn('NOW')
        }, {
            'where': {
                'id': id
            }
        }
    ));
    [err, region] = await to(Region.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : region,
        'result' : '201',
        'actor' : req.user.id
    }));
    return ReS(res, {'region': region.toWeb(), 
                    'message': 'update region: ' + id,
                    'log' : log});
};

/**
* @api {post} /regions/:id/deactivate Deactivate Region
* @apiName DeactivateRegion
* @apiGroup Region
*
* @apiParam {String} id Region unique ID.
*
* @apiSuccess {String} id Region ID.
* @apiSuccess {String} code  Code of the Region.
* @apiSuccess {String} name  Name of the Region.
* @apiSuccess {Timestamp} created  Date and Time the Region is created.
* @apiSuccess {Timestamp} updated  Date and Time the Region is updated.
* @apiSuccess {Timestamp} deleted  Date and Time the Region is deleted.
* @apiSuccess {String} country_id  Country ID referenced from Country.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
       "region": {
            "id": "8c0d476e-ed0b-4e8f-9f6c-fe54ba4d6be4",
            "code": "CAL",
            "name": "Calabarzon",
            "created": "2018-07-10T08:09:27.000Z",
            "updated": "2018-07-10T08:14:29.000Z",
            "deleted": "2018-07-10T08:18:19.000Z",
            "country_id": "cb86f578-06b9-4298-9256-1a5552854435"
        },
        "message": "deactivated region: 8c0d476e-ed0b-4e8f-9f6c-fe54ba4d6be4"
    }
*
*/

const deactivate = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let region;
    const id = req.params.id;
    [err, region] = await to(Region.update({
            deleted : Sequelize.fn('NOW')
        },
        {
            'where': {
                'id': id
            }
        }
    ));
    [err, region] = await to(Region.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422'
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : region,
        'result' : '201'
    }));
    return ReS(res, {'region' : region.toWeb(), 
                    'message' : 'deactivated region: ' + id,
                    'log' : log});
};

/**
* @api {post} /regions/:id/reactivate Reactivate Region
* @apiName ReactivateRegion
* @apiGroup Region
*
* @apiParam {String} id Region unique ID.
*
* @apiSuccess {String} id Region ID.
* @apiSuccess {String} code  Code of the Region.
* @apiSuccess {String} name  Name of the Region.
* @apiSuccess {Timestamp} created  Date and Time the Region is created.
* @apiSuccess {Timestamp} updated  Date and Time the Region is updated.
* @apiSuccess {Timestamp} deleted  Date and Time the Region is deleted.
* @apiSuccess {String} country_id  Country ID referenced from Country.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
       
        "region": {
            "id": "8c0d476e-ed0b-4e8f-9f6c-fe54ba4d6be4",
            "code": "CAL",
            "name": "Calabarzon",
            "created": "2018-07-10T08:09:27.000Z",
            "updated": "2018-07-10T08:14:29.000Z",
            "deleted": null,
            "country_id": "cb86f578-06b9-4298-9256-1a5552854435"
        },
        "message": "reactivated region: 8c0d476e-ed0b-4e8f-9f6c-fe54ba4d6be4"
    }
*
*/

const reactivate = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let region;
    const id = req.params.id;
    [err, region] = await to(Region.update({
            deleted : null
        },
        {
            'where': {
                'id': id
            }
        }
    ));
    [err, region] = await to(Region.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : region,
        'result' : '201',
        'actor' : req.user.id
    }));
    return ReS(res, {'region' : region.toWeb(), 
                    'message' : 'reactivated region: ' + id,
                    'log' : log});
};

/**
* @api {get} /regions/search Search Region
* @apiName SearchRegion
* @apiGroup Region
*
* @apiParam (Query Params) {String} code code of the Region
* @apiParam (Query Params) {String} name name of the Region
* @apiParam (Query Params) {Timestamp} created Date and Time the Region is created.
* @apiParam (Query Params) {Timestamp} updated Date and Time the Region is updated.
* @apiParam (Query Params) {Timestamp} deleted Date and Time the Region is deleted.
* @apiParam (Query Params) {String} country_id Country ID.
*
* @apiSuccess {String} id Region ID.
* @apiSuccess {String} code  Code of the Region.
* @apiSuccess {String} name  Name of the Region.
* @apiSuccess {Timestamp} created  Date and Time the Region is created.
* @apiSuccess {Timestamp} updated  Date and Time the Region is updated.
* @apiSuccess {Timestamp} deleted  Date and Time the Region is deleted.
* @apiSuccess {String} country_id  Country ID referenced from Country.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
       "regions": [
            {
                "id": "8c0d476e-ed0b-4e8f-9f6c-fe54ba4d6be4",
                "code": "CAL",
                "name": "Calabarzon",
                "created": "2018-07-10T08:09:27.000Z",
                "updated": "2018-07-10T08:14:29.000Z",
                "deleted": null,
                "country_id": "cb86f578-06b9-4298-9256-1a5552854435"
            }
        ],
        "success": true
    }
*
*/

const search = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const {
        country_id,
        code,
        name,
        created,
        updated,
        deleted
    } = req.query;
    [err, region] = await to(Region.findAll({
            include: [{
               model: Country,
                attributes: ['id', 'code', 'name'],
                required: true
            }],

            where: {
                [Op.or]: [{'country_id': country_id}, 
                        {'code': code}, 
                        {'name': name}, 
                        {'created': created},
                        {'updated': updated}, 
                        {'deleted': deleted}]
            }
    }));
    return ReS(res, {'regions': region});
};

module.exports = {
    'get'   : get,
    'getOne' : getOne,
    'create' : create,
    'update' : update,
    'deactivate' : deactivate,
    'reactivate' : reactivate,
    'search' : search
}