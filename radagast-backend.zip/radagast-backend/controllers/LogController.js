const Log   = require('./../models').log;

/**
 * @api {get} /logs getLogs
 * @apiGroup Log
 * @apiName getLogs
 *
 * @apiSuccess {UUID} id ID of log
 * @apiSuccess {String} actor actor of the event
 * @apiSuccess {String} route route of the event
 * @apiSuccess {String} body body of the event
 * @apiSuccess {String} result result of the event
 * @apiSuccess {Timestamp} created Date and Time the log is created.
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *    "logs": [
 *        {
 *            "id": "0e6b2193-8ef1-4d5b-b4e6-c6bd249dfb2e",
 *            "actor": "1",
 *            "route": "/zone-barangays",
 *            "body": {
 *                "id": "258b59b7-7907-4d7e-a3bf-961bbdb97a3a",
 *                "created": {
 *                    "val": "NOW()"
 *                },
 *                "zone_id": "2c933419-6a70-4139-b399-7930ad72ee10",
 *                "barangay_id": "89fc14b8-d853-4cb2-9f66-4cc8c08fc767"
 *            },
 *            "result": "201",
 *            "created": "2018-07-12T03:20:34.000Z"
 *        },
 *        {
 *            "id": "0e871986-5a9b-4abe-bd52-989abd04a5d0",
 *            "actor": "1",
 *            "route": "/users/1",
 *            "body": {
 *                "id": 1,
 *                "email": "kzarzoso@gmail.com",
 *                "created": "2018-07-11T08:22:25.000Z",
 *                "deleted": null,
 *                "updated": null,
 *                "password": "$2b$10$Ncvq8cVr15.TE1alWaOcWe13.Bip4wJLSdjWN43z05jC7vqb.xxyq",
 *                "createdAt": "2018-07-11T08:22:25.000Z",
 *                "last_name": "Zarzoso",
 *                "updatedAt": "2018-07-12T01:21:13.742Z",
 *                "first_name": "Kiara",
 *                "middle_name": "Calbera",
 *                "contact_number": "09168650222"
 *            },
 *            "result": "201",
 *            "created": "2018-07-12T01:21:13.000Z"
 *        }
 *      ],
 *      "success": true
 *  }   
 *
 */

const get = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    let err, logs;
    [err, logs] = await to(Log.findAll());
    return ReS(res, {'logs' : logs});
}

/**
 * @api {getOne} /logs/:id getOneLog
 * @apiGroup Log
 * @apiName getOneLog
 *
 * @apiSuccess {UUID} id ID of log
 * @apiSuccess {String} actor actor of the event
 * @apiSuccess {String} route route of the event
 * @apiSuccess {String} body body of the event
 * @apiSuccess {String} result result of the event
 * @apiSuccess {Timestamp} created Date and Time the log is created.
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *    "log": 
 *        {
 *            "id": "0e6b2193-8ef1-4d5b-b4e6-c6bd249dfb2e",
 *            "actor": "1",
 *            "route": "/zone-barangays",
 *            "body": {
 *                "id": "258b59b7-7907-4d7e-a3bf-961bbdb97a3a",
 *                "created": {
 *                    "val": "NOW()"
 *                },
 *                "zone_id": "2c933419-6a70-4139-b399-7930ad72ee10",
 *                "barangay_id": "89fc14b8-d853-4cb2-9f66-4cc8c08fc767"
 *            },
 *            "result": "201",
 *            "created": "2018-07-12T03:20:34.000Z"
 *        },
 *      "success": true
 *  }   
 *
 */
const getOne = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const id = req.params.id;
    let err, log;
    [err, log] = await to(Log.findById(id));
    return ReS(res, {'log' : log});
}

/**
 * @api {post} /logs addLog
 * @apiGroup Log
 * @apiName addLog
 *
 * @apiParam (Body Params) {String} actor actor of the event
 * @apiParam (Body Params) {String} route route of the event
 * @apiParam (Body Params) {String} body body of the event
 * @apiParam (Body Params) {String} result result of the event
 * 
 * @apiSuccess {UUID} id ID of log
 * @apiSuccess {String} actor actor of the event
 * @apiSuccess {String} route route of the event
 * @apiSuccess {String} body body of the event
 * @apiSuccess {String} result result of the event
 * @apiSuccess {Timestamp} created Date and Time the log is created.
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *    "logs": [
 *        {
 *            "id": "0e6b2193-8ef1-4d5b-b4e6-c6bd249dfb2e",
 *            "actor": "1",
 *            "route": "/zone-barangays",
 *            "body": {
 *                "id": "258b59b7-7907-4d7e-a3bf-961bbdb97a3a",
 *                "created": {
 *                    "val": "NOW()"
 *                },
 *                "zone_id": "2c933419-6a70-4139-b399-7930ad72ee10",
 *                "barangay_id": "89fc14b8-d853-4cb2-9f66-4cc8c08fc767"
 *            },
 *            "result": "201",
 *            "created": "2018-07-12T03:20:34.000Z"
 *        },
 *        {
 *            "id": "0e871986-5a9b-4abe-bd52-989abd04a5d0",
 *            "actor": "1",
 *            "route": "/users/1",
 *            "body": {
 *                "id": 1,
 *                "email": "kzarzoso@gmail.com",
 *                "created": "2018-07-11T08:22:25.000Z",
 *                "deleted": null,
 *                "updated": null,
 *                "password": "$2b$10$Ncvq8cVr15.TE1alWaOcWe13.Bip4wJLSdjWN43z05jC7vqb.xxyq",
 *                "createdAt": "2018-07-11T08:22:25.000Z",
 *                "last_name": "Zarzoso",
 *                "updatedAt": "2018-07-12T01:21:13.742Z",
 *                "first_name": "Kiara",
 *                "middle_name": "Calbera",
 *                "contact_number": "09168650222"
 *            },
 *            "result": "201",
 *            "created": "2018-07-12T01:21:13.000Z"
 *        }
 *      ],
 *      "success": true
 *  }   
 *
 */


module.exports = {
    'get' : get,
    'getOne' : getOne
}