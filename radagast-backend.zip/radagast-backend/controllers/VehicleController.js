const Vehicle   = require('./../models').vehicle;
const Authorized = require('./../models').authorized;
const authService   = require('./../services/AuthService');
const Log = require('./../models').log;
const Sequelize = require('sequelize');
const Op = Sequelize.Op;

/**
* @api {get} /v1/vehicles Get Vehicles
* @apiGroup Vehicle
* @apiName Get Vehicles
*
* @apiSuccess {Object[]} vehicles array of vehicles
* @apiSuccess {UUID} vehicles.id ID of vehicle
* @apiSuccess {String} vehicles.code code of vehicle
* @apiSuccess {String} vehicles.name name of vehicle
* @apiSuccess {String} vehicles.address address of vehicle
* @apiSuccess {char} vehicles.country country
* @apiSuccess {char} vehicles.region region
* @apiSuccess {char} vehicles.province province
* @apiSuccess {char} vehicles.district district
* @apiSuccess {char} vehicles.sub_district sub_district
* @apiSuccess {Timestamp} vehicles.created timestamp of creation
* @apiSuccess {Timestamp} vehicles.updated timestamp when updated
* @apiSuccess {Timestamp} vehicles.deleted timestamp of deletion
*
* @apiSuccessExample {json} Success-Response:
*{
*    "vehicles": [
*        {
*            "id": "ed7b7aa2-aa55-4486-bcb7-725b9c558bd3",
*            "plate_number": "TRX 1221",
*            "type": "truck",
*            "model": "Nissan Navara",
*            "created": "2018-07-11T02:59:39.000Z",
*            "updated": null,
*            "deleted": null
*        },
*        {
*            "id": "fe4a9a8e-4454-4b7b-b855-ba785efa0c04",
*            "plate_number": "LTO 1234",
*            "type": "motorcycle",
*            "model": "Honda Wave",
*            "created": "2018-07-11T02:56:29.000Z",
*            "updated": null,
*            "deleted": null
*        }
*    ],
*    "success": true
*}
* @apiError (Error 422) {Number} status status code
* @apiError (Error 422) {String} message Error message
*/

const get = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    [err, vehicle] = await to(Vehicle.findAll());
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422'
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : vehicle,
        'result' : '201'
    }));
    return ReS(res, {'vehicles': vehicle,
                    'log' : log});
};
 /**
* @api {get} /v1/vehicles/:id Get Vehicle by ID
* @apiGroup Vehicle
* @apiName Get Vehicle by ID
* @apiParam {UUID} id Vehicle's unique ID.
*
* @apiSuccess {Object} vehicle new vehicle
* @apiSuccess {UUID} vehicle.id ID of vehicle
* @apiSuccess {String} vehicle.code code of vehicle
* @apiSuccess {String} vehicle.name name of vehicle
* @apiSuccess {String} vehicle.address address of vehicle
* @apiSuccess {char} vehicle.country country
* @apiSuccess {char} vehicle.region region
* @apiSuccess {char} vehicle.province province
* @apiSuccess {char} vehicle.district district
* @apiSuccess {char} vehicle.sub_district sub_district
* @apiSuccess {Timestamp} vehicle.created timestamp of creation
* @apiSuccess {Timestamp} vehicle.updated timestamp when updated
* @apiSuccess {Timestamp} vehicle.deleted timestamp of deletion
* @apiSuccessExample {json} Success-Response:
*   {
*      "vehicle": {
*        "id": "ed7b7aa2-aa55-4486-bcb7-725b9c558bd3",
*        "plate_number": "TRX 1221",
*        "type": "truck",
*        "model": "Nissan Navara",
*       "created": "2018-07-11T02:59:39.000Z",
*       "updated": null,
*        "deleted": null
*    }
*       "success": true
*   }
* @apiError (Error 422) {Number} status status code
* @apiError (Error 422) {String} message Error message
*/
const getOne = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const id = req.params.id;
    [err, vehicle] = await to(Vehicle.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422'
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : vehicle,
        'result' : '201'
    }));
    return ReS(res, {'vehicle': vehicle,
                    'log' : log});
};

/**
* @api {post} /v1/vehicles Add Vehicle
* @apiGroup Vehicle
* @apiName Add Vehicle
*
* @apiParam (System Generated) {UUID} id unique ID  
* @apiParam (Body Params) {String} plate_number plate number of vehicle
* @apiParam (Body Params) {String} type type of vehicle
* @apiParam (Body Params) {String} model model of vehicle
*
* @apiSuccess {Object} vehicle new vehicle
* @apiSuccess {UUID} vehicle.id ID of vehicle
* @apiSuccess {String} vehicle.code code of vehicle
* @apiSuccess {String} vehicle.name name of vehicle
* @apiSuccess {String} vehicle.address address of vehicle
* @apiSuccess {char} vehicle.country country
* @apiSuccess {char} vehicle.region region
* @apiSuccess {char} vehicle.province province
* @apiSuccess {char} vehicle.district district
* @apiSuccess {char} vehicle.sub_district sub_district
* @apiSuccess {Timestamp} vehicle.created timestamp of creation
* @apiSuccess {Timestamp} vehicle.updated timestamp when updated
* @apiSuccess {Timestamp} vehicle.deleted timestamp of deletion
* @apiSuccessExample {json} Success-Response:
*   {
*       "message": "successfully created new vehicle",
*       "vehicle": {
*           "id": "fe4a9a8e-4454-4b7b-b855-ba785efa0c04",
*           "created": {
*               "val": "NOW()"
*           },
*           "updated": null,
*           "deleted": null,
*           "plate_number": "LTO 1234",
*           "type": "motorcycle",
*           "model": "Honda Wave"
*       },
*       "success": true
*   }
* @apiError (Error 422) {Number} status status code
* @apiError (Error 422) {String} message Error message
*/


const create = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    const {
        plate_number,
        type,
        model
    } = req.body;
    let  vehicle;
    [err, vehicle] = await to(Vehicle.create({
        'plate_number':plate_number,
        'type':type,
        'model': model
    }));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
           'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : vehicle,
        'result' : '201',
       'actor' : req.user.id
    }));
    return ReS(res, {'message':'successfully created new vehicle', 
                    'vehicle': vehicle.toWeb(),
                    'log' : log}, 201);
};
/**
* @api {put} /v1/vehicles/:id Update Port by ID
* @apiName Update Port by ID
* @apiGroup Port
* @apiParam {UUID} id Port's unique ID.
*
* @apiParam (Body Params) {String} plate_number plate number of vehicle
* @apiParam (Body Params) {String} type type of vehicle
* @apiParam (Body Params) {String} model model of vehicle
*
* @apiSuccess {Object} vehicle new vehicle
* @apiSuccess {UUID} vehicle.id ID of vehicle
* @apiSuccess {String} vehicle.code code of vehicle
* @apiSuccess {String} vehicle.name name of vehicle
* @apiSuccess {String} vehicle.address address of vehicle
* @apiSuccess {char} vehicle.country country
* @apiSuccess {char} vehicle.region region
* @apiSuccess {char} vehicle.province province
* @apiSuccess {char} vehicle.district district
* @apiSuccess {char} vehicle.sub_district sub_district
* @apiSuccess {Timestamp} vehicle.created timestamp of creation
* @apiSuccess {Timestamp} vehicle.updated timestamp when updated
* @apiSuccess {Timestamp} vehicle.deleted timestamp of deletion
* @apiSuccessExample {json} Success-Response:
*   {
*       "vehicle": {
*           "id": "ed7b7aa2-aa55-4486-bcb7-725b9c558bd3",
*           "plate_number": "TRX 1221",
*           "type": "truck",
*           "model": "Nissan Navara",
*           "created": "2018-07-11T02:59:39.000Z",
*           "updated": null,
*           "deleted": null
*       },
*       "message": "update vehicle: ed7b7aa2-aa55-4486-bcb7-725b9c558bd3",
*       "success": true
*   }
* @apiError (Error 422) {Number} status status code
* @apiError (Error 422) {String} message Error message
*/

const update = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    let vehicle;
    const id = req.params.id;
    const {
        plate_number,
        type,
        model
    } = req.body;
    [err, vehicle] = await to(Vehicle.update({
        'plate_number':plate_number,
        'type': type,
        'model': model,
        updated : Sequelize.fn('NOW')
        }, {
            'where': {
                'id': id
            }
        }
    ));
    [err, vehicle] = await to(Vehicle.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
           'actor' : req.user.id
        }));
        return ReE(res, err);
    }
    [err, vehicle] = await to(Vehicle.findById(id));
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : vehicle,
        'result' : '201',
       'actor' : req.user.id
    }));
    return ReS(res, {'vehicle': vehicle.toWeb(), 'message': 'update vehicle: ' + id, 'log' : log});
};
/**
* @api {get} /v1/ports/search Search Vehicle
* @apiName  Search Vehicle
* @apiGroup Vehicle
*
* @apiParam (Parameter) {UUID} id unique ID  
* @apiParam (Parameter) {String} plate_number plate number of vehicle
* @apiParam (Parameter) {String} type type of vehicle
* @apiParam (Parameter) {String} model model of vehicle
*
* @apiSuccess {Object[]} vehicles array of vehicles
* @apiSuccess {UUID} vehicles.id ID of vehicle
* @apiSuccess {String} vehicles.plate_number plate_number of vehicle
* @apiSuccess {String} vehicles.type type of vehicle
* @apiSuccess {String} vehicles.model model of vehicle
* @apiSuccess {Timestamp} vehicles.created timestamp of creation
* @apiSuccess {Timestamp} vehicles.updated timestamp when updated
* @apiSuccess {Timestamp} vehicles.deleted timestamp of deletion
* @apiSuccessExample {json} Success-Response:
{
    "vehicle": [
        {
            "id": "05778e25-498a-4738-96ac-243f7b7f27f9",
            "plate_number": "PPG 1221",
            "type": "truck",
            "model": "Nissan Navara",
            "created": "2018-07-12T06:33:17.000Z",
            "updated": null,
            "deleted": null
        }
    ],
    "success": true
}
* @apiError (Error 422) {Number} status status code
* @apiError (Error 422) {String} message Error message
*/
const search = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    const {
        id,
        plate_number,
        type,
        model,
        created,
        updated,
        deleted
    } = req.query;

    [err, vehicle] = await to(Vehicle.findAll({
            where: {
                [Op.or]: [{'id': id}, {'plate_number':plate_number},{'type': type}, {'model': model}, 
               {'created': created}, {'updated': updated}, {'deleted': deleted}]
            }
    }));
    if(err){
        return ReE(res, err, 422);
    }
    return ReS(res, {'vehicle': vehicle});
};

/**
* @api {post} /v1/vehicles/:id/deactivate Deactivate Vehicle by ID
* @apiName Deactivate Vehicle by ID
* @apiGroup Vehicle
* @apiParam {UUID} id Vehicle's unique ID.
*
* @apiSuccess {Object} vehicle new vehicle
* @apiSuccess {UUID} vehicle.id ID of vehicle
* @apiSuccess {String} vehicle.code code of vehicle
* @apiSuccess {String} vehicle.name name of vehicle
* @apiSuccess {String} vehicle.address address of vehicle
* @apiSuccess {char} vehicle.country country
* @apiSuccess {char} vehicle.region region
* @apiSuccess {char} vehicle.province province
* @apiSuccess {char} vehicle.district district
* @apiSuccess {char} vehicle.sub_district sub_district
* @apiSuccess {Timestamp} vehicle.created timestamp of creation
* @apiSuccess {Timestamp} vehicle.updated timestamp when updated
* @apiSuccess {Timestamp} vehicle.deleted timestamp of deletion
* @apiSuccessExample {json} Success-Response:
*   {
*       "message": "deactivated vehicle",
*      "vehicle": {
*           "id": "fe4a9a8e-4454-4b7b-b855-ba785efa0c04",
*           "plate_number": "LTO 1234",
*           "type": "motorcycle",
*           "model": "Honda Wave",
*           "created": "2018-07-11T02:56:29.000Z",
*           "updated": null,
*           "deleted": "2018-07-11T03:25:32.000Z"
*       },
*       "success": true
*   }
* @apiError (Error 422) {Number} status status code
* @apiError (Error 422) {String} message Error message
 */
const deactivate = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    let vehicle;
    const id = req.params.id;
    [err, vehicle] = await to(Vehicle.update({
            deleted : Sequelize.fn('NOW')
        },
        {
            'where': {
                'id': id
            }
        }
    ));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, 'error occured while deactivating vehicle');
    }
    [err, vehicle] = await to(Vehicle.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422'
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : vehicle,
        'result' : '201'
    }));
    return ReS(res, {'message': 'deactivated vehicle',
                    'vehicle': vehicle.toWeb(),
                    'log' : log});
};

/**
* @api {post} /v1/vehicles/:id/reactivate Reactivate Vehicle by ID
* @apiName Reactivate Vehicle by ID
* @apiGroup Vehicle
* @apiParam {UUID} id Vehicle's unique ID.
*
* @apiSuccess {Object} vehicle new vehicle
* @apiSuccess {UUID} vehicle.id ID of vehicle
* @apiSuccess {String} vehicle.code code of vehicle
* @apiSuccess {String} vehicle.name name of vehicle
* @apiSuccess {String} vehicle.address address of vehicle
* @apiSuccess {char} vehicle.country country
* @apiSuccess {char} vehicle.region region
* @apiSuccess {char} vehicle.province province
* @apiSuccess {char} vehicle.district district
* @apiSuccess {char} vehicle.sub_district sub_district
* @apiSuccess {Timestamp} vehicle.created timestamp of creation
* @apiSuccess {Timestamp} vehicle.updated timestamp when updated
* @apiSuccess {Timestamp} vehicle.deleted timestamp of deletion
* @apiSuccessExample {json} Success-Response:
*   {
*       "message": "reactivated vehicle",
*       "vehicle": {
*           "id": "fe4a9a8e-4454-4b7b-b855-ba785efa0c04",
*           "plate_number": "LTO 1234",
*           "type": "motorcycle",
*           "model": "Honda Wave",
*           "created": "2018-07-11T02:56:29.000Z",
*           "updated": null,
*           "deleted": null
*       },
*       "success": true
*   }
* @apiError (Error 422) {Number} status status code
* @apiError (Error 422) {String} message Error message
 */
const reactivate = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    let vehicle;
    const id = req.params.id;
    [err, vehicle] = await to(Vehicle.update({
            deleted : null
        },
        {
            'where': {
                'id': id
            }
        }
    ));
    if (err) {
        [err, log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422'
            //'actor' : req.user.id
        }));
        return ReE(res, 'error occured while reactivating vehicle');
    }
    [err, vehicle] = await to(Vehicle.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422'
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : vehicle,
        'result' : '201'
    }));
    return ReS(res, {'message': 'reactivated vehicle',
                    'vehicle': vehicle.toWeb(),
                    'log' : log});
};



module.exports = {

    'get'   : get,
    'getOne' : getOne,
    'create' : create,
    'update' : update,
    'search'  : search,
    'deactivate' : deactivate,
    'reactivate' : reactivate
}