const SubDistrict = require('./../models').sub_district;
const District = require('./../models').district;
const Province   = require('./../models').province;
const Region  = require('./../models').region;
const Country = require('./../models').country;
const Barangay = require('./../models').barangay;
const Log = require('./../models').log;
const Sequelize = require('sequelize');
const Op = Sequelize.Op;
const Authorized = require('./../models').authorized;
const authService   = require('./../services/AuthService');

/**
 * @api {post} /barangays addBarangay
 * @apiGroup Barangay
 * @apiName addBarangay
 *
 * @apiParam (System Generated) {UUID} id ID of barangay
 * @apiParam (Body Params) {Character} code code of barangay 
 * @apiParam (Body Params) {String} name name of barangay
 * @apiParam (Body Params) {String} district_id district_id of barangay referenced from district
 * @apiParam (Body Params) {String} sub_district_id sub_district_id of barangay referenced from sub_district
 *
 * @apiSuccess {UUID} id ID of the barangay
 * @apiSuccess {Character} code code of barangay
 * @apiSuccess {String} name name of barangay
 * @apiSuccess {String} district_id district_id of barangay referenced from district
 * @apiSuccess {Timestamp} created Date and Time the barangay is created.
 * @apiSuccess {Timestamp} updated Date and Time the barangay is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the barangay is deleted.
 * @apiSuccess {String} Message Successfully created new barangay
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *      {
 *          "message": "Successfully created new barangay",
 *          "barangay": {
 *              "id": "89fc14b8-d853-4cb2-9f66-4cc8c08fc767",
 *              "created": {
 *                  "val": "NOW()"
 *              },
 *              "district_id": "bf6e171c-c292-4626-95dc-b5698c7e281a",
 *              "sub_district_id": "f72dfca7-8258-4ec5-b0f3-d46ceec478a8",
 *              "code": "AN",
 *              "name": "ANOS"
 *          },
 *          "success": true
 *      }
 *
 */

const create = async (req, res) => {
     ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    const {
        district_id,
        sub_district_id,
        code,
        name
    } = req.body;
    let barangay;
    let user = req.user;
    [err, barangay] = await to(Barangay.create({
        'district_id'   : district_id,
        'sub_district_id'   : sub_district_id,
        'code'  : code,
        'name'  : name
    }));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : barangay,
        'result' : '201',
        'actor' : user.id
    }));
    return ReS(res, {'message' : 'Successfully created new barangay',
                    'barangay' : barangay.toWeb(),
                    'log' : log}, 201);
};

/**
 * @api {get} /barangays getBarangays
 * @apiGroup Barangay
 * @apiName getBarangays
 *
 * @apiSuccess {UUID} id ID of the barangay
 * @apiSuccess {Character} code code of barangay
 * @apiSuccess {String} name name of barangay
 * @apiSuccess {String} district_id district_id of barangay referenced from district
 * @apiSuccess {String} code code of district
 * @apiSuccess {String} name name of district
 * @apiSuccess {UUID} id id of sub_district
 * @apiSuccess {String} code code of sub_district
 * @apiSuccess {String} name name of sub_district
 * @apiSuccess {UUID} id id of province
 * @apiSuccess {String} code code of province
 * @apiSuccess {String} name name of province
 * @apiSuccess {UUID} id id of region
 * @apiSuccess {String} code code of region
 * @apiSuccess {String} name name of region
 * @apiSuccess {UUID} id id of country
 * @apiSuccess {String} code code of country
 * @apiSuccess {String} name name of country
 * @apiSuccess {Timestamp} created Date and Time the barangay is created.
 * @apiSuccess {Timestamp} updated Date and Time the barangay is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the barangay is deleted.
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *      "barangays": [
 *          {
 *              "id": "31f39813-9592-433c-ab93-d35de4b69c38",
 *              "code": "BM",
 *              "name": "batong malake",
 *              "created": "2018-07-12T02:23:42.000Z",
 *              "updated": null,
 *              "deleted": null,
 *              "district_id": "bf6e171c-c292-4626-95dc-b5698c7e281a",
 *              "sub_district_id": "f72dfca7-8258-4ec5-b0f3-d46ceec478a8",
 *              "sub_district": {
 *                  "id": "f72dfca7-8258-4ec5-b0f3-d46ceec478a8",
 *                  "code": "LB",
 *                  "name": "Los Banos",
 *                  "district": {
 *                      "id": "bf6e171c-c292-4626-95dc-b5698c7e281a",
 *                      "code": "D2",
 *                      "name": "District2",
 *                      "province": {
 *                          "id": "d9991792-c27a-4639-a7be-66f5e7e8e470",
 *                          "code": "LAG",
 *                          "name": "Laguna",
 *                          "region": {
 *                              "id": "32205cd1-8f91-4c33-90a8-f334df890b15",
 *                              "code": "CAL",
 *                              "name": "CALABARZON",
 *                              "country": {
 *                                  "id": "96055792-1044-472b-b058-b8012019d8a7",
 *                                  "code": "P",
 *                                  "name": "Philippines"
 *                              }
 *                          }
 *                      }
 *                  }
 *              }
 *          },
 *          {
 *              "id": "89fc14b8-d853-4cb2-9f66-4cc8c08fc767",
 *              "code": "AN",
 *              "name": "ANOS",
 *              "created": "2018-07-12T02:23:59.000Z",
 *              "updated": null,
 *              "deleted": null,
 *              "district_id": "bf6e171c-c292-4626-95dc-b5698c7e281a",
 *              "sub_district_id": "f72dfca7-8258-4ec5-b0f3-d46ceec478a8",
 *              "sub_district": {
 *                  "id": "f72dfca7-8258-4ec5-b0f3-d46ceec478a8",
 *                  "code": "LB",
 *                  "name": "Los Banos",
 *                  "district": {
 *                      "id": "bf6e171c-c292-4626-95dc-b5698c7e281a",
 *                      "code": "D2",
 *                      "name": "District2",
 *                      "province": {
 *                          "id": "d9991792-c27a-4639-a7be-66f5e7e8e470",
 *                          "code": "LAG",
 *                          "name": "Laguna",
 *                          "region": {
 *                              "id": "32205cd1-8f91-4c33-90a8-f334df890b15",
 *                              "code": "CAL",
 *                              "name": "CALABARZON",
 *                              "country": {
 *                                  "id": "96055792-1044-472b-b058-b8012019d8a7",
 *                                  "code": "P",
 *                                  "name": "Philippines"
 *                              }
 *                          }
 *                      }
 *                  }
 *              }
 *          }
 *      ],
 *      "success": true
 *  }
 *
 */

const get = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    [err, barangay] = await to(Barangay.findAll({
        include: [{
            model: SubDistrict,
            attributes: ['id', 'code', 'name'],
            required: true,
            include: [{
                    model: District,
                    attributes: ['id', 'code', 'name'],
                    required: true,
                    include: [{
                            model: Province,
                            attributes: ['id', 'code', 'name'],
                            required: true,
                            include: [{
                                model: Region,
                                attributes: ['id', 'code', 'name'],
                                required: true,
                                include: [{
                                    model: Country,
                                    attributes: ['id', 'code', 'name'],
                                    required: true
                                }]
                            }]
                    }]
            }]
        }]
    }));
    return ReS(res, {'barangays' : barangay});
};


/**
 * @api {getOne} /barangays/:id getOneBarangay
 * @apiGroup Barangay
 * @apiName getOneBarangay
 *
 * @apiSuccess {UUID} id ID of the barangay
 * @apiSuccess {Character} code code of barangay
 * @apiSuccess {String} name name of barangay
 * @apiSuccess {String} district_id district_id of barangay referenced from district
 * @apiSuccess {Timestamp} created Date and Time the barangay is created.
 * @apiSuccess {Timestamp} updated Date and Time the barangay is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the barangay is deleted.
 * @apiSuccess {String} code code of district
 * @apiSuccess {String} name name of district
 * @apiSuccess {UUID} id id of sub_district
 * @apiSuccess {String} code code of sub_district
 * @apiSuccess {String} name name of sub_district
 * @apiSuccess {UUID} id id of province
 * @apiSuccess {String} code code of province
 * @apiSuccess {String} name name of province
 * @apiSuccess {UUID} id id of region
 * @apiSuccess {String} code code of region
 * @apiSuccess {String} name name of region
 * @apiSuccess {UUID} id id of country
 * @apiSuccess {String} code code of country
 * @apiSuccess {String} name name of country
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *      {
 *         "barangay": {
 *             "id": "31f39813-9592-433c-ab93-d35de4b69c38",
 *             "code": "BM",
 *             "name": "batong malake",
 *             "created": "2018-07-12T02:23:42.000Z",
 *             "updated": null,
 *             "deleted": null,
 *             "district_id": "bf6e171c-c292-4626-95dc-b5698c7e281a",
 *             "sub_district_id": "f72dfca7-8258-4ec5-b0f3-d46ceec478a8",
 *             "sub_district": {
 *                 "id": "f72dfca7-8258-4ec5-b0f3-d46ceec478a8",
 *                 "code": "LB",
 *                 "name": "Los Banos",
 *                 "district": {
 *                     "id": "bf6e171c-c292-4626-95dc-b5698c7e281a",
 *                     "code": "D2",
 *                     "name": "District2",
 *                     "province": {
 *                         "id": "d9991792-c27a-4639-a7be-66f5e7e8e470",
 *                         "code": "LAG",
 *                         "name": "Laguna",
 *                         "region": {
 *                             "id": "32205cd1-8f91-4c33-90a8-f334df890b15",
 *                             "code": "CAL",
 *                             "name": "CALABARZON",
 *                             "country": {
 *                                 "id": "96055792-1044-472b-b058-b8012019d8a7",
 *                                 "code": "P",
 *                                 "name": "Philippines"
 *                             }
 *                         }
 *                     }
 *                 }
 *             }
 *         },
 *         "success": true
 *      }     
 *
 */

const getOne = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const id = req.params.id;
    [err, barangay] = await to(Barangay.find(
        {
            'where' : {
                'id' : id
            },
            include: [{
                model: SubDistrict,
                attributes: ['id', 'code', 'name'],
                required: true,
                include: [{
                    model: District,
                    attributes: ['id', 'code', 'name'],
                    required: true,
                    include: [{
                        model: Province,
                        attributes: ['id', 'code', 'name'],
                        required: true,
                        include: [{
                            model: Region,
                            attributes: ['id', 'code', 'name'],
                            required: true,
                            include: [{
                                model: Country,
                                attributes: ['id', 'code', 'name'],
                                required: true
                            }]
                        }]
                    }]
                }]
            }]
        }
    ));
    return ReS(res, {'barangay' : barangay.toWeb()});
};

/**
 * @api {put} /barangays/:id updateBarangay
 * @apiGroup Barangay
 * @apiName updateBarangay
 *
 * @apiParam (Body Params) {Character} code code of barangay 
 * @apiParam (Body Params) {String} name name of barangay
 * @apiParam (Body Params) {String} district_id district_id of barangay referenced from district
 * @apiParam (Body Params) {String} sub_district_id sub_district_id of barangay referenced from sub_district
 *
 * @apiSuccess {UUID} id ID of the barangay
 * @apiSuccess {Character} code code of barangay
 * @apiSuccess {String} name name of barangay
 * @apiSuccess {String} district_id district_id of barangay referenced from district
 * @apiSuccess {Timestamp} created Date and Time the barangay is created.
 * @apiSuccess {Timestamp} updated Date and Time the barangay is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the barangay is deleted.
 * @apiSuccess {String} Message update barangay + id
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *  {
 *     "barangay": {
 *         "id": "89fc14b8-d853-4cb2-9f66-4cc8c08fc767",
 *         "code": "MA",
 *         "name": "MAAHAS",
 *         "created": "2018-07-12T02:23:59.000Z",
 *         "updated": "2018-07-12T02:50:41.000Z",
 *         "deleted": null,
 *         "district_id": "bf6e171c-c292-4626-95dc-b5698c7e281a",
 *         "sub_district_id": "f72dfca7-8258-4ec5-b0f3-d46ceec478a8"
 *     },
 *     "message": "update barangay: 89fc14b8-d853-4cb2-9f66-4cc8c08fc767",
 *     "success": true
 *   }
 *
 */

const update = async (req, res) => {
     ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let barangay;
    let user = req.user;
    const id = req.params.id;
    const {
        district_id,
        sub_district_id,
        code,
        name
    } = req.body;
    [err, barangay] = await to(Barangay.update({
        'district_id' : district_id,
        'sub_district_id' : sub_district_id,
        'code' : code,
        'name' : name,
        'updated' : Sequelize.fn('NOW')
    }, 
    {
        'where' : {
            'id' : id
        }
    }));
    [err, barangay] = await to(Barangay.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : barangay,
        'result' : '201',
        'actor' : user.id
    }));
    return ReS(res, {'barangay' : barangay.toWeb(), 
                    'message' : 'update barangay: ' + id,
                    'log' : log});
}

/**
 * @api {deactivate} /barangays/:id/deactivate deactivateBarangay
 * @apiGroup Barangay
 * @apiName deactivateBarangay
 *
 * @apiSuccess {UUID} id ID of the barangay
 * @apiSuccess {Character} code code of barangay
 * @apiSuccess {String} name name of barangay
 * @apiSuccess {String} district_id district_id of barangay referenced from district
 * @apiSuccess {Timestamp} created Date and Time the barangay is created.
 * @apiSuccess {Timestamp} updated Date and Time the barangay is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the barangay is deleted.
 * @apiSuccess {String} Message Deactivated Barangay + id
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *     {
 *         "barangay": {
 *             "id": "89fc14b8-d853-4cb2-9f66-4cc8c08fc767",
 *             "code": "MA",
 *             "name": "MAAHAS",
 *             "created": "2018-07-12T02:23:59.000Z",
 *             "updated": "2018-07-12T02:50:41.000Z",
 *             "deleted": "2018-07-12T02:53:28.000Z",
 *             "district_id": "bf6e171c-c292-4626-95dc-b5698c7e281a",
 *             "sub_district_id": "f72dfca7-8258-4ec5-b0f3-d46ceec478a8"
 *         },
 *         "message": "deactivated barangay: 89fc14b8-d853-4cb2-9f66-4cc8c08fc767",
 *         "success": true
 *     }
 *
 */

const deactivate = async (req, res) => {
     ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let barangay;
    let user = req.user;
    const id = req.params.id;
   
    [err, barangay] = await to(Barangay.update({
        'deleted' : Sequelize.fn('NOW')
    },  {
        'where' : {
            'id' : id
        }
    }));
    [err, barangay] = await to(Barangay.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : barangay,
        'result' : '201',
        'actor' : user.id
    }));
    return ReS(res, {'barangay' : barangay.toWeb(), 
                    'log' : log,
                    'message' : 'deactivated barangay: ' + id});
};

/**
 * @api {reactivate} /barangays/:id/reactivate reactivateBarangay
 * @apiGroup Barangay
 * @apiName reactivateBarangay
 *
 * @apiSuccess {UUID} id ID of the barangay
 * @apiSuccess {Character} code code of barangay
 * @apiSuccess {String} name name of barangay
 * @apiSuccess {String} district_id district_id of barangay referenced from district
 * @apiSuccess {Timestamp} created Date and Time the barangay is created.
 * @apiSuccess {Timestamp} updated Date and Time the barangay is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the barangay is deleted.
 * @apiSuccess {String} Message reactivated barangay + id
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *  {
 *     "barangay": {
 *         "id": "89fc14b8-d853-4cb2-9f66-4cc8c08fc767",
 *         "code": "MA",
 *         "name": "MAAHAS",
 *         "created": "2018-07-12T02:23:59.000Z",
 *         "updated": "2018-07-12T02:50:41.000Z",
 *         "deleted": null,
 *         "district_id": "bf6e171c-c292-4626-95dc-b5698c7e281a",
 *         "sub_district_id": "f72dfca7-8258-4ec5-b0f3-d46ceec478a8"
 *     },
 *     "message": "reactivated barangay: 89fc14b8-d853-4cb2-9f66-4cc8c08fc767",
 *     "success": true
 *  }
 *
 */

const reactivate = async (req, res) => {
     ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let  barangay;
    const id = req.params.id;
    [err, barangay] = await to(Barangay.update({
        'deleted' : null
    },  {
        'where' : {
            'id' : id
        }
    }));
    [err, barangay] = await to(Barangay.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : barangay,
        'result' : '201',
        'actor' : req.user.id
    }));
    return ReS(res, {'barangay' : barangay.toWeb(), 
                    'message' : 'reactivated barangay: ' + id,
                    'log' : log});
};

/**
 * @api {search} /barangays/search searchBarangay
 * @apiGroup Barangay
 * @apiName searchBarangay
 *
 * @apiParam (Query Params) {UUID} ID id of barangay
 * @apiParam (Query Params) {Character} code code of barangay 
 * @apiParam (Query Params) {String} name name of barangay
 * @apiParam (Query Params) {String} district_id district_id of barangay referenced from district
 * @apiParam (Query Params) {String} sub_district_id sub_district_id of barangay referenced from sub_district
 *
 * @apiSuccess {UUID} id ID of the barangay
 * @apiSuccess {Character} code code of barangay
 * @apiSuccess {String} name name of barangay
 * @apiSuccess {String} district_id district_id of barangay referenced from district
 * @apiSuccess {Timestamp} created Date and Time the barangay is created.
 * @apiSuccess {Timestamp} updated Date and Time the barangay is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the barangay is deleted.
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *      "barangays": [
 *          {
 *              "id": "89fc14b8-d853-4cb2-9f66-4cc8c08fc767",
 *              "code": "MA",
 *              "name": "MAAHAS",
 *              "created": "2018-07-12T02:23:59.000Z",
 *              "updated": "2018-07-12T02:50:41.000Z",
 *              "deleted": null,
 *              "district_id": "bf6e171c-c292-4626-95dc-b5698c7e281a",
 *              "sub_district_id": "f72dfca7-8258-4ec5-b0f3-d46ceec478a8"
 *          }
 *      ],
 *      "success": true
 *   }
 *
 */

const search = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const {
        id,
        district_id,
        sub_district_id,
        code,
        name
    } = req.query;
    let err, barangay;
    [err, barangay] = await to(Barangay.findAll({
        where : {
            [Op.or] : 
                [
                    {'id' : id}, 
                    {'district_id' : district_id},
                    {'sub_district_id' : sub_district_id}, 
                    {'code' : code}, 
                    {'name' : name}
                ]
        }
    }));
    return ReS(res, {'barangays' : barangay});
}

module.exports = {
    'create' : create,
    'get'   : get,
    'getOne' : getOne,
    'update' : update,
    'deactivate' : deactivate,
    'reactivate' : reactivate,
    'search' : search
}