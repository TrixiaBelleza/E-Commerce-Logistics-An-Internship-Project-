const AreaManager = require('./../models').area_manager;
const User = require('./../models').User;
const Log = require('./../models').log;
const Sequelize = require('sequelize');
const Op = Sequelize.Op;
const Authorized = require('./../models').authorized;
const authService   = require('./../services/AuthService');

/**
 * @api {post} /area-managers addAreaManager
 * @apiGroup AreaManager
 * @apiName addAreaManager
 *
 * @apiParam (System Generated) {UUID} id ID of area manager 
 * @apiParam (Body Params) {String} hub_id hub_id of area manager referenced from hub
 * @apiParam (Body Params) {String} distribution_center_id distribution_center_id of area manager referenced from distribution_center
 *
 * @apiSuccess {UUID} id ID of the area manager
 * @apiSuccess {String} hub_id hub_id of area manager referenced from hub
 * @apiSuccess {String} distribution_center_id distribution_center_id of area manager referenced from hub
 * @apiSuccess {Timestamp} created Date and Time the Area Manager is created.
 * @apiSuccess {Timestamp} updated Date and Time the Area Manager is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the Area Manager is deleted.
 * @apiSuccess {String} Message Successfully created new area manager
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *  {
 *      "message": "Successfully created new area manager",
 *      "area_manager": {
 *          "id": "d465a5b9-c900-4e9e-a818-714576a54c89",
 *          "created": {
 *              "val": "NOW()"
 *          },
 *          "user_id": "1",
 *          "hub_id": "12b356bd-0877-4b82-9c2a-fc5d26489bd4",
 *          "distribution_center_id": "da6d1764-a3c7-4e58-946a-7ab0fb4bf75c"
 *      },
 *      "success": true
 *  }
 *
 */
const create = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
     ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    const {
        user_id,
        hub_id,
        distribution_center_id
    } = req.body;
    let  area_manager;
    let user = req.user;
    [err, area_manager] = await to(AreaManager.create({
        'user_id' : user_id,
        'hub_id' : hub_id,
        'distribution_center_id' : distribution_center_id
    }));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : area_manager,
        'result' : '201',
        'actor' : user.id
    }));
    return ReS(res, {'message' : 'Successfully created new area manager',
                    'area_manager' : area_manager.toWeb(),
                    'log' : log}, 201);
};

/**
 * @api {get} /area-managers getAreaManagers
 * @apiGroup AreaManager
 * @apiName getAreaManagers
 *
 * @apiSuccess {UUID} id ID of the area manager.
 * @apiSuccess  {String} hub_id hub_id of area manager referenced from hub
 * @apiSuccess {String} distribution_center_id distribution_center_id of area manager referenced from distribution_center
 * @apiSuccess {Timestamp} created Date and Time the Area Manager is created.
 * @apiSuccess {Timestamp} updated Date and Time the Area Manager is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the Area Manager is deleted.
 * @apiSuccess {UUID} id ID of area manager as user.
 * @apiSuccess {String} email Email of area manager.
 * @apiSuccess {String} first_name First Name of area manager.
 * @apiSuccess {String} last_name Last Name of area manager.
 * @apiSuccess {String} middle_name Middle Name of area manager.
 * @apiSuccess {String} contact_number Contact Number of area manager.
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *      {
 *         "area_managers": [
 *             {
 *                 "id": "4dc6abda-b9af-44eb-8805-39aa5ce6b283",
 *                 "hub_id": "797439a8-d074-46a3-bfb8-50e6af677857",
 *                 "distribution_center_id": null,
 *                 "created": "2018-07-12T00:48:36.000Z",
 *                 "updated": null,
 *                 "deleted": null,
 *                 "user_id": 1,
 *                 "User": {
 *                     "id": 1,
 *                     "email": "kzarzoso@gmail.com",
 *                     "first_name": "Kiara",
 *                     "last_name": "Zarzoso",
 *                     "middle_name": "Calbera",
 *                     "contact_number": "09168650222"
 *                 }
 *             },
 *             {
 *                 "id": "5f7a8260-529a-41c3-8e7e-30a998d29b9b",
 *                 "hub_id": "797439a8-d074-46a3-bfb8-50e6af677857",
 *                 "distribution_center_id": "e6cb457e-653a-44e6-87d9-7eeab7c8448c",
 *                 "created": "2018-07-12T01:10:16.000Z",
 *                 "updated": null,
 *                 "deleted": null,
 *                 "user_id": 2,
 *                 "User": {
 *                     "id": 2,
 *                     "email": "ahabulan@gmail.com",
 *                     "first_name": "Aljay",
 *                     "last_name": "Habulan",
 *                     "middle_name": "Ranchez",
 *                     "contact_number": "09271238752"
 *                 }
 *             }
 *         ],
 *         "success": true
 *      }
 *
 */
const get = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    [err, area_manager] = await to(AreaManager.findAll({
        include: [{
            model: User,
            attributes: ['id', 'email', 'first_name', 'last_name', 'middle_name', 'contact_number'],
            required: true
        }]
    }));
    return ReS(res, {'area_managers' : area_manager}, 201);
};

/**
 * @api {getOne} /area-managers/:id getOneAreaManager
 * @apiGroup AreaManager
 * @apiName getAreaManager
 *
 * @apiSuccess {UUID} id ID of the area manager.
 * @apiSuccess {String} hub_id hub_id of area manager referenced from hub
 * @apiSuccess {String} distribution_center_id distribution_center_id of area manager referenced from distribution_center
 * @apiSuccess {Timestamp} created Date and Time the Area Manager is created.
 * @apiSuccess {Timestamp} updated Date and Time the Area Manager is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the Area Manager is deleted.
 * @apiSuccess {UUID} id ID of area manager as user.
 * @apiSuccess {String} email Email of area manager.
 * @apiSuccess {String} first_name First Name of area manager.
 * @apiSuccess {String} last_name Last Name of area manager.
 * @apiSuccess {String} middle_name Middle Name of area manager.
 * @apiSuccess {String} contact_number Contact Number of area manager.
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *      {
 *         "area_manager": {
 *             "id": "4dc6abda-b9af-44eb-8805-39aa5ce6b283",
 *             "hub_id": "797439a8-d074-46a3-bfb8-50e6af677857",
 *             "distribution_center_id": null,
 *             "created": "2018-07-12T00:48:36.000Z",
 *             "updated": null,
 *             "deleted": null,
 *             "user_id": 1,
 *             "User": {
 *                 "id": 1,
 *                 "email": "kzarzoso@gmail.com",
 *                 "first_name": "Kiara",
 *                 "last_name": "Zarzoso",
 *                 "middle_name": "Calbera",
 *                 "contact_number": "09168650222"
 *             }
 *         },
 *         "success": true
 *      }
 *
 */
const getOne = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const id = req.params.id;
    [err, area_manager] = await to(AreaManager.find({
        include: [{
            model: User,
            attributes: ['id', 'email', 'first_name', 'last_name', 'middle_name', 'contact_number'],
            required: true
        }]
    },
    {
        'where' : {
            'id' : id
        }
    }));
    return ReS(res, {'area_manager' : area_manager});
};

/**
 * @api {put} /area-managers/:id updateAreaManager
 * @apiGroup AreaManager
 * @apiName updateAreaManager
 *
 * @apiParam (Body Params) {String} hub_id hub_id of area manager referenced from hub
 * @apiParam (Body Params) {String} distribution_center_id distribution_center_id of area manager referenced from distribution_center
 *
 * @apiSuccess {UUID} id ID of the area manager.
 * @apiSuccess {String} hub_id hub_id of area manager referenced from hub
 * @apiSuccess {String} distribution_center_id distribution_center_id of area manager referenced from distribution_center
 * @apiSuccess {Timestamp} created Date and Time the Area Manager is created.
 * @apiSuccess {Timestamp} updated Date and Time the Area Manager is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the Area Manager is deleted.
 * @apiSuccess {String} Message Update area manager + id
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *  {
 *      "message": "Successfully updated area manager",
 *      "area_manager": {
 *          "id": "d465a5b9-c900-4e9e-a818-714576a54c89",
 *          "created": {
 *              "val": "NOW()"
 *          },
 *          "user_id": "1",
 *          "hub_id": "12b356bd-0877-4b82-9c2a-fc5d26489bd4",
 *          "distribution_center_id": "da6d1764-a3c7-4e58-946a-7ab0fb4bf75c"
 *      },
 *      "success": true
 *  }
 *
 */

const update = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
     ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    const id = req.params.id;
    const {
        user_id,
        hub_id,
        distribution_center_id
    } = req.body;
    let  area_manager;
    let user = req.user;
    [err, area_manager] = await to(AreaManager.update({
        'user_id' : user_id,
        'hub_id'  : hub_id,
        'distribution_center_id' : distribution_center_id,
        'updated' : Sequelize.fn('NOW')
    },
    {
        'where' : {
            'id' : id
        }
    }));
    [err, area_manager] = await to(AreaManager.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : area_manager,
        'result' : '201',
        'actor' : user.id
    }));
    return ReS(res, {'area_manager' : area_manager.toWeb(),
                    'log' : log,
                    'message' : 'update area manager ' + id});
}

/**
 * @api {deactivate} /area-managers/:id/deactivate deactivateAreaManager
 * @apiGroup AreaManager
 * @apiName deactivateAreaManager
 *
 * @apiSuccess {UUID} id ID of the area manager.
 * @apiSuccess {String} hub_id hub_id of area manager referenced from hub
 * @apiSuccess {String} distribution_center_id distribution_center_id of area manager referenced from distribution_center
 * @apiSuccess {Timestamp} created Date and Time the Area Manager is created.
 * @apiSuccess {Timestamp} updated Date and Time the Area Manager is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the Area Manager is deleted.
 * @apiSuccess {String} Message Deactivated Area Manager
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *      "area manager": {
 *          "id": "4a03aaf7-b84b-4a32-9c93-b9e6c57f4803",
 *          "hub_id": "12b356bd-0877-4b82-9c2a-fc5d26489bd4",
 *          "distribution_center_id": "da6d1764-a3c7-4e58-946a-7ab0fb4bf75c",
 *          "created": "2018-07-06T01:49:16.000Z",
 *          "updated": "2018-07-10T07:28:40.000Z",
 *          "deleted": "2018-07-10T07:32:23.000Z",
 *          "user_id": 2
 *      },
 *      "message": "deactivated area manager",
 *      "success": true
 *   }
 *
 */

const deactivate = async (req, res) => {
     ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let area_manager;
    let user = req.user;
    const id = req.params.id;
    [err, area_manager] = await to(AreaManager.update({
            deleted : Sequelize.fn('NOW')
        },
        {
            'where': {
                'id': id
            }
        }
    ));
    [err, area_manager] = await to(AreaManager.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : area_manager,
        'result' : '201',
        'actor' : user.id
    }));
    return ReS(res, {'area manager' : area_manager.toWeb(),
                    'log' : log,
                    'message': 'deactivated area manager'});
};

/**
 * @api {reactivate} /area-managers/:id/reactivate reactivateAreaManager
 * @apiGroup AreaManager
 * @apiName reactivateAreaManager
 *
 * @apiSuccess {UUID} id ID of the area manager.
 * @apiSuccess {String} hub_id hub_id of area manager referenced from hub
 * @apiSuccess {String} distribution_center_id distribution_center_id of area manager referenced from distribution_center
 * @apiSuccess {Timestamp} created Date and Time the Area Manager is created.
 * @apiSuccess {Timestamp} updated Date and Time the Area Manager is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the Area Manager is deleted.
 * @apiSuccess {String} Message Reactivated Area Manager
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *      "area manager": {
 *          "id": "4a03aaf7-b84b-4a32-9c93-b9e6c57f4803",
 *          "hub_id": "12b356bd-0877-4b82-9c2a-fc5d26489bd4",
 *          "distribution_center_id": "da6d1764-a3c7-4e58-946a-7ab0fb4bf75c",
 *          "created": "2018-07-06T01:49:16.000Z",
 *          "updated": "2018-07-10T07:28:40.000Z",
 *          "deleted": null,
 *          "user_id": 2
 *      },
 *      "message": "reactivated area manager",
 *      "success": true
 *   }
 *
 */

const reactivate = async (req, res) => {
     ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    const id = req.params.id;
    let  area_manager;
    let user = req.user;
    [err, area_manager] = await to(AreaManager.update({
        'deleted' : null
    },
    {
        'where' : {
            'id' : id
        }
    }));
    [err, area_manager] = await to(AreaManager.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : area_manager,
        'result' : '201',
        'actor' : user.id
    }));
    return ReS(res, {'area_manager' : area_manager.toWeb(),
                    'log' : log,
                    'message' : 'reactivated area manager : ' + id});
}

/**
 * @api {search} /area-managers/search searchAreaManager
 * @apiGroup AreaManager
 * @apiName searchAreaManager
 *
 * @apiParam (Query Params) {UUID} id ID of area manager 
 * @apiParam (Query Params) {String} hub_id hub_id of area manager referenced from hub
 * @apiParam (Query Params) {String} distribution_center_id distribution_center_id of area manager referenced from distribution_center
 * @apiParam (Query Params) {Timestamp} created Date and Time the Area Manager is created
 * @apiParam (Query Params) {Timestamp} updated Date and Time the Area Manager is updated
 * @apiParam (Query Params) {Timestamp} deleted Date and Time the Area Manager is deleted
 *
 * @apiSuccess {UUID} id ID of the area manager
 * @apiSuccess {String} hub_id hub_id of area manager referenced from hub
 * @apiSuccess {String} distribution_center_id distribution_center_id of area manager referenced from hub
 * @apiSuccess {Timestamp} created Date and Time the Area Manager is created.
 * @apiSuccess {Timestamp} updated Date and Time the Area Manager is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the Area Manager is deleted.
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
  *  {
 *      "area_manager": [
 *          {
 *              "id": "4a03aaf7-b84b-4a32-9c93-b9e6c57f4803",
 *              "hub_id": "12b356bd-0877-4b82-9c2a-fc5d26489bd4",
 *              "distribution_center_id": "da6d1764-a3c7-4e58-946a-7ab0fb4bf75c",
 *              "created": "2018-07-06T01:49:16.000Z",
 *              "updated": "2018-07-06T01:52:11.000Z",
 *              "deleted": null,
 *              "user_id": 2
 *          }
 *      ],
 *      "success": true
 *  }
 *
 */

const search = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const {
        user_id,
        hub_id,
        distribution_center_id
    } = req.query;
    let err, area_manager;
    [err, area_manager] = await to(AreaManager.findAll({
        where : {
            [Op.or] :
                [         
                    {'user_id' : user_id},
                    {'hub_id' : hub_id},
                    {'distribution_center_id' : distribution_center_id}
                ]
        }
    }));
    return ReS(res, {'area_managers' : area_manager});
}

module.exports = {
    'create' : create,
    'get' : get,
    'getOne' : getOne,
    'deactivate' : deactivate,
    'reactivate' : reactivate,
    'update' : update,
    'search' : search
}