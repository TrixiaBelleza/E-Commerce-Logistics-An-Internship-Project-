const User          = require('./../models').User;
const Authorized = require('./../models').authorized;
const authService   = require('./../services/AuthService');
const Log           = require('./../models').log;
/**
* @api {post} /v1/users Add User
* @apiGroup User
* @apiName Add User
*
* @apiParam (System Generated) {Integer} id unique ID  
* @apiParam (Body Params) {String} email email of user
* @apiParam (Body Params) {String} password password of user
* @apiParam (Body Params) {String} first_name first_name
* @apiParam (Body Params) {String} middle_name middle_name
* @apiParam (Body Params) {String} last_name last_name
* @apiParam (Body Params) {String} contact_number contact number
*
* @apiSuccess {Object} user new user
* @apiSuccess {Integer} user.id ID of user
* @apiSuccess {String} user.email email of user
* @apiSuccess {String} user.password encrypted password of user
* @apiSuccess {String} user.first_name first name of user
* @apiSuccess {String} user.middle_name middle name of user
* @apiSuccess {String} user.last_name last name of user
* @apiSuccess {String} user.first_name first name of user
* @apiSuccess {String} user.contact_number contact_number of user
* @apiSuccess {Timestamp} user.created timestamp of creation
* @apiSuccess {Timestamp} user.updated timestamp when updated
* @apiSuccess {Timestamp} user.deleted timestamp of deletion
* @apiSuccess {String} token valid token
*
* @apiSuccessExample {json} Success-Response:
{
    "message": "successfully created new user",
    "user": {
        "created": {
            "val": "NOW()"
        },
        "updated": null,
        "deleted": null,
        "id": 4,
        "email": "aporca@gmail.com",
        "password": "$2b$10$Vmkh7/x2v6O7I9dtdSOzSusCeo3oRE1bgacgsMEA7ZqNQXOcUb3fq",
        "first_name": "antonette",
        "middle_name": "middle",
        "last_name": "porca",
        "updatedAt": "2018-07-12T02:02:21.947Z",
        "createdAt": "2018-07-12T02:02:21.947Z"
    },
    "token": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjo0LCJpYXQiOjE1MzEzNjA5NDIsImV4cCI6MTUzMTM3MDk0MiwianRpIjoiMTk5NjcwM2YtNDIyZi00NTRhLThiNjItOTFlZDdiMWYyMmUxIn0.LK1B0buga_TQGAv2F6-izTiEMI3818O09Skt6Cp6DqM",
    "success": true
}
*
*/
const create = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const body = req.body;
    if (!body.unique_key && !body.email) {
        return ReE(res, 'enter an email address to register');
    } else if (!body.password) {
        return ReE(res, 'enter a password to register');
    } else {
        let err, user;
        [err, user] = await to(authService.createUser(body));
        if (err) {
            [log] = await to(Log.create({
                'route' : req.path,
                'body' : err,
                'result' : '422'
            }));
            return ReE(res, err, 422);
        }
        [err, log] = await to(Log.create({
            'route' : req.path,
            'body' : user,
            'result' : '201'
        }));
        return ReS(res, {'message':'successfully created new user', 
                        'user': user.toWeb(), 
                        'token': user.getJWT(),
                        'log' : log}, 201);
    }
};
/**
* @api {get} /v1/users Get User
* @apiGroup User
* @apiName Get User
*
* @apiHeader (Header) {String} authorization jwt token ex: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoxLCJpYXQiOjE1MzEyODk2MDQsImV4cCI6MTUzMTI5OTYwNCwianRpIjoiMGU0Y2JiNDctYjk4Yy00MTMxLWFhMDAtNGIwNmZjYWZmMGQ0In0.6TgWivCAefsoMnmJ0uaeth8-1mW-Z8CLPc_V_rX37I0
* @apiSuccess {Object} user new user
* @apiSuccess {Integer} user.id ID of user
* @apiSuccess {String} user.email email of user
* @apiSuccess {String} user.password encrypted password of user
* @apiSuccess {String} user.first_name first name of user
* @apiSuccess {String} user.middle_name middle name of user
* @apiSuccess {String} user.last_name last name of user
* @apiSuccess {String} user.first_name first name of user
* @apiSuccess {String} user.contact_number contact_number of user
* @apiSuccess {Timestamp} user.created timestamp of creation
* @apiSuccess {Timestamp} user.updated timestamp when updated
* @apiSuccess {Timestamp} user.deleted timestamp of deletion
* @apiSuccess {String} token valid token
*
* @apiSuccessExample {json} Success-Response:
{
    "user": {
        "id": 3,
        "email": "jdelacruz@gmail.com",
        "password": "$2b$10$/1JsJ2x9xaSeYtsgd3TE.OXkfz1z4apVvLWhJQwVKXlI0nUY4J1j2",
        "first_name": "juan",
        "last_name": "delacruz",
        "middle_name": "reyes",
        "contact_number": null,
        "created": "2018-07-12T01:36:45.000Z",
        "updated": "2018-07-12T01:53:58.000Z",
        "deleted": null,
        "createdAt": "2018-07-12T01:36:45.000Z",
        "updatedAt": "2018-07-12T01:53:58.000Z"
    },
    "success": true
}
*
*/
const get = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    let user = req.user;
  
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : user,
        'result' : '201',
        'actor' : user.id
    }));
    return ReS(res, {'user': user.toWeb(),
                    'log' : log});
};

/**
* @api {put} /v1/users Update User
* @apiGroup User
* @apiName Update User
*
* @apiHeader (Header) {String} authorization jwt token ex: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoxLCJpYXQiOjE1MzEyODk2MDQsImV4cCI6MTUzMTI5OTYwNCwianRpIjoiMGU0Y2JiNDctYjk4Yy00MTMxLWFhMDAtNGIwNmZjYWZmMGQ0In0.6TgWivCAefsoMnmJ0uaeth8-1mW-Z8CLPc_V_rX37I0
*
* @apiParam (Body Params) {String} first_name first_name
* @apiParam (Body Params) {String} middle_name middle_name
* @apiParam (Body Params) {String} last_name last_name
* @apiParam (Body Params) {String} contact_number contact number
*
* @apiSuccessExample {json} Success-Response:
{
    "message": "update user: jdelacruz@gmail.com",
    "success": true
}
*
*/
const update = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    let user, data;
    user = req.user;
    data = req.body;
    user.set(data);
    [err, user] = await to(user.save());
    if (err) {
        if (err.message === 'Validation error') {
            err = 'email is already in use';
            [log] = await to(Log.create({
                'route' : req.path,
                'body' : err,
                'result' : '422',
                'actor' : user.id
            }));
            return ReE(res, err);
        }
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : user,
        'result' : '201',
        'actor' : user.id
    }));
    return ReS(res, {'message': 'update user: ' + user.email,
                    'log' : log});
};

/**
* @api {del} /v1/users Remove User
* @apiGroup User
* @apiName Remove User
*
* @apiHeader (Header) {String} authorization jwt token ex: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoxLCJpYXQiOjE1MzEyODk2MDQsImV4cCI6MTUzMTI5OTYwNCwianRpIjoiMGU0Y2JiNDctYjk4Yy00MTMxLWFhMDAtNGIwNmZjYWZmMGQ0In0.6TgWivCAefsoMnmJ0uaeth8-1mW-Z8CLPc_V_rX37I0
*
* @apiSuccessExample {json} Success-Response:
{
    "message": "deleted user",
    "success": true
}
*
*/
const remove = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    let user;
    user = req.user;
    [err, user] = await to(user.destroy());
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : user.id
        }));
        return ReE(res, 'error occured trying to delete user');
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : log,
        'result' : '201',
        'actor' : user.id
    }));
    
    return ReS(res, {'message': 'deleted user',
                    'log' : log});
}

/**
* @api {post} /users/login Log in
* @apiGroup User
* @apiName Log in
*
* @apiParam (Body Params) {String} email email
* @apiParam (Body Params) {String} password password
*
* @apiSuccess {String} token valid token
* @apiSuccess {Object} user new user
* @apiSuccess {Integer} user.id ID of user
* @apiSuccess {String} user.email email of user
* @apiSuccess {String} user.password encrypted password of user
* @apiSuccess {String} user.first_name first name of user
* @apiSuccess {String} user.middle_name middle name of user
* @apiSuccess {String} user.last_name last name of user
* @apiSuccess {String} user.first_name first name of user
* @apiSuccess {String} user.contact_number contact_number of user
* @apiSuccess {Timestamp} user.created timestamp of creation
* @apiSuccess {Timestamp} user.updated timestamp when updated
* @apiSuccess {Timestamp} user.deleted timestamp of deletion
*
* @apiSuccessExample {json} Success-Response:
{
    "token": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjozLCJpYXQiOjE1MzEzNTk0NjYsImV4cCI6MTUzMTM2OTQ2NiwianRpIjoiNzM1OTU4NjEtNjExMS00ZGZkLWEzODEtNWY2MTA1MzhmYjYxIn0.3b7P3MzHrr9LICXvfyKGdcPicZZAcm_-yVc2u5bEQeI",
    "user": {
        "id": 3,
        "email": "jdelacruz@gmail.com",
        "password": "$2b$10$e9wuucvYYcyxH0M5cYnOH.RDo7vL6ZZ3pVNBlxRJYCQ1lWtikZ8VW",
        "first_name": "juan",
        "last_name": "delacruz",
        "middle_name": "reyes",
        "contact_number": null,
        "created": "2018-07-12T01:36:45.000Z",
        "updated": null,
        "deleted": null,
        "createdAt": "2018-07-12T01:36:45.000Z",
        "updatedAt": "2018-07-12T01:36:45.000Z"
    },
    "success": true
}
*/

const login = async (req, res) => {
    const body = req.body;
    let err, user,jti;
    [err, user] = await to(authService.authUser(req.body));

    if (err) {
        return ReE(res, err, 422);
    }
    
    if(user){
        const token = user.getJWT();
        console.log(token);
        [err,jti] = await to (authService.get_jti(token));
        if (err) { return ReE(res, err, 422);}

        let authorized;
        [err, authorized] = await to(Authorized.create({'token_id' :jti }));
        if (err) { return ReE(res, err, 422);}

        
        return ReS(res, {'token': token, 'user': user.toWeb()});   

    }

}

module.exports = {
    'create': create,
    'get'   : get,
    'update': update,
    'remove': remove,
    'login' : login
}