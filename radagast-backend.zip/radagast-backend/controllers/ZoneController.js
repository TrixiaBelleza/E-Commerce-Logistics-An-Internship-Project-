const Zone   = require('./../models').zone;
const Log = require('./../models').log;
const Sequelize = require('sequelize');
const Op = Sequelize.Op;
const Authorized = require('./../models').authorized;
const authService   = require('./../services/AuthService');
/**
* @api {get} /v1/zones Get Zones
* @apiGroup Zone
* @apiName Get Zones
*
* @apiSuccess {Object[]} zones array of zones
* @apiSuccess {UUID} zones.id ID of zone
* @apiSuccess {String} zones.code code of zone
* @apiSuccess {String} zones.name name of zone
* @apiSuccess {String} zones.address address of zone
* @apiSuccess {char} zones.country country
* @apiSuccess {char} zones.region region
* @apiSuccess {char} zones.province province
* @apiSuccess {char} zones.district district
* @apiSuccess {char} zones.sub_district sub_district
* @apiSuccess {Timestamp} zones.created timestamp of creation
* @apiSuccess {Timestamp} zones.updated timestamp when updated
* @apiSuccess {Timestamp} zones.deleted timestamp of deletion
* @apiSuccessExample {json} Success-Response:
*    {
*        "zones": [
*            {
*                "id": "47af714f-cfd9-47e0-ae60-b71cd8ce4856",
*                "code": "ZN1",
*                "name": "Zone 1",
*                "address": "Los Banos",
*                "country": "PHL",
*                "region": "4A",
*                "province": "LGN",
*                "district": "3",
*                "sub_district": "",
*                "barangay": "Maahas",
*                "created": "2018-07-11T01:33:34.000Z",
*                "updated": null,
*                "deleted": null,
*                "distribution_center_id": "e5673532-de5b-4886-a24e-a447a58b4782"
*            },
*            {
*                "id": "9d1d9327-9b86-49c6-8f76-478b1e06bfcf",
*                "code": "ZN2",
*                "name": "Zone 2",
*                "address": "Los Banos",
*                "country": "PHL",
*                "region": "4A",
*                "province": "LGN",
*                "district": "3",
*                "sub_district": "",
*                "barangay": "Anos",
*                "created": "2018-07-11T01:35:30.000Z",
*                "updated": null,
*                "deleted": null,
*                "distribution_center_id": "e5673532-de5b-4886-a24e-a447a58b4782"
*            }
*        ],
*        "success": true
*    }
*/
const get = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    [err, zone] = await to(Zone.findAll());
    return ReS(res, {'zones': zone});
};

 /**
* @api {get} /v1/xones/:id Get Zone by ID
* @apiGroup Zone
* @apiName Get Zone by ID
* @apiParam {UUID} id Users unique ID.
*
* @apiSuccess {Object} zone new zone
* @apiSuccess {UUID} zone.id ID of zone
* @apiSuccess {String} zone.code code of zone
* @apiSuccess {String} zone.name name of zone
* @apiSuccess {String} zone.address address of zone
* @apiSuccess {char} zone.country country
* @apiSuccess {char} zone.region region
* @apiSuccess {char} zone.province province
* @apiSuccess {char} zone.district district
* @apiSuccess {char} zone.sub_district sub_district
* @apiSuccess {char} zone.barangay barangay
* @apiSuccess {Timestamp} zone.created timestamp of creation
* @apiSuccess {Timestamp} zone.updated timestamp when updated
* @apiSuccess {Timestamp} zone.deleted timestamp of deletion
* @apiSuccessExample {json} Success-Response:
*    {
*        "zone": {
*            "id": "47af714f-cfd9-47e0-ae60-b71cd8ce4856",
*            "code": "ZN1",
*            "name": "Zone 1",
*            "address": "Los Banos",
*            "country": "PHL",
*            "region": "4A",
*            "province": "LGN",
*            "district": "3",
*            "sub_district": "",
*            "barangay": "Maahas",
*            "created": "2018-07-11T01:33:34.000Z",
*            "updated": null,
*            "deleted": null,
*            "distribution_center_id": "e5673532-de5b-4886-a24e-a447a58b4782"
*        },
*        "success": true
*    }
*
*/
const getOne = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const id = req.params.id;
    [err, zone] = await to(Zone.findById(id));
    return ReS(res, {'zone': zone.toWeb()});
};

/**
* @api {post} /v1/zones Add Zone
* @apiGroup Zone
* @apiName Add Zone
*
* @apiParam (System Generated) {UUID} id unique ID  
* @apiParam (Body Params) {String} code unique code for each zone
* @apiParam (Body Params) {String} distribution_center_id ID of the distribution center the zone belongs to (foreign key)
* @apiParam (Body Params) {String} name name of zone
* @apiParam (Body Params) {String} address address of the zone
* @apiParam (Body Params) {char}   country country
* @apiParam (Body Params) {char}   region region
* @apiParam (Body Params) {char}   province province
* @apiParam (Body Params) {char}   district district
* @apiParam (Body Params) {char}   sub_district sub_district
* @apiParam (Body Params) {char}   barangay barangay
*
* @apiSuccess {Object} zone new zone
* @apiSuccess {UUID} zone.id ID of zone
* @apiSuccess {String} zone.code code of zone
* @apiSuccess {String} zone.name name of zone
* @apiSuccess {String} zone.address address of zone
* @apiSuccess {char} zone.country country
* @apiSuccess {char} zone.region region
* @apiSuccess {char} zone.province province
* @apiSuccess {char} zone.district district
* @apiSuccess {char} zone.sub_district sub_district
* @apiSuccess {char} zone.barangay barangay
* @apiSuccess {Timestamp} zone.created timestamp of creation
* @apiSuccess {Timestamp} zone.updated timestamp when updated
* @apiSuccess {Timestamp} zone.deleted timestamp of deletion
* @apiSuccessExample {json} Success-Response:
*    {
*        "message": "successfully created new zone",
*        "zone": {
*            "id": "47af714f-cfd9-47e0-ae60-b71cd8ce4856",
*            "created": {
*                "val": "NOW()"
*            },
*            "updated": null,
*            "deleted": null,
*            "distribution_center_id": "e5673532-de5b-4886-a24e-a447a58b4782",
*            "code": "ZN1",
*            "name": "Zone 1",
*            "address": "Los Banos",
*            "country": "PHL",
*            "region": "4A",
*            "province": "LGN",
*            "district": "3",
*            "sub_district": "",
*            "barangay": "Maahas"
*        },
*        "success": true
*    }
*/

const create = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}

    console.log(jti);

    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    const {
        distribution_center_id,
        code,
        name,
        address,
        country,
        region,
        province,
        district,
        sub_district,
        barangay
    } = req.body;
    let hub;
    [err, zone] = await to(Zone.create({
       'distribution_center_id' : distribution_center_id,
        'code' : code,
        'name' : name,
        'address' : address,
        'country' : country,
        'region' : region,
        'province' : province,
        'district' : district,
        'sub_district' : sub_district,
        'barangay' : barangay
    }));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : zone,
        'result' : '201',
        'actor' : req.user.id
    }));
    return ReS(res, {'message':'successfully created new zone', 
                    'zone': zone.toWeb(),
                    'log' : log}, 201);
};

/**
* @api {put} /v1/zones/:id Update Zone by ID
* @apiName Update Zone by ID
* @apiGroup Zone
* @apiParam {UUID} id Zone's unique ID.
*
* @apiParam (Body Params) {String} code unique code for each zone
* @apiParam (Body Params) {String} distribution_center_id ID of the distribution center the zone belongs to (foreign key)
* @apiParam (Body Params) {String} name name of zone
* @apiParam (Body Params) {String} address address of the zone
* @apiParam (Body Params) {char}   country country
* @apiParam (Body Params) {char}   region region
* @apiParam (Body Params) {char}   province province
* @apiParam (Body Params) {char}   district district
* @apiParam (Body Params) {char}   sub_district sub_district
* @apiParam (Body Params) {char}   barangay barangay
*
* @apiSuccess {Object} zone new zone
* @apiSuccess {UUID} zone.id ID of zone
* @apiSuccess {String} zone.code code of zone
* @apiSuccess {String} zone.name name of zone
* @apiSuccess {String} zone.address address of zone
* @apiSuccess {char} zone.country country
* @apiSuccess {char} zone.region region
* @apiSuccess {char} zone.province province
* @apiSuccess {char} zone.district district
* @apiSuccess {char} zone.sub_district sub_district
* @apiSuccess {char} zone.barangay barangay
* @apiSuccess {Timestamp} zone.created timestamp of creation
* @apiSuccess {Timestamp} zone.updated timestamp when updated
* @apiSuccess {Timestamp} zone.deleted timestamp of deletion
* @apiSuccessExample {json} Success-Response:
*    {
*        "zone": {
*            "id": "47af714f-cfd9-47e0-ae60-b71cd8ce4856",
*            "code": "ZN1",
*            "name": "Zone 1",
*            "address": "Los Banos",
*            "country": "PHL",
*            "region": "4A",
*            "province": "LGN",
*            "district": "3",
*            "sub_district": null,
*            "barangay": "Bayog",
*            "created": "2018-07-11T01:33:34.000Z",
*            "updated": "2018-07-11T01:46:50.000Z",
*            "deleted": null,
*            "distribution_center_id": "e5673532-de5b-4886-a24e-a447a58b4782"
*        },
*        "message": "update zone: 47af714f-cfd9-47e0-ae60-b71cd8ce4856",
*        "success": true
*    }
*/


const update = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}

    console.log(jti);

    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let zone;
    const id = req.params.id;
    const {
        code,
        name,
        address,
        country,
        region,
        province,
        district,
        sub_district,
        barangay
    } = req.body;
    [err, zone] = await to(Zone.update({
       'code' :code,
        'name' :name,
        'address' :address,
        'country' :country,
        'region' :region,
        'province' :province,
        'district' :district,
        'sub_district' :sub_district,
        'barangay' :barangay,
        'updated' : Sequelize.fn('NOW')
        
        }, {
            'where': {
                'id': id
            }
        }
    ));
    [err, zone] = await to(Zone.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : zone,
        'result' : '201',
        'actor' : req.user.id
    }));
    return ReS(res, {'zone': zone.toWeb(), 
                    'message': 'update zone: ' + id,
                    'log' : log});
};

/**
* @api {get} /v1/zones/search Search Zone
* @apiName Search Zone
* @apiGroup Zone
*
* @apiParam (Parameter) {UUID}   id Zone's unique ID
* @apiParam (Parameter) {String} code unique code for each Zone
* @apiParam (Parameter) {String} distribution_center_id ID of the distribution center the Zone belongs to (foreign key)
* @apiParam (Parameter) {String} name name of Zone
* @apiParam (Parameter) {String} address address of the Zone
* @apiParam (Parameter) {char}   country country
* @apiParam (Parameter) {char}   region region
* @apiParam (Parameter) {char}   province province
* @apiParam (Parameter) {char}   district district
* @apiParam (Parameter) {char}   sub_district sub_district
* @apiParam (Parameter) {char}   barangay barangay
*
* @apiSuccess {Object[]} zones array of zones
* @apiSuccess {UUID} zones.id ID of zone
* @apiSuccess {String} zones.code code of zone
* @apiSuccess {String} zones.name name of zone
* @apiSuccess {String} zones.address address of zone
* @apiSuccess {char} zones.country country
* @apiSuccess {char} zones.region region
* @apiSuccess {char} zones.province province
* @apiSuccess {char} zones.district district
* @apiSuccess {char} zones.sub_district sub_district
* @apiSuccess {Timestamp} zones.created timestamp of creation
* @apiSuccess {Timestamp} zones.updated timestamp when updated
* @apiSuccess {Timestamp} zones.deleted timestamp of deletion
* @apiSuccessExample {json} Success-Response:
*    {
*        "zone": [
*            {
*                "id": "47af714f-cfd9-47e0-ae60-b71cd8ce4856",
*                "code": "ZN1",
*                "name": "Zone 1",
*                "address": "Los Banos",
*                "country": "PHL",
*                "region": "4A",
*                "province": "LGN",
*                "district": "3",
*                "sub_district": null,
*                "barangay": "Bayog",
*                "created": "2018-07-11T01:33:34.000Z",
*                "updated": "2018-07-11T01:46:50.000Z",
*                "deleted": null,
*                "distribution_center_id": "e5673532-de5b-4886-a24e-a447a58b4782"
*            }
*        ],
*        "success": true
*    }
*/

const search = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const {
        id,
        distribution_center_id,
        code,
        name,
        address,
        country,
        region,
        province,
        district,
        sub_district,
        created,
        updated,
        deleted
    } = req.query;

    [err, zone] = await to(Zone.findAll({
            where: {
                [Op.or]: [{'id': id}, {'distribution_center_id':distribution_center_id},{'code': code}, {'name': name}, 
                {'address' : address}, {'country' : country},{'region' : region},
                {'province' : province},{'district': district},
                {'sub_district':sub_district}, {'created': created}, {'updated': updated}, {'deleted': deleted}]
            }
    }));
    return ReS(res, {'zone': zone});
};

/**
* @api {post} /v1/zones/:id/deactivate Deactivate Zone by ID
* @apiName Deactivate Zone by ID
* @apiGroup Zone
* @apiParam {UUID} id Zone's unique ID.
*
* @apiSuccess {Object} zone new zone
* @apiSuccess {UUID} zone.id ID of zone
* @apiSuccess {String} zone.code code of zone
* @apiSuccess {String} zone.name name of zone
* @apiSuccess {String} zone.address address of zone
* @apiSuccess {char} zone.country country
* @apiSuccess {char} zone.region region
* @apiSuccess {char} zone.province province
* @apiSuccess {char} zone.district district
* @apiSuccess {char} zone.sub_district sub_district
* @apiSuccess {char} zone.barangay barangay
* @apiSuccess {Timestamp} zone.created timestamp of creation
* @apiSuccess {Timestamp} zone.updated timestamp when updated
* @apiSuccess {Timestamp} zone.deleted timestamp of deletion
* @apiSuccessExample {json} Success-Response:
*	{
*        "message": "deactivated zone",
*        "zone": {
*            "id": "47af714f-cfd9-47e0-ae60-b71cd8ce4856",
*            "code": "ZN1",
*            "name": "Zone 1",
*            "address": "Los Banos",
*            "country": "PHL",
*            "region": "4A",
*            "province": "LGN",
*            "district": "3",
*            "sub_district": null,
*            "barangay": "Bayog",
*            "created": "2018-07-11T01:33:34.000Z",
*            "updated": "2018-07-11T01:46:50.000Z",
*            "deleted": "2018-07-11T01:59:42.000Z",
*            "distribution_center_id": "e5673532-de5b-4886-a24e-a447a58b4782"
*        },
*        "success": true
*    }
*/

const deactivate = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}

    console.log(jti);

    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let zone;
    const id = req.params.id;
    [err, zone] = await to(Zone.update({
            deleted : Sequelize.fn('NOW')
        },
        {
            'where': {
                'id': id
            }
        }
    ));
    [err, zone] = await to(Zone.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : zone,
        'result' : '201',
        'actor' : req.user.id
    }));
    return ReS(res, {'message':'deactivated zone','zone': zone.toWeb(),
                    'log' : log});
};

/**
* @api {post} /v1/zones/:id/reactivate Reactivate Zone by ID
* @apiName Reactivate Zone by ID
* @apiGroup Zone
* @apiParam {UUID} id Zone's unique ID.
* @apiSuccess {Object} zone new zone
* @apiSuccess {UUID} zone.id ID of zone
* @apiSuccess {String} zone.code code of zone
* @apiSuccess {String} zone.name name of zone
* @apiSuccess {String} zone.address address of zone
* @apiSuccess {char} zone.country country
* @apiSuccess {char} zone.region region
* @apiSuccess {char} zone.province province
* @apiSuccess {char} zone.district district
* @apiSuccess {char} zone.sub_district sub_district
* @apiSuccess {char} zone.barangay barangay
* @apiSuccess {Timestamp} zone.created timestamp of creation
* @apiSuccess {Timestamp} zone.updated timestamp when updated
* @apiSuccess {Timestamp} zone.deleted timestamp of deletion
* @apiSuccessExample {json} Success-Response:
*	{
*        "message": "reactivated zone",
*        "zone": {
*            "id": "47af714f-cfd9-47e0-ae60-b71cd8ce4856",
*            "code": "ZN1",
*            "name": "Zone 1",
*            "address": "Los Banos",
*            "country": "PHL",
*            "region": "4A",
*            "province": "LGN",
*            "district": "3",
*            "sub_district": null,
*            "barangay": "Bayog",
*            "created": "2018-07-11T01:33:34.000Z",
*            "updated": "2018-07-11T01:46:50.000Z",
*            "deleted": null,
*            "distribution_center_id": "e5673532-de5b-4886-a24e-a447a58b4782"
*        },
*        "success": true
*    }
*/



const reactivate = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}

    console.log(jti);

    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let zone;
    const id = req.params.id;
    [err, zone] = await to(Zone.update({
            deleted : null
        },
        {
            'where': {
                'id': id
            }
        }
    ));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }
    [err, zone] = await to(Zone.findById(id));
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : zone,
        'result' : '201',
        'actor' : req.user.id
    }));
    return ReS(res, {'message': 'reactivated zone','zone': zone.toWeb(),
                    'log' : log});
};

module.exports = {
    'get'   : get,
    'getOne' : getOne,
    'create' : create,
    'update' : update,
    'search' : search,
    'deactivate' : deactivate,
    'reactivate' : reactivate
}



