const Province   = require('./../models').province;
const Region  = require('./../models').region;
const Country = require('./../models').country;
const Log = require('./../models').log;
const Sequelize = require('sequelize');
const Op = Sequelize.Op;
const Authorized = require('./../models').authorized;
const authService   = require('./../services/AuthService');

/**
* @api {get} /provinces Retrieve Provinces
* @apiName GetProvinces
* @apiGroup Province
*
* @apiSuccess {String} id Province ID.
* @apiSuccess {String} code  Code of the Province.
* @apiSuccess {String} name  Name of the Province.
* @apiSuccess {Timestamp} created  Date and Time the Province is created.
* @apiSuccess {Timestamp} updated  Date and Time the Province is updated.
* @apiSuccess {Timestamp} deleted  Date and Time the Province is deleted.
* @apiSuccess {String} region_id  Region ID referenced from Region.
* @apiSuccess {String} region_id.id  Region ID.
* @apiSuccess {String} region_id.code  Code of the Region.
* @apiSuccess {String} region_id.name  Code of the Region.
* @apiSuccess {String} country_id  Country ID referenced from Country.
* @apiSuccess {String} country_id.id  Country ID.
* @apiSuccess {String} country_id.code  Code of the Country.
* @apiSuccess {String} country_id.name  Code of the Country.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
         "provinces": [
            {
                "id": "a91c7fdc-7b5a-42ae-8342-d578a57a1b46",
                "code": "LAG",
                "name": "Laguna",
                "created": "2018-07-11T00:43:43.000Z",
                "updated": null,
                "deleted": null,
                "region_id": "b157ed7b-1060-4a35-ae24-67aa0a14e20f",
                "region": {
                    "id": "b157ed7b-1060-4a35-ae24-67aa0a14e20f",
                    "code": "CAL",
                    "name": "Calabarzon",
                    "country": {
                        "id": "406405a2-8255-48d0-86c6-7f1109d10e30",
                        "code": "PH",
                        "name": "Philippines"
                    }
                }
            },
            {
                "id": "e6dd2897-81e1-46da-8401-6f01cd1738db",
                "code": "RZL",
                "name": "Rizal",
                "created": "2018-07-09T01:59:18.000Z",
                "updated": null,
                "deleted": null,
                "region_id": "b157ed7b-1060-4a35-ae24-67aa0a14e20f",
                "region": {
                    "id": "b157ed7b-1060-4a35-ae24-67aa0a14e20f",
                    "code": "CAL",
                    "name": "Calabarzon",
                    "country": {
                        "id": "406405a2-8255-48d0-86c6-7f1109d10e30",
                        "code": "PH",
                        "name": "Philippines"
                    }
                }
            }
        ],
        "success": true
    }
*
*/

const get = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    [err, province] = await to(Province.findAll({
        include: [{
            model: Region,
            attributes: ['id', 'code', 'name'],
            required: true,
            include: [{
                    model: Country,
                    attributes: ['id', 'code', 'name'],
                    required: true
            }]
        }]
    }));
    return ReS(res, {'provinces': province});
};

/**
* @api {get} /provinces/:id Retrieve Province By ID
* @apiName GetProvinceByID
* @apiGroup Province
*
* @apiParam {String} id Province unique ID.
*
* @apiSuccess {String} id Province ID.
* @apiSuccess {String} code  Code of the Province.
* @apiSuccess {String} name  Name of the Province.
* @apiSuccess {Timestamp} created  Date and Time the Province is created.
* @apiSuccess {Timestamp} updated  Date and Time the Province is updated.
* @apiSuccess {Timestamp} deleted  Date and Time the Province is deleted.
* @apiSuccess {String} region_id  Region ID referenced from Region.
* @apiSuccess {String} region_id.id  Region ID.
* @apiSuccess {String} region_id.code  Code of the Region.
* @apiSuccess {String} region_id.name  Code of the Region.
* @apiSuccess {String} country_id  Country ID referenced from Country.
* @apiSuccess {String} country_id.id  Country ID.
* @apiSuccess {String} country_id.code  Code of the Country.
* @apiSuccess {String} country_id.name  Code of the Country.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
        "province": {
            "id": "a91c7fdc-7b5a-42ae-8342-d578a57a1b46",
            "code": "LAG",
            "name": "Laguna",
            "created": "2018-07-11T00:43:43.000Z",
            "updated": null,
            "deleted": null,
            "region_id": "b157ed7b-1060-4a35-ae24-67aa0a14e20f",
            "region": {
                "id": "b157ed7b-1060-4a35-ae24-67aa0a14e20f",
                "code": "CAL",
                "name": "Calabarzon",
                "country": {
                    "id": "406405a2-8255-48d0-86c6-7f1109d10e30",
                    "code": "PH",
                    "name": "Philippines"
                }
            }
        },
        "success": true
    }
*
*/

const getOne = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const id = req.params.id;
    [err, province] = await to(Province.find({
            include: [{
                model: Region,
                attributes: ['id', 'code', 'name'],
                required: true,
                include: [{
                    model: Country,
                    attributes: ['id', 'code', 'name'],
                    required: true
                }]
            }],

            'where' : {
                'id' : id
            }
    }));
    return ReS(res, {'province': province.toWeb()});
};

/**
* @api {post} /provinces Add Province
* @apiName AddProvince
* @apiGroup Province
*
* @apiParam (System Generated) {String} id Province unique ID.
* @apiParam (Body Params) {String} code code of the Province.
* @apiParam (Body Params) {String} name name of the Province.
* @apiParam (Body Params) {String} region_id Region ID.
*
* @apiSuccess {String} id Province ID.
* @apiSuccess {String} code  Code of the Province.
* @apiSuccess {String} name  Name of the Province.
* @apiSuccess {Timestamp} created  Date and Time the Province is created.
* @apiSuccess {Timestamp} updated  Date and Time the Province is updated.
* @apiSuccess {Timestamp} deleted  Date and Time the Province is deleted.
* @apiSuccess {String} region_id  Region ID referenced from Region.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
        "message": "successfully created new province",
        "province": {
            "id": "58b66509-40d8-4600-9b32-56619fc6c0b5",
            "created": {
                "val": "NOW()"
            },
            "updated": null,
            "deleted": null,
            "region_id": "8c0d476e-ed0b-4e8f-9f6c-fe54ba4d6be4",
            "code": "QZN",
            "name": "Quezon"
        }
        "success": true
    }
*
*/

const create = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
	res.setHeader('Content-Type', 'application/json');
	const {
		region_id,
		code,
		name
	} = req.body;

	let province;
	[err, province] = await to(Province.create({
		'region_id' : region_id,
		'code' : code,
		'name' : name
	}));

	if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : province,
        'result' : '201',
        'actor' : req.user.id
    }));
    return ReS(res, {'message' : 'successfully created new province', 
                    'province' : province.toWeb(),
                    'log' : log}, 201);
};

/**
* @api {put} /provinces/:id Update Province
* @apiName UpdateProvince
* @apiGroup Province
*
* @apiParam (System Generated) {String} id Province unique ID.
* @apiParam (Body Params) {String} code code of the Province.
* @apiParam (Body Params) {String} name name of the Province.
* @apiParam (Body Params) {String} region_id Region ID.
*
* @apiSuccess {String} id Province ID.
* @apiSuccess {String} code  Code of the Province.
* @apiSuccess {String} name  Name of the Province.
* @apiSuccess {Timestamp} created  Date and Time the Province is created.
* @apiSuccess {Timestamp} updated  Date and Time the Province is updated.
* @apiSuccess {Timestamp} deleted  Date and Time the Province is deleted.
* @apiSuccess {String} region_id  Region ID referenced from Region.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
        "province": {
            "id": "58b66509-40d8-4600-9b32-56619fc6c0b5",
            "code": "CAV",
            "name": "Cavite",
            "created": "2018-07-11T00:58:10.000Z",
            "updated": "2018-07-11T01:01:34.000Z",
            "deleted": null,
            "region_id": "8c0d476e-ed0b-4e8f-9f6c-fe54ba4d6be4"
        }
        "success": true
    }
*
*/

const update = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let province;
    const id = req.params.id;
    const {
        region_id,
        code,
        name
    } = req.body;
    [err, province] = await to(Province.update({
            'region_id' : region_id,
            'code' : code,
            'name' : name,
            'updated' : Sequelize.fn('NOW')
        }, {
            'where' : {
                'id' : id
            }
        }
    ));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : province,
        'result' : '201',
        'actor' : req.user.id
    }));
    [err, province] = await to(Province.findById(id))
    return ReS(res, {'province' : province.toWeb(), 
                    'message' : 'update province: ' + id,
                    'log' : log});
};

/**
* @api {post} /provinces/:id/deactivate Deactivate Province
* @apiName DeactivateProvince
* @apiGroup Province
*
* @apiParam {String} id Province unique ID.
*
* @apiSuccess {String} id Province ID.
* @apiSuccess {String} code  Code of the Province.
* @apiSuccess {String} name  Name of the Province.
* @apiSuccess {Timestamp} created  Date and Time the Province is created.
* @apiSuccess {Timestamp} updated  Date and Time the Province is updated.
* @apiSuccess {Timestamp} deleted  Date and Time the Province is deleted.
* @apiSuccess {String} region_id  Region ID referenced from Region.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
        "province": {
            "id": "58b66509-40d8-4600-9b32-56619fc6c0b5",
            "code": "CAV",
            "name": "Cavite",
            "created": "2018-07-11T00:58:10.000Z",
            "updated": "2018-07-11T01:01:34.000Z",
            "deleted": "2018-07-11T01:05:23.000Z",
            "region_id": "8c0d476e-ed0b-4e8f-9f6c-fe54ba4d6be4"
        }
        "message": "deactivated province: 58b66509-40d8-4600-9b32-56619fc6c0b5",
        "success": true
    }
*
*/

const deactivate = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let province;
    const id = req.params.id;
    [err, province] = await to(Province.update({
            deleted : Sequelize.fn('NOW')
        },
        {
            'where': {
                'id': id
            }
        }
    ));
    [err, province] = await to(Province.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : province,
        'result' : '201',
        'actor' : req.user.id
    }));
    return ReS(res, {'province' : province.toWeb(), 
                    'message' : 'deactivated province: ' + id,
                    'log' : log});
};

/**
* @api {post} /provinces/:id/reactivate Reactivate Province
* @apiName ReactivateProvince
* @apiGroup Province
*
* @apiParam {String} id Province unique ID.
*
* @apiSuccess {String} id Province ID.
* @apiSuccess {String} code  Code of the Province.
* @apiSuccess {String} name  Name of the Province.
* @apiSuccess {Timestamp} created  Date and Time the Province is created.
* @apiSuccess {Timestamp} updated  Date and Time the Province is updated.
* @apiSuccess {Timestamp} deleted  Date and Time the Province is deleted.
* @apiSuccess {String} region_id  Region ID referenced from Region.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
        "province": {
            "id": "58b66509-40d8-4600-9b32-56619fc6c0b5",
            "code": "CAV",
            "name": "Cavite",
            "created": "2018-07-11T00:58:10.000Z",
            "updated": "2018-07-11T01:01:34.000Z",
            "deleted": null,
            "region_id": "8c0d476e-ed0b-4e8f-9f6c-fe54ba4d6be4"
        }
        "message": "reactivated province: 58b66509-40d8-4600-9b32-56619fc6c0b5",
        "success": true
    }
*
*/

const reactivate = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let province;
    const id = req.params.id;
    [err, province] = await to(Province.update({
            deleted : null
        },
        {
            'where': {
                'id': id
            }
        }
    ));
    [err, province] = await to(Province.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : province,
        'result' : '201',
        'actor' : req.user.id
    }));
    return ReS(res, {'province' : province.toWeb(), 
                    'message' : 'reactivated province: ' + id,
                    'log' : log});
};

/**
* @api {get} /provinces/search Search Province
* @apiName SearchProvince
* @apiGroup Province
*
* @apiParam (Query Params) {String} code code of the Province
* @apiParam (Query Params) {String} name name of the Province
* @apiParam (Query Params) {Timestamp} created Date and Time the Province is created.
* @apiParam (Query Params) {Timestamp} updated Date and Time the Province is updated.
* @apiParam (Query Params) {Timestamp} deleted Date and Time the Province is deleted.
* @apiParam (Query Params) {String} region_id Region ID.
*
* @apiSuccess {String} id Province ID.
* @apiSuccess {String} code  Code of the Province.
* @apiSuccess {String} name  Name of the Province.
* @apiSuccess {Timestamp} created  Date and Time the Province is created.
* @apiSuccess {Timestamp} updated  Date and Time the Province is updated.
* @apiSuccess {Timestamp} deleted  Date and Time the Province is deleted.
* @apiSuccess {String} region_id  Region ID referenced from Region.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
       "provinces": [
            {
                "id": "58b66509-40d8-4600-9b32-56619fc6c0b5",
                "code": "CAV",
                "name": "Cavite",
                "created": "2018-07-11T00:58:10.000Z",
                "updated": "2018-07-11T01:01:34.000Z",
                "deleted": "2018-07-11T01:05:23.000Z",
                "region_id": "8c0d476e-ed0b-4e8f-9f6c-fe54ba4d6be4"
            }
        ],
        "success": true
    }
*
*/

const search = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const {
        region_id,
        code,
        name,
        created,
        updated,
        deleted
    } = req.query;

    [err, province] = await to(Province.findAll({
            include: [{
               model: Region,
                attributes: ['id', 'code', 'name'],
                required: true,
                include: [{
                   model: Country,
                    attributes: ['id', 'code', 'name'],
                    required: true
                }]
            }],

            where: {
                [Op.or]: [{'region_id': region_id}, 
                        {'code': code}, 
                        {'name': name}, 
                        {'created': created},
                        {'updated': updated}, 
                        {'deleted': deleted}]
            }
    }));
    return ReS(res, {'provinces': province});
};

module.exports = {
    'get'   : get,
    'getOne' : getOne,
    'create' : create,
    'update' : update,
    'deactivate' : deactivate,
    'reactivate' : reactivate,
    'search' : search
}