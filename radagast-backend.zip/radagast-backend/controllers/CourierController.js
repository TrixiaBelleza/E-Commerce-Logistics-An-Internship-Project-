const Courier = require('./../models').Courier;
const User = require('./../models').User;
const Log = require('./../models').log;
const Sequelize = require('sequelize');
const Op = Sequelize.Op;
const Authorized = require('./../models').authorized;
const authService   = require('./../services/AuthService');

/**
 * @api {post} /couriers addCourier
 * @apiGroup Courier
 * @apiName addCourier
 *
 * @apiParam (System Generated) {UUID} id ID of courier 
 * @apiParam (Body Params) {String} zone_id zone_id of courier referenced from zone
 * @apiParam (Body Params) {String} distribution_center_id distribution_center_id of courier referenced from distribution_center
 *
 * @apiSuccess {UUID} id ID of the courier
 * @apiSuccess {String} zone_id zone_id of courier referenced from zone
 * @apiSuccess {String} distribution_center_id distribution_center_id of courier referenced from zone
 * @apiSuccess {Timestamp} created Date and Time the courier is created.
 * @apiSuccess {Timestamp} updated Date and Time the courier is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the courier is deleted.
 * @apiSuccess {String} Message Successfully created new courier.
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *       "message": "Successfully created new courier",
 *       "courier": {
 *           "id": "8f573092-65f1-4b34-9542-a2a00355fae0",
 *           "created": {
 *               "val": "NOW()"
 *           },
 *           "user_id": "1",
 *           "zone_id": "ec7bbf22-64f2-40f3-856d-ec5237fb2107",
 *           "distribution_center_id": "1dbbeefc-b6a4-40e4-a85d-6c5362b4ec50"
 *       },
 *       "success": true
 *   }
 *
 * @apiError (Error 500) {Number} status status code
 * @apiError (Error 500) {String} message Error message
 * @apiErrorExample {json} Error-Response:
 *   HTTP/1.1 500 Internal Server Error
 *   {
 *     "status": 500,
 *     "message": "Internal server error"
 *   }
 */
const create = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}

    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    // //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    const {
        user_id,
        zone_id,
        distribution_center_id
    } = req.body;
    let courier;
    [err, courier] = await to(Courier.create({
        'user_id' : user_id,
        'zone_id' : zone_id,
        'distribution_center_id' : distribution_center_id
    }));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : courier,
        'result' : '201',
        'actor' : req.user.id
    }));
    return ReS(res, {'message' : 'Successfully created new courier',
                    'courier' : courier.toWeb(),
                    'log' : log}, 201);  
};

/**
 * @api {get} /couriers getCouriers
 * @apiGroup Courier
 * @apiName getCouriers
 *
 * @apiSuccess {UUID} id ID of the courier.
 * @apiSuccess  {String} zone_id zone_id of courier referenced from zone
 * @apiSuccess {String} distribution_center_id distribution_center_id of courier referenced from distribution_center
 * @apiSuccess {Timestamp} created Date and Time the courier is created.
 * @apiSuccess {Timestamp} updated Date and Time the courier is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the courier is deleted.
 * @apiSuccess {UUID} id ID of courier as user.
 * @apiSuccess {String} email Email of courier.
 * @apiSuccess {String} first_name First Name of courier.
 * @apiSuccess {String} last_name Last Name of courier.
 * @apiSuccess {String} middle_name Middle Name of courier.
 * @apiSuccess {String} contact_number Contact Number of courier.
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *       "couriers": [
 *           {
 *               "id": "1032a869-edda-4610-bcd9-dc2b45abf74e",
 *               "created": "2018-07-16T07:57:57.000Z",
 *               "updated": null,
 *               "deleted": null,
 *               "zone_id": "ec7bbf22-64f2-40f3-856d-ec5237fb2107",
 *               "distribution_center_id": "1dbbeefc-b6a4-40e4-a85d-6c5362b4ec50",
 *               "user_id": 1,
 *               "User": {
 *                   "id": 1,
 *                   "email": "ahabulan@gmail.com",
 *                   "first_name": "Aljay",
 *                   "last_name": "Habulan",
 *                   "middle_name": "Ranchez",
 *                   "contact_number": "09271238752"
 *               }
 *           },
 *           {
 *               "id": "1137023a-8ce8-45dd-8039-34abe5f71076",
 *               "created": "2018-07-16T07:57:06.000Z",
 *               "updated": null,
 *               "deleted": null,
 *               "zone_id": "ec7bbf22-64f2-40f3-856d-ec5237fb2107",
 *               "distribution_center_id": "1dbbeefc-b6a4-40e4-a85d-6c5362b4ec50",
 *               "user_id": 2,
 *               "User": {
 *                   "id": 1,
 *                   "email": "kzarzoso@gmail.com",
 *                   "first_name": "Kiara",
 *                   "last_name": "Zarzoso",
 *                   "middle_name": "Calbera",
 *                   "contact_number": "092715428752"
 *               }
 *           },
 *       ],
 *       "success": true
 *   }
 * 
 */
const get = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    [err, courier] = await to(Courier.findAll({
        include: [{
            model: User,
            attributes: ['id', 'email', 'first_name', 'last_name', 'middle_name', 'contact_number'],
            required: true
        }]
    }));
    return ReS(res, {'couriers' : courier});
};

/**
 * @api {getOne} /couriers/:id getOneCourier
 * @apiGroup Courier
 * @apiName getCourier
 *
 * @apiSuccess {UUID} id ID of the courier.
 * @apiSuccess {String} zone_id zone_id of courier referenced from zone
 * @apiSuccess {String} distribution_center_id distribution_center_id of courier referenced from distribution_center
 * @apiSuccess {Timestamp} created Date and Time the courier is created.
 * @apiSuccess {Timestamp} updated Date and Time the courier is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the courier is deleted.
 * @apiSuccess {UUID} id ID of courier as user.
 * @apiSuccess {String} email Email of courier.
 * @apiSuccess {String} first_name First Name of courier.
 * @apiSuccess {String} last_name Last Name of courier.
 * @apiSuccess {String} middle_name Middle Name of courier.
 * @apiSuccess {String} contact_number Contact Number of courier.
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *       "courier": {
 *           "id": "1032a869-edda-4610-bcd9-dc2b45abf74e",
 *           "created": "2018-07-16T07:57:57.000Z",
 *           "updated": null,
 *           "deleted": null,
 *           "zone_id": "ec7bbf22-64f2-40f3-856d-ec5237fb2107",
 *           "distribution_center_id": "1dbbeefc-b6a4-40e4-a85d-6c5362b4ec50",
 *           "user_id": 1,
 *           "User": {
 *               "id": 1,
 *               "email": "ahabulan@gmail.com",
 *               "first_name": "Aljay",
 *               "last_name": "Habulan",
 *               "middle_name": "Ranchez",
 *               "contact_number": "09271238752"
 *           }
 *       },
 *       "success": true
 *   }
 *
 */
const getOne = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const id = req.params.id;
    [err, courier] = await to(Courier.find({
        include: [{
            model: User,
            attributes: ['id', 'email', 'first_name', 'last_name', 'middle_name', 'contact_number'],
            required: true
        }]
    },
    {
        'where' : {
            'id' : id
        }
    }));
    return ReS(res, {'courier' : courier}, 201);
};

/**
 * @api {put} /couriers/:id updateCourier
 * @apiGroup Courier
 * @apiName updateCourier
 *
 * @apiParam (Body Params) {String} zone_id zone_id of courier referenced from zone
 * @apiParam (Body Params) {String} distribution_center_id distribution_center_id of courier referenced from distribution_center
 *
 * @apiSuccess {UUID} id ID of the courier.
 * @apiSuccess {String} zone_id zone_id of courier referenced from zone
 * @apiSuccess {String} distribution_center_id distribution_center_id of courier referenced from distribution_center
 * @apiSuccess {Timestamp} created Date and Time the courier is created.
 * @apiSuccess {Timestamp} updated Date and Time the courier is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the courier is deleted.
 * @apiSuccess {String} Message Update courier
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *      "courier": {
 *          "id": "1032a869-edda-4610-bcd9-dc2b45abf74e",
 *          "created": "2018-07-16T07:57:57.000Z",
 *          "updated": "2018-07-16T08:20:45.000Z",
 *          "deleted": null,
 *          "zone_id": "ec7bbf22-64f2-40f3-856d-ec5237fb2107",
 *          "distribution_center_id": "1dbbeefc-b6a4-40e4-a85d-6c5362b4ec50",
 *          "user_id": 2
 *      },
 *      "message": "update courier: 1032a869-edda-4610-bcd9-dc2b45abf74e",
 *      "success": true
 *  }
 *
 */

const update = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    const id = req.params.id;
    const {
        user_id,
        zone_id,
        distribution_center_id
    } = req.body;
    let courier;
    [err, courier] = await to(Courier.update({
        'user_id' : user_id,
        'zone_id'  : zone_id,
        'distribution_center_id' : distribution_center_id,
        'updated' : Sequelize.fn('NOW')
    },
    {
        'where' : {
            'id' : id
        }
    }));
    [err, courier] = await to(Courier.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : courier,
        'result' : '201',
        'actor' : req.user.id
    }));
    return ReS(res, {'courier' : courier.toWeb(),
                    'log' : log,
                    'message' : 'update courier: ' + id});
}

/**
 * @api {deactivate} /couriers/:id/deactivate deactivateCourier
 * @apiGroup Courier
 * @apiName deactivateCourier
 *
 * @apiSuccess {UUID} id ID of the courier.
 * @apiSuccess {String} zone_id zone_id of courier referenced from zone
 * @apiSuccess {String} distribution_center_id distribution_center_id of courier referenced from distribution_center
 * @apiSuccess {Timestamp} created Date and Time the courier is created.
 * @apiSuccess {Timestamp} updated Date and Time the courier is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the courier is deleted.
 * @apiSuccess {Message} Deactivated Courier
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *      "courier": {
 *          "id": "1032a869-edda-4610-bcd9-dc2b45abf74e",
 *          "created": "2018-07-16T07:57:57.000Z",
 *          "updated": "2018-07-16T08:20:45.000Z",
 *          "deleted": "2018-07-16T08:25:03.000Z",
 *          "zone_id": "ec7bbf22-64f2-40f3-856d-ec5237fb2107",
 *          "distribution_center_id": "1dbbeefc-b6a4-40e4-a85d-6c5362b4ec50",
 *          "user_id": 2
 *      },
 *      "message": "deactivated courier",
 *      "success": true
 *   }
 *
 */

const deactivate = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let courier;
    const id = req.params.id;
    [err, courier] = await to(Courier.update({
            deleted : Sequelize.fn('NOW')
        },
        {
            'where': {
                'id': id
            }
        }
    ));
    if (err) {
        return ReE(res, 'error occured trying to deactivate courier');
    }
    [err, courier] = await to(Courier.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : courier,
        'result' : '201',
        'actor' : req.user.id
    }));
    return ReS(res, {'courier' : courier.toWeb(),
                    'log' : log,
                    'message': 'deactivated courier'});
};

/**
 * @api {reactivate} /couriers/:id/reactivate reactivateCourier
 * @apiGroup Courier
 * @apiName reactivateCourier
 *
 * @apiSuccess {UUID} id ID of the courier.
 * @apiSuccess {String} zone_id zone_id of courier referenced from zone
 * @apiSuccess {String} distribution_center_id distribution_center_id of courier referenced from distribution_center
 * @apiSuccess {Timestamp} created Date and Time the courier is created.
 * @apiSuccess {Timestamp} updated Date and Time the courier is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the courier is deleted.
 * @apiSuccess {Message} Reactivated Courier
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *      "courier": {
 *          "id": "1032a869-edda-4610-bcd9-dc2b45abf74e",
 *          "created": "2018-07-16T07:57:57.000Z",
 *          "updated": "2018-07-16T08:20:45.000Z",
 *          "deleted": null,
 *          "zone_id": "ec7bbf22-64f2-40f3-856d-ec5237fb2107",
 *          "distribution_center_id": "1dbbeefc-b6a4-40e4-a85d-6c5362b4ec50",
 *          "user_id": 2
 *      },
 *      "message": "reactivated courier : 1032a869-edda-4610-bcd9-dc2b45abf74e",
 *      "success": true
 *   }  
 *
 */

const reactivate = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    const id = req.params.id;
    let courier;
    [err, courier] = await to(Courier.update({
        'deleted' : null
    },
    {
        'where' : {
            'id' : id
        }
    }));
    if (err) {
        return ReE(res, err);
    }
    [err, courier] = await to(Courier.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : courier,
        'result' : '201',
        'actor' : req.user.id
    }));
    return ReS(res, {'courier' : courier.toWeb(),
                    'log' : log,
                    'message' : 'reactivated courier : ' + id});
}

/**
 * @api {search} /couriers/search searchCourier
 * @apiGroup Courier
 * @apiName searchCourier
 *
 * @apiParam (Query Params) {UUID} id ID of courier 
 * @apiParam (Query Params) {String} zone_id zone_id of courier referenced from zone
 * @apiParam (Query Params) {String} distribution_center_id distribution_center_id of courier referenced from distribution_center
 * @apiParam (Query Params) {Timestamp} created Date and Time the courier is created
 * @apiParam (Query Params) {Timestamp} updated Date and Time the courier is updated
 * @apiParam (Query Params) {Timestamp} deleted Date and Time the courier is deleted
 *
 * @apiSuccess {UUID} id ID of the courier
 * @apiSuccess {String} zone_id zone_id of courier referenced from zone
 * @apiSuccess {String} distribution_center_id distribution_center_id of courier referenced from zone
 * @apiSuccess {Timestamp} created Date and Time the courier is created.
 * @apiSuccess {Timestamp} updated Date and Time the courier is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the courier is deleted.
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *      "courier": {
 *          "id": "1032a869-edda-4610-bcd9-dc2b45abf74e",
 *          "created": "2018-07-16T07:57:57.000Z",
 *          "updated": "2018-07-16T08:20:45.000Z",
 *          "deleted": null,
 *          "zone_id": "ec7bbf22-64f2-40f3-856d-ec5237fb2107",
 *          "distribution_center_id": "1dbbeefc-b6a4-40e4-a85d-6c5362b4ec50",
 *          "user_id": 2,
 *          "User": {
 *              "id": 2,
 *              "email": "kzarzoso@gmail.com",
 *              "first_name": "Kiara",
 *              "last_name": "Zarzoso",
 *              "middle_name": "Calbera",
 *              "contact_number": "09271542752"
 *          }
 *      },
 *      "success": true
 *   }  
 *
 */

const search = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const {
        user_id,
        zone_id,
        distribution_center_id,
        email,
        first_name,
        last_name,
        middle_name,
        contact_number
    } = req.query;
    let err, courier;
    [err, courier] = await to(Courier.findAll({
        include: [{
            model: User,
            attributes: ['id', 'email', 'first_name', 'last_name', 'middle_name', 'contact_number'],
            required: true
        }],
        where : {
            [Op.or] :
                [         
                    {'user_id' : user_id},
                    {'zone_id' : zone_id},
                    {'distribution_center_id' : distribution_center_id}
                ]
        }
    }));
    return ReS(res, {'couriers' : courier});
}

module.exports = {
    'create' : create,
    'get' : get,
    'getOne' : getOne,
    'update' : update,
    'deactivate' : deactivate,
    'reactivate' : reactivate,
    'search' : search
}