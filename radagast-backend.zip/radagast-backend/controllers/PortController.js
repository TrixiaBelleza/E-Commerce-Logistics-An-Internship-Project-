const Port   = require('./../models').port;
const Authorized = require('./../models').authorized;
const authService   = require('./../services/AuthService');
const Sequelize = require('sequelize');
const Op = Sequelize.Op;
/**
* @api {get} /v1/ports Get Ports
* @apiGroup Port
* @apiName Get Ports
*
* @apiSuccess {Object[]} ports array of ports
* @apiSuccess {UUID} ports.id ID of port
* @apiSuccess {String} ports.code code of port
* @apiSuccess {String} ports.name name of port
* @apiSuccess {String} ports.address address of port
* @apiSuccess {char} ports.country country
* @apiSuccess {char} ports.region region
* @apiSuccess {char} ports.province province
* @apiSuccess {char} ports.district district
* @apiSuccess {char} ports.sub_district sub_district
* @apiSuccess {Timestamp} ports.created timestamp of creation
* @apiSuccess {Timestamp} ports.updated timestamp when updated
* @apiSuccess {Timestamp} ports.deleted timestamp of deletion
* @apiSuccessExample {json} Success-Response:
*    {
*        "ports": [
*            {
*                "id": "8a94d745-1768-4ec8-8eff-7bbc8b889c26",
*                "code": "CEB",
*                "name": "Cebu Port",
*                "address": "Cebu",
*                "country": "PHL",
*                "region": "8",
*                "province": "n/a",
*                "district": "1",
*                "sub_district": "",
*                "created": "2018-07-11T02:24:08.000Z",
*                "updated": null,
*                "deleted": null
*            },
*            {
*                "id": "b2145f97-8985-42f6-8b43-3cd290872a69",
*                "code": "MNL",
*                "name": "Manila Port",
*                "address": "Manila",
*                "country": "PHL",
*                "region": "NCR",
*                "province": "n/a",
*                "district": "1",
*                "sub_district": "",
*                "created": "2018-07-11T02:17:53.000Z",
*                "updated": null,
*                "deleted": null
*            }
*        ],
*        "success": true
*    }
*
*/
const get = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    [err, port] = await to(Port.findAll())
    return ReS(res, {'ports': port});
};
 /**
* @api {get} /v1/ports/:id Get Port by ID
* @apiGroup Port
* @apiName Get Port by ID
* @apiParam {UUID} id Port's unique ID.
*
* @apiSuccess {Object} port new port
* @apiSuccess {UUID} port.id ID of port
* @apiSuccess {String} port.code code of port
* @apiSuccess {String} port.name name of port
* @apiSuccess {String} port.address address of port
* @apiSuccess {char} port.country country
* @apiSuccess {char} port.region region
* @apiSuccess {char} port.province province
* @apiSuccess {char} port.district district
* @apiSuccess {char} port.sub_district sub_district
* @apiSuccess {Timestamp} port.created timestamp of creation
* @apiSuccess {Timestamp} port.updated timestamp when updated
* @apiSuccess {Timestamp} port.deleted timestamp of deletion
* @apiSuccessExample {json} Success-Response:
*    {
*        "port": {
*            "id": "b2145f97-8985-42f6-8b43-3cd290872a69",
*            "code": "MNL",
*            "name": "Manila Port",
*            "address": "Manila",
*            "country": "PHL",
*            "region": "NCR",
*            "province": "n/a",
*            "district": "1",
*            "sub_district": "",
*            "created": "2018-07-11T02:17:53.000Z",
*            "updated": null,
*            "deleted": null
*        },
*        "success": true
*    }
*/

const getOne = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const id = req.params.id;
    [err, port] = await to(Port.findById(id))
    return ReS(res, {'port': port.toWeb()});
};

/**
* @api {post} /v1/ports Add Port
* @apiGroup Port
* @apiName Add Port
*
* @apiParam (System Generated) {UUID} id unique ID  
* @apiParam (Body Params) {String} code unique code for each port
* @apiParam (Body Params) {String} name name of port
* @apiParam (Body Params) {String} address address of the port
* @apiParam (Body Params) {char}   country country
* @apiParam (Body Params) {char}   region region
* @apiParam (Body Params) {char}   province province
* @apiParam (Body Params) {char}   district district
* @apiParam (Body Params) {char}   sub_district sub_district
*
* @apiSuccess {Object} port new port
* @apiSuccess {UUID} port.id ID of port
* @apiSuccess {String} port.code code of port
* @apiSuccess {String} port.name name of port
* @apiSuccess {String} port.address address of port
* @apiSuccess {char} port.country country
* @apiSuccess {char} port.region region
* @apiSuccess {char} port.province province
* @apiSuccess {char} port.district district
* @apiSuccess {char} port.sub_district sub_district
* @apiSuccess {Timestamp} port.created timestamp of creation
* @apiSuccess {Timestamp} port.updated timestamp when updated
* @apiSuccess {Timestamp} port.deleted timestamp of deletion
* @apiSuccessExample {json} Success-Response:
*    {
*        "message": "successfully created new port",
*        "port": {
*            "id": "b2145f97-8985-42f6-8b43-3cd290872a69",
*            "created": {
*                "val": "NOW()"
*            },
*            "updated": null,
*            "deleted": null,
*            "code": "MNL",
*            "name": "Manila Port",
*            "address": "Manila",
*            "country": "PHL",
*            "region": "NCR",
*            "province": "n/a",
*            "district": "1",
*           "sub_district": ""
*        },
*        "success": true
*    }
*/


const create = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    const {
        code,
        name,
        address,
        country,
        region,
        province,
        district,
        sub_district
    } = req.body;
    let  port;
    [err, port] = await to(Port.create({
        'code' :code,
        'name' :name,
        'address' :address,
        'country' :country,
        'region' :region,
        'province' :province,
        'district' :district,
        'sub_district' :sub_district
    }));
    if (err) {
        return ReE(res, err, 422);
    }
    return ReS(res, {'message':'successfully created new port', 'port': port.toWeb()}, 201);
};
/**
* @api {put} /v1/ports/:id Update Port by ID
* @apiName Update Port by ID
* @apiGroup Port
* @apiParam {UUID} id Port's unique ID.
*
* @apiParam (Body Params) {String} code unique code for each port
* @apiParam (Body Params) {String} name name of port
* @apiParam (Body Params) {String} address address of the port
* @apiParam (Body Params) {char}   country country
* @apiParam (Body Params) {char}   region region
* @apiParam (Body Params) {char}   province province
* @apiParam (Body Params) {char}   district district
* @apiParam (Body Params) {char}   sub_district sub_district
*
* @apiSuccess {Object} port new port
* @apiSuccess {UUID} port.id ID of port
* @apiSuccess {String} port.code code of port
* @apiSuccess {String} port.name name of port
* @apiSuccess {String} port.address address of port
* @apiSuccess {char} port.country country
* @apiSuccess {char} port.region region
* @apiSuccess {char} port.province province
* @apiSuccess {char} port.district district
* @apiSuccess {char} port.sub_district sub_district
* @apiSuccess {Timestamp} port.created timestamp of creation
* @apiSuccess {Timestamp} port.updated timestamp when updated
* @apiSuccess {Timestamp} port.deleted timestamp of deletion
* @apiSuccessExample {json} Success-Response:
*   {
*       "port": {
*           "id": "b2145f97-8985-42f6-8b43-3cd290872a69",
*           "code": "MNL",
*           "name": "Manila Port",
*           "address": "Manila",
*           "country": "PHL",
*           "region": "NCR",
*          "province": "n/a",
*           "district": "1",
*           "sub_district": "1",
*           "created": "2018-07-11T02:17:53.000Z",
*           "updated": "2018-07-11T02:33:17.000Z",
*           "deleted": null
*       },
*       "message": "update port: b2145f97-8985-42f6-8b43-3cd290872a69",
*       "success": true
*   }
*/


const update = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    let port;
    const id = req.params.id;
    const {
        code,
        name,
        address,
        country,
        region,
        province,
        district,
        sub_district
    } = req.body;
    [err, port] = await to(Port.update({
       'code' :code,
        'name' :name,
        'address' :address,
        'country' :country,
        'region' :region,
        'province' :province,
        'district' :district,
        'sub_district' :sub_district,
        updated : Sequelize.fn('NOW')
        }, {
            'where': {
                'id': id
            }
        }
    ));
    if (err) {
        return ReE(res, err);
    }
    [err, port] = await to(Port.findById(id))
    return ReS(res, {'port': port.toWeb(), 'message': 'update port: ' + id});
};

/**
* @api {post} /v1/ports/:id/deactivate Deactivate Port by ID
* @apiName Deactivate Port by ID
* @apiGroup Port
* @apiParam {UUID} id Port's unique ID.
*
* @apiSuccess {Object} port new port
* @apiSuccess {UUID} port.id ID of port
* @apiSuccess {String} port.code code of port
* @apiSuccess {String} port.name name of port
* @apiSuccess {String} port.address address of port
* @apiSuccess {char} port.country country
* @apiSuccess {char} port.region region
* @apiSuccess {char} port.province province
* @apiSuccess {char} port.district district
* @apiSuccess {char} port.sub_district sub_district
* @apiSuccess {Timestamp} port.created timestamp of creation
* @apiSuccess {Timestamp} port.updated timestamp when updated
* @apiSuccess {Timestamp} port.deleted timestamp of deletion
* @apiSuccessExample {json} Success-Response:
*   {
*       "message": "deactivated port",
*       "port": {
*           "id": "b2145f97-8985-42f6-8b43-3cd290872a69",
*           "code": "MNL",
*           "name": "Manila Port",
*           "address": "Manila",
*           "country": "PHL",
*           "region": "NCR",
*           "province": "n/a",
*           "district": "1",
*           "sub_district": "1",
*           "created": "2018-07-11T02:17:53.000Z",
*           "updated": "2018-07-11T02:33:17.000Z",
*           "deleted": "2018-07-11T02:37:45.000Z"
*       },
*       "success": true
*   }
 */
const deactivate = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    let port;
    const id = req.params.id;
    [err, port] = await to(Port.update({
            deleted : Sequelize.fn('NOW')
        },
        {
            'where': {
                'id': id
            }
        }
    ));
    if (err) {
        return ReE(res, 'error occured while deactivating port');
    }
    [err, port] = await to(Port.findById(id))
    return ReS(res, {'message': 'deactivated port','port': port.toWeb()});
};
/**
* @api {post} /v1/ports/:id/reactivate Reactivate Port by ID
* @apiName Reactivate Port by ID
* @apiGroup Port
* @apiParam {UUID} id Port's unique ID.
*
* @apiSuccess {Object} port new port
* @apiSuccess {UUID} port.id ID of port
* @apiSuccess {String} port.code code of port
* @apiSuccess {String} port.name name of port
* @apiSuccess {String} port.address address of port
* @apiSuccess {char} port.country country
* @apiSuccess {char} port.region region
* @apiSuccess {char} port.province province
* @apiSuccess {char} port.district district
* @apiSuccess {char} port.sub_district sub_district
* @apiSuccess {Timestamp} port.created timestamp of creation
* @apiSuccess {Timestamp} port.updated timestamp when updated
* @apiSuccess {Timestamp} port.deleted timestamp of deletion
* @apiSuccessExample {json} Success-Response:
*   {
*       "message": "reactivated port",
*       "port": {
*           "id": "b2145f97-8985-42f6-8b43-3cd290872a69",
*           "code": "MNL",
*           "name": "Manila Port",
*           "address": "Manila",
*           "country": "PHL",
*           "region": "NCR",
*           "province": "n/a",
*           "district": "1",
*           "sub_district": "1",
*           "created": "2018-07-11T02:17:53.000Z",
*           "updated": "2018-07-11T02:33:17.000Z",
*           "deleted": null
*       },
*       "success": true
*   }
 */
const reactivate = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    let port;
    const id = req.params.id;
    [err, port] = await to(Port.update({
            deleted : null
        },
        {
            'where': {
                'id': id
            }
        }
    ));
    if (err) {
        return ReE(res, 'error occured while reactivating port');
    }
    [err, port] = await to(Port.findById(id))
    return ReS(res, {'message': 'reactivated port','port': port.toWeb()});
};

module.exports = {

    'get'   : get,
    'getOne' : getOne,
    'create' : create,
    'update' : update,
    'deactivate' : deactivate,
    'reactivate' : reactivate
}