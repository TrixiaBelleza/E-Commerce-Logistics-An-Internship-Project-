const InboundOfficer = require('./../models').inbound_officer;
const User = require('./../models').User;
const Log = require('./../models').log;
const Sequelize = require('sequelize');
const Op = Sequelize.Op;
const Authorized = require('./../models').authorized;
const authService   = require('./../services/AuthService');


/**
 * @api {post} /inbound-officers addInboundOfficer
 * @apiGroup InboundOfficer
 * @apiName addInboundOfficer
 *
 * @apiParam (System Generated) {UUID} id ID of inbound officer 
 * @apiParam (Body Params) {String} hub_id hub_id of inbound officer referenced from hub
 * @apiParam (Body Params) {String} distribution_center_id distribution_center_id of inbound officer referenced from distribution_center
 *
 * @apiSuccess {UUID} id ID of the inbound officer
 * @apiSuccess {String} hub_id hub_id of inbound officer referenced from hub
 * @apiSuccess {String} distribution_center_id distribution_center_id of inbound officer referenced from hub
 * @apiSuccess {Timestamp} created Date and Time the inbound officer is created.
 * @apiSuccess {Timestamp} updated Date and Time the inbound officer is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the inbound officer is deleted.
 * @apiSuccess {String} Message Successfully created new inbound officer.
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *  {
 *      "message": "Successfully created new inbound officer",
 *      "inbound_officer": {
 *          "id": "0ca114d4-ad64-4b76-977e-97bcf58e6d4d",
 *          "created": {
 *              "val": "NOW()"
 *          },
 *          "user_id": "1",
 *          "hub_id": "12b356bd-0877-4b82-9c2a-fc5d26489bd4",
 *          "distribution_center_id": "da6d1764-a3c7-4e58-946a-7ab0fb4bf75c"
 *      },
 *      "success": true
 *  }
 *
 */
const create = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    const {
        user_id,
        hub_id,
        distribution_center_id
    } = req.body;
    let inbound_officer;
    [err, inbound_officer] = await to(InboundOfficer.create({
        'user_id' : user_id,
        'hub_id'  : hub_id,
        'distribution_center_id' : distribution_center_id
    }));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : inbound_officer,
        'result' : '201',
        'actor' : req.user.id
    }));
    return ReS(res, {'message' : 'Successfully created new inbound officer',
                    'inbound_officer' : inbound_officer.toWeb(),
                    'log' : log}, 201);  
};

/**
 * @api {get} /inbound-officers getInboundOfficers
 * @apiGroup InboundOfficer
 * @apiName getInboundOfficers
 *
 * @apiSuccess {UUID} id ID of the inbound officer.
 * @apiSuccess  {String} hub_id hub_id of inbound officer referenced from hub
 * @apiSuccess {String} distribution_center_id distribution_center_id of inbound officer referenced from distribution_center
 * @apiSuccess {Timestamp} created Date and Time the inbound officer is created.
 * @apiSuccess {Timestamp} updated Date and Time the inbound officer is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the inbound officer is deleted.
 * @apiSuccess {UUID} id ID of inbound officer as user.
 * @apiSuccess {String} email Email of inbound officer.
 * @apiSuccess {String} first_name First Name of inbound officer.
 * @apiSuccess {String} last_name Last Name of inbound officer.
 * @apiSuccess {String} middle_name Middle Name of inbound officer.
 * @apiSuccess {String} contact_number Contact Number of inbound officer.
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *      {
 *         "inbound_officers": [
 *             {
 *                 "id": "cab79e6e-e364-4c95-bd44-faefeee9ce41",
 *                 "hub_id": "797439a8-d074-46a3-bfb8-50e6af677857",
 *                 "distribution_center_id": "e6cb457e-653a-44e6-87d9-7eeab7c8448c",
 *                 "created": "2018-07-12T01:22:47.000Z",
 *                 "updated": null,
 *                 "deleted": null,
 *                 "user_id": 1,
 *                 "User": {
 *                     "id": 1,
 *                     "email": "ahabulan@gmail.com",
 *                     "first_name": "Aljay",
 *                     "last_name": "Habulan",
 *                     "middle_name": "Ranchez",
 *                     "contact_number": "09271238752"
 *                 }
 *             },
 *             {
 *                  "id": "cdbb4dc8-6dfe-482d-a00b-15ac3192397a",
 *                  "hub_id": "797439a8-d074-46a3-bfb8-50e6af677857",
 *                  "distribution_center_id": "e6cb457e-653a-44e6-87d9-7eeab7c8448c",
 *                  "created": "2018-07-12T01:31:57.000Z",
 *                  "updated": null,
 *                  "deleted": null,
 *                  "user_id": 2,
 *                  "User": {
 *                      "id": 2,
 *                      "email": "asdfghjkl111@gmail.com",
 *                      "first_name": "A",
 *                      "last_name": "B",
 *                      "middle_name": "C",
 *                      "contact_number": "091111111"
 *                  }
 *              }
 *         ],
 *         "success": true
 *      }
 *
 */
const get = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    [err, inbound_officer] = await to(InboundOfficer.findAll({
        include: [{
            model: User,
            attributes: ['id', 'email', 'first_name', 'last_name', 'middle_name', 'contact_number'],
            required: true
        }]
    }));
    return ReS(res, {'inbound_officers' : inbound_officer});
};

/**
 * @api {getOne} /inbound-officers/:id getOneInboundOfficer
 * @apiGroup InboundOfficer
 * @apiName getInboundOfficer
 *
 * @apiSuccess {UUID} id ID of the inbound officer.
 * @apiSuccess {String} hub_id hub_id of inbound officer referenced from hub
 * @apiSuccess {String} distribution_center_id distribution_center_id of inbound officer referenced from distribution_center
 * @apiSuccess {Timestamp} created Date and Time the inbound officer is created.
 * @apiSuccess {Timestamp} updated Date and Time the inbound officer is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the inbound officer is deleted.
 * @apiSuccess {UUID} id ID of inbound officer as user.
 * @apiSuccess {String} email Email of inbound officer.
 * @apiSuccess {String} first_name First Name of inbound officer.
 * @apiSuccess {String} last_name Last Name of inbound officer.
 * @apiSuccess {String} middle_name Middle Name of inbound officer.
 * @apiSuccess {String} contact_number Contact Number of inbound officer.
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *      {
 *          "inbound_officer": {
 *              "id": "cab79e6e-e364-4c95-bd44-faefeee9ce41",
 *              "hub_id": "797439a8-d074-46a3-bfb8-50e6af677857",
 *              "distribution_center_id": "e6cb457e-653a-44e6-87d9-7eeab7c8448c",
 *              "created": "2018-07-12T01:22:47.000Z",
 *              "updated": null,
 *              "deleted": null,
 *              "user_id": 1,
 *              "User": {
 *                  "id": 1,
 *                  "email": "ahabulan@gmail.com",
 *                  "first_name": "Aljay",
 *                  "last_name": "Habulan",
 *                  "middle_name": "Ranchez",
 *                  "contact_number": "09271238752"
 *              }
 *          },
 *          "success": true
 *      }
 *
 */
const getOne = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const id = req.params.id;
    [err, inbound_officer] = await to(InboundOfficer.find({
        include: [{
            model: User,
            attributes: ['id', 'email', 'first_name', 'last_name', 'middle_name', 'contact_number'],
            required: true
        }]
    },
    {
        'where' : {
            'id' : id
        }
    }));
    return ReS(res, {'inbound_officer' : inbound_officer}, 201);
};

/**
 * @api {put} /inbound-officers/:id updateInboundOfficer
 * @apiGroup InboundOfficer
 * @apiName updateInboundOfficer
 *
 * @apiParam (Body Params) {String} hub_id hub_id of inbound officer referenced from hub
 * @apiParam (Body Params) {String} distribution_center_id distribution_center_id of inbound officer referenced from distribution_center
 *
 * @apiSuccess {UUID} id ID of the inbound officer.
 * @apiSuccess {String} hub_id hub_id of inbound officer referenced from hub
 * @apiSuccess {String} distribution_center_id distribution_center_id of inbound officer referenced from distribution_center
 * @apiSuccess {Timestamp} created Date and Time the inbound officer is created.
 * @apiSuccess {Timestamp} updated Date and Time the inbound officer is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the inbound officer is deleted.
 * @apiSuccess {String} Message Update inbound officer
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *  {
 *      "message": "Update inbound officer 7c484cbd-3ffe-4d77-8b0a-958da424d4ea",
 *      "inbound_officer": {
 *          "id": "7c484cbd-3ffe-4d77-8b0a-958da424d4ea",
 *          "created": {
 *              "val": "NOW()"
 *          },
 *          "user_id": "2",
 *          "hub_id": "12b356bd-0877-4b82-9c2a-fc5d26489bd4",
 *          "distribution_center_id": "da6d1764-a3c7-4e58-946a-7ab0fb4bf75c"
 *      },
 *      "success": true
 *  }
 *
 */

const update = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    const id = req.params.id;
    const {
        user_id,
        hub_id,
        distribution_center_id
    } = req.body;
    let inbound_officer;
    [err, inbound_officer] = await to(InboundOfficer.update({
        'user_id' : user_id,
        'hub_id'  : hub_id,
        'distribution_center_id' : distribution_center_id,
        'updated' : Sequelize.fn('NOW')
    },
    {
        'where' : {
            'id' : id
        }
    }));
    [err, inbound_officer] = await to(InboundOfficer.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : inbound_officer,
        'result' : '201',
        'actor' : req.user.id
    }));
    return ReS(res, {'inbound_officer' : inbound_officer.toWeb(),
                    'log' : log,
                    'message' : 'update inbound officer: ' + id});
}

/**
 * @api {deactivate} /inbound-officers/:id/deactivate deactivateInboundOfficer
 * @apiGroup InboundOfficer
 * @apiName deactivateInboundOfficer
 *
 * @apiSuccess {UUID} id ID of the inbound officer.
 * @apiSuccess {String} hub_id hub_id of inbound officer referenced from hub
 * @apiSuccess {String} distribution_center_id distribution_center_id of inbound officer referenced from distribution_center
 * @apiSuccess {Timestamp} created Date and Time the inbound officer is created.
 * @apiSuccess {Timestamp} updated Date and Time the inbound officer is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the inbound officer is deleted.
 * @apiSuccess {Message} Deactivated Inbound Officer
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *      "inbound officer": {
 *          "id": "7c484cbd-3ffe-4d77-8b0a-958da424d4ea",
 *          "hub_id": "12b356bd-0877-4b82-9c2a-fc5d26489bd4",
 *          "distribution_center_id": "da6d1764-a3c7-4e58-946a-7ab0fb4bf75c",
 *          "created": "2018-07-04T07:15:23.000Z",
 *          "updated": null,
 *          "deleted": "2018-07-10T08:25:35.000Z",
 *          "user_id": 1
 *      },
 *      "message": "deactivated inbound officer",
 *      "success": true
 *   }
 *
 */

const deactivate = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let inbound_officer;
    const id = req.params.id;
    [err, inbound_officer] = await to(InboundOfficer.update({
            deleted : Sequelize.fn('NOW')
        },
        {
            'where': {
                'id': id
            }
        }
    ));
    if (err) {
        return ReE(res, 'error occured trying to deactivate inbound officer');
    }
    [err, inbound_officer] = await to(InboundOfficer.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : inbound_officer,
        'result' : '201',
        'actor' : req.user.id
    }));
    return ReS(res, {'inbound_officer' : inbound_officer.toWeb(),
                    'log' : log,
                    'message': 'deactivated inbound officer'});
};

/**
 * @api {reactivate} /inbound-officers/:id/reactivate reactivateInboundOfficer
 * @apiGroup InboundOfficer
 * @apiName reactivateInboundOfficer
 *
 * @apiSuccess {UUID} id ID of the inbound officer.
 * @apiSuccess {String} hub_id hub_id of inbound officer referenced from hub
 * @apiSuccess {String} distribution_center_id distribution_center_id of inbound officer referenced from distribution_center
 * @apiSuccess {Timestamp} created Date and Time the inbound officer is created.
 * @apiSuccess {Timestamp} updated Date and Time the inbound officer is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the inbound officer is deleted.
 * @apiSuccess {Message} Reactivated Inbound Officer
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *      "inbound officer": {
 *          "id": "7c484cbd-3ffe-4d77-8b0a-958da424d4ea",
 *          "hub_id": "12b356bd-0877-4b82-9c2a-fc5d26489bd4",
 *          "distribution_center_id": "da6d1764-a3c7-4e58-946a-7ab0fb4bf75c",
 *          "created": "2018-07-04T07:15:23.000Z",
 *          "updated": null,
 *          "deleted": null,
 *          "user_id": 1
 *      },
 *      "message": "reactivated inbound officer",
 *      "success": true
 *   }
 *
 */

const reactivate = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    const id = req.params.id;
    let inbound_officer;
    [err, inbound_officer] = await to(InboundOfficer.update({
        'deleted' : null
    },
    {
        'where' : {
            'id' : id
        }
    }));
    if (err) {
        return ReE(res, err);
    }
    [err, inbound_officer] = await to(InboundOfficer.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : inbound_officer,
        'result' : '201',
        'actor' : req.user.id
    }));
    return ReS(res, {'inbound_officer' : inbound_officer.toWeb(),
                    'log' : log,
                    'message' : 'reactivated inbound officer : ' + id});
}

/**
 * @api {search} /inbound-officers/search searchInboundOfficer
 * @apiGroup InboundOfficer
 * @apiName searchInboundOfficer
 *
 * @apiParam (Query Params) {UUID} id ID of inbound officer 
 * @apiParam (Query Params) {String} hub_id hub_id of inbound officer referenced from hub
 * @apiParam (Query Params) {String} distribution_center_id distribution_center_id of inbound officer referenced from distribution_center
 * @apiParam (Query Params) {Timestamp} created Date and Time the inbound officer is created
 * @apiParam (Query Params) {Timestamp} updated Date and Time the inbound officer is updated
 * @apiParam (Query Params) {Timestamp} deleted Date and Time the inbound officer is deleted
 *
 * @apiSuccess {UUID} id ID of the inbound officer
 * @apiSuccess {String} hub_id hub_id of inbound officer referenced from hub
 * @apiSuccess {String} distribution_center_id distribution_center_id of inbound officer referenced from hub
 * @apiSuccess {Timestamp} created Date and Time the inbound officer is created.
 * @apiSuccess {Timestamp} updated Date and Time the inbound officer is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the inbound officer is deleted.
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
  *  {
 *      "inbound_officer": [
 *          {
 *              "id": "7c484cbd-3ffe-4d77-8b0a-958da424d4ea",
 *              "hub_id": "12b356bd-0877-4b82-9c2a-fc5d26489bd4",
 *              "distribution_center_id": "da6d1764-a3c7-4e58-946a-7ab0fb4bf75c",
 *              "created": "2018-07-04T07:15:23.000Z",
 *              "updated": null,
 *              "deleted": "2018-07-10T08:25:35.000Z",
 *              "user_id": 1
 *          }
 *      ],
 *      "success": true
 *  }
 *
 */

const search = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const {
        user_id,
        hub_id,
        distribution_center_id,
        email,
        first_name,
        last_name,
        middle_name,
        contact_number
    } = req.query;
    let err, inbound_officer;
    [err, inbound_officer] = await to(InboundOfficer.findAll({
        include: [{
            model: User,
            attributes: ['id', 'email', 'first_name', 'last_name', 'middle_name', 'contact_number'],
            required: true
        }],
        where : {
            [Op.or] :
                [         
                    {'user_id' : user_id},
                    {'hub_id' : hub_id},
                    {'distribution_center_id' : distribution_center_id}
                ]
        }
    }));
    return ReS(res, {'inbound_officers' : inbound_officer});
}

module.exports = {
    'create' : create,
    'get' : get,
    'getOne' : getOne,
    'update' : update,
    'deactivate' : deactivate,
    'reactivate' : reactivate,
    'search' : search
}