const generator = require('generate-password');
const User   = require('./../models').User;
const authService   = require('./../services/AuthService');
const Sequelize = require('sequelize');
const nodemailer = require('nodemailer');

/**
* @api {post} /v1/forgot-password Forgot Password
* @apiName Forgot Password
* @apiGroup Password
* @apiParam {String} email User's email
* @apiSuccessExample {json} Success-Response:
* {
*     "user": {
*         "id": 1,
*         "email": "email@gmail.com",
*         "password": "$2b$10$xGfCsiLBFDam/5chkodHL.Ijle4mk07TB2TFsAuTsFK6HgnD62jfq",
*         "createdAt": "2018-07-09T07:23:52.000Z",
*         "updatedAt": "2018-07-09T07:23:52.000Z"
*     },
*     "success": true
* }
*/

const forgot_password = async (req, res) => {
    let user = req.user;
    const body = req.body;
    
 
    var new_password = generator.generate({
        length: 10,
        numbers: true,
        uppercase: true
    });

    console.log(new_password);



    var transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: 'youremail@gmail.com',
        pass: 'yourpassword'
      }
    });

    var mailOptions = {
      from: 'youremail@gmail.com',
      to: 'myfriend@yahoo.com',
      subject: 'Sending Email using Node.js',
      text: 'That was easy!'
    };

    transporter.sendMail(mailOptions, function(error, info){
      if (error) {
        console.log(error);
      } else {
        console.log('Email sent: ' + info.response);
      }
    });
    

    [err, user] = await to(User.findOne({
        'where': {'email': body.email}
    }));
    if (err) {
        return ReE(res, err, 422);
    }

    let updateValues = { password: new_password, updated : Sequelize.fn('NOW') };
    [err, user] = await to(User.findOne({
        'where': {'email': body.email}
    }));
    if (err) {
        return ReE(res, err, 422);
    }
    if(!user){
        return ReE(res, err, 422);
    }
    [err, user] = await to(user.update(updateValues));
    if (err) {
        return ReE(res, err, 422);
    }
    if(!user){
        return ReE(res, err, 422);
    }
   
     return ReS(res, {'user': user.toWeb()});
    
}

module.exports = {
    'forgot_password' : forgot_password
}