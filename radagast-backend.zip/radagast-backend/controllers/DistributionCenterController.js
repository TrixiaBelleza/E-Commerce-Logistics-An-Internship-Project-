const Distribution_center   = require('./../models').distribution_center;
const Log = require('./../models').log;
const Sequelize = require('sequelize');
const Op = Sequelize.Op;
const Authorized = require('./../models').authorized;
const authService   = require('./../services/AuthService');

/**
* @api {get} /v1/distribution-centers Get Distribution Centers
* @apiGroup Distribution Center
* @apiName Get Distribution Centers
*
* @apiSuccess {Object[]} distribution_centers array of distribution centers
* @apiSuccess {UUID} distribution_centers.id ID of distribution center
* @apiSuccess {String} distribution_centers.code code of distribution center
* @apiSuccess {String} distribution_centers.name name of distribution center
* @apiSuccess {String} distribution_centers.address address of distribution center
* @apiSuccess {char} distribution_centers.country country
* @apiSuccess {char} distribution_centers.region region
* @apiSuccess {char} distribution_centers.province province
* @apiSuccess {char} distribution_centers.district district
* @apiSuccess {char} distribution_centers.sub_district sub_district
* @apiSuccess {Timestamp} distribution_centers.created timestamp of creation
* @apiSuccess {Timestamp} distribution_centers.updated timestamp when updated
* @apiSuccess {Timestamp} distribution_centers.deleted timestamp of deletion
* @apiSuccessExample {json} Success-Response:
*    {
*        "distribution_centers": [
*            {
*                "id": "9da7a22e-9acf-44fc-8c5f-30107b334993",
*                "code": "SXZA1",
*                "name": "Los Banos Distribution Center",
*                "address": "Los Banos",
*                "country": "PHL",
*                "region": "4A",
*                "province": "LGN",
*                "district": "4",
*                "sub_district": "",
*                "barangay": "Anos",
*                "created": "2018-07-11T00:25:17.000Z",
*                "updated": null,
*                "deleted": null,
*                "hub_id": "8cf19a0b-c6fd-45f7-8859-678535befc60"
*            },
*            {
*                "id": "e5673532-de5b-4886-a24e-a447a58b4782",
*                "code": "SCDC",
*                "name": "Santa Cruz Distribution Center",
*                "address": "Santa Cruz",
*                "country": "PHL",
*                "region": "4A",
*                "province": "LGN",
*                "district": "4",
*                "sub_district": "",
*                "barangay": "Bagumbayan",
*                "created": "2018-07-11T00:27:45.000Z",
*                "updated": null,
*                "deleted": null,
*                "hub_id": "d3d16b9f-e0ea-46e7-9a15-d2cdcfdd484e"
*            }
*        ],
*        "success": true
*    }
*
*/
const get = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    [err, distribution_center] = await to(Distribution_center.findAll());
    return ReS(res, {'distribution_centers': distribution_center});

};


 /**
* @api {get} /v1/distribution-centers/:id Get Distribution Center by ID
* @apiGroup Distribution Center
* @apiName Get Distribution Center by ID
* @apiParam {UUID} id Users unique ID.
*
* @apiSuccess {Object} distribution_center new distribution_center
* @apiSuccess {UUID} distribution_center.id ID of distribution_center
* @apiSuccess {String} distribution_center.code code of distribution_center
* @apiSuccess {String} distribution_center.name name of distribution_center
* @apiSuccess {String} distribution_center.address address of distribution_center
* @apiSuccess {char} distribution_center.country country
* @apiSuccess {char} distribution_center.region region
* @apiSuccess {char} distribution_center.province province
* @apiSuccess {char} distribution_center.district district
* @apiSuccess {char} distribution_center.sub_district sub_district
* @apiSuccess {char} distribution_center.barangay barangay
* @apiSuccess {Timestamp} distribution_center.created timestamp of creation
* @apiSuccess {Timestamp} distribution_center.updated timestamp when updated
* @apiSuccess {Timestamp} distribution_center.deleted timestamp of deletion
* @apiSuccessExample {json} Success-Response:
*   {
*        "distribution_center": {
*            "id": "e5673532-de5b-4886-a24e-a447a58b4782",
*            "code": "SCDC",
*            "name": "Santa Cruz Distribution Center",
*            "address": "Santa Cruz",
*            "country": "PHL",
*            "region": "4A",
*            "province": "LGN",
*            "district": "4",
*            "sub_district": "",
*            "barangay": "Bagumbayan",
*            "created": "2018-07-11T00:27:45.000Z",
*            "updated": null,
*            "deleted": null,
*            "hub_id": "d3d16b9f-e0ea-46e7-9a15-d2cdcfdd484e"
*        },
*        "success": true
*    }
*
*/

const getOne = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const id = req.params.id;
    [err, distribution_center] = await to(Distribution_center.findById(id));
    return ReS(res, {'distribution_center': distribution_center.toWeb()});
};


/**
* @api {post} /v1/distribution-centers Add Distribution Center
* @apiGroup Distribution Center
* @apiName Add Distribution Center
*
* @apiParam (System Generated) {UUID} id unique ID  
* @apiParam (Body Params) {String} code unique code for each distribution center
* @apiParam (Body Params) {String} hub_id ID of the Hub the Distribution Center belongs to (foreign key)
* @apiParam (Body Params) {String} name name of distribution center
* @apiParam (Body Params) {String} address address of the distribution center
* @apiParam (Body Params) {char}   country country
* @apiParam (Body Params) {char}   region region
* @apiParam (Body Params) {char}   province province
* @apiParam (Body Params) {char}   district district
* @apiParam (Body Params) {char}   sub_district sub_district
* @apiParam (Body Params) {char}   barangay barangay
*
* @apiSuccess {Object} distribution_center new distribution_center
* @apiSuccess {UUID} distribution_center.id ID of distribution_center
* @apiSuccess {String} distribution_center.code code of distribution_center
* @apiSuccess {String} distribution_center.name name of distribution_center
* @apiSuccess {String} distribution_center.address address of distribution_center
* @apiSuccess {char} distribution_center.country country
* @apiSuccess {char} distribution_center.region region
* @apiSuccess {char} distribution_center.province province
* @apiSuccess {char} distribution_center.district district
* @apiSuccess {char} distribution_center.sub_district sub_district
* @apiSuccess {char} distribution_center.barangay barangay
* @apiSuccess {Timestamp} distribution_center.created timestamp of creation
* @apiSuccess {Timestamp} distribution_center.updated timestamp when updated
* @apiSuccess {Timestamp} distribution_center.deleted timestamp of deletion
*
* @apiSuccessExample {json} Success-Response:
*  {
*        "message": "successfully created new distribution_center",
*        "distribution_center": {
*            "id": "9da7a22e-9acf-44fc-8c5f-30107b334993",
*            "created": {
*                "val": "NOW()"
*            },
*            "updated": null,
*            "deleted": null,
*            "code": "SXZA1",
*            "hub_id": "8cf19a0b-c6fd-45f7-8859-678535befc60",
*            "name": "Los Banos Distribution Center",
*            "address": "Los Banos",
*            "country": "PHL",
*            "region": "4A",
*            "province": "LGN",
*            "district": "4",
*            "sub_district": "",
*            "barangay": "Anos"
*        },
*        "success": true
*    }
*/

const create = async (req, res) => {
     ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    const {
        hub_id,
        code,
        name,
        address,
        country,
        region,
        province,
        district,
        sub_district,
        barangay
    } = req.body;
    let distribution_center;
    [err, distribution_center] = await to(Distribution_center.create({
        'code' : code,
        'hub_id' : hub_id,
        'name' : name,
        'address' : address,
        'country' : country,
        'region' : region,
        'province' : province,
        'district' : district,
        'sub_district' : sub_district,
        'barangay' : barangay
    }));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : distribution_center,
        'result' : '201',
        'actor' : req.user.id
    }));
    return ReS(res, {'message':'successfully created new distribution_center', 
                    'distribution_center': distribution_center.toWeb(),
                    'log' : log}, 201);
};

/**
* @api {put} /v1/distribution-centers/:id Update Distribution Center by ID
* @apiName Update Distribution Center by ID
* @apiGroup Distribution Center
* @apiParam {UUID} id Distribution Center's unique ID.
*
* @apiParam (Body Params) {String} code unique code for each distribution center
* @apiParam (Body Params) {String} hub_id ID of the Hub the Distribution Center belongs to (foreign key)
* @apiParam (Body Params) {String} name name of distribution center
* @apiParam (Body Params) {String} address address of the distribution center
* @apiParam (Body Params) {char}   country country
* @apiParam (Body Params) {char}   region region
* @apiParam (Body Params) {char}   province province
* @apiParam (Body Params) {char}   district district
* @apiParam (Body Params) {char}   sub_district sub_district
* @apiParam (Body Params) {char}   barangay barangay
*
* @apiSuccess {Object} distribution_center new distribution_center
* @apiSuccess {UUID} distribution_center.id ID of distribution_center
* @apiSuccess {String} distribution_center.code code of distribution_center
* @apiSuccess {String} distribution_center.name name of distribution_center
* @apiSuccess {String} distribution_center.address address of distribution_center
* @apiSuccess {char} distribution_center.country country
* @apiSuccess {char} distribution_center.region region
* @apiSuccess {char} distribution_center.province province
* @apiSuccess {char} distribution_center.district district
* @apiSuccess {char} distribution_center.sub_district sub_district
* @apiSuccess {char} distribution_center.barangay barangay
* @apiSuccess {Timestamp} distribution_center.created timestamp of creation
* @apiSuccess {Timestamp} distribution_center.updated timestamp when updated
* @apiSuccess {Timestamp} distribution_center.deleted timestamp of deletion
* @apiSuccessExample {json} Success-Response:
*    {
*        "distribution_center": {
*            "id": "9da7a22e-9acf-44fc-8c5f-30107b334993",
*            "code": "",
*            "name": "",
*            "address": "",
*            "country": "",
*            "region": "",
*            "province": "",
*            "district": "",
*            "sub_district": "1",
*            "barangay": "",
*            "created": "2018-07-11T00:25:17.000Z",
*            "updated": "2018-07-11T00:52:43.000Z",
*            "deleted": null,
*            "hub_id": "8cf19a0b-c6fd-45f7-8859-678535befc60"
*        },
*        "message": "update distribution_center: 9da7a22e-9acf-44fc-8c5f-30107b334993",
*        "success": true
*    }
*/

const update = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let distribution_center;
    const id = req.params.id;
    const {
        code,
        name,
        address,
        country,
        region,
        province,
        district,
        sub_district,
        barangay
    } = req.body;
    [err, distribution_center] = await to(Distribution_center.update({
       'code' :code,
        'name' :name,
        'address' :address,
        'country' :country,
        'region' :region,
        'province' :province,
        'district' :district,
        'sub_district' :sub_district,
        'barangay' :barangay,
        'updated' : Sequelize.fn('NOW')
        
        }, {
            'where': {
                'id': id
            }
        }
    ));
    [err, distribution_center] = await to(Distribution_center.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : distribution_center,
        'result' : '201',
        'actor' : req.user.id
    }));
    return ReS(res, {'distribution_center': distribution_center.toWeb(), 
                    'message': 'update distribution_center: ' + id,
                    'log' : log});
};


/**
* @api {get} /v1/distribution-centers/search Search Distribution Center
* @apiName Search Distribution Center
* @apiGroup Distribution Center
*
* @apiParam (Parameter) {UUID}   id Distribution Center's unique ID
* @apiParam (Parameter) {String} code unique code for each distribution center
* @apiParam (Parameter) {String} hub_id ID of the Hub the Distribution Center belongs to (foreign key)
* @apiParam (Parameter) {String} name name of distribution center
* @apiParam (Parameter) {String} address address of the distribution center
* @apiParam (Parameter) {char}   country country
* @apiParam (Parameter) {char}   region region
* @apiParam (Parameter) {char}   province province
* @apiParam (Parameter) {char}   district district
* @apiParam (Parameter) {char}   sub_district sub_district
* @apiParam (Parameter) {char}   barangay barangay
*
* @apiSuccess {Object[]} distribution_centers array of distribution centers
* @apiSuccess {UUID} distribution_centers.id ID of distribution center
* @apiSuccess {String} distribution_centers.code code of distribution center
* @apiSuccess {String} distribution_centers.name name of distribution center
* @apiSuccess {String} distribution_centers.address address of distribution center
* @apiSuccess {char} distribution_centers.country country
* @apiSuccess {char} distribution_centers.region region
* @apiSuccess {char} distribution_centers.province province
* @apiSuccess {char} distribution_centers.district district
* @apiSuccess {char} distribution_centers.sub_district sub_district
* @apiSuccess {Timestamp} distribution_centers.created timestamp of creation
* @apiSuccess {Timestamp} distribution_centers.updated timestamp when updated
* @apiSuccess {Timestamp} distribution_centers.deleted timestamp of deletion
* @apiSuccessExample {json} Success-Response:
*    {
*        "distribution_center": [
*            {
*                "id": "e5673532-de5b-4886-a24e-a447a58b4782",
*                "code": "SCDC",
*                "name": "Santa Cruz Distribution Center",
*                "address": "Santa Cruz",
*                "country": "PHL",
*                "region": "4A",
*                "province": "LGN",
*                "district": "4",
*                "sub_district": "",
*                "barangay": "Bagumbayan",
*                "created": "2018-07-11T00:27:45.000Z",
*                "updated": null,
*                "deleted": null,
*                "hub_id": "d3d16b9f-e0ea-46e7-9a15-d2cdcfdd484e"
*            }
*        ],
*        "success": true
*    }
*/

const search = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const {
        id,
        hub_id,
        code,
        name,
        address,
        country,
        region,
        province,
        district,
        sub_district,
        created,
        updated,
        deleted
    } = req.query;

    [err, distribution_center] = await to(Distribution_center.findAll({
            where: {
                [Op.or]: [{'id': id}, {'hub_id':hub_id},{'code': code}, {'name': name}, {'address' : address}, {'country' : country},{'region' : region},
                {'province' : province},{'district': district},
                {'sub_district':sub_district}, {'created': created}, {'updated': updated}, {'deleted': deleted}]
            }
    }));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422'
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : distribution_center,
        'result' : '201'
    }));
    return ReS(res, {'distribution_center': distribution_center,
                    'log' : log});
};

/**
* @api {post} /v1/distribution-centers/:id/deactivate Deactivate Distribution Center by ID
* @apiName Deactivate Distribution Center by ID
* @apiGroup Distribution Center
* @apiParam {UUID} id Distribution Center's unique ID.
*
* @apiSuccess {Object} distribution_center new distribution_center
* @apiSuccess {UUID} distribution_center.id ID of distribution_center
* @apiSuccess {String} distribution_center.code code of distribution_center
* @apiSuccess {String} distribution_center.name name of distribution_center
* @apiSuccess {String} distribution_center.address address of distribution_center
* @apiSuccess {char} distribution_center.country country
* @apiSuccess {char} distribution_center.region region
* @apiSuccess {char} distribution_center.province province
* @apiSuccess {char} distribution_center.district district
* @apiSuccess {char} distribution_center.sub_district sub_district
* @apiSuccess {char} distribution_center.barangay barangay
* @apiSuccess {Timestamp} distribution_center.created timestamp of creation
* @apiSuccess {Timestamp} distribution_center.updated timestamp when updated
* @apiSuccess {Timestamp} distribution_center.deleted timestamp of deletion
* @apiSuccessExample {json} Success-Response:
*   {
*       "message": "deactivated distribution_center",
*       "destination": {
*           "id": "e5673532-de5b-4886-a24e-a447a58b4782",
*           "code": "SCDC",
*           "name": "Santa Cruz Distribution Center",
*           "address": "Santa Cruz",
*           "country": "PHL",
*           "region": "4A",
*           "province": "LGN",
*           "district": "4",
*           "sub_district": "",
*           "barangay": "Bagumbayan",
*           "created": "2018-07-11T00:27:45.000Z",
*           "updated": null,
*           "deleted": "2018-07-11T01:20:04.000Z",
*           "hub_id": "d3d16b9f-e0ea-46e7-9a15-d2cdcfdd484e"
*       },
*       "success": true
*   }
*/


const deactivate = async (req, res) => {
     ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let distribution_center;
    const id = req.params.id;
    [err, distribution_center] = await to(Distribution_center.update({
            deleted : Sequelize.fn('NOW')
        },
        {
            'where': {
                'id': id
            }
        }
    ));
    [err, distribution_center] = await to(Distribution_center.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }

    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : distribution_center,
        'result' : '201',
        'actor' : req.user.id
    }));
    return ReS(res, {'message': 'deactivated distribution_center',
                    'destination': distribution_center.toWeb(),
                    'log' : log});
};

/**
* @api {post} /v1/distribution-centers/:id/reactivate Reactivate Distribution Center by ID
* @apiName Reactivate Distribution Center by ID
* @apiGroup Distribution Center
* @apiParam {UUID} id Distribution Center's unique ID.
* @apiSuccess {Object} distribution_center new distribution_center
* @apiSuccess {UUID} distribution_center.id ID of distribution_center
* @apiSuccess {String} distribution_center.code code of distribution_center
* @apiSuccess {String} distribution_center.name name of distribution_center
* @apiSuccess {String} distribution_center.address address of distribution_center
* @apiSuccess {char} distribution_center.country country
* @apiSuccess {char} distribution_center.region region
* @apiSuccess {char} distribution_center.province province
* @apiSuccess {char} distribution_center.district district
* @apiSuccess {char} distribution_center.sub_district sub_district
* @apiSuccess {char} distribution_center.barangay barangay
* @apiSuccess {Timestamp} distribution_center.created timestamp of creation
* @apiSuccess {Timestamp} distribution_center.updated timestamp when updated
* @apiSuccess {Timestamp} distribution_center.deleted timestamp of deletion
* @apiSuccessExample {json} Success-Response:
*    {
*        "message": "reactivated distribution_center",
*        "destination": {
*            "id": "e5673532-de5b-4886-a24e-a447a58b4782",
*            "code": "SCDC",
*            "name": "Santa Cruz Distribution Center",
*            "address": "Santa Cruz",
*            "country": "PHL",
*            "region": "4A",
*            "province": "LGN",
*            "district": "4",
*            "sub_district": "",
*            "barangay": "Bagumbayan",
*            "created": "2018-07-11T00:27:45.000Z",
*            "updated": null,
*            "deleted": null,
*            "hub_id": "d3d16b9f-e0ea-46e7-9a15-d2cdcfdd484e"
*        },
*        "success": true
*    }
*/


const reactivate = async (req, res) => {
     ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let distribution_center;
    const id = req.params.id;
    [err, distribution_center] = await to(Distribution_center.update({
            deleted : null
        },
        {
            'where': {
                'id': id
            }
        }
    ));
    if (err) {
        return ReE(res, 'error occured while reactivating distribution_center');
    }
    [err, distribution_center] = await to(Distribution_center.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : distribution_center,
        'result' : '201',
        'actor' : req.user.id
    }));
    return ReS(res, {'message': 'reactivated distribution_center',
                    'destination': distribution_center.toWeb(),
                    'log' : log});
};

module.exports = {
    'get'   : get,
    'getOne' : getOne,
    'create' : create,
    'update' : update,
    'search' : search,
    'deactivate' : deactivate,
    'reactivate' : reactivate
}
