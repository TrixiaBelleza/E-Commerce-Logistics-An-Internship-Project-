const CustomerSupport  = require('./../models').customer_support;
const Log = require('./../models').log;
const User = require('./../models').User;
const Sequelize = require('sequelize');
const Op = Sequelize.Op;
const Authorized = require('./../models').authorized;
const authService   = require('./../services/AuthService');


/**
* @api {get} /customer-supports Retrieve Customer Supports
* @apiName GetCustomerSupports
* @apiGroup Customer Support
*
* @apiSuccess {String} id Customer Support ID.
* @apiSuccess {Timestamp} created  Date and Time the Customer Support is created.
* @apiSuccess {Timestamp} updated  Date and Time the Customer Support is updated.
* @apiSuccess {Timestamp} deleted  Date and Time the Customer Support is deleted.
* @apiSuccess {String} hub_id  Hub ID referenced from Hub.
* @apiSuccess {Float} distribution_center_id  Distribution Center ID referenced from Distribution Center.
* @apiSuccess {String} user_id  User ID referenced from User.
* @apiSuccess {String} user_id.email  Email Address of the Customer Support.
* @apiSuccess {String} user_id.first_name  First Name of the Customer Support.
* @apiSuccess {String} user_id.last_name  Last Name of the Customer Support.
* @apiSuccess {String} user_id.middle_name  Middle Name of the Customer Support.
* @apiSuccess {String} user_id.contact_number  Contact Number of the Customer Support.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
        "customer_supports": [
            {
                "id": "19de5e99-27ab-476b-a815-e8edabc881e7",
                "created": "2018-07-12T02:14:01.000Z",
                "updated": null,
                "deleted": null,
                "user_id": 1,
                "hub_id": "5ca82e33-f401-4985-a329-33c62f791c23",
                "distribution_center_id": "cc5c5aa7-16c0-4173-87f2-f9172661cafc",
                "User": {
                    "email": "jdelacruz@gmail.com",
                    "first_name": "Juan",
                    "last_name": "Dela Cruz",
                    "middle_name": "Reyes",
                    "contact_number": "09096755833"
                }
            }
        ],
        "success": true
    }
*
*/

const get = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    [err, customer_supports] = await to(CustomerSupport.findAll({
        include: [{
            model: User,
            attributes: ['email', 'first_name', 'last_name', 'middle_name', 'contact_number'],
            required: true
        }]
    }));
    return ReS(res, {'customer_supports': customer_supports});
};

/**
* @api {get} /customer-supports/:id Retrieve Customer Support By ID
* @apiName GetCustomerSupportByID
* @apiGroup Customer Support
*
* @apiParam {String} id Customer Support unique ID.
*
* @apiSuccess {String} id Customer Support ID.
* @apiSuccess {Timestamp} created  Date and Time the Customer Support is created.
* @apiSuccess {Timestamp} updated  Date and Time the Customer Support is updated.
* @apiSuccess {Timestamp} deleted  Date and Time the Customer Support is deleted.
* @apiSuccess {String} hub_id  Hub ID referenced from Hub.
* @apiSuccess {Float} distribution_center_id  Distribution Center ID referenced from Distribution Center.
* @apiSuccess {String} user_id  User ID referenced from User.
* @apiSuccess {String} user_id.email  Email Address of the Customer Support.
* @apiSuccess {String} user_id.first_name  First Name of the Customer Support.
* @apiSuccess {String} user_id.last_name  Last Name of the Customer Support.
* @apiSuccess {String} user_id.middle_name  Middle Name of the Customer Support.
* @apiSuccess {String} user_id.contact_number  Contact Number of the Customer Support.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
        "customer_support": {
            "id": "19de5e99-27ab-476b-a815-e8edabc881e7",
            "created": "2018-07-12T02:14:01.000Z",
            "updated": null,
            "deleted": null,
            "user_id": 1,
            "hub_id": "5ca82e33-f401-4985-a329-33c62f791c23",
            "distribution_center_id": "cc5c5aa7-16c0-4173-87f2-f9172661cafc",
            "User": {
                "email": "jdelacruz@gmail.com",
                "first_name": "Juan",
                "last_name": "Dela Cruz",
                "middle_name": "Reyes",
                "contact_number": "09096755833"
            }
        },
        "success": true
    }
*
*/

const getOne = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const id = req.params.id;
    [err, customer_support] = await to(CustomerSupport.find({
            include: [{
               model: User,
                attributes: ['email', 'first_name', 'last_name', 'middle_name', 'contact_number'],
                required: true
            }],

            'where' : {
                'id' : id
            }
    }));
    return ReS(res, {'customer_support': customer_support.toWeb()});
};

/**
* @api {post} /customer-supports Add Customer Support
* @apiName AddCustomerSupport
* @apiGroup Customer Support
*
* @apiParam (System Generated) {String} id Customer Support unique ID.
* @apiParam (Body Params) {String} user_id  User ID.
* @apiParam (Body Params) {String} hub_id  Hub ID.
* @apiParam (Body Params) {String} distribution_center_id  Distribution Center ID.
*
* @apiSuccess {Timestamp} created  Date and Time the Customer Support is created.
* @apiSuccess {Timestamp} updated  Date and Time the Customer Support is updated.
* @apiSuccess {Timestamp} deleted  Date and Time the Customer Support is deleted.
* @apiSuccess {String} user_id  User ID referenced from User.
* @apiSuccess {String} hub_id  Hub ID referenced from Hub.
* @apiSuccess {String} distribution_center_id  Distribution Center ID referenced from Distribution Center.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
        "message": "successfully created new dispatcher",
        "dispatcher": {
            "id": "9bff837f-b416-49c8-9000-62ec09e2ff3d",
            "created": {
                "val": "NOW()"
            },
            "updated": null,
            "deleted": null,
            "user_id": "1",
            "hub_id": "5ca82e33-f401-4985-a329-33c62f791c23",
            "distribution_center_id": "cc5c5aa7-16c0-4173-87f2-f9172661cafc"
        },
        "success": true
    }
*
*/

const create = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    const {
        user_id,
        hub_id,
        distribution_center_id
    } = req.body;
    let customer_support;
    let user = req.user;
    [err, customer_support] = await to(CustomerSupport.create({
        'user_id' : user_id,
        'hub_id'  : hub_id,
        'distribution_center_id' : distribution_center_id
    }));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : customer_support,
        'result' : '201',
        'actor' : user.id
    }));
    return ReS(res, {'message':'successfully created new customer_support', 
                    'customer_support': customer_support.toWeb(),
                    'log' : log}, 201);
};

/**
* @api {put} /customer-supports/:id Update Customer Support
* @apiName UpdateCustomerSupportByID
* @apiGroup Customer Support
*
* @apiParam {String} id Customer Support unique ID.
* @apiParam (Body Params) {String} user_id  User ID.
* @apiParam (Body Params) {String} hub_id  Hub ID.
* @apiParam (Body Params) {String} distribution_center_id  Distribution Center ID.
*
* @apiSuccess {Timestamp} created  Date and Time the Customer Support is created.
* @apiSuccess {Timestamp} updated  Date and Time the Customer Support is updated.
* @apiSuccess {Timestamp} deleted  Date and Time the Customer Support is deleted.
* @apiSuccess {String} user_id  User ID referenced from User.
* @apiSuccess {String} hub_id  Hub ID referenced from Hub.
* @apiSuccess {String} distribution_center_id  Distribution Center ID referenced from Distribution Center.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
        "customer_support": {
            "id": "19de5e99-27ab-476b-a815-e8edabc881e7",
            "created": "2018-07-12T02:14:01.000Z",
            "updated": null,
            "deleted": null,
            "user_id": 1,
            "hub_id": "5ca82e33-f401-4985-a329-33c62f791c23",
            "distribution_center_id": "cc5c5aa7-16c0-4173-87f2-f9172661cafc"
        },
        "message": "update customer_support: 19de5e99-27ab-476b-a815-e8edabc881e7",
        "success": true
    }
*
*/

const update = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let customer_support;
    let user = req.user;
    const id = req.params.id;
    const {
    	user_id,
        hub_id,
        distribution_center_id
    } = req.body;
    [err, customer_support] = await to(CustomerSupport.update({
    	'user_id' : user_id,
        'hub_id'  : hub_id,
        'distribution_center_id' : distribution_center_id,
        'updated' : Sequelize.fn('NOW')
        }, {
            'where': {
                'id': id
            }
        }
    ));
    [err, customer_support] = await to(CustomerSupport.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : customer_support,
        'result' : '201',
        'actor' : user.id
    }));
    return ReS(res, {'customer_support': customer_support.toWeb(), 
                    'message': 'update customer_support: ' + id,
                    'log' : log});
};

/**
* @api {post} /customer-supports/:id/deactivate Deactivate Customer Support
* @apiName DeactivateCustomerSupport
* @apiGroup Customer Support
*
* @apiParam {String} id Customer Support unique ID.
*
* @apiSuccess {Timestamp} created  Date and Time the Customer Support is created.
* @apiSuccess {Timestamp} updated  Date and Time the Customer Support is updated.
* @apiSuccess {Timestamp} deleted  Date and Time the Customer Support is deleted.
* @apiSuccess {String} user_id  User ID referenced from User.
* @apiSuccess {String} hub_id  Hub ID referenced from Hub.
* @apiSuccess {String} distribution_center_id  Distribution Center ID referenced from Distribution Center.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
        "customer_support": {
            "id": "19de5e99-27ab-476b-a815-e8edabc881e7",
            "created": "2018-07-12T02:14:01.000Z",
            "updated": null,
            "deleted": "2018-07-12T02:55:58.000Z",
            "user_id": 1,
            "hub_id": "5ca82e33-f401-4985-a329-33c62f791c23",
            "distribution_center_id": "cc5c5aa7-16c0-4173-87f2-f9172661cafc"
        },
        "message": "deactivated customer_support: 19de5e99-27ab-476b-a815-e8edabc881e7",
        "success": true
    }
*
*/

const deactivate = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let customer_support;
    let user = req.user;
    const id = req.params.id;
    [err, customer_support] = await to(CustomerSupport.update({
            'deleted' : Sequelize.fn('NOW')
        },
        {
            'where': {
                'id': id
            }
        }
    ));
    [err, customer_support] = await to(CustomerSupport.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : customer_support,
        'result' : '201',
        'actor' : user.id
    }));
    return ReS(res, {'customer_support': customer_support.toWeb(), 
                    'message': 'deactivated customer_support: ' + id,
                    'log' : log});
};

/**
* @api {post} /customer-supports/:id/reactivate Reactivate Customer Support
* @apiName ReactivateCustomerSupport
* @apiGroup Customer Support
*
* @apiParam {String} id Customer Support unique ID.
*
* @apiSuccess {Timestamp} created  Date and Time the Customer Support is created.
* @apiSuccess {Timestamp} updated  Date and Time the Customer Support is updated.
* @apiSuccess {Timestamp} deleted  Date and Time the Customer Support is deleted.
* @apiSuccess {String} user_id  User ID referenced from User.
* @apiSuccess {String} hub_id  Hub ID referenced from Hub.
* @apiSuccess {String} distribution_center_id  Distribution Center ID referenced from Distribution Center.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
        "customer_support": {
            "id": "19de5e99-27ab-476b-a815-e8edabc881e7",
            "created": "2018-07-12T02:14:01.000Z",
            "updated": null,
            "deleted": "2018-07-12T02:55:58.000Z",
            "user_id": 1,
            "hub_id": "5ca82e33-f401-4985-a329-33c62f791c23",
            "distribution_center_id": "cc5c5aa7-16c0-4173-87f2-f9172661cafc"
        },
        "message": "reactivated customer_support: 19de5e99-27ab-476b-a815-e8edabc881e7",
        "success": true
    }
*
*/

const reactivate = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let customer_support;
    let user = req.user;
    const id = req.params.id;
    [err, customer_support] = await to(CustomerSupport.update({
            'deleted' : null
        },
        {
            'where': {
                'id': id
            }
        }
    ));
    [err, customer_support] = await to(CustomerSupport.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : customer_support,
        'result' : '201',
        'actor' : user.id
    }));
    return ReS(res, {'customer_support': customer_support.toWeb(), 
                    'message': 'reactivated customer_support: ' + id,
                    'log' : log});
};

/**
* @api {get} /customer-supports/search Search Customer Support
* @apiName SearchCustomerSupport
* @apiGroup Customer Support
*
* @apiParam (Body Params) {String} user_id  User ID.
* @apiParam (Body Params) {String} hub_id  Hub ID.
* @apiParam (Body Params) {String} distribution_center_id  Distribution Center ID.
*
* @apiSuccess {Timestamp} created  Date and Time the Customer Support is created.
* @apiSuccess {Timestamp} updated  Date and Time the Customer Support is updated.
* @apiSuccess {Timestamp} deleted  Date and Time the Customer Support is deleted.
* @apiSuccess {String} hub_id  Hub ID referenced from Hub.
* @apiSuccess {String} distribution_center_id  Distribution Center ID referenced from Distribution Center.
* @apiSuccess {String} user_id  User ID referenced from User.
* @apiSuccess {String} user_id.email  Email Address of the Customer Support.
* @apiSuccess {String} user_id.first_name  First Name of the Customer Support.
* @apiSuccess {String} user_id.last_name  Last Name of the Customer Support.
* @apiSuccess {String} user_id.middle_name  Middle Name of the Customer Support.
* @apiSuccess {String} user_id.contact_number  Contact Number of the Customer Support.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
        "customer supports": [
            {
                "id": "19de5e99-27ab-476b-a815-e8edabc881e7",
                "created": "2018-07-12T02:14:01.000Z",
                "updated": null,
                "deleted": null,
                "user_id": 1,
                "hub_id": "5ca82e33-f401-4985-a329-33c62f791c23",
                "distribution_center_id": "cc5c5aa7-16c0-4173-87f2-f9172661cafc",
                "User": {
                    "email": "jdelacruz@gmail.com",
                    "first_name": "Juan",
                    "last_name": "Dela Cruz",
                    "middle_name": "Reyes",
                    "contact_number": "09096755833"
                }
            }
        ],
        "success": true
    }
*
*/


const search = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const {
        user_id,
        hub_id,
        distribution_center_id,
        created,
        updated,
        deleted,
        first_name
    } = req.query;

    [err, customer_support] = await to(CustomerSupport.findAll({
            include: [{
               model: User,
                attributes: ['email', 'first_name', 'last_name', 'middle_name', 'contact_number'],
                required: true
            }],

            'where' : {
                [Op.or]: [{'user_id': user_id}, 
                        {'hub_id': hub_id}, 
                        {'distribution_center_id': distribution_center_id}, 
                        {'created': created}, 
                        {'updated': updated}, 
                        {'deleted': deleted}]
            }
    }));
    return ReS(res, {'customer supports': customer_support});
};

module.exports = {
    'get'   : get,
    'create' : create,
    'getOne' : getOne,
    'deactivate' : deactivate,
    'reactivate' : reactivate,
    'update' : update,
    'search' : search
}