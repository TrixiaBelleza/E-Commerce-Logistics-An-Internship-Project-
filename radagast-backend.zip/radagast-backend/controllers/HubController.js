const Hub   = require('./../models').hub;
const Log = require('./../models').log;
const Sequelize = require('sequelize');
const Op = Sequelize.Op;
const Authorized = require('./../models').authorized;
const authService   = require('./../services/AuthService');

/**
* @api {get} /v1/hubs Get Hubs
* @apiGroup Hub
* @apiName Get Hubs
*
* @apiSuccess {Object[]} hubs array of hubs
* @apiSuccess {UUID} hubs.id ID of Hub
* @apiSuccess {String} hubs.code code of Hub
* @apiSuccess {String} hubs.name name of Hub
* @apiSuccess {String} hubs.address address of Hub
* @apiSuccess {char} hubs.country country
* @apiSuccess {char} hubs.region region
* @apiSuccess {char} hubs.province province
* @apiSuccess {char} hubs.district district
* @apiSuccess {char} hubs.sub_district sub_district
* @apiSuccess {Timestamp} hubs.created timestamp of creation
* @apiSuccess {Timestamp} hubs.updated timestamp when updated
* @apiSuccess {Timestamp} hubs.deleted timestamp of deletion
*
* @apiSuccessExample {json} Success-Response:
*   {
*       "hubs": [
*           {
*               "id": "8cf19a0b-c6fd-45f7-8859-678535befc60",
*               "code": "QWK2",
*               "name": "Cabuyao Hub",
*               "address": "Cabuyao",
*               "country": "PHL",
*               "region": "4A",
*               "province": "LGN",
*               "district": "4A",
*               "sub_district": "1",
*               "created": "2018-07-10T06:17:12.000Z",
*               "updated": null,
*               "deleted": null
*           },
*           {
*               "id": "d3d16b9f-e0ea-46e7-9a15-d2cdcfdd484e",
*               "code": "QAXS1",
*               "name": "Calamba Hub",
*               "address": "Calamba",
*               "country": "PHL",
*               "region": "4A",
*               "province": "LGN",
*               "district": "4",
*               "sub_district": "1",
*               "created": "2018-07-10T07:27:00.000Z",
*               "updated": null,
*               "deleted": null
*           }
*       ],
*       "success": true
*   }
*
*/

const get = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    [err, hub] = await to(Hub.findAll());
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422'
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : hub,
        'result' : '201'
    }));
    return ReS(res, {'hubs': hub,
                    'log' : log});
};



 /**
* @api {get} /v1/hubs/:id Get Hub by ID
* @apiGroup Hub
* @apiName Get Hub by ID
* @apiParam {UUID} id Hub's unique ID.
*
* @apiSuccess {Object} hub new Hub
* @apiSuccess {UUID} hub.id ID of Hub
* @apiSuccess {String} hub.code code of Hub
* @apiSuccess {String} hub.name name of Hub
* @apiSuccess {String} hub.address address of Hub
* @apiSuccess {char} hub.country country
* @apiSuccess {char} hub.region region
* @apiSuccess {char} hub.province province
* @apiSuccess {char} hub.district district
* @apiSuccess {char} hub.sub_district sub_district
* @apiSuccess {Timestamp} hub.created timestamp of creation
* @apiSuccess {Timestamp} hub.updated timestamp when updated
* @apiSuccess {Timestamp} hub.deleted timestamp of deletion
*
* @apiSuccessExample {json} Success-Response:
*   {
*   "hub": {
*        "id": "8cf19a0b-c6fd-45f7-8859-678535befc60",
*        "code": "QWK2",
*        "name": "Cabuyao Hub",
*        "address": "Cabuyao",
*        "country": "PHL",
*        "region": "4A",
*        "province": "LGN",
*        "district": "4A",
*        "sub_district": "1",
*        "created": "2018-07-10T06:17:12.000Z",
*        "updated": null,
*        "deleted": null
*   },
*   
*   "success": true
*  }
*
*/

const getOne = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const id = req.params.id;
    [err, hub] = await to(Hub.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422'
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : hub,
        'result' : '201'
    }));
    return ReS(res, {'hub': hub.toWeb(),
                    'log' : log});
};

/**
* @api {post} /v1/hubs Add Hub
* @apiGroup Hub
* @apiName Add Hub
*
* @apiParam (System Generated) {UUID} id unique ID  
* @apiParam (Body Params) {String} code unique code for each hub
* @apiParam (Body Params) {String} name name of hub
* @apiParam (Body Params) {String} address address of the hub
* @apiParam (Body Params) {char}   country country
* @apiParam (Body Params) {char}   region region
* @apiParam (Body Params) {char}   province province
* @apiParam (Body Params) {char}   district district
* @apiParam (Body Params) {char}   sub_district sub_district
*
* @apiSuccess {Object} hub new Hub
* @apiSuccess {UUID} hub.id ID of Hub
* @apiSuccess {String} hub.code code of Hub
* @apiSuccess {String} hub.name name of Hub
* @apiSuccess {String} hub.address address of Hub
* @apiSuccess {char} hub.country country
* @apiSuccess {char} hub.region region
* @apiSuccess {char} hub.province province
* @apiSuccess {char} hub.district district
* @apiSuccess {char} hub.sub_district sub_district
* @apiSuccess {Timestamp} hub.created timestamp of creation
* @apiSuccess {Timestamp} hub.updated timestamp when updated
* @apiSuccess {Timestamp} hub.deleted timestamp of deletion
*
* @apiSuccessExample {json} Success-Response:
*   {
*   "message": "successfully created new hub",
*   "hub": {
*       "id": "8cf19a0b-c6fd-45f7-8859-678535befc60",
*       "created": {
*           "val": "NOW()"
*       },
*       "updated": null,
*       "deleted": null,
*       "code": "code",
*       "name": "Laguna Hub",
*       "address": "Cabuyao",
*       "country": "PHL",
*       "region": "4A",
*       "province": "LGN",
*       "district": "4",
*      "sub_district": null
*   },
*   
*   "success": true
*  }
*
*/

const create = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}

    console.log(jti);

    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    const {
        code,
        name,
        address,
        country,
        region,
        province,
        district,
        sub_district
    } = req.body;
    let hub;
    [err, hub] = await to(Hub.create({
        'code' :code,
        'name' :name,
        'address' :address,
        'country' :country,
        'region' :region,
        'province' :province,
        'district' :district,
        'sub_district' :sub_district
    }));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : hub,
        'result' : '201',
        'actor' : req.user.id
    }));
    return ReS(res, {'message':'successfully created new hub', 
                    'hub': hub.toWeb(),
                    'log' : log}, 201);
};

/**
* @api {put} /v1/hubs/:id Update Hub by ID
* @apiName Update Hub by ID
* @apiGroup Hub
* @apiParam {UUID} id Hub's unique ID.
*
* @apiSuccess {Object} hub new Hub
* @apiSuccess {UUID} hub.id ID of Hub
* @apiSuccess {String} hub.code code of Hub
* @apiSuccess {String} hub.name name of Hub
* @apiSuccess {String} hub.address address of Hub
* @apiSuccess {char} hub.country country
* @apiSuccess {char} hub.region region
* @apiSuccess {char} hub.province province
* @apiSuccess {char} hub.district district
* @apiSuccess {char} hub.sub_district sub_district
* @apiSuccess {Timestamp} hub.created timestamp of creation
* @apiSuccess {Timestamp} hub.updated timestamp when updated
* @apiSuccess {Timestamp} hub.deleted timestamp of deletion
*
* @apiParam (Body Params) {String} code unique code for each hub
* @apiParam (Body Params) {String} name name of hub
* @apiParam (Body Params) {String} address address of the hub
* @apiParam (Body Params) {char}   country country
* @apiParam (Body Params) {char}   region region
* @apiParam (Body Params) {char}   province province
* @apiParam (Body Params) {char}   district district
* @apiParam (Body Params) {char}   sub_district sub_district
* @apiSuccessExample {json} Success-Response:
*    {
*        "hub": {
*            "id": "8cf19a0b-c6fd-45f7-8859-678535befc60",
*            "code": "QWK1",
*            "name": "Cabuyao Hub",
*            "address": "Cabuyao",
*            "country": "PHL",
*            "region": "4A",
*            "province": "LGN",
*            "district": "2",
*            "sub_district": "1",
*            "created": "2018-07-10T06:17:12.000Z",
*            "updated": "2018-07-10T07:49:58.000Z",
*            "deleted": null
*        },
*        "message": "update hub: 8cf19a0b-c6fd-45f7-8859-678535befc60",
*        "success": true
*    }
*/

const update = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////

    let hub;
    const id = req.params.id;
    const {
        code,
        name,
        address,
        country,
        region,
        province,
        district,
        sub_district
    } = req.body;
    [err, hub] = await to(Hub.update({
       'code' :code,
        'name' :name,
        'address' :address,
        'country' :country,
        'region' :region,
        'province' :province,
        'district' :district,
        'sub_district' :sub_district,
        updated : Sequelize.fn('NOW')
        }, {
            'where': {
                'id': id
            }
        }
    ));
    [err, hub] = await to(Hub.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err);
    }
    [err, hub] = await to(Hub.findById(id));
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : hub,
        'result' : '201',
        'actor' : req.user.id
    }));
    return ReS(res, {'hub': hub.toWeb(), 'message': 'update hub: ' + id, 'log' : log});
};

/**
* @api {get} /v1/hubs/search Search Hub
* @apiName  Search Hub
* @apiGroup Hub
*
* @apiParam (Paramater) {UUID}   id Hub's unique ID
* @apiParam (Paramater) {String} code unique code for each hub
* @apiParam (Paramater) {String} name name of hub
* @apiParam (Paramater) {String} address address of the hub
* @apiParam (Paramater) {char}   country country
* @apiParam (Paramater) {char}   region region
* @apiParam (Paramater) {char}   province province
* @apiParam (Paramater) {char}   district district
* @apiParam (Paramater) {char}   sub_district sub_district
*
* @apiSuccess {Object[]} hubs array of hubs
* @apiSuccess {UUID} hubs.id ID of Hub
* @apiSuccess {String} hubs.code code of Hub
* @apiSuccess {String} hubs.name name of Hub
* @apiSuccess {String} hubs.address address of Hub
* @apiSuccess {char} hubs.country country
* @apiSuccess {char} hubs.region region
* @apiSuccess {char} hubs.province province
* @apiSuccess {char} hubs.district district
* @apiSuccess {char} hubs.sub_district sub_district
* @apiSuccess {Timestamp} hubs.created timestamp of creation
* @apiSuccess {Timestamp} hubs.updated timestamp when updated
* @apiSuccess {Timestamp} hubs.deleted timestamp of deletion
*
* @apiSuccessExample {json} Success-Response:
*    {
*        "hubs": [
*            {
*                "id": "8cf19a0b-c6fd-45f7-8859-678535befc60",
*                "code": "QWK1",
*                "name": "Cabuyao Hub",
*                "address": "Cabuyao",
*                "country": "PHL",
*                "region": "4A",
*                "province": "LGN",
*                "district": "2",
*                "sub_district": "1",
*                "created": "2018-07-10T06:17:12.000Z",
*                "updated": "2018-07-10T07:49:58.000Z",
*                "deleted": null
*            }
*        ],
*        "success": true
*    }
*/

const search = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const {
        id,
        code,
        name,
        address,
        country,
        region,
        province,
        district,
        sub_district,
        created,
        updated,
        deleted
    } = req.query;

    [err, hub] = await to(Hub.findAll({
            where: {
                [Op.or]: [{'id': id}, {'code': code}, {'name': name}, {'address' : address}, {'country' : country},{'region' : region},
                {'province' : province},{'district': district},
                {'sub_district':sub_district}, {'created': created}, {'updated': updated}, {'deleted': deleted}]
            }
    }));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422'
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : hub,
        'result' : '201'
    }));
    return ReS(res, {'hubs': hub,
                    'log' : log});
};

/**
* @api {post} /v1/hubs/:id/deactivate Deactivate Hub by ID
* @apiName Deactivate Hub by ID
* @apiGroup Hub
* @apiParam {UUID} id Hub's unique ID.
* @apiSuccess {Object} hub new Hub
* @apiSuccess {UUID} hub.id ID of Hub
* @apiSuccess {String} hub.code code of Hub
* @apiSuccess {String} hub.name name of Hub
* @apiSuccess {String} hub.address address of Hub
* @apiSuccess {char} hub.country country
* @apiSuccess {char} hub.region region
* @apiSuccess {char} hub.province province
* @apiSuccess {char} hub.district district
* @apiSuccess {char} hub.sub_district sub_district
* @apiSuccess {Timestamp} hub.created timestamp of creation
* @apiSuccess {Timestamp} hub.updated timestamp when updated
* @apiSuccess {Timestamp} hub.deleted timestamp of deletion
* @apiSuccessExample {json} Success-Response:
*    {
*        "message": "deactivated hub",
*        "hub": {
*            "id": "8cf19a0b-c6fd-45f7-8859-678535befc60",
*            "code": "QWK1",
*            "name": "Cabuyao Hub",
*            "address": "Cabuyao",
*            "country": "PHL",
*            "region": "4A",
*            "province": "LGN",
*            "district": "2",
*            "sub_district": "1",
*            "created": "2018-07-10T06:17:12.000Z",
*            "updated": "2018-07-10T07:49:58.000Z",
*            "deleted": "2018-07-10T08:04:16.000Z"
*        },
*        "success": true
*    }
*/


const deactivate = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////

    let hub;
    const id = req.params.id;
    [err, hub] = await to(Hub.update({
            deleted : Sequelize.fn('NOW')
        },
        {
            'where': {
                'id': id
            }
        }
    ));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, 'error occured while deactivating hub');
    }
    [err, hub] = await to(Hub.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422'
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : hub,
        'result' : '201'
    }));
    return ReS(res, {'message': 'deactivated hub',
                    'hub': hub.toWeb(),
                    'log' : log});
};

/**
* @api {post} /v1/hubs/:id/reactivate Reactivate Hub by ID
* @apiName Reactivate Hub by ID
* @apiGroup Hub
* @apiParam {UUID} id Hub's unique ID.
* @apiSuccess {Object} hub new Hub
* @apiSuccess {UUID} hub.id ID of Hub
* @apiSuccess {String} hub.code code of Hub
* @apiSuccess {String} hub.name name of Hub
* @apiSuccess {String} hub.address address of Hub
* @apiSuccess {char} hub.country country
* @apiSuccess {char} hub.region region
* @apiSuccess {char} hub.province province
* @apiSuccess {char} hub.district district
* @apiSuccess {char} hub.sub_district sub_district
* @apiSuccess {Timestamp} hub.created timestamp of creation
* @apiSuccess {Timestamp} hub.updated timestamp when updated
* @apiSuccess {Timestamp} hub.deleted timestamp of deletion
* @apiSuccessExample {json} Success-Response:
*    {
*        "message": "reactivated hub",
*        "hub": {
*            "id": "8cf19a0b-c6fd-45f7-8859-678535befc60",
*            "code": "QWK1",
*            "name": "Cabuyao Hub",
*            "address": "Cabuyao",
*            "country": "PHL",
*            "region": "4A",
*            "province": "LGN",
*            "district": "2",
*            "sub_district": "1",
*            "created": "2018-07-10T06:17:12.000Z",
*            "updated": "2018-07-10T07:49:58.000Z",
*            "deleted": null
*        },
*        "success": true
*    }
 */

const reactivate = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    let hub;
    const id = req.params.id;
    [err, hub] = await to(Hub.update({
            deleted : null
        },
        {
            'where': {
                'id': id
            }
        }
    ));
    if (err) {
        [err, log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, 'error occured while reactivating hub');
    }
    [err, hub] = await to(Hub.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422'
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : hub,
        'result' : '201'
    }));
    return ReS(res, {'message': 'reactivated hub',
                    'hub': hub.toWeb(),
                    'log' : log});
};

module.exports = {

    'get'   : get,
    'getOne' : getOne,
    'create' : create,
    'update' : update,
    'search' : search,
    'deactivate' : deactivate,
    'reactivate' : reactivate
}