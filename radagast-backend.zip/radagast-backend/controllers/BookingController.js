const Booking = require('./../models').booking;
const Client = require('./../models').client;
const User = require('./../models').User;
const Assignment = require('./../models').assignment;
const Log = require('./../models').log;
const Sequelize = require('sequelize');
const Op = Sequelize.Op;
const Authorized = require('./../models').authorized;
const authService   = require('./../services/AuthService');

/**
 * @api {post} /bookings addBooking
 * @apiGroup Booking
 * @apiName addBooking
 *
 * @apiParam (System Generated) {UUID} id ID of booking
 * @apiParam (Body Params) {String} shipper_name shipper_name of booking 
 * @apiParam (Body Params) {String} pick_up_address pick_up_address of booking
 * @apiParam (Body Params) {String} contact_number contact_number of booking
 * @apiParam (Body Params) {String} email email of booking
 * @apiParam (Body Params) {String} product_type product_type of booking
 * @apiParam (Body Params) {String} cargo_type cargo_type of booking
 * @apiParam (Body Params) {String} mode_of_payment mode_of_payment of booking
 * @apiParam (Body Params) {String} client_account_number
 *
 * @apiSuccess {UUID} id ID of booking
 * @apiSuccess {String} shipper_name shipper_name of booking 
 * @apiSuccess {String} pick_up_address pick_up_address of booking
 * @apiSuccess {String} contact_number contact_number of booking
 * @apiSuccess {String} email email of booking
 * @apiSuccess {String} product_type product_type of booking
 * @apiSuccess {String} cargo_type cargo_type of booking
 * @apiSuccess {String} mode_of_payment mode_of_payment of booking
 * @apiSuccess {String} client_account_number
 * @apiSuccess {Timestamp} created Date and Time the district is created.
 * @apiSuccess {Timestamp} updated Date and Time the district is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the district is deleted.
 * @apiSuccess {String} Message Successfully created booking.
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *      "message": "Successfully created booking.",
 *      "booking": {
 *          "id": "c5318d95-964a-4973-856f-a81da63c6320",
 *          "created": {
 *              "val": "NOW()"
 *          },
 *          "shipper_name": "Lazada",
 *          "pick_up_address": "Ilag's Compound",
 *          "contact_number": "09168679865",
 *          "email": "ahabulan@gmail.com",
 *          "product_type": "Apparel",
 *          "cargo_type": "Dry bulk",
 *          "mode_of_payment": "visa",
 *          "client_account_number" : null
 *      },
 *      "success": true
 *   }
 *
 */
const create = async (req, res) => {
     ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    const{
        shipper_name,
        pick_up_address,
        contact_number,
        email,
        product_type,
        cargo_type,
        mode_of_payment,
        client_account_number
    } = req.body;
    let  booking;
    let actor;
    if(req.user){
        actor = req.user.id;
    }
    else {
        actor = contact_number;
    }
    [err, booking] = await to(Booking.create({
        'shipper_name' : shipper_name,
        'pick_up_address' : pick_up_address,
        'contact_number' : contact_number,
        'email' : email,
        'product_type' : product_type,
        'cargo_type' : cargo_type,
        'mode_of_payment' : mode_of_payment,
        'client_account_number' : client_account_number
    }));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : actor
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : booking,
        'result' : '201',
        'actor' : actor
    }));
    return ReS(res, {'message' : 'Successfully created booking.',
                    'booking' : booking.toWeb(),
                    'log' : log}, 201);
};

/**
 * @api {get} /bookings getBookings
 * @apiGroup Booking
 * @apiName getBookings
 *
 * @apiSuccess {UUID} id ID of booking
 * @apiSuccess {String} shipper_name shipper_name of booking 
 * @apiSuccess {String} pick_up_address pick_up_address of booking
 * @apiSuccess {String} contact_number contact_number of booking
 * @apiSuccess {String} email email of booking
 * @apiSuccess {String} product_type product_type of booking
 * @apiSuccess {String} cargo_type cargo_type of booking
 * @apiSuccess {String} mode_of_payment mode_of_payment of booking
 * @apiSuccess {String} client_account_number
 * @apiSuccess {Timestamp} created Date and Time the district is created.
 * @apiSuccess {Timestamp} updated Date and Time the district is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the district is deleted.
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *      "bookings": [
 *          {
 *              "id": "490e0c2b-138b-4770-b18f-235b0dc8f4b1",
 *              "shipper_name": "Lazada",
 *              "pick_up_address": "Ilag's Compound, ",
 *              "contact_number": "09168679865",
 *              "email": "ahabulan@gmail.com",
 *              "product_type": "Apparel",
 *              "cargo_type": "Dry bulk",
 *              "mode_of_payment": "visa",
 *              "created": "2018-07-12T03:49:15.000Z",
 *              "updated": null,
 *              "deleted": null,
 *              "client_account_number": null
 *          },
 *          {
 *              "id": "bd4ef8f7-ddea-4163-9bba-6c21dc87a61c",
 *              "shipper_name": "Shoppee",
 *              "pick_up_address": "Raymundo",
 *              "contact_number": "09271234561",
 *              "email": "kzarzoso@gmail.com",
 *              "product_type": "Apparel",
 *              "cargo_type": "Dry bulk",
 *              "mode_of_payment": "visa",
 *              "created": "2018-07-12T06:48:10.000Z",
 *              "updated": null,
 *              "deleted": null,
 *              "client_account_number": "8b776f3f-63a9-4e38-a318-cab8a86ef7d4"
 *          }
 *      ], 
 *      "success": true
 *  }   
 *
 */
const get = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    let err, booking;
    if(Booking.client_account_number) {
        [err, booking] = await to(Booking.findAll({
            include: [{
                model : Client,
                attributes : ['pick_up_address', 'ftp_address', 'credit_term', 'mode_of_payment'],
                required : true
            }]
        }));
    }
    else {
        [err, booking] = await to(Booking.findAll());
    }
   
    return ReS(res, {'bookings' : booking});  
}

/**
 * @api {getOne} /bookings/:id getOneBooking
 * @apiGroup Booking
 * @apiName getOneBooking
 *
 * @apiSuccess {UUID} id ID of booking
 * @apiSuccess {String} shipper_name shipper_name of booking 
 * @apiSuccess {String} pick_up_address pick_up_address of booking
 * @apiSuccess {String} contact_number contact_number of booking
 * @apiSuccess {String} email email of booking
 * @apiSuccess {String} product_type product_type of booking
 * @apiSuccess {String} cargo_type cargo_type of booking
 * @apiSuccess {String} mode_of_payment mode_of_payment of booking
 * @apiSuccess {String} client_account_number
 * @apiSuccess {Timestamp} created Date and Time the district is created.
 * @apiSuccess {Timestamp} updated Date and Time the district is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the district is deleted.
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *      "booking": {
 *          "id": "490e0c2b-138b-4770-b18f-235b0dc8f4b1",
 *          "shipper_name": "Lazada",
 *          "pick_up_address": "Ilag's Compound, ",
 *          "contact_number": "09168679865",
 *          "email": "ahabulan@gmail.com",
 *          "product_type": "Apparel",
 *          "cargo_type": "Dry bulk",
 *          "mode_of_payment": "visa",
 *          "created": "2018-07-12T03:49:15.000Z",
 *          "updated": null,
 *          "deleted": null,
 *          "client_account_number": null
 *      },
 *      "success": true
 *   }
 *
 */
const getOne = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const id = req.params.id;
    let err, booking;
    [err, booking] = await to(Booking.findById(id));
    return ReS(res, {'booking' : booking});
}

/**
 * @api {search} /bookings searchBooking
 * @apiGroup Booking
 * @apiName searchBooking
 *
 * @apiParam (Query Params) {UUID} id ID of booking
 * @apiParam (Query Params) {String} shipper_name shipper_name of booking 
 * @apiParam (Query Params) {String} pick_up_address pick_up_address of booking
 * @apiParam (Query Params) {String} contact_number contact_number of booking
 * @apiParam (Query Params) {String} email email of booking
 * @apiParam (Query Params) {String} product_type product_type of booking
 * @apiParam (Query Params) {String} cargo_type cargo_type of booking
 * @apiParam (Query Params) {String} mode_of_payment mode_of_payment of booking
 * @apiParam (Query Params) {String} client_account_number
 *
 * @apiSuccess {UUID} id ID of booking
 * @apiSuccess {String} shipper_name shipper_name of booking 
 * @apiSuccess {String} pick_up_address pick_up_address of booking
 * @apiSuccess {String} contact_number contact_number of booking
 * @apiSuccess {String} email email of booking
 * @apiSuccess {String} product_type product_type of booking
 * @apiSuccess {String} cargo_type cargo_type of booking
 * @apiSuccess {String} mode_of_payment mode_of_payment of booking
 * @apiSuccess {String} client_account_number
 * @apiSuccess {Timestamp} created Date and Time the district is created.
 * @apiSuccess {Timestamp} updated Date and Time the district is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the district is deleted.
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *      "bookings": [
 *          {
 *              "id": "490e0c2b-138b-4770-b18f-235b0dc8f4b1",
 *              "shipper_name": "Lazada",
 *              "pick_up_address": "Ilag's Compound, ",
 *              "contact_number": "09168679865",
 *              "email": "ahabulan@gmail.com",
 *              "product_type": "Apparel",
 *              "cargo_type": "Dry bulk",
 *              "mode_of_payment": "visa",
 *              "created": "2018-07-12T03:49:15.000Z",
 *              "updated": null,
 *              "deleted": null,
 *              "client_account_number": null
 *          }
 *      ],
 *          "success" : true
 *   }
 *
 */
const search = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const{
        shipper_name,
        pick_up_address,
        contact_number,
        email,
        product_type,
        cargo_type,
        mode_of_payment
    } = req.query;
    let err, booking;
    [err, booking] = await to(Booking.findAll({
        where : {
            [Op.or] :
                [
                    {'shipper_name' : shipper_name},
                    {'pick_up_address' : pick_up_address},
                    {'contact_number' : contact_number},
                    {'email' : email},
                    {'product_type' : product_type},
                    {'cargo_type' : cargo_type},
                    {'mode_of_payment' : mode_of_payment}
                ]
        }
    }));
    return ReS(res, {'bookings' : booking});
}

/**
 * @api {put} /bookings/:id updateBooking
 * @apiGroup Booking
 * @apiName updateBooking
 *
 * @apiParam (Body Params) {String} shipper_name shipper_name of booking 
 * @apiParam (Body Params) {String} pick_up_address pick_up_address of booking
 * @apiParam (Body Params) {String} contact_number contact_number of booking
 * @apiParam (Body Params) {String} email email of booking
 * @apiParam (Body Params) {String} product_type product_type of booking
 * @apiParam (Body Params) {String} cargo_type cargo_type of booking
 * @apiParam (Body Params) {String} mode_of_payment mode_of_payment of booking
 * @apiParam (Body Params) {String} client_account_number
 *
 * @apiSuccess {UUID} id ID of booking
 * @apiSuccess {String} shipper_name shipper_name of booking 
 * @apiSuccess {String} pick_up_address pick_up_address of booking
 * @apiSuccess {String} contact_number contact_number of booking
 * @apiSuccess {String} email email of booking
 * @apiSuccess {String} product_type product_type of booking
 * @apiSuccess {String} cargo_type cargo_type of booking
 * @apiSuccess {String} mode_of_payment mode_of_payment of booking
 * @apiSuccess {String} client_account_number
 * @apiSuccess {Timestamp} created Date and Time the district is created.
 * @apiSuccess {Timestamp} updated Date and Time the district is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the district is deleted.
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *      "booking": {
 *          "id": "c5318d95-964a-4973-856f-a81da63c6320",
 *          "shipper_name": "Lazada",
 *          "pick_up_address": "Ilag's Compound",
 *          "contact_number": "09168679812",
 *          "email": "ahabulan@gmail.com",
 *          "product_type": "Apparel",
 *          "cargo_type": "Dry bulk",
 *          "mode_of_payment": "visa",
 *          "created": "2018-07-12T03:49:25.000Z",
 *          "updated": "2018-07-12T03:51:15.000Z",
 *          "deleted": null,
 *          "client_account_number": null
 *      },
 *      "message": "update booking: c5318d95-964a-4973-856f-a81da63c6320",
 *      "success": true
 *   }
 *
 */
const update = async (req, res) => {
     ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let  booking;
    const id = req.params.id;
    const {
        shipper_name,
        pick_up_address,
        contact_number,
        email,
        product_type,
        cargo_type,
        mode_of_payment
    } = req.body;
    [err, booking] = await to(Booking.update({
        'shipper_name' : shipper_name,
        'pick_up_address' : pick_up_address,
        'contact_number' : contact_number,
        'email' : email,
        'product_type' : product_type,
        'cargo_type' : cargo_type,
        'mode_of_payment' : mode_of_payment,
        'updated' : Sequelize.fn('NOW')
    },
    {
        'where' : {
            'id' : id
        }
    }));
    [err, booking] = await to(Booking.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : booking,
        'result' : '201',
        'actor' : req.user.id
    }));

    return ReS(res, {'booking' : booking.toWeb(),
                    'log' : log,
                    'message' : 'update booking: ' + id});
}

/**
 * @api {delete} /bookings/:id cancelBooking
 * @apiGroup Booking
 * @apiName cancelBooking
 *
 * @apiSuccess {UUID} id ID of booking
 * @apiSuccess {String} shipper_name shipper_name of booking 
 * @apiSuccess {String} pick_up_address pick_up_address of booking
 * @apiSuccess {String} contact_number contact_number of booking
 * @apiSuccess {String} email email of booking
 * @apiSuccess {String} product_type product_type of booking
 * @apiSuccess {String} cargo_type cargo_type of booking
 * @apiSuccess {String} mode_of_payment mode_of_payment of booking
 * @apiSuccess {String} client_account_number
 * @apiSuccess {Timestamp} created Date and Time the district is created.
 * @apiSuccess {Timestamp} updated Date and Time the district is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the district is deleted.
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *      "message": "Successfully cancelled booking",
 *      "success": true
 *   }
 *
 */
const remove = async (req, res) => {
     ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    const id = req.params.id;
    let booking;
    [err, booking] = await to(Booking.destroy({
        'where' : {
            'id' : id
        }
    }));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : booking,
        'result' : '201',
        'actor' : req.user.id
    }));
    return ReS(res, {'log' : log,
                    'message' : 'Successfully cancelled booking'});
}

/**
 * @api {assign} /bookings/:id/assign assignBooking
 * @apiGroup Booking
 * @apiName assignBooking
 *
 * @apiSuccess {UUID} id ID of booking
 * @apiSuccess {Timestamp} created Date and Time the district is created.
 * @apiSuccess {String} status Status of booking
 * apiSuccess  {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *      "message": "Successfully assigned booking",
 *      "assignment": {
 *          "id": "44097751-364e-422a-91de-0b4ce99c59be",
 *          "created": {
 *              "val": "NOW()"
 *          },
 *          "status": "Pending",
 *          "booking_id": "c5318d95-964a-4973-856f-a81da63c6320"
 *      },
 *      "success": true
 *   }
 */
const assign = async (req, res) => {
     ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    const id = req.params.id;
    [err, assignment] = await to(Assignment.create({
        'booking_id' : id
    }));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : assignment,
        'result' : '201',
        'actor' : req.user.id
    }));
    return ReS(res, {'message' : 'Successfully assigned booking',
                    'assignment' : assignment.toWeb(),
                    'log' : log}, 201);
};

/**
 * @api {unassign} /bookings/:id/unassign unassignBooking
 * @apiGroup Booking
 * @apiName unassignBooking
 *
 * @apiSuccess {Timestamp} Timestamp timestamp of unassignment.
 * @apiSuccess {String} Message unassigned booking + id
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *      "message": "Unassigned booking c5318d95-964a-4973-856f-a81da63c6320",
 *      "success": true
 *   }
 *
 */
const unassign = async (req, res) => {
     ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    const id = req.params.id;
    [err, assignment] = await to(Assignment.update({
        'timestamp_of_unassignment_from_booking' : Sequelize.fn('NOW')
    },
    {
        'where' : {
            'booking_id' : id
        }
    }));
    [err, assignment] = await to(Assignment.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : assignment,
        'result' : '201',
        'actor' : req.user.id
    }));
    return ReS(res, {'message' : 'Unassigned booking ' + id,
                    'log' : log});
};

module.exports = {
    'create' : create,
    'get'    : get,
    'getOne' : getOne,
    'search' : search,
    'update' : update,
    'remove' : remove,
    'assign' : assign,
    'unassign' : unassign
} 