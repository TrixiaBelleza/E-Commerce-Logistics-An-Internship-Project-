const User   = require('./../models').User;
const Authorized = require('./../models').authorized;
const authService   = require('./../services/AuthService');
const Sequelize = require('sequelize');
/**
* @api {post} /auth/sign-in Sign in
* @apiGroup Auth
* @apiName Sign in
*
* @apiParam (Body Params) {String} email email
* @apiParam (Body Params) {String} password password
*
* @apiSuccess {String} token valid token
* @apiSuccess {Object} user new user
* @apiSuccess {Integer} user.id ID of user
* @apiSuccess {String} user.email email of user
* @apiSuccess {String} user.password encrypted password of user
* @apiSuccess {String} user.first_name first name of user
* @apiSuccess {String} user.middle_name middle name of user
* @apiSuccess {String} user.last_name last name of user
* @apiSuccess {String} user.first_name first name of user
* @apiSuccess {String} user.contact_number contact_number of user
* @apiSuccess {Timestamp} user.created timestamp of creation
* @apiSuccess {Timestamp} user.updated timestamp when updated
* @apiSuccess {Timestamp} user.deleted timestamp of deletion
*
* @apiSuccessExample {json} Success-Response:
{
    "token": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjozLCJpYXQiOjE1MzEzNTk0NjYsImV4cCI6MTUzMTM2OTQ2NiwianRpIjoiNzM1OTU4NjEtNjExMS00ZGZkLWEzODEtNWY2MTA1MzhmYjYxIn0.3b7P3MzHrr9LICXvfyKGdcPicZZAcm_-yVc2u5bEQeI",
    "user": {
        "id": 3,
        "email": "jdelacruz@gmail.com",
        "password": "$2b$10$e9wuucvYYcyxH0M5cYnOH.RDo7vL6ZZ3pVNBlxRJYCQ1lWtikZ8VW",
        "first_name": "juan",
        "last_name": "delacruz",
        "middle_name": "reyes",
        "contact_number": null,
        "created": "2018-07-12T01:36:45.000Z",
        "updated": null,
        "deleted": null,
        "createdAt": "2018-07-12T01:36:45.000Z",
        "updatedAt": "2018-07-12T01:36:45.000Z"
    },
    "success": true
}
*/

const sign_in = async (req, res) => {
    const body = req.body;
    let err, user,jti;

    [err, user] = await to(authService.authUser(req.body));
    if (err) {
        return ReE(res, err, 422);
    }

    if(user){
        const token = user.getJWT();
        console.log(token);
        [err,jti] = await to (authService.get_jti(token));
        if (err) { return ReE(res, err, 422);}

        let authorized;
        [err, authorized] = await to(Authorized.create({'token_id' :jti }));
        if (err) { return ReE(res, err, 422);}

        
        return ReS(res, {'token': token, 'user': user.toWeb()});   

    }

}
/**
* @api {post} /auth/sign-out Sign out
* @apiGroup Auth
* @apiName Sign out
*
* @apiHeader (Header) {String} authorization jwt token ex: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoxLCJpYXQiOjE1MzEyODk2MDQsImV4cCI6MTUzMTI5OTYwNCwianRpIjoiMGU0Y2JiNDctYjk4Yy00MTMxLWFhMDAtNGIwNmZjYWZmMGQ0In0.6TgWivCAefsoMnmJ0uaeth8-1mW-Z8CLPc_V_rX37I0
*
* @apiSuccessExample {json} Success-Response:
*    {
*        "message": "logged out",
*        "success": true
*    }
*/

const sign_out = async (req, res) => {
    const header = req.headers.authorization;
    let err,jti;
    console.log(req.headers);
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}

    let authorized;
    [err, authorized] = await to(Authorized.destroy({where:{'token_id' :jti }}));
    if (err) { return ReE(res, err, 422);}
        
    return ReS(res,{'message':'logged out'});

    
}
/**
* @api {post} /auth/reset-password Reset password
* @apiGroup Auth
* @apiName Reset password
*
* @apiHeader (Header) {String} authorization jwt token ex: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoxLCJpYXQiOjE1MzEyODk2MDQsImV4cCI6MTUzMTI5OTYwNCwianRpIjoiMGU0Y2JiNDctYjk4Yy00MTMxLWFhMDAtNGIwNmZjYWZmMGQ0In0.6TgWivCAefsoMnmJ0uaeth8-1mW-Z8CLPc_V_rX37I0
* @apiParam (Body Params) {string} email email
* @apiParam (Body Params) {string} password current password
* @apiParam (Body Params) {string} new_password new password 
* @apiParam (Body Params) {string} confirm_password verify password
*
* @apiSuccess {Object} user new user
* @apiSuccess {Integer} user.id ID of user
* @apiSuccess {String} user.email email of user
* @apiSuccess {String} user.password encrypted password of user
* @apiSuccess {String} user.first_name first name of user
* @apiSuccess {String} user.middle_name middle name of user
* @apiSuccess {String} user.last_name last name of user
* @apiSuccess {String} user.first_name first name of user
* @apiSuccess {String} user.contact_number contact_number of user
* @apiSuccess {Timestamp} user.created timestamp of creation
* @apiSuccess {Timestamp} user.updated timestamp when updated
* @apiSuccess {Timestamp} user.deleted timestamp of deletion
* @apiSuccessExample {json} Success-Response:
{
    "user": {
        "id": 3,
        "email": "jdelacruz@gmail.com",
        "password": "$2b$10$/1JsJ2x9xaSeYtsgd3TE.OXkfz1z4apVvLWhJQwVKXlI0nUY4J1j2",
        "first_name": "juan",
        "last_name": "delacruz",
        "middle_name": "reyes",
        "contact_number": null,
        "created": "2018-07-12T01:36:45.000Z",
        "updated": {
            "fn": "NOW",
            "args": []
        },
        "deleted": null,
        "createdAt": "2018-07-12T01:36:45.000Z",
        "updatedAt": "2018-07-12T01:53:58.690Z"
    },
    "success": true
}
*/
const reset_password = async (req, res) => {
    let user = req.user;
    const body = req.body;
    
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}


    if(body.new_password!=body.confirm_password){
    	return ReE(res,{'message': 'new password did not match'});
    }

    [err, user] = await to(authService.authUser(body));
    if (err) {
        return ReE(res, err, 422);
    }


    let updateValues = { password: body.new_password, updated : Sequelize.fn('NOW') };
    [err, user] = await to(User.findOne({
        'where': {'email': body.email}
    }));
    if (err) {
        return ReE(res, err, 422);
    }

    [err, user] = await to(user.update(updateValues));
    if (err) {
        return ReE(res, err, 422);
    }
    
    [err, authorized] = await to(Authorized.destroy({where:{'token_id' :jti }}));
    if (err) { return ReE(res, err, 422);}

    return ReS(res, {'user': user.toWeb()});
    
}

module.exports = {
    'sign_in': sign_in,
    'sign_out': sign_out,
    'reset_password' : reset_password
}