const SubDistrict = require('./../models').sub_district;
const District = require('./../models').district;
const Province   = require('./../models').province;
const Region  = require('./../models').region;
const Country = require('./../models').country;
const Log = require('./../models').log;
const Sequelize = require('sequelize');
const Op = Sequelize.Op;
const Authorized = require('./../models').authorized;
const authService   = require('./../services/AuthService');

/**
 * @api {post} /sub-districts addSubDistrict
 * @apiGroup SubDistrict
 * @apiName addSubDistrict
 *
 * @apiParam (System Generated) {UUID} id ID of subdistrict
 * @apiParam (Body Params) {Character} code code of subdistrict 
 * @apiParam (Body Params) {String} name name of subdistrict
 * @apiParam (Body Params) {String} district_id district_id of subdistrict referenced from district
 *
 * @apiSuccess {UUID} id ID of the sub-district
 * @apiSuccess {Character} code code of sub-district
 * @apiSuccess {String} name name of sub-district
 * @apiSuccess {String} district_id district_id of sub-district referenced from district
 * @apiSuccess {Timestamp} created Date and Time the sub-district is created.
 * @apiSuccess {Timestamp} updated Date and Time the sub-district is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the sub-district is deleted.
 * @apiSuccess {String} Message Successfully created new sub_district
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *  {
 *      "message": "Successfully created new sub_district",
 *      "sub_district": {
 *          "id": "53d3ac42-675b-49bd-bb51-b0a000f196f1",
 *          "created": {
 *              "val": "NOW()"
 *          },
 *          "updated": null,
 *          "deleted": null,
 *          "district_id": "7db0be44-a06f-4e27-a8be-81fa7078075e",
 *          "code": "LB",
 *          "name": "Los Banos"
 *      },
 *      "success" : true
 *  }
 *
 * @apiError (Error 500) {Number} status status code
 * @apiError (Error 500) {String} message Error message
 * @apiErrorExample {json} Error-Response:
 *   HTTP/1.1 500 Internal Server Error
 *   {
 *     "status": 500,
 *     "message": "Internal server error"
 *   }
 */

const create = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    const {
        district_id,
        code,
        name
    } = req.body;
    let sub_district;
    [err, sub_district] = await to(SubDistrict.create({
        'district_id'   : district_id,
        'code'  : code,
        'name'  : name
    }));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : sub_district,
        'result' : '201',
        'actor' : req.user.id
    }));
    return ReS(res, {'message' : 'Successfully created new sub_district',
                    'sub_district' : sub_district.toWeb(),
                    'log' : log}, 201);
};

/**
 * @api {get} /sub-districts getSubDistricts
 * @apiGroup SubDistrict
 * @apiName getSubDistricts
 *
 * @apiSuccess {UUID} id ID of the sub-district
 * @apiSuccess {Character} code code of sub-district
 * @apiSuccess {String} name name of sub-district
 * @apiSuccess {String} district_id district_id of sub-district referenced from district
 * @apiSuccess {String} code code of district
 * @apiSuccess {String} name name of district
 * @apiSuccess {UUID} id id of province
 * @apiSuccess {String} code code of province
 * @apiSuccess {String} name name of province
 * @apiSuccess {UUID} id id of region
 * @apiSuccess {String} code code of region
 * @apiSuccess {String} name name of region
 * @apiSuccess {UUID} id id of country
 * @apiSuccess {String} code code of country
 * @apiSuccess {String} name name of country
 * @apiSuccess {Timestamp} created Date and Time the sub-district is created.
 * @apiSuccess {Timestamp} updated Date and Time the sub-district is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the sub-district is deleted.
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *  {
  "sub_districts": [
        {
            "id": "53d3ac42-675b-49bd-bb51-b0a000f196f1",
            "code": "LB",
            "name": "Los Banos",
            "created": "2018-07-11T02:07:01.000Z",
            "updated": null,
            "deleted": null,
            "district_id": "7db0be44-a06f-4e27-a8be-81fa7078075e",
            "district": {
                "id": "7db0be44-a06f-4e27-a8be-81fa7078075e",
                "code": "D2",
                "name": "District2",
                "province": {
                    "id": "3390ede7-e509-4f06-97b2-8580c29dfb3c",
                    "code": "p",
                    "name": "province",
                    "region": {
                        "id": "84d0f129-a195-486e-8c63-012857af6f1a",
                        "code": "NCR",
                        "name": "National Capital Region",
                        "country": {
                            "id": "79dd673a-3c03-47bc-8957-c47ffcb33ef2",
                            "code": "PH",
                            "name": "Philippines"
                        }
                    }
                }
            }
        },
        {
            "id": "68d365f7-354f-4437-9b7d-7c616b8883f6",
            "code": "SP",
            "name": "San Pablo City",
            "created": "2018-07-11T02:17:08.000Z",
            "updated": "2018-07-11T02:20:11.000Z",
            "deleted": null,
            "district_id": "d9ea75ae-1f3c-48d3-8b18-d2c30c84c38d",
            "district": {
                "id": "d9ea75ae-1f3c-48d3-8b18-d2c30c84c38d",
                "code": "D3",
                "name": "District Three",
                "province": {
                    "id": "3390ede7-e509-4f06-97b2-8580c29dfb3c",
                    "code": "p",
                    "name": "province",
                    "region": {
                        "id": "84d0f129-a195-486e-8c63-012857af6f1a",
                        "code": "NCR",
                        "name": "National Capital Region",
                        "country": {
                            "id": "79dd673a-3c03-47bc-8957-c47ffcb33ef2",
                            "code": "PH",
                            "name": "Philippines"
                        }
                    }
                }
            }
        },
 *      "success": true
 *  }
 *
 * @apiError (Error 500) {Number} status status code
 * @apiError (Error 500) {String} message Error message
 * @apiErrorExample {json} Error-Response:
 *   HTTP/1.1 500 Internal Server Error
 *   {
 *     "status": 500,
 *     "message": "Internal server error"
 *   }
 */
const get = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    [err,sub_district] = await to(SubDistrict.findAll({
        include: [{
            model: District,
            attributes: ['id', 'code', 'name'],
            required: true,
            include: [{
                    model: Province,
                    attributes: ['id', 'code', 'name'],
                    required: true,
                    include: [{
                            model: Region,
                            attributes: ['id', 'code', 'name'],
                            required: true,
                            include: [{
                                model: Country,
                                attributes: ['id', 'code', 'name'],
                                required: true
                            }]
                    }]
            }]
        }]
    }));
    return ReS(res, {'sub_districts' : sub_district});
};

/**
 * @api {getOne} /sub-districts/:id getOneSubDistrict
 * @apiGroup SubDistrict
 * @apiName getOneSubDistrict
 *
 * @apiSuccess {UUID} id ID of the sub-district
 * @apiSuccess {Character} code code of sub-district
 * @apiSuccess {String} name name of sub-district
 * @apiSuccess {String} district_id district_id of sub-district referenced from district
 * @apiSuccess {String} code code of district
 * @apiSuccess {String} name name of district
 * @apiSuccess {UUID} id id of province
 * @apiSuccess {String} code code of province
 * @apiSuccess {String} name name of province
 * @apiSuccess {UUID} id id of region
 * @apiSuccess {String} code code of region
 * @apiSuccess {String} name name of region
 * @apiSuccess {UUID} id id of country
 * @apiSuccess {String} code code of country
 * @apiSuccess {String} name name of country
 * @apiSuccess {Timestamp} created Date and Time the sub-district is created.
 * @apiSuccess {Timestamp} updated Date and Time the sub-district is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the sub-district is deleted.
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *  {
 *      "sub_district": 
 *          {
 *           "id": "53d3ac42-675b-49bd-bb51-b0a000f196f1",
 *           "code": "LB",
 *           "name": "Los Banos",
 *           "created": "2018-07-11T02:07:01.000Z",
 *           "updated": null,
 *           "deleted": null,
 *           "district_id": "7db0be44-a06f-4e27-a8be-81fa7078075e",
 *           "district": {
 *               "id": "7db0be44-a06f-4e27-a8be-81fa7078075e",
 *               "code": "D2",
 *               "name": "District2",
 *               "province": {
 *                   "id": "3390ede7-e509-4f06-97b2-8580c29dfb3c",
 *                   "code": "p",
 *                   "name": "province",
 *                   "region": {
 *                       "id": "84d0f129-a195-486e-8c63-012857af6f1a",
 *                       "code": "NCR",
 *                       "name": "National Capital Region",
 *                       "country": {
 *                           "id": "79dd673a-3c03-47bc-8957-c47ffcb33ef2",
 *                           "code": "PH",
 *                           "name": "Philippines"
 *                       }
 *                   }
 *               }
 *           }
 *       },
 *      "success": true
 *  }
 *
 */

const getOne = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const id = req.params.id;
    [err, sub_district] = await to(SubDistrict.find(
        {
            include: [{
                model: District,
                attributes: ['id', 'code', 'name'],
                required: true,
                include: [{
                    model: Province,
                    attributes: ['id', 'code', 'name'],
                    required: true,
                    include: [{
                        model: Region,
                        attributes: ['id', 'code', 'name'],
                        required: true,
                        include: [{
                            model: Country,
                            attributes: ['id', 'code', 'name'],
                            required: true
                        }]
                    }]
                }]
            }]
        },
        {
            'where' : {
                'id' : id
            }
        }
    ));
    return ReS(res, {'sub_district' : sub_district.toWeb()});
};

/**
 * @api {put} /sub-districts/:id updateSubDistrict
 * @apiGroup SubDistrict
 * @apiName updateSubDistrict
 *
 * @apiParam (Body Params) {Character} code code of sub-district 
 * @apiParam (Body Params) {String} name name of sub-district
 * @apiParam (Body Params) {String} district_id district_id of sub-district referenced from district
 *
 * @apiSuccess {UUID} id ID of the sub-district
 * @apiSuccess {Character} code code of sub-district
 * @apiSuccess {String} name name of sub-district
 * @apiSuccess {String} district_id district_id of sub-district referenced from district
 * @apiSuccess {Timestamp} created Date and Time the sub-district is created.
 * @apiSuccess {Timestamp} updated Date and Time the sub-district is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the sub-district is deleted.
 * @apiSuccess {String} Message update sub-district + id
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *  {
 *      "sub_district": 
 *          {
 *              "id": "53d3ac42-675b-49bd-bb51-b0a000f196f1",
 *              "code": "LB",
 *              "name": "Los Banos Sub District",
 *              "created": "2018-07-11T02:07:01.000Z",
 *              "updated": "2018-07-11T02:20:11.000Z",
 *              "deleted": null,
 *              "district_id": "7db0be44-a06f-4e27-a8be-81fa7078075e"
 *          },
 *         "message": "update sub-district: 53d3ac42-675b-49bd-bb51-b0a000f196f1",
 *         "success": true
 *  }
 *
 */

const update = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let sub_district;
    const id = req.params.id;
    const {
        district_id,
        code,
        name
    } = req.body;
    [err, sub_district] = await to(SubDistrict.update({
        'district_id' : district_id,
        'code' : code,
        'name' : name,
        'updated' : Sequelize.fn('NOW')
    },  {
        'where' : {
            'id' : id
        }
    }));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : sub_district,
        'result' : '201',
        'actor' : req.user.id
    }));
    [err, sub_district] = await to(SubDistrict.findById(id))
    return ReS(res, {'sub_district' : sub_district.toWeb(), 
                    'log' : log, 
                    'message' : 'update sub_district: ' + id});
};

/**
 * @api {deactivate} /sub-districts/:id/deactivate deactivateSubDistrict
 * @apiGroup SubDistrict
 * @apiName deactivateSubDistrict
 *
 * @apiSuccess {UUID} id ID of the sub-district
 * @apiSuccess {Character} code code of sub-district
 * @apiSuccess {String} name name of sub-district
 * @apiSuccess {String} district_id district_id of sub-district referenced from district
 * @apiSuccess {Timestamp} created Date and Time the sub-district is created.
 * @apiSuccess {Timestamp} updated Date and Time the sub-district is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the sub-district is deleted.
 * @apiSuccess {String} Message deactivated subdistrict + id
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *  {
 *      "sub_district": {
 *             "id": "68d365f7-354f-4437-9b7d-7c616b8883f6",
 *             "code": "SP",
 *             "name": "San Pablo City",
 *             "created": "2018-07-11T02:17:08.000Z",
 *             "updated": "2018-07-11T02:20:11.000Z",
 *             "deleted": "2018-07-11T02:23:34.000Z",
 *             "district_id": "d9ea75ae-1f3c-48d3-8b18-d2c30c84c38d"
 *         },
 *      "message": "deactivated sub_district: 68d365f7-354f-4437-9b7d-7c616b8883f6",
 *      "success": true
 *  }
 *
 */

const deactivate = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let sub_district;
    const id = req.params.id;
   
    [err, sub_district] = await to(SubDistrict.update({
        'deleted' : Sequelize.fn('NOW')
    },  {
        'where' : {
            'id' : id
        }
    }));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : sub_district,
        'result' : '201',
        'actor' : req.user.id
    }));
    [err, sub_district] = await to(SubDistrict.findById(id))
    return ReS(res, {'sub_district' : sub_district.toWeb(), 
                    'log' : log,
                    'message' : 'deactivated sub_district: ' + id});
};

/**
 * @api {reactivate} /sub-districts/:id/reactivate reactivateSubDistrict
 * @apiGroup SubDistrict
 * @apiName reactivateSubDistrict
 *
 * @apiSuccess {UUID} id ID of the sub-district
 * @apiSuccess {Character} code code of sub-district
 * @apiSuccess {String} name name of sub-district
 * @apiSuccess {String} district_id district_id of sub-district referenced from district
 * @apiSuccess {Timestamp} created Date and Time the sub-district is created.
 * @apiSuccess {Timestamp} updated Date and Time the sub-district is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the sub-district is deleted.
 * @apiSuccess {String} Message reactivated sub_district + id
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *  {
 *      "sub_district": {
 *             "id": "68d365f7-354f-4437-9b7d-7c616b8883f6",
 *             "code": "SP",
 *             "name": "San Pablo City",
 *             "created": "2018-07-11T02:17:08.000Z",
 *             "updated": "2018-07-11T02:20:11.000Z",
 *             "deleted": null,
 *             "district_id": "d9ea75ae-1f3c-48d3-8b18-d2c30c84c38d"
 *         },
 *      "message": "reactivated sub_district: 68d365f7-354f-4437-9b7d-7c616b8883f6",
 *      "success": true
 *  }
 *
 */
const reactivate = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let sub_district;
    const id = req.params.id;
   
    [err, sub_district] = await to(SubDistrict.update({
        'deleted' : null
    },  {
        'where' : {
            'id' : id
        }
    }));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : sub_district,
        'result' : '201',
        'actor' : req.user.id
    }));
    [err, sub_district] = await to(SubDistrict.findById(id))
    return ReS(res, {'sub_district' : sub_district.toWeb(), 
                    'log' : log,
                    'message' : 'reactivated sub_district: ' + id});
};

/**
 * @api {search} /sub-district/:id searchSubDistrict
 * @apiGroup SubDistrict
 * @apiName searchSubDistrict
 * 
 * @apiParam (Query Params) {UUID} id ID of sub-district
 * @apiParam (Query Params) {Character} code code of sub-district 
 * @apiParam (Query Params) {String} name name of sub-district
 * @apiParam (Query Params) {String} district_id district_id of sub-district referenced from district
 * @apiParam (Query Params) {Timestamp} created Date and Time the sub-district is created
 * @apiParam (Query Params) {Timestamp} updated Date and Time the sub-district is updated
 * @apiParam (Query Params) {Timestamp} deleted Date and Time the sub-district is deleted
 * 
 * @apiSuccess {UUID} id ID of the sub-district
 * @apiSuccess {Character} code code of sub-district
 * @apiSuccess {String} name name of sub-district
 * @apiSuccess {String} district_id district_id of sub-district referenced from district
 * @apiSuccess {Timestamp} created Date and Time the sub-district is created.
 * @apiSuccess {Timestamp} updated Date and Time the sub-district is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the sub-district is deleted.
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *  {
 *      "sub_districts": [
 *          {
 *              "id": "68d365f7-354f-4437-9b7d-7c616b8883f6",
 *              "code": "SP",
 *              "name": "San Pablo City",
 *              "created": "2018-07-11T02:17:08.000Z",
 *              "updated": "2018-07-11T02:20:11.000Z",
 *              "deleted": null,
 *              "district_id": "d9ea75ae-1f3c-48d3-8b18-d2c30c84c38d"
 *          }
 *      ],
 *      "success": true
 *  }
 *
 */

const search = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const {
        id,
        district_id,
        code,
        name
    } = req.query;
    let err, sub_district;
    [err, sub_district] = await to(SubDistrict.findAll({
        where : {
            [Op.or] : 
                [
                    {'id' : id}, 
                    {'district_id' : district_id},
                    {'code' : code}, 
                    {'name' : name}
                ]
        }
    }));
    return ReS(res, {'sub_districts' : sub_district});
}

module.exports = {
    'create' : create,
    'get'   : get,
    'getOne' : getOne,
    'update' : update,
    'deactivate' : deactivate,
    'reactivate' : reactivate,
    'search' : search
}