const District = require('./../models').district;
const Province   = require('./../models').province;
const Region  = require('./../models').region;
const Country = require('./../models').country;
const Log = require('./../models').log;
const Sequelize = require('sequelize');
const Op = Sequelize.Op;
const Authorized = require('./../models').authorized;
const authService   = require('./../services/AuthService');


/**
 * @api {post} /districts addDistrict
 * @apiGroup District
 * @apiName addDistrict
 *
 * @apiParam (System Generated) {UUID} id ID of district
 * @apiParam (Body Params) {Character} code code of district 
 * @apiParam (Body Params) {String} name name of district
 * @apiParam (Body Params) {String} province_id province_id of district referenced from province
 *
 * @apiSuccess {UUID} id ID of the district
 * @apiSuccess {Character} code code of district
 * @apiSuccess {String} name name of district
 * @apiSuccess {String} province_id province_id of district referenced from province
 * @apiSuccess {Timestamp} created Date and Time the district is created.
 * @apiSuccess {Timestamp} updated Date and Time the district is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the district is deleted.
 * @apiSuccess {String} Message Successfully created new district
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *  {
 *      "message": "Successfully created new district",
 *      "district": {
 *      "id": "7db0be44-a06f-4e27-a8be-81fa7078075e",
 *      "created": {
 *          "val": "NOW()"
 *      },
 *      "updated": null,
 *      "deleted": null,
 *      "province_id": "3390ede7-e509-4f06-97b2-8580c29dfb3c",
 *      "code": "D2",
 *      "name": "District2"
 *      },
 *      "success" : true
 *  }
 *
 */

const create = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    const {
        province_id,
        code,
        name
    } = req.body;
    let district;
    [err, district] = await to(District.create({
        'province_id'   :province_id,
        'code'  : code,
        'name'  : name
    }));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : district,
        'result' : '201',
        'actor' : req.user.id
    }));
    return ReS(res, {'message' : 'Successfully created new district', 
                    'district' : district.toWeb(),
                    'log' : log}, 201);
};

/**
 * @api {get} /districts getDistricts
 * @apiGroup District
 * @apiName getDistricts
 *
 * @apiSuccess {UUID} id ID of the district
 * @apiSuccess {Character} code code of district
 * @apiSuccess {String} name name of district
 * @apiSuccess {String} province_id province_id of district referenced from province
 * @apiSuccess {String} code code of province
 * @apiSuccess {String} name name of province
 * @apiSuccess {UUID} id id of region
 * @apiSuccess {String} code code of region
 * @apiSuccess {String} name name of region
 * @apiSuccess {UUID} id id of country
 * @apiSuccess {String} code code of country
 * @apiSuccess {String} name name of country
 * @apiSuccess {Timestamp} created Date and Time the district is created.
 * @apiSuccess {Timestamp} updated Date and Time the district is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the district is deleted.
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *  {
 *      "districts": [
 *        {
 *             "id": "7db0be44-a06f-4e27-a8be-81fa7078075e",
 *             "code": "D2",
 *             "name": "District2",
 *             "created": "2018-07-11T00:58:36.000Z",
 *             "updated": "2018-07-11T02:03:54.000Z",
 *             "deleted": null,
 *             "province_id": "3390ede7-e509-4f06-97b2-8580c29dfb3c",
 *             "province": {
 *                 "id": "3390ede7-e509-4f06-97b2-8580c29dfb3c",
 *                 "code": "LAG",
 *                 "name": "Laguna",
 *                 "region": {
 *                     "id": "84d0f129-a195-486e-8c63-012857af6f1a",
 *                     "code": "CAL",
 *                     "name": "Calabarzon",
 *                     "country": {
 *                         "id": "79dd673a-3c03-47bc-8957-c47ffcb33ef2",
 *                         "code": "PH",
 *                         "name": "Philippines"
 *                     }
 *                 }
 *             }
 *         },
 *         {
 *             "id": "d9ea75ae-1f3c-48d3-8b18-d2c30c84c38d",
 *             "code": "D3",
 *             "name": "District3",
 *             "created": "2018-07-11T01:02:30.000Z",
 *             "updated": "2018-07-11T02:02:59.000Z",
 *             "deleted": "2018-07-11T01:18:46.000Z",
 *             "province_id": "3390ede7-e509-4f06-97b2-8580c29dfb3c",
 *             "province": {
 *                 "id": "3390ede7-e509-4f06-97b2-8580c29dfb3c",
 *                 "code": "LAG",
 *                 "name": "Laguna",
 *                 "region": {
 *                     "id": "84d0f129-a195-486e-8c63-012857af6f1a",
 *                     "code": "CAL",
 *                     "name": "CALABARZON",
 *                     "country": {
 *                         "id": "79dd673a-3c03-47bc-8957-c47ffcb33ef2",
 *                         "code": "PH",
 *                         "name": "Philippines"
 *                     }
 *                 }
 *             }
 *         }
 *      ],
 *      "success": true
 *  }
 *
 */

const get = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    [err, district] = await to(District.findAll({
        include: [{
            model: Province,
            attributes: ['id', 'code', 'name'],
            required: true,
            include: [{
                    model: Region,
                    attributes: ['id', 'code', 'name'],
                    required: true,
                    include: [{
                            model: Country,
                            attributes: ['id', 'code', 'name'],
                            required: true
                    }]
            }]
        }]
    }));
    return ReS(res, {'message' : 'Successfully logged',
                    'districts' : district}, 201);
};

/**
 * @api {getOne} /districts/:id getOneDistrict
 * @apiGroup District
 * @apiName getOneDistrict
 *
 * @apiSuccess {UUID} id ID of the district
 * @apiSuccess {Character} code code of district
 * @apiSuccess {String} name name of district
 * @apiSuccess {String} province_id province_id of district referenced from province
 * @apiSuccess {String} code code of province
 * @apiSuccess {String} name name of province
 * @apiSuccess {UUID} id id of region
 * @apiSuccess {String} code code of region
 * @apiSuccess {String} name name of region
 * @apiSuccess {UUID} id id of country
 * @apiSuccess {String} code code of country
 * @apiSuccess {String} name name of country
 * @apiSuccess {Timestamp} created Date and Time the district is created.
 * @apiSuccess {Timestamp} updated Date and Time the district is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the district is deleted.
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *  {
 *      "district": 
 *         {
 *             "id": "d9ea75ae-1f3c-48d3-8b18-d2c30c84c38d",
 *             "code": "D3",
 *             "name": "District3",
 *             "created": "2018-07-11T01:02:30.000Z",
 *             "updated": "2018-07-11T02:02:59.000Z",
 *             "deleted": "2018-07-11T01:18:46.000Z",
 *             "province_id": "3390ede7-e509-4f06-97b2-8580c29dfb3c",
 *             "province": {
 *                 "id": "3390ede7-e509-4f06-97b2-8580c29dfb3c",
 *                 "code": "LAG",
 *                 "name": "Laguna",
 *                 "region": {
 *                     "id": "84d0f129-a195-486e-8c63-012857af6f1a",
 *                     "code": "CAL",
 *                     "name": "Calabarzon",
 *                     "country": {
 *                         "id": "79dd673a-3c03-47bc-8957-c47ffcb33ef2",
 *                         "code": "PH",
 *                         "name": "Philippines"
 *                     }
 *                 }
 *             }
 *         },
 *      "success": true
 *  }
 *
 */

const getOne = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const id = req.params.id;
    [err, district] = await to(District.find(
        {
            include: [{
                model: Province,
                attributes: ['id', 'code', 'name'],
                required: true,
                include: [{
                    model: Region,
                    attributes: ['id', 'code', 'name'],
                    required: true,
                    include: [{
                        model: Country,
                        attributes: ['id', 'code', 'name'],
                        required: true
                    }]
                }]
            }]
        },
        {
            'where' : {
                'id' : id
            }
        }
    ));
    return ReS(res, {'district' : district.toWeb()});
};

/**
 * @api {put} /districts/:id updateDistrict
 * @apiGroup District
 * @apiName updateDistrict
 *
 * @apiParam (Body Params) {Character} code code of district 
 * @apiParam (Body Params) {String} name name of district
 * @apiParam (Body Params) {String} province_id province_id of district referenced from province
 *
 * @apiSuccess {UUID} id ID of the district
 * @apiSuccess {Character} code code of district
 * @apiSuccess {String} name name of district
 * @apiSuccess {String} province_id province_id of district referenced from province
 * @apiSuccess {Timestamp} created Date and Time the district is created.
 * @apiSuccess {Timestamp} updated Date and Time the district is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the district is deleted.
 * @apiSuccess {String} Message update district + id
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *  {
 *       "district": 
 *          {
 *             "id": "d9ea75ae-1f3c-48d3-8b18-d2c30c84c38d",
 *             "code": "D3",
 *             "name": "District3",
 *             "created": "2018-07-11T01:02:30.000Z",
 *             "updated": "2018-07-11T01:09:50.000Z",
 *             "deleted": null,
 *             "province_id": "3390ede7-e509-4f06-97b2-8580c29dfb3c"
 *         },
 *         "message": "update district: d9ea75ae-1f3c-48d3-8b18-d2c30c84c38d",
 *         "success": true
 *  }
 *
 */

const update = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let district;
    const id = req.params.id;
    const {
        province_id,
        code,
        name
    } = req.body;
    [err, district] = await to(District.update({
        'province_id' : province_id,
        'code' : code,
        'name' : name,
        'updated' : Sequelize.fn('NOW')
    },  {
        'where' : {
            'id' : id
        }
    }));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }
    [err, district] = await to(District.findById(id));
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : district,
        'result' : '201',
        'actor' : req.user.id
    }));
    return ReS(res, {'district' : district.toWeb(), 
                    'message' : 'update district: ' + id,
                    'log' : log});
};

/**
 * @api {deactivate} /districts/:id/deactivate deactivateDistrict
 * @apiGroup District
 * @apiName deactivateDistrict
 *
 * @apiSuccess {UUID} id ID of the district
 * @apiSuccess {Character} code code of district
 * @apiSuccess {String} name name of district
 * @apiSuccess {String} province_id province_id of district referenced from province
 * @apiSuccess {Timestamp} created Date and Time the district is created.
 * @apiSuccess {Timestamp} updated Date and Time the district is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the district is deleted.
 * @apiSuccess {String} Message deactivated district + id
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *  {
 *      "districts": [
 *          {
 *              "id": "7db0be44-a06f-4e27-a8be-81fa7078075e",
 *              "code": "D2",
 *              "name": "District2",
 *              "created": "2018-07-11T00:58:36.000Z",
 *              "updated": null,
 *              "deleted": "2018-07-11T01:18:46.000Z",
 *              "province_id": "3390ede7-e509-4f06-97b2-8580c29dfb3c"
 *          }
 *      ],
 *      "message" : deactivated district 7db0be44-a06f-4e27-a8be-81fa7078075e,
 *      "success": true
 *  }
 *
 */

const deactivate = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let district;
    const id = req.params.id;
   
    [err, district] = await to(District.update({
        'deleted' : Sequelize.fn('NOW')
    },  {
        'where' : {
            'id' : id
        }
    }));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }
    [err, district] = await to(District.findById(id));
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : district,
        'result' : '201',
        'actor' : req.user.id
    }));
    return ReS(res, {'district' : district.toWeb(), 
                    'message' : 'deactivated district: ' + id,
                    'log' : log});
};

/**
 * @api {reactivate} /districts/:id/reactivate reactivateDistrict
 * @apiGroup District
 * @apiName reactivateDistrict
 *
 * @apiSuccess {UUID} id ID of the district
 * @apiSuccess {Character} code code of district
 * @apiSuccess {String} name name of district
 * @apiSuccess {String} province_id province_id of district referenced from province
 * @apiSuccess {Timestamp} created Date and Time the district is created.
 * @apiSuccess {Timestamp} updated Date and Time the district is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the district is deleted.
 * @apiSuccess {String} Message reactivated district + id
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *  {
 *      "districts": [
 *          {
 *              "id": "7db0be44-a06f-4e27-a8be-81fa7078075e",
 *              "code": "D2",
 *              "name": "District2",
 *              "created": "2018-07-11T00:58:36.000Z",
 *              "updated": null,
 *              "deleted": null,
 *              "province_id": "3390ede7-e509-4f06-97b2-8580c29dfb3c"
 *          }
 *      ],
 *      "message" : reactivated district 7db0be44-a06f-4e27-a8be-81fa7078075e,
 *      "success": true
 *  }
 *
 */

const reactivate = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let district;
    const id = req.params.id;
    [err, district] = await to(District.update({
        'deleted' : null
    },  {
        'where' : {
            'id' : id
        }
    }));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : req.user.id
        }));
        return ReE(res, err, 422);
    }
    [err, district] = await to(District.findById(id));
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : district,
        'result' : '201',
        'actor' : req.user.id
    }));
    return ReS(res, {'district' : district.toWeb(), 
                    'message' : 'reactivated district: ' + id,
                    'log' : log});
};

/**
 * @api {search} /districts/search searchDistrict
 * @apiGroup District
 * @apiName searchDistrict
 * 
 * @apiParam (Query Params) {UUID} id ID of district
 * @apiParam (Query Params) {Character} code code of district 
 * @apiParam (Query Params) {String} name name of district
 * @apiParam (Query Params) {String} province_id province_id of district referenced from province
 * @apiParam (Query Params) {Timestamp} created Date and Time the district is created
 * @apiParam (Query Params) {Timestamp} updated Date and Time the district is updated
 * @apiParam (Query Params) {Timestamp} deleted Date and Time the district is deleted
 * 
 * @apiSuccess {UUID} id ID of the district
 * @apiSuccess {Character} code code of district
 * @apiSuccess {String} name name of district
 * @apiSuccess {String} province_id province_id of district referenced from province
 * @apiSuccess {Timestamp} created Date and Time the district is created.
 * @apiSuccess {Timestamp} updated Date and Time the district is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the district is deleted.
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *  {
 *       "district": [ 
 *          {
 *              "id": "d9ea75ae-1f3c-48d3-8b18-d2c30c84c38d",
 *              "code": "D3",
 *              "name": "District3",
 *              "created": "2018-07-11T01:02:30.000Z",
 *              "updated": "2018-07-11T01:09:50.000Z",
 *              "deleted": null,
 *              "province_id": "3390ede7-e509-4f06-97b2-8580c29dfb3c"
 *           }
 *         ],
 *         "success": true
 *  }
 *
 */

const search = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const {
        id,
        province_id,
        code,
        name
    } = req.query;
    let err, district;
    [err, district] = await to(District.findAll({
        where : {
            [Op.or] : 
                [
                    {'id' : id}, 
                    {'province_id' : province_id}, 
                    {'code' : code}, 
                    {'name' : name}
                ]
        }
    }));
    return ReS(res, {'districts' : district});
}

module.exports = {
    'create' : create,
    'get' : get,
    'getOne' : getOne,
    'update' : update,
    'deactivate' : deactivate,
    'reactivate' : reactivate,
    'search' : search
}