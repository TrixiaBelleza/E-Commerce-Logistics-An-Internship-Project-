const Dispatcher  = require('./../models').dispatcher;
const Log = require('./../models').log;
const User = require('./../models').User;
const Sequelize = require('sequelize');
const Op = Sequelize.Op;
const Authorized = require('./../models').authorized;
const authService   = require('./../services/AuthService');


/**
* @api {get} /dispatchers Retrieve Dispatchers
* @apiName GetDispatchers
* @apiGroup Dispatcher
*
* @apiSuccess {String} id Dispatcher ID.
* @apiSuccess {Timestamp} created  Date and Time the Dispatcher is created.
* @apiSuccess {Timestamp} updated  Date and Time the Dispatcher is updated.
* @apiSuccess {Timestamp} deleted  Date and Time the Dispatcher is deleted.
* @apiSuccess {String} hub_id  Hub ID referenced from Hub.
* @apiSuccess {Float} distribution_center_id  Distribution Center ID referenced from Distribution Center.
* @apiSuccess {String} user_id  User ID referenced from User.
* @apiSuccess {String} user_id.email  Email Address of the Dispatcher.
* @apiSuccess {String} user_id.first_name  First Name of the Dispatcher.
* @apiSuccess {String} user_id.last_name  Last Name of the Dispatcher.
* @apiSuccess {String} user_id.middle_name  Middle Name of the Dispatcher.
* @apiSuccess {String} user_id.contact_number  Contact Number of the Dispatcher.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
        "dispatchers": [
            {
                "id": "9bff837f-b416-49c8-9000-62ec09e2ff3d",
                "created": "2018-07-12T01:47:22.000Z",
                "updated": null,
                "deleted": null,
                "user_id": 1,
                "hub_id": "5ca82e33-f401-4985-a329-33c62f791c23",
                "distribution_center_id": "cc5c5aa7-16c0-4173-87f2-f9172661cafc",
                "User": {
                    "email": "jdelacruz@gmail.com",
                    "first_name": "Juan",
                    "last_name": "Dela Cruz",
                    "middle_name": "Reyes",
                    "contact_number": "09096755833"
                }
            }
        ],
        "success": true
    }
*
*/

const get = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    [err, dispatchers] = await to(Dispatcher.findAll({
        include: [{
            model: User,
            attributes: ['email', 'first_name', 'last_name', 'middle_name', 'contact_number'],
            required: true
        }]
    }));
    return ReS(res, {'dispatchers': dispatchers});
};

/**
* @api {get} /dispatchers/:id Retrieve Dispatcher By ID
* @apiName GetDispatcherByID
* @apiGroup Dispatcher
*
* @apiParam {String} id Dispatcher unique ID.
*
* @apiSuccess {String} id Dispatcher ID.
* @apiSuccess {Timestamp} created  Date and Time the Dispatcher is created.
* @apiSuccess {Timestamp} updated  Date and Time the Dispatcher is updated.
* @apiSuccess {Timestamp} deleted  Date and Time the Dispatcher is deleted.
* @apiSuccess {String} hub_id  Hub ID referenced from Hub.
* @apiSuccess {Float} distribution_center_id  Distribution Center ID referenced from Distribution Center.
* @apiSuccess {String} user_id  User ID referenced from User.
* @apiSuccess {String} user_id.email  Email Address of the Dispatcher.
* @apiSuccess {String} user_id.first_name  First Name of the Dispatcher.
* @apiSuccess {String} user_id.last_name  Last Name of the Dispatcher.
* @apiSuccess {String} user_id.middle_name  Middle Name of the Dispatcher.
* @apiSuccess {String} user_id.contact_number  Contact Number of the Dispatcher.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
        "dispatcher": {
            "id": "9bff837f-b416-49c8-9000-62ec09e2ff3d",
            "created": "2018-07-12T01:47:22.000Z",
            "updated": null,
            "deleted": null,
            "user_id": 1,
            "hub_id": "5ca82e33-f401-4985-a329-33c62f791c23",
            "distribution_center_id": "cc5c5aa7-16c0-4173-87f2-f9172661cafc",
            "User": {
                "email": "jdelacruz@gmail.com",
                "first_name": "Juan",
                "last_name": "Dela Cruz",
                "middle_name": "Reyes",
                "contact_number": "09096755833"
            }
        },
        "success": true
    }
*
*/

const getOne = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const id = req.params.id;
    [err, dispatcher] = await to(Dispatcher.find({
            include: [{
               model: User,
                attributes: ['email', 'first_name', 'last_name', 'middle_name', 'contact_number'],
                required: true
            }],

            'where' : {
                'id' : id
            }
    }));
    return ReS(res, {'dispatcher': dispatcher.toWeb()});
};

/**
* @api {post} /dispatchers Add Dispatcher
* @apiName AddDispatcher
* @apiGroup Dispatcher
*
* @apiParam (System Generated) {String} id Dispatcher unique ID.
* @apiParam (Body Params) {String} user_id  User ID.
* @apiParam (Body Params) {String} hub_id  Hub ID.
* @apiParam (Body Params) {String} distribution_center_id  Distribution Center ID.
*
* @apiSuccess {Timestamp} created  Date and Time the Dispatcher is created.
* @apiSuccess {Timestamp} updated  Date and Time the Dispatcher is updated.
* @apiSuccess {Timestamp} deleted  Date and Time the Dispatcher is deleted.
* @apiSuccess {String} user_id  User ID referenced from User.
* @apiSuccess {String} hub_id  Hub ID referenced from Hub.
* @apiSuccess {String} distribution_center_id  Distribution Center ID referenced from Distribution Center.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
        "message": "successfully created new dispatcher",
        "dispatcher": {
            "id": "9bff837f-b416-49c8-9000-62ec09e2ff3d",
            "created": {
                "val": "NOW()"
            },
            "updated": null,
            "deleted": null,
            "user_id": "1",
            "hub_id": "5ca82e33-f401-4985-a329-33c62f791c23",
            "distribution_center_id": "cc5c5aa7-16c0-4173-87f2-f9172661cafc"
        },
        "success": true
    }
*
*/

const create = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    const {
        user_id,
        hub_id,
        distribution_center_id
    } = req.body;
    let dispatcher;
    let user = req.user;
    [err, dispatcher] = await to(Dispatcher.create({
        'user_id' : user_id,
        'hub_id'  : hub_id,
        'distribution_center_id' : distribution_center_id
    }));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : dispatcher,
        'result' : '201',
        'actor' : user.id
    }));
    return ReS(res, {'message':'successfully created new dispatcher', 
                    'dispatcher': dispatcher.toWeb(),
                    'log' : log}, 201);
};

/**
* @api {get} /dispatchers/search Search Dispatcher
* @apiName SearchDispatcher
* @apiGroup Dispatcher
*
* @apiParam (Query Params) {String} user_id  User ID.
* @apiParam (Query Params) {String} hub_id  Hub ID.
* @apiParam (Query Params) {String} distribution_center_id  Distribution Center ID.
*
* @apiSuccess {String} id Dispatcher ID.
* @apiSuccess {Timestamp} created  Date and Time the Dispatcher is created.
* @apiSuccess {Timestamp} updated  Date and Time the Dispatcher is updated.
* @apiSuccess {Timestamp} deleted  Date and Time the Dispatcher is deleted.
* @apiSuccess {String} hub_id  Hub ID referenced from Hub.
* @apiSuccess {String} distribution_center_id  Distribution Center ID referenced from Distribution Center.
* @apiSuccess {String} user_id  User ID referenced from User.
* @apiSuccess {String} user_id.email  Email Address of the Dispatcher.
* @apiSuccess {String} user_id.first_name  First Name of the Dispatcher.
* @apiSuccess {String} user_id.last_name  Last Name of the Dispatcher.
* @apiSuccess {String} user_id.middle_name  Middle Name of the Dispatcher.
* @apiSuccess {String} user_id.contact_number  Contact Number of the Dispatcher.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
         "dispatchers": [
            {
                "id": "9bff837f-b416-49c8-9000-62ec09e2ff3d",
                "created": "2018-07-12T01:47:22.000Z",
                "updated": null,
                "deleted": null,
                "user_id": 1,
                "hub_id": "5ca82e33-f401-4985-a329-33c62f791c23",
                "distribution_center_id": "cc5c5aa7-16c0-4173-87f2-f9172661cafc",
                "User": {
                    "email": "jdelacruz@gmail.com",
                    "first_name": "Juan",
                    "last_name": "Dela Cruz",
                    "middle_name": "Reyes",
                    "contact_number": "09096755833"
                }
            }
        ],
        "success": true
    }
*
*/

const search = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const {
        user_id,
        hub_id,
        distribution_center_id,
        created,
        updated,
        deleted
    } = req.query;
    [err, dispatcher] = await to(Dispatcher.findAll({
            include: [{
               model: User,
                attributes: ['email', 'first_name', 'last_name', 'middle_name', 'contact_number'],
                required: true
            }],

            'where' : {
                [Op.or]: [{'user_id': user_id}, 
                        {'hub_id': hub_id}, 
                        {'distribution_center_id': distribution_center_id}, 
                        {'created': created}, 
                        {'updated': updated}, 
                        {'deleted': deleted}]
            }
    }));
    return ReS(res, {'dispatchers': dispatcher});
};

/**
* @api {put} /dispatchers/:id Update Dispatcher
* @apiName UpdateDispatcherByID
* @apiGroup Dispatcher
*
* @apiParam {String} id Dispatcher unique ID.
* @apiParam (Body Params) {String} user_id  User ID.
* @apiParam (Body Params) {String} hub_id  Hub ID.
* @apiParam (Body Params) {String} distribution_center_id  Distribution Center ID.
*
* @apiSuccess {String} id Dispatcher ID.
* @apiSuccess {Timestamp} created  Date and Time the Dispatcher is created.
* @apiSuccess {Timestamp} updated  Date and Time the Dispatcher is updated.
* @apiSuccess {Timestamp} deleted  Date and Time the Dispatcher is deleted.
* @apiSuccess {String} user_id  User ID referenced from User.
* @apiSuccess {String} hub_id  Hub ID referenced from Hub.
* @apiSuccess {String} distribution_center_id  Distribution Center ID referenced from Distribution Center.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
        "dispatcher": {
            "id": "2e4dca57-d5dd-4a71-b04f-b9ee404d33df",
            "created": "2018-07-11T08:30:16.000Z",
            "updated": null,
            "deleted": null,
            "user_id": 1,
            "hub_id": "61b54974-015f-4ac9-b8e0-17b3bca537a1",
            "distribution_center_id": "1046eed9-c0be-408c-a685-1faa08f9760e"
        },
        "message": "update dispatcher: 2e4dca57-d5dd-4a71-b04f-b9ee404d33df",
        "success": true
    }
*
*/

const update = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let dispatcher;
    let user = req.user;
    const id = req.params.id;
    const {
    	user_id,
        hub_id,
        distribution_center_id
    } = req.body;
    [err, dispatcher] = await to(Dispatcher.update({
    	'user_id' : user_id,
        'hub_id'  : hub_id,
        'distribution_center_id' : distribution_center_id,
        'updated' : Sequelize.fn('NOW')
        }, {
            'where': {
                'id': id
            }
        }
    ));
    [err, dispatcher] = await to(Dispatcher.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : dispatcher,
        'result' : '201',
        'actor' : user.id
    }));
    return ReS(res, {'dispatcher': dispatcher.toWeb(), 
                    'message': 'update dispatcher: ' + id,
                    'log' : log});
};

/**
* @api {post} /dispatchers/:id/deactivate Deactivate Dispatcher
* @apiName DeactivateDispatcher
* @apiGroup Dispatcher
*
* @apiParam {String} id Dispatcher unique ID.
*
* @apiSuccess {String} id Dispatcher ID.
* @apiSuccess {Timestamp} created  Date and Time the Dispatcher is created.
* @apiSuccess {Timestamp} updated  Date and Time the Dispatcher is updated.
* @apiSuccess {Timestamp} deleted  Date and Time the Dispatcher is deleted.
* @apiSuccess {String} user_id  User ID referenced from User.
* @apiSuccess {String} hub_id  Hub ID referenced from Hub.
* @apiSuccess {String} distribution_center_id  Distribution Center ID referenced from Distribution Center.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
        "dispatcher": {
            "id": "2e4dca57-d5dd-4a71-b04f-b9ee404d33df",
            "created": "2018-07-11T08:30:16.000Z",
            "updated": null,
            "deleted": "2018-07-12T01:13:37.000Z",
            "user_id": 1,
            "hub_id": "61b54974-015f-4ac9-b8e0-17b3bca537a1",
            "distribution_center_id": "1046eed9-c0be-408c-a685-1faa08f9760e"
        },
        "message": "deactivated dispatcher: 2e4dca57-d5dd-4a71-b04f-b9ee404d33df",
        "success": true
    }
*
*/

const deactivate = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let dispatcher;
    let user = req.user;
    const id = req.params.id;
    [err, dispatcher] = await to(Dispatcher.update({
            deleted : Sequelize.fn('NOW')
        },
        {
            'where': {
                'id': id
            }
        }
    ));
    [err, dispatcher] = await to(Dispatcher.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : dispatcher,
        'result' : '201',
        'actor' : user.id
    }));
    return ReS(res, {'dispatcher': dispatcher.toWeb(), 
                    'message': 'deactivated dispatcher: ' + id,
                    'log' : log});
};

/**
* @api {post} /dispatchers/:id/reactivate Reactivate Dispatcher
* @apiName ReactivateDispatcher
* @apiGroup Dispatcher
*
* @apiParam {String} id Dispatcher unique ID.
*
* @apiSuccess {String} id Dispatcher ID.
* @apiSuccess {Timestamp} created  Date and Time the Dispatcher is created.
* @apiSuccess {Timestamp} updated  Date and Time the Dispatcher is updated.
* @apiSuccess {Timestamp} deleted  Date and Time the Dispatcher is deleted.
* @apiSuccess {String} user_id  User ID referenced from User.
* @apiSuccess {String} hub_id  Hub ID referenced from Hub.
* @apiSuccess {String} distribution_center_id  Distribution Center ID referenced from Distribution Center.
* @apiSuccessExample {json} Success-Response:
*   HTTP/1.1 200 OK
*   {
        "dispatcher": {
            "id": "2e4dca57-d5dd-4a71-b04f-b9ee404d33df",
            "created": "2018-07-11T08:30:16.000Z",
            "updated": null,
            "deleted": null,
            "user_id": 1,
            "hub_id": "61b54974-015f-4ac9-b8e0-17b3bca537a1",
            "distribution_center_id": "1046eed9-c0be-408c-a685-1faa08f9760e"
        },
        "message": "reactivated dispatcher: 2e4dca57-d5dd-4a71-b04f-b9ee404d33df",
        "success": true
    }
*
*/

const reactivate = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let dispatcher;
    let user = req.user;
    const id = req.params.id;
    [err, dispatcher] = await to(Dispatcher.update({
            deleted : null
        },
        {
            'where': {
                'id': id
            }
        }
    ));
    [err, dispatcher] = await to(Dispatcher.findById(id));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : dispatcher,
        'result' : '201',
        'actor' : user.id
    }));
    return ReS(res, {'dispatcher': dispatcher.toWeb(), 
                    'message': 'reactivated dispatcher: ' + id,
                    'log' : log});
};

module.exports = {
    'get'   : get,
    'create' : create,
    'getOne' : getOne,
    'deactivate' : deactivate,
    'reactivate' : reactivate,
    'update' : update,
    'search' : search
}