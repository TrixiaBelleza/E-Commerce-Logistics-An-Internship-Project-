const ItemVolume = require('./../models').item_volume;
const Log = require('./../models').log;
const Sequelize = require('sequelize');
const Op = Sequelize.Op;
const Authorized = require('./../models').authorized;
const authService   = require('./../services/AuthService');


/**
 * @api {get} /item-volumes getItemVolumes
 * @apiGroup ItemVolume
 * @apiName getItemVolumes
 *
 * @apiSuccess {UUID} id ID of item volume
 * @apiSuccess {Float} length length of item volume 
 * @apiSuccess {Float} height height of item volume
 * @apiSuccess {Float} width width of item volume
 * @apiSuccess {Float} volume volume of item volume
 * @apiSuccess {Timestamp} created Date and Time the item volume is created.
 * @apiSuccess {Timestamp} updated Date and Time the item volume is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the item volume is deleted.
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *       "item_volumes": [
 *           {
 *               "id": "25fb351f-7ceb-46bc-b8c8-7f4a075e6f77",
 *               "length": 2.5,
 *               "height": 3.5,
 *               "width": 4.2,
 *               "volume": 23.3,
 *               "created": "2018-07-12T08:50:21.000Z",
 *               "updated": null,
 *               "deleted": null
 *           },
 *           {
 *               "id": "ab1c7311-d79b-4cbe-aa91-f0c375c1aa4e",
 *               "length": 2.2,
 *               "height": 3.1,
 *               "width": 4.2,
 *               "volume": 23.3,
 *               "created": "2018-07-12T08:51:37.000Z",
 *               "updated": null,
 *               "deleted": null
 *           }
 *       ],
 *       "success": true
 *   }
 *
 */

const get = async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    [err, item_volume] = await to(ItemVolume.findAll());
    return ReS(res, {'item_volumes' : item_volume});
};

/**
 * @api {getOne} /item-volumes/:id getOneItemVolume
 * @apiGroup ItemVolume
 * @apiName getOneItemVolume
 *
 * @apiSuccess {UUID} id ID of item volume
 * @apiSuccess {Float} length length of item volume 
 * @apiSuccess {Float} height height of item volume
 * @apiSuccess {Float} width width of item volume
 * @apiSuccess {Float} volume volume of item volume
 * @apiSuccess {Timestamp} created Date and Time the item volume is created.
 * @apiSuccess {Timestamp} updated Date and Time the item volume is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the item volume is deleted.
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *       "item_volumes": 
 *           {
 *               "id": "25fb351f-7ceb-46bc-b8c8-7f4a075e6f77",
 *               "length": 2.5,
 *               "height": 3.5,
 *               "width": 4.2,
 *               "volume": 23.3,
 *               "created": "2018-07-12T08:50:21.000Z",
 *               "updated": null,
 *               "deleted": null
 *           }
 *       "success": true
 *   }
 *
 */
const getOne = async (req, res) => {
    res.setHeader('Content-Type', 'applciation/json');
    const id = req.params.id;
    [err, item_volume] = await to(ItemVolume.findById(id));
    return ReS(res, {'item_volume' : item_volume});
};

/**
 * @api {post} /item-volumes addItemVolume
 * @apiGroup ItemVolume
 * @apiName addItemVolume
 *
 * @apiParam (Body Params) {Float} length length of item volume 
 * @apiParam (Body Params) {Float} height height of item volume
 * @apiParam (Body Params) {Float} width width of item volume
 * @apiParam (Body Params) {Float} volume volume of item volume
 *
 * @apiSuccess {UUID} id ID of item volume
 * @apiSuccess {Float} length length of item volume 
 * @apiSuccess {Float} height height of item volume
 * @apiSuccess {Float} width width of item volume
 * @apiSuccess {Float} volume volume of item volume
 * @apiSuccess {Timestamp} created Date and Time the item volume is created.
 * @apiSuccess {Timestamp} updated Date and Time the item volume is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the item volume is deleted.
 * @apiSuccess {String} Message Successfully created new item volume
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *      "message": "Successfully created new item_volume",
 *      "item_volume": {
 *          "id": "25fb351f-7ceb-46bc-b8c8-7f4a075e6f77",
 *          "created": {
 *              "val": "NOW()"
 *          },
 *          "length": "2.5",
 *          "height": "3.5",
 *          "width": "4.2",
 *          "volume": "23.3"
 *      },
 *      "success": true
 *   }
 *
 */

const create = async(req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    const {
        length,
        height,
        width,
        volume
    } = req.body;
    let item_volume;
    let user = req.user;
    [err, item_volume] = await to(ItemVolume.create({
        'length' : length,
        'height' : height,
        'width' : width,
        'volume' : volume
    }));
    if (err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : item_volume,
        'result' : '201',
        'actor' : user.id
    }));
    return ReS(res, {'message' : 'Successfully created new item_volume',
                    'item_volume' : item_volume,
                    'log' : log}, 201);
};

/**
 * @api {put} /item-volumes/:id updateItemVolume
 * @apiGroup ItemVolume
 * @apiName updateItemVolume
 *
 * @apiParam (Body Params) {Float} length length of item volume 
 * @apiParam (Body Params) {Float} height height of item volume
 * @apiParam (Body Params) {Float} width width of item volume
 * @apiParam (Body Params) {Float} volume volume of item volume
 *
 * @apiSuccess {UUID} id ID of item volume
 * @apiSuccess {Float} length length of item volume 
 * @apiSuccess {Float} height height of item volume
 * @apiSuccess {Float} width width of item volume
 * @apiSuccess {Float} volume volume of item volume
 * @apiSuccess {Timestamp} created Date and Time the item volume is created.
 * @apiSuccess {Timestamp} updated Date and Time the item volume is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the item volume is deleted.
 * @apiSuccess {String} Message updated item_volume + id
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *       "item_volume": {
 *           "id": "25fb351f-7ceb-46bc-b8c8-7f4a075e6f77",
 *           "length": 2.2,
 *           "height": 8.9,
 *           "width": 4.2,
 *           "volume": 56.2,
 *           "created": "2018-07-12T08:50:21.000Z",
 *           "updated": "2018-07-12T08:53:38.000Z",
 *           "deleted": null
 *       },
 *       "message": "update item_volume: 25fb351f-7ceb-46bc-b8c8-7f4a075e6f77",
 *       "success": true
 *   }
 */

const update = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let item_volume;
    let user = req.user;
    const id = req.params.id;
    const {
        length,
        height,
        width,
        volume
    } = req.body;
    [err, item_volume] = await to(ItemVolume.update({
        'length' : length,
        'height' : height,
        'width' : width,
        'volume' : volume,
        'updated' : Sequelize.fn('NOW')
    }, {
        'where' : {
            'id' : id
        }
    }));
    [err, item_volume] = await to(ItemVolume.findById(id));
    if(err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : item_volume,
        'result' : '201',
        'actor' : user.id
    }));
    return ReS(res, {'item_volume' : item_volume,
                    'message' : 'update item_volume: ' + id,
                    'log' : log});
};

/**
 * @api {deactivate} /item-volumes/:id/deactivate deactivateItemVolume
 * @apiGroup ItemVolume
 * @apiName deactivateItemVolume
 *
 * @apiSuccess {UUID} id ID of item volume
 * @apiSuccess {Float} length length of item volume 
 * @apiSuccess {Float} height height of item volume
 * @apiSuccess {Float} width width of item volume
 * @apiSuccess {Float} volume volume of item volume
 * @apiSuccess {Timestamp} created Date and Time the item volume is created.
 * @apiSuccess {Timestamp} updated Date and Time the item volume is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the item volume is deleted.
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *      "item_volume": {
 *          "id": "25fb351f-7ceb-46bc-b8c8-7f4a075e6f77",
 *          "length": 2.2,
 *          "height": 8.9,
 *          "width": 4.2,
 *          "volume": 56.2,
 *          "created": "2018-07-12T08:50:21.000Z",
 *          "updated": "2018-07-12T08:53:38.000Z",
 *          "deleted": "2018-07-12T08:55:16.000Z"
 *      },
 *      "message": "deactivated item volume: 25fb351f-7ceb-46bc-b8c8-7f4a075e6f77",
 *      "log": {
 *          "id": "d2e562e9-935f-49a2-8310-eaf305d1ec4f",
 *          "created": {
 *              "val": "NOW()"
 *          },
 *          "route": "/item-volumes/25fb351f-7ceb-46bc-b8c8-7f4a075e6f77/deactivate",
 *          "body": {
 *              "id": "25fb351f-7ceb-46bc-b8c8-7f4a075e6f77",
 *              "length": 2.2,
 *              "height": 8.9,
 *              "width": 4.2,
 *              "volume": 56.2,
 *              "created": "2018-07-12T08:50:21.000Z",
 *              "updated": "2018-07-12T08:53:38.000Z",
 *              "deleted": "2018-07-12T08:55:16.000Z"
 *          },
 *          "result": "201",
 *          "actor": 1
 *      },
 *      "success": true
 *  }   
 *
 */
const deactivate = async(req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let item_volume;
    let user = req.user;
    const id = req.params.id;
    [err, item_volume] = await to(ItemVolume.update({
        'deleted' : Sequelize.fn('NOW')
    }, {
        'where' : {
            'id' : id
        }
    }));
    [err, item_volume] = await to(ItemVolume.findById(id));
    if(err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : item_volume,
        'result' : '201',
        'actor' : user.id
    }));
    return ReS(res, {'item_volume' : item_volume,
                    'message' : 'deactivated item volume: ' + id,
                    'log' : log});
};

/**
 * @api {reactivate} /item-volumes/:id/reactivate reactivateItemVolume
 * @apiGroup ItemVolume
 * @apiName reactivateItemVolume
 *
 * @apiSuccess {UUID} id ID of item volume
 * @apiSuccess {Float} length length of item volume 
 * @apiSuccess {Float} height height of item volume
 * @apiSuccess {Float} width width of item volume
 * @apiSuccess {Float} volume volume of item volume
 * @apiSuccess {Timestamp} created Date and Time the item volume is created.
 * @apiSuccess {Timestamp} updated Date and Time the item volume is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the item volume is deleted.
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *      "item_volume": {
 *          "id": "25fb351f-7ceb-46bc-b8c8-7f4a075e6f77",
 *          "length": 2.2,
 *          "height": 8.9,
 *          "width": 4.2,
 *          "volume": 56.2,
 *          "created": "2018-07-12T08:50:21.000Z",
 *          "updated": "2018-07-12T08:53:38.000Z",
 *          "deleted": null
 *      },
 *      "message": "reactivate item_volume: 25fb351f-7ceb-46bc-b8c8-7f4a075e6f77",
 *      "log": {
 *          "id": "c924fd12-c19f-4296-bfed-3e087ba7aef2",
 *          "created": {
 *              "val": "NOW()"
 *          },
 *          "route": "/item-volumes/25fb351f-7ceb-46bc-b8c8-7f4a075e6f77/reactivate",
 *          "body": {
 *              "id": "25fb351f-7ceb-46bc-b8c8-7f4a075e6f77",
 *              "length": 2.2,
 *              "height": 8.9,
 *              "width": 4.2,
 *              "volume": 56.2,
 *              "created": "2018-07-12T08:50:21.000Z",
 *              "updated": "2018-07-12T08:53:38.000Z",
 *              "deleted": null
 *          },
 *          "result": "201",
 *          "actor": 1
 *      },
 *      "success": true
 *  }  
 *
 */
const reactivate = async (req, res) => {
    ///////for auth//////////////////////////////////////////////
    const header = req.headers.authorization;
    let err,jti;
    
    [err,jti] = await to (authService.get_jti(header));
    if (err) { return ReE(res, err, 422);}


    [err, authorized] = await to(Authorized.findById(jti));
    if (err) { return ReE(res, err, 422); }
    if(!authorized) {return ReE(res,{'message': 'unauthorized'});}
    //////////////////////////////////////////////////////////////
    res.setHeader('Content-Type', 'application/json');
    let item_volume;
    let user = req.user;
    const id = req.params.id;
    [err, item_volume] = await to(ItemVolume.update({
        'deleted' : null
    }, {
        'where' : {
            'id' : id
        }
    }));
    [err, item_volume] = await to(ItemVolume.findById(id));
    if(err) {
        [log] = await to(Log.create({
            'route' : req.path,
            'body' : err,
            'result' : '422',
            'actor' : user.id
        }));
        return ReE(res, err, 422);
    }
    [err, log] = await to(Log.create({
        'route' : req.path,
        'body' : item_volume,
        'result' : '201',
        'actor' : user.id
    }));
    return ReS(res, {'item_volume' : item_volume,
                    'message' : 'reactivate item_volume: ' + id,
                    'log' : log});
};

/**
 * @api {search} /item-volumes/search searchItemVolume
 * @apiGroup ItemVolume
 * @apiName searchItemVolume
 *
 * @apiParam (Query Params) {Float} length length of item volume 
 * @apiParam (Query Params) {Float} height height of item volume
 * @apiParam (Query Params) {Float} width width of item volume
 * @apiParam (Query Params) {Float} volume volume of item volume
 *
 * @apiSuccess {UUID} id ID of item volume
 * @apiSuccess {Float} length length of item volume 
 * @apiSuccess {Float} height height of item volume
 * @apiSuccess {Float} width width of item volume
 * @apiSuccess {Float} volume volume of item volume
 * @apiSuccess {Timestamp} created Date and Time the item volume is created.
 * @apiSuccess {Timestamp} updated Date and Time the item volume is updated.
 * @apiSuccess {Timestamp} deleted Date and Time the item volume is deleted.
 * @apiSuccess {String} Message updated item_volume + id
 * @apiSuccess {Boolean} success true
 * 
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *      "item_volumes": [
 *          {
 *              "id": "25fb351f-7ceb-46bc-b8c8-7f4a075e6f77",
 *              "length": 2.2,
 *              "height": 8.9,
 *              "width": 4.2,
 *              "volume": 56.2,
 *              "created": "2018-07-12T08:50:21.000Z",
 *              "updated": "2018-07-12T08:53:38.000Z",
 *              "deleted": null
 *          },
 *          {
 *              "id": "ab1c7311-d79b-4cbe-aa91-f0c375c1aa4e",
 *              "length": 2.2,
 *              "height": 3.1,
 *              "width": 4.2,
 *              "volume": 23.3,
 *              "created": "2018-07-12T08:51:37.000Z",
 *              "updated": null,
 *              "deleted": null
 *          }
 *      ],
 *      "success": true
 *  }  
 *
 */

const search = async(req, res) => {
    res.setHeader('Content-Type', 'application/json');
    const {
        length,
        height, 
        width, 
        volume
    } = req.query;
    [err, item_volume] = await to(ItemVolume.findAll({
        'where' : {
            [Op.or]: [{'length': length},
                    {'height' : height},
                    {'width': width},
                    {'volume': volume}]
        }
    }));
    return ReS(res, {'item_volume' : item_volume});
};

module.exports = {
    'get' : get,
    'create' : create, 
    'getOne' : getOne,
    'deactivate' : deactivate,
    'reactivate' : reactivate,
    'update' : update,
    'search' : search
}