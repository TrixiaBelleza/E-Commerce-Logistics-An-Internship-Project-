const express           = require('express');
const router            = express.Router();

const custom            = require('./../middleware/custom');

const passport          = require('passport');
const path              = require('path');

const CountryController = require('./../controllers/CountryController');
const RegionController = require('./../controllers/RegionController');
const ProvinceController = require('./../controllers/ProvinceController');
const DistrictController           = require('./../controllers/DistrictController');
const SubDistrictController        = require('./../controllers/SubDistrictController');
const BarangayController           = require('./../controllers/BarangayController');
const PriceController = require('./../controllers/PriceController');
const ClientServiceScheduleController = require('./../controllers/ClientServiceScheduleController');
const ItemVolumeController = require('./../controllers/ItemVolumeController');

require('./../middleware/passport')(passport);

router.post('/districts/', passport.authenticate('jwt', {'session': false}), DistrictController.create);
router.get('/districts/', DistrictController.get);
router.get('/districts/search', DistrictController.search);
router.get('/districts/:id', DistrictController.getOne);
router.put('/districts/:id', passport.authenticate('jwt', {'session': false}), DistrictController.update);
router.post('/districts/:id/deactivate', passport.authenticate('jwt', {'session': false}), DistrictController.deactivate);
router.post('/districts/:id/reactivate', passport.authenticate('jwt', {'session': false}), DistrictController.reactivate);

router.post('/sub-districts/', passport.authenticate('jwt', {'session': false}), SubDistrictController.create);
router.get('/sub-districts/', SubDistrictController.get);
router.get('/sub-districts/search', SubDistrictController.search);
router.get('/sub-districts/:id', SubDistrictController.getOne);
router.put('/sub-districts/:id', passport.authenticate('jwt', {'session': false}), SubDistrictController.update);
router.post('/sub-districts/:id/deactivate', passport.authenticate('jwt', {'session': false}), SubDistrictController.deactivate);
router.post('/sub-districts/:id/reactivate', passport.authenticate('jwt', {'session': false}), SubDistrictController.reactivate);

router.post('/barangays/', passport.authenticate('jwt', {'session': false}), BarangayController.create);
router.get('/barangays/', BarangayController.get);
router.get('/barangays/search', BarangayController.search);
router.get('/barangays/:id', BarangayController.getOne);
router.put('/barangays/:id', passport.authenticate('jwt', {'session': false}), BarangayController.update);
router.post('/barangays/:id/deactivate', passport.authenticate('jwt', {'session': false}), BarangayController.deactivate);
router.post('/barangays/:id/reactivate', passport.authenticate('jwt', {'session': false}), BarangayController.reactivate);

router.get('/countries', CountryController.get);
router.get('/countries/search', CountryController.search);
router.get('/countries/:id', CountryController.getOne);
router.post('/countries', passport.authenticate('jwt', {'session': false}), CountryController.create);
router.put('/countries/:id', passport.authenticate('jwt', {'session': false}), CountryController.update);
router.post('/countries/:id/deactivate', passport.authenticate('jwt', {'session': false}), CountryController.deactivate);
router.post('/countries/:id/reactivate', passport.authenticate('jwt', {'session': false}), CountryController.reactivate);

router.get('/regions', RegionController.get);
router.get('/regions/search', RegionController.search);
router.get('/regions/:id', RegionController.getOne);
router.post('/regions', passport.authenticate('jwt', {'session': false}), RegionController.create);
router.put('/regions/:id', passport.authenticate('jwt', {'session': false}), RegionController.update);
router.post('/regions/:id/deactivate', passport.authenticate('jwt', {'session': false}), RegionController.deactivate);
router.post('/regions/:id/reactivate', passport.authenticate('jwt', {'session': false}), RegionController.reactivate);

router.get('/provinces', ProvinceController.get);
router.get('/provinces/search', ProvinceController.search);
router.get('/provinces/:id', ProvinceController.getOne);
router.post('/provinces', passport.authenticate('jwt', {'session': false}), ProvinceController.create);
router.put('/provinces/:id', passport.authenticate('jwt', {'session': false}), ProvinceController.update);
router.post('/provinces/:id/deactivate', passport.authenticate('jwt', {'session': false}), ProvinceController.deactivate);
router.post('/provinces/:id/reactivate', passport.authenticate('jwt', {'session': false}), ProvinceController.reactivate);

router.get('/prices', PriceController.get);
router.post('/prices', PriceController.create);
router.get('/prices/:id', PriceController.getOne);
router.put('/prices/:id', PriceController.update);
router.post('/prices/:id/deactivate', PriceController.deactivate);
router.post('/prices/:id/reactivate', PriceController.reactivate);

router.post('/clients/:id/schedules', ClientServiceScheduleController.create);
router.get('/clients/:id/schedules', ClientServiceScheduleController.get_client_schedule);
router.get('/schedules/:id', ClientServiceScheduleController.getOne);
router.put('/schedules/:id', ClientServiceScheduleController.update);
router.delete('/schedules/:id', ClientServiceScheduleController.remove);

router.post('/item-volumes/', passport.authenticate('jwt', {'session': false}), ItemVolumeController.create);
router.get('/item-volumes/', ItemVolumeController.get);
router.get('/item-volumes/search', ItemVolumeController.search);
router.get('/item-volumes/:id', ItemVolumeController.getOne);
router.put('/item-volumes/:id', passport.authenticate('jwt', {'session': false}), ItemVolumeController.update);
router.post('/item-volumes/:id/deactivate', passport.authenticate('jwt', {'session': false}), ItemVolumeController.deactivate);
router.post('/item-volumes/:id/reactivate', passport.authenticate('jwt', {'session': false}), ItemVolumeController.reactivate);

module.exports = router;