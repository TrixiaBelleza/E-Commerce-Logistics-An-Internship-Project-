const express           = require('express');
const router            = express.Router();

const custom            = require('./../middleware/custom');

const passport          = require('passport');
const path              = require('path');

const UserController            = require('./../controllers/UserController');
const HubController		=require('./../controllers/HubController');
const DistributionCenterController = require('./../controllers/DistributionCenterController');
const ZoneController = require('./../controllers/ZoneController');
const ClientController = require('./../controllers/ClientController');
const InboundOfficerController = require('./../controllers/InboundOfficerController');
const AreaManagerController = require('./../controllers/AreaManagerController');
const DispatcherController = require('./../controllers/DispatcherController');
const CustomerSupportController = require('./../controllers/CustomerSupportController');
const PasswordController            = require('./../controllers/PasswordController');
const BookingController = require('./../controllers/BookingController');
const AssignmentController = require('./../controllers/AssignmentController');
const LogController = require('./../controllers/LogController');
const ItemController = require('./../controllers/ItemController');
const ZoneBarangayController = require('./../controllers/ZoneBarangayController');
const PortController			= require('./../controllers/PortController');
const VehicleController			= require('./../controllers/VehicleController');
const CourierController         = require('./../controllers/CourierController');

require('./../middleware/passport')(passport);
router.del = router.delete;

router.post('/couriers', passport.authenticate('jwt', {'session': false}), CourierController.create);
router.get('/couriers', CourierController.get);
router.get('/couriers/:id', CourierController.getOne);
router.put('/couriers/:id', passport.authenticate('jwt', {'session': false}), CourierController.update);
router.post('/couriers/:id/deactivate', passport.authenticate('jwt', {'session': false}), CourierController.deactivate);
router.post('/couriers/:id/reactivate', passport.authenticate('jwt', {'session': false}), CourierController.reactivate);
router.get('/couriers/search', CourierController.search);

router.get('/ports', PortController.get);
router.get('/ports/:id', PortController.getOne);
router.post('/ports', passport.authenticate('jwt', {'session': false}),PortController.create);
router.put('/ports/:id',passport.authenticate('jwt', {'session': false}), PortController.update);
router.post('/ports/:id/deactivate',passport.authenticate('jwt', {'session': false}), PortController.deactivate);
router.post('/ports/:id/reactivate',passport.authenticate('jwt', {'session': false}), PortController.reactivate);

router.get('/vehicles', VehicleController.get);
router.get('/vehicles/search', VehicleController.search);
router.get('/vehicles/:id', VehicleController.getOne);
router.put('/vehicles/:id', passport.authenticate('jwt', {'session': false}),VehicleController.update);
router.post('/vehicles', passport.authenticate('jwt', {'session': false}),VehicleController.create);
router.post('/vehicles/:id/deactivate',passport.authenticate('jwt', {'session': false}), VehicleController.deactivate);
router.post('/vehicles/:id/reactivate',passport.authenticate('jwt', {'session': false}), VehicleController.reactivate);

router.post('/forgot-password', PasswordController.forgot_password);
router.del('/bookings/:id',  passport.authenticate('jwt', {'session': false}), BookingController.remove); 
router.post('/zone-barangays', passport.authenticate('jwt', {'session': false}), ZoneBarangayController.create);
router.post('/clients', passport.authenticate('jwt', {'session': false}), ClientController.create);
router.post('/hubs', passport.authenticate('jwt', {'session': false}), HubController.create);
router.post('/distribution-centers', passport.authenticate('jwt', {'session': false}), DistributionCenterController.create);
router.post('/zones', passport.authenticate('jwt', {'session': false}), ZoneController.create);
router.post('/inbound-officers', passport.authenticate('jwt', {'session': false}), InboundOfficerController.create);
router.post('/area-managers', passport.authenticate('jwt', {'session': false}), AreaManagerController.create);
router.post('/bookings', BookingController.create);
router.post('/bookings/loggedIn', passport.authenticate('jwt', {'session': false}), BookingController.create); 
router.post('/bookings/:id/assign', passport.authenticate('jwt', {'session': false}), BookingController.assign);
router.post('/bookings/:id/unassign', passport.authenticate('jwt', {'session': false}), BookingController.unassign);
router.post('/assignments/:id/assign', passport.authenticate('jwt', {'session': false}), AssignmentController.assign);
router.post('/assignments/:id/unassign', passport.authenticate('jwt', {'session': false}), AssignmentController.unassign);

router.get('/zone-barangays',ZoneBarangayController.get);
router.get('/clients',ClientController.get);
router.get('/hubs',HubController.get);
router.get('/distribution-centers',DistributionCenterController.get);
router.get('/zones',ZoneController.get);
router.get('/inbound-officers', InboundOfficerController.get);
router.get('/area-managers', AreaManagerController.get);
router.get('/bookings', BookingController.get);
router.get('/assignments', AssignmentController.get);

router.get('/zone-barangays/search', ZoneBarangayController.search);
router.get('/clients/search', ClientController.search);
router.get('/hubs/search', HubController.search);
router.get('/distribution-centers/search', DistributionCenterController.search);
router.get('/zones/search', ZoneController.search);
router.get('/inbound-officers/search', InboundOfficerController.search);
router.get('/area-managers/search', AreaManagerController.search);
router.get('/bookings/search', BookingController.search);

router.get('/zone-barangays/:id', ZoneBarangayController.getOne);
router.get('/clients/:id',ClientController.getOne);
router.get('/hubs/:id',HubController.getOne);
router.get('/distribution-centers/:id',DistributionCenterController.getOne);
router.get('/zones/:id', ZoneController.getOne);
router.get('/inbound-officers/:id', InboundOfficerController.getOne);
router.get('/area-managers/:id', AreaManagerController.getOne);
router.get('/bookings/:id', BookingController.getOne);
router.get('/assignments/:id', AssignmentController.getOne);

router.put('/zone-barangays/:id', passport.authenticate('jwt', {'session': false}), ZoneBarangayController.update);
router.put('/clients/:id', passport.authenticate('jwt', {'session': false}), ClientController.update);
router.put('/hubs/:id', passport.authenticate('jwt', {'session': false}), HubController.update);
router.put('/distribution-centers/:id', passport.authenticate('jwt', {'session': false}), DistributionCenterController.update);
router.put('/zones/:id', passport.authenticate('jwt', {'session': false}), ZoneController.update);
router.put('/inbound-officers/:id', passport.authenticate('jwt', {'session': false}), InboundOfficerController.update);
router.put('/area-managers/:id', passport.authenticate('jwt', {'session': false}), AreaManagerController.update);
router.put('/bookings/:id', passport.authenticate('jwt', {'session': false}), BookingController.update); 
router.put('/assignments/:id', passport.authenticate('jwt', {'session': false}), AssignmentController.update);

router.post('/zone-barangays/:id/deactivate', passport.authenticate('jwt', {'session': false}), ZoneBarangayController.deactivate);
router.post('/clients/:id/deactivate', passport.authenticate('jwt', {'session': false}), ClientController.deactivate);
router.post('/hubs/:id/deactivate', passport.authenticate('jwt', {'session': false}), HubController.deactivate);
router.post('/distribution-centers/:id/deactivate', passport.authenticate('jwt', {'session': false}), DistributionCenterController.deactivate);
router.post('/zones/:id/deactivate', passport.authenticate('jwt', {'session': false}), ZoneController.deactivate);
router.post('/inbound-officers/:id/deactivate', passport.authenticate('jwt', {'session': false}), InboundOfficerController.deactivate);
router.post('/area-managers/:id/deactivate', passport.authenticate('jwt', {'session': false}), AreaManagerController.deactivate);

router.post('/zone-barangays/:id/reactivate', passport.authenticate('jwt', {'session': false}), ZoneBarangayController.reactivate);
router.post('/clients/:id/reactivate', passport.authenticate('jwt', {'session': false}), ClientController.reactivate);
router.post('/hubs/:id/reactivate', passport.authenticate('jwt', {'session': false}), HubController.reactivate);
router.post('/distribution-centers/:id/reactivate', passport.authenticate('jwt', {'session': false}),  DistributionCenterController.reactivate);
router.post('/zones/:id/reactivate', passport.authenticate('jwt', {'session': false}), ZoneController.reactivate);
router.post('/inbound-officers/:id/reactivate', passport.authenticate('jwt', {'session': false}), InboundOfficerController.reactivate);
router.post('/area-managers/:id/reactivate', passport.authenticate('jwt', {'session': false}), AreaManagerController.reactivate);

router.post('/users', UserController.create);
router.get ('/users', passport.authenticate('jwt', {'session': false}), UserController.get);
router.put ('/users/:id', passport.authenticate('jwt', {'session': false}), UserController.update);
router.del ('/users', passport.authenticate('jwt', {'session': false}), UserController.remove);
router.post('/users/login', UserController.login);

router.get('/dispatchers', DispatcherController.get);
router.get('/dispatchers/search', DispatcherController.search);
router.post('/dispatchers', passport.authenticate('jwt', {'session': false}), DispatcherController.create);
router.get('/dispatchers/:id', DispatcherController.getOne);
router.post('/dispatchers/:id/deactivate', passport.authenticate('jwt', {'session': false}), DispatcherController.deactivate);
router.post('/dispatchers/:id/reactivate', passport.authenticate('jwt', {'session': false}), DispatcherController.reactivate);
router.put('/dispatchers/:id', passport.authenticate('jwt', {'session': false}), DispatcherController.update);

router.get('/customer-supports', CustomerSupportController.get);
router.post('/customer-supports', passport.authenticate('jwt', {'session': false}), CustomerSupportController.create);
router.get('/customer-supports/search', CustomerSupportController.search);
router.get('/customer-supports/:id', CustomerSupportController.getOne);
router.post('/customer-supports/:id/deactivate', passport.authenticate('jwt', {'session': false}), CustomerSupportController.deactivate);
router.post('/customer-supports/:id/reactivate', passport.authenticate('jwt', {'session': false}), CustomerSupportController.reactivate);
router.put('/customer-supports/:id', passport.authenticate('jwt', {'session': false}), CustomerSupportController.update);

router.get('/logs', LogController.get);
router.get('/logs/:id', LogController.getOne);

router.get('/items', ItemController.get);
router.get('/items/search', ItemController.search);
router.get('/items/:id', ItemController.getOne);
router.post('/items',  passport.authenticate('jwt', {'session': false}), ItemController.create);
router.put('/items/:id',  passport.authenticate('jwt', {'session': false}), ItemController.update);
router.delete('/items/:id',  passport.authenticate('jwt', {'session': false}), ItemController.remove);

module.exports = router;