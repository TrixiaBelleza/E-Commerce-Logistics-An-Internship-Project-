const express           = require('express');
const router            = express.Router();

const custom            = require('./../middleware/custom');

const passport          = require('passport');
const path              = require('path');

const AuthController            = require('./../controllers/AuthController');

require('./../middleware/passport')(passport);
router.del = router.delete;

router.post('/sign-in', AuthController.sign_in);
router.post('/reset-password',passport.authenticate('jwt',{'session':false}), AuthController.reset_password);
router.post('/sign-out',passport.authenticate('jwt',{'session':false}),AuthController.sign_out);


module.exports = router;