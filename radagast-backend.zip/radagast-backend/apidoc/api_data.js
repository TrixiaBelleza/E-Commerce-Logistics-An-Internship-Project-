define({ "api": [
  {
    "type": "post",
    "url": "/area-managers",
    "title": "addAreaManager",
    "group": "AreaManager",
    "name": "addAreaManager",
    "parameter": {
      "fields": {
        "System Generated": [
          {
            "group": "System Generated",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of area manager</p>"
          }
        ],
        "Body Params": [
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "hub_id",
            "description": "<p>hub_id of area manager referenced from hub</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>distribution_center_id of area manager referenced from distribution_center</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the area manager</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hub_id",
            "description": "<p>hub_id of area manager referenced from hub</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>distribution_center_id of area manager referenced from hub</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Area Manager is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Area Manager is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Area Manager is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Message",
            "description": "<p>Successfully created new area manager</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n{\n    \"message\": \"Successfully created new area manager\",\n    \"area_manager\": {\n        \"id\": \"d465a5b9-c900-4e9e-a818-714576a54c89\",\n        \"created\": {\n            \"val\": \"NOW()\"\n        },\n        \"user_id\": \"1\",\n        \"hub_id\": \"12b356bd-0877-4b82-9c2a-fc5d26489bd4\",\n        \"distribution_center_id\": \"da6d1764-a3c7-4e58-946a-7ab0fb4bf75c\"\n    },\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/AreaManagerController.js",
    "groupTitle": "AreaManager"
  },
  {
    "type": "deactivate",
    "url": "/area-managers/:id/deactivate",
    "title": "deactivateAreaManager",
    "group": "AreaManager",
    "name": "deactivateAreaManager",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the area manager.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hub_id",
            "description": "<p>hub_id of area manager referenced from hub</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>distribution_center_id of area manager referenced from distribution_center</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Area Manager is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Area Manager is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Area Manager is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Message",
            "description": "<p>Deactivated Area Manager</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n   \"area manager\": {\n       \"id\": \"4a03aaf7-b84b-4a32-9c93-b9e6c57f4803\",\n       \"hub_id\": \"12b356bd-0877-4b82-9c2a-fc5d26489bd4\",\n       \"distribution_center_id\": \"da6d1764-a3c7-4e58-946a-7ab0fb4bf75c\",\n       \"created\": \"2018-07-06T01:49:16.000Z\",\n       \"updated\": \"2018-07-10T07:28:40.000Z\",\n       \"deleted\": \"2018-07-10T07:32:23.000Z\",\n       \"user_id\": 2\n   },\n   \"message\": \"deactivated area manager\",\n   \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/AreaManagerController.js",
    "groupTitle": "AreaManager"
  },
  {
    "type": "getOne",
    "url": "/area-managers/:id",
    "title": "getOneAreaManager",
    "group": "AreaManager",
    "name": "getAreaManager",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the area manager.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hub_id",
            "description": "<p>hub_id of area manager referenced from hub</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>distribution_center_id of area manager referenced from distribution_center</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Area Manager is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Area Manager is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Area Manager is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "email",
            "description": "<p>Email of area manager.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "first_name",
            "description": "<p>First Name of area manager.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "last_name",
            "description": "<p>Last Name of area manager.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "middle_name",
            "description": "<p>Middle Name of area manager.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "contact_number",
            "description": "<p>Contact Number of area manager.</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n   {\n      \"area_manager\": {\n          \"id\": \"4dc6abda-b9af-44eb-8805-39aa5ce6b283\",\n          \"hub_id\": \"797439a8-d074-46a3-bfb8-50e6af677857\",\n          \"distribution_center_id\": null,\n          \"created\": \"2018-07-12T00:48:36.000Z\",\n          \"updated\": null,\n          \"deleted\": null,\n          \"user_id\": 1,\n          \"User\": {\n              \"id\": 1,\n              \"email\": \"kzarzoso@gmail.com\",\n              \"first_name\": \"Kiara\",\n              \"last_name\": \"Zarzoso\",\n              \"middle_name\": \"Calbera\",\n              \"contact_number\": \"09168650222\"\n          }\n      },\n      \"success\": true\n   }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/AreaManagerController.js",
    "groupTitle": "AreaManager"
  },
  {
    "type": "get",
    "url": "/area-managers",
    "title": "getAreaManagers",
    "group": "AreaManager",
    "name": "getAreaManagers",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the area manager.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hub_id",
            "description": "<p>hub_id of area manager referenced from hub</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>distribution_center_id of area manager referenced from distribution_center</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Area Manager is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Area Manager is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Area Manager is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "email",
            "description": "<p>Email of area manager.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "first_name",
            "description": "<p>First Name of area manager.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "last_name",
            "description": "<p>Last Name of area manager.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "middle_name",
            "description": "<p>Middle Name of area manager.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "contact_number",
            "description": "<p>Contact Number of area manager.</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n   {\n      \"area_managers\": [\n          {\n              \"id\": \"4dc6abda-b9af-44eb-8805-39aa5ce6b283\",\n              \"hub_id\": \"797439a8-d074-46a3-bfb8-50e6af677857\",\n              \"distribution_center_id\": null,\n              \"created\": \"2018-07-12T00:48:36.000Z\",\n              \"updated\": null,\n              \"deleted\": null,\n              \"user_id\": 1,\n              \"User\": {\n                  \"id\": 1,\n                  \"email\": \"kzarzoso@gmail.com\",\n                  \"first_name\": \"Kiara\",\n                  \"last_name\": \"Zarzoso\",\n                  \"middle_name\": \"Calbera\",\n                  \"contact_number\": \"09168650222\"\n              }\n          },\n          {\n              \"id\": \"5f7a8260-529a-41c3-8e7e-30a998d29b9b\",\n              \"hub_id\": \"797439a8-d074-46a3-bfb8-50e6af677857\",\n              \"distribution_center_id\": \"e6cb457e-653a-44e6-87d9-7eeab7c8448c\",\n              \"created\": \"2018-07-12T01:10:16.000Z\",\n              \"updated\": null,\n              \"deleted\": null,\n              \"user_id\": 2,\n              \"User\": {\n                  \"id\": 2,\n                  \"email\": \"ahabulan@gmail.com\",\n                  \"first_name\": \"Aljay\",\n                  \"last_name\": \"Habulan\",\n                  \"middle_name\": \"Ranchez\",\n                  \"contact_number\": \"09271238752\"\n              }\n          }\n      ],\n      \"success\": true\n   }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/AreaManagerController.js",
    "groupTitle": "AreaManager"
  },
  {
    "type": "reactivate",
    "url": "/area-managers/:id/reactivate",
    "title": "reactivateAreaManager",
    "group": "AreaManager",
    "name": "reactivateAreaManager",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the area manager.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hub_id",
            "description": "<p>hub_id of area manager referenced from hub</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>distribution_center_id of area manager referenced from distribution_center</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Area Manager is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Area Manager is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Area Manager is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Message",
            "description": "<p>Reactivated Area Manager</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n   \"area manager\": {\n       \"id\": \"4a03aaf7-b84b-4a32-9c93-b9e6c57f4803\",\n       \"hub_id\": \"12b356bd-0877-4b82-9c2a-fc5d26489bd4\",\n       \"distribution_center_id\": \"da6d1764-a3c7-4e58-946a-7ab0fb4bf75c\",\n       \"created\": \"2018-07-06T01:49:16.000Z\",\n       \"updated\": \"2018-07-10T07:28:40.000Z\",\n       \"deleted\": null,\n       \"user_id\": 2\n   },\n   \"message\": \"reactivated area manager\",\n   \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/AreaManagerController.js",
    "groupTitle": "AreaManager"
  },
  {
    "type": "search",
    "url": "/area-managers/search",
    "title": "searchAreaManager",
    "group": "AreaManager",
    "name": "searchAreaManager",
    "parameter": {
      "fields": {
        "Query Params": [
          {
            "group": "Query Params",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of area manager</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "hub_id",
            "description": "<p>hub_id of area manager referenced from hub</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>distribution_center_id of area manager referenced from distribution_center</p>"
          },
          {
            "group": "Query Params",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Area Manager is created</p>"
          },
          {
            "group": "Query Params",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Area Manager is updated</p>"
          },
          {
            "group": "Query Params",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Area Manager is deleted</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the area manager</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hub_id",
            "description": "<p>hub_id of area manager referenced from hub</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>distribution_center_id of area manager referenced from hub</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Area Manager is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Area Manager is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Area Manager is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n{\n    \"area_manager\": [\n        {\n            \"id\": \"4a03aaf7-b84b-4a32-9c93-b9e6c57f4803\",\n            \"hub_id\": \"12b356bd-0877-4b82-9c2a-fc5d26489bd4\",\n            \"distribution_center_id\": \"da6d1764-a3c7-4e58-946a-7ab0fb4bf75c\",\n            \"created\": \"2018-07-06T01:49:16.000Z\",\n            \"updated\": \"2018-07-06T01:52:11.000Z\",\n            \"deleted\": null,\n            \"user_id\": 2\n        }\n    ],\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/AreaManagerController.js",
    "groupTitle": "AreaManager"
  },
  {
    "type": "put",
    "url": "/area-managers/:id",
    "title": "updateAreaManager",
    "group": "AreaManager",
    "name": "updateAreaManager",
    "parameter": {
      "fields": {
        "Body Params": [
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "hub_id",
            "description": "<p>hub_id of area manager referenced from hub</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>distribution_center_id of area manager referenced from distribution_center</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the area manager.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hub_id",
            "description": "<p>hub_id of area manager referenced from hub</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>distribution_center_id of area manager referenced from distribution_center</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Area Manager is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Area Manager is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Area Manager is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Message",
            "description": "<p>Update area manager + id</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n{\n    \"message\": \"Successfully updated area manager\",\n    \"area_manager\": {\n        \"id\": \"d465a5b9-c900-4e9e-a818-714576a54c89\",\n        \"created\": {\n            \"val\": \"NOW()\"\n        },\n        \"user_id\": \"1\",\n        \"hub_id\": \"12b356bd-0877-4b82-9c2a-fc5d26489bd4\",\n        \"distribution_center_id\": \"da6d1764-a3c7-4e58-946a-7ab0fb4bf75c\"\n    },\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/AreaManagerController.js",
    "groupTitle": "AreaManager"
  },
  {
    "type": "assign",
    "url": "/assignments/:id/assign",
    "title": "assignAssignment",
    "group": "Assignment",
    "name": "assignAssignment",
    "parameter": {
      "fields": {
        "Body Params": [
          {
            "group": "Body Params",
            "type": "UUID",
            "optional": false,
            "field": "courier_id",
            "description": "<p>id of courier</p>"
          },
          {
            "group": "Body Params",
            "type": "UUID",
            "optional": false,
            "field": "dispatcher_id",
            "description": "<p>id of dispatcher</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the assignment</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "status",
            "description": "<p>status of assignment</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "remarks",
            "description": "<p>remarks when failed assignment</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name_of_receiver",
            "description": "<p>name of receiver of assignment</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "relationship_to_shipper",
            "description": "<p>relationship to shipper (for receiver details)</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "check_in_time",
            "description": "<p>check in time of assignment</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "check_out_time",
            "description": "<p>check out time of assignment</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "timestamp_of_unassignment_from_booking",
            "description": "<p>Timestamp of unassignment from booking</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "timestamp_of_completion",
            "description": "<p>Timestamp of completion</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the barangay is created</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "booking_id",
            "description": "<p>id of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "courier_id",
            "description": "<p>id of courier</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "dispatcher_id",
            "description": "<p>id of dispatcher</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Message",
            "description": "<p>assigned booking + id</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n    \"assignment\": {\n        \"id\": \"309c888d-67eb-40ff-9828-aff5de15e47b\",\n        \"created\": \"2018-07-12T05:52:20.000Z\",\n        \"timestamp_of_completion\": null,\n        \"status\": \"Served\",\n        \"check_in_time\": null,\n        \"check_out_time\": null,\n        \"remarks\": null,\n        \"name_of_receiver\": null,\n        \"relationship_to_shipper\": null,\n        \"timestamp_of_unassignment_from_booking\": null,\n        \"booking_id\": \"490e0c2b-138b-4770-b18f-235b0dc8f4b1\",\n        \"courier_id\": \"9frb12fge-653a-44e6-87d9-7eeab7c818c\",\n        \"dispatcher_id\": \"13e7c5a8-6b49-49f5-9bb0-7ed0b25c1164\"\n    },\n    \"message\": \"assigned booking: 309c888d-67eb-40ff-9828-aff5de15e47b\",\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/AssignmentController.js",
    "groupTitle": "Assignment"
  },
  {
    "type": "get",
    "url": "/assignments",
    "title": "getAssignments",
    "group": "Assignment",
    "name": "getAssignments",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the assignment</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "status",
            "description": "<p>status of assignment</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "remarks",
            "description": "<p>remarks when failed assignment</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name_of_receiver",
            "description": "<p>name of receiver of assignment</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "relationship_to_shipper",
            "description": "<p>relationship to shipper (for receiver details)</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "check_in_time",
            "description": "<p>check in time of assignment</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "check_out_time",
            "description": "<p>check out time of assignment</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "timestamp_of_unassignment_from_booking",
            "description": "<p>Timestamp of unassignment from booking</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "timestamp_of_completion",
            "description": "<p>Timestamp of completion</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the barangay is created</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "booking_id",
            "description": "<p>id of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "courier_id",
            "description": "<p>id of courier</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "dispatcher_id",
            "description": "<p>id of dispatcher</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "shipper_name",
            "description": "<p>shipper_name of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "pick_up_address",
            "description": "<p>pick_up_address of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "contact_number",
            "description": "<p>contact_number of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "email",
            "description": "<p>email of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "product_type",
            "description": "<p>product_type of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "cargo_type",
            "description": "<p>cargo_type of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "mode_of_payment",
            "description": "<p>mode_of_payment of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "client_account_number",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n {\n    \"assignments\": [\n        {\n            \"id\": \"309c888d-67eb-40ff-9828-aff5de15e47b\",\n            \"created\": \"2018-07-12T05:52:20.000Z\",\n            \"timestamp_of_completion\": null,\n            \"status\": \"Pending\",\n            \"check_in_time\": null,\n            \"check_out_time\": null,\n            \"remarks\": null,\n            \"name_of_receiver\": null,\n            \"relationship_to_shipper\": null,\n            \"timestamp_of_unassignment_from_booking\": \"2018-07-12T05:58:23.000Z\",\n            \"booking_id\": \"490e0c2b-138b-4770-b18f-235b0dc8f4b1\",\n            \"courier_id\": null,\n            \"dispatcher_id\": null,\n            \"booking\": {\n                \"shipper_name\": \"Lazada\",\n                \"pick_up_address\": \"Ilag's Compound, \",\n                \"contact_number\": \"09168679865\",\n                \"email\": \"ahabulan@gmail.com\",\n                \"product_type\": \"Apparel\",\n                \"cargo_type\": \"Dry bulk\",\n                \"mode_of_payment\": \"visa\"\n                \"client_account_number\" : null\n            }\n        },\n        {\n            \"id\": \"44097751-364e-422a-91de-0b4ce99c59be\",\n            \"created\": \"2018-07-12T03:53:26.000Z\",\n            \"timestamp_of_completion\": null,\n            \"status\": \"Pending\",\n            \"check_in_time\": null,\n            \"check_out_time\": null,\n            \"remarks\": null,\n            \"name_of_receiver\": null,\n            \"relationship_to_shipper\": null,\n            \"timestamp_of_unassignment_from_booking\": \"2018-07-12T05:50:36.000Z\",\n            \"booking_id\": \"c5318d95-964a-4973-856f-a81da63c6320\",\n            \"courier_id\": null,\n            \"dispatcher_id\": null,\n            \"booking\": {\n                \"shipper_name\": \"Lazada\",\n                \"pick_up_address\": \"Ilag's Compound, \",\n                \"contact_number\": \"09168679812\",\n                \"email\": \"ahabulan@gmail.com\",\n                \"product_type\": \"Apparel\",\n                \"cargo_type\": \"Dry bulk\",\n                \"mode_of_payment\": \"visa\",,\n                \"client_account_number\" : null\n            }\n        }\n    ],\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/AssignmentController.js",
    "groupTitle": "Assignment"
  },
  {
    "type": "getOne",
    "url": "/assignments/:id",
    "title": "getOneAssignment",
    "group": "Assignment",
    "name": "getOneAssignment",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the assignment</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "status",
            "description": "<p>status of assignment</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "remarks",
            "description": "<p>remarks when failed assignment</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name_of_receiver",
            "description": "<p>name of receiver of assignment</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "relationship_to_shipper",
            "description": "<p>relationship to shipper (for receiver details)</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "check_in_time",
            "description": "<p>check in time of assignment</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "check_out_time",
            "description": "<p>check out time of assignment</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "timestamp_of_unassignment_from_booking",
            "description": "<p>Timestamp of unassignment from booking</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "timestamp_of_completion",
            "description": "<p>Timestamp of completion</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the barangay is created</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "booking_id",
            "description": "<p>id of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "courier_id",
            "description": "<p>id of courier</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "dispatcher_id",
            "description": "<p>id of dispatcher</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "shipper_name",
            "description": "<p>shipper_name of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "pick_up_address",
            "description": "<p>pick_up_address of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "contact_number",
            "description": "<p>contact_number of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "email",
            "description": "<p>email of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "product_type",
            "description": "<p>product_type of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "cargo_type",
            "description": "<p>cargo_type of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "mode_of_payment",
            "description": "<p>mode_of_payment of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "client_account_number",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n {\n    \"assignments\": [\n        {\n            \"id\": \"309c888d-67eb-40ff-9828-aff5de15e47b\",\n            \"created\": \"2018-07-12T05:52:20.000Z\",\n            \"timestamp_of_completion\": null,\n            \"status\": \"Pending\",\n            \"check_in_time\": null,\n            \"check_out_time\": null,\n            \"remarks\": null,\n            \"name_of_receiver\": null,\n            \"relationship_to_shipper\": null,\n            \"timestamp_of_unassignment_from_booking\": \"2018-07-12T05:58:23.000Z\",\n            \"booking_id\": \"490e0c2b-138b-4770-b18f-235b0dc8f4b1\",\n            \"courier_id\": null,\n            \"dispatcher_id\": null,\n            \"booking\": {\n                \"shipper_name\": \"Lazada\",\n                \"pick_up_address\": \"Ilag's Compound, \",\n                \"contact_number\": \"09168679865\",\n                \"email\": \"ahabulan@gmail.com\",\n                \"product_type\": \"Apparel\",\n                \"cargo_type\": \"Dry bulk\",\n                \"mode_of_payment\": \"visa\",\n                \"client_account_number\" : null\n            }\n        }\n    ],\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/AssignmentController.js",
    "groupTitle": "Assignment"
  },
  {
    "type": "unassign",
    "url": "/assignments/:id/unassign",
    "title": "unassignAssignment",
    "group": "Assignment",
    "name": "unassignAssignment",
    "parameter": {
      "fields": {
        "Body Params": [
          {
            "group": "Body Params",
            "type": "UUID",
            "optional": false,
            "field": "dispatcher_id",
            "description": "<p>id of dispatcher</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the assignment</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "status",
            "description": "<p>status of assignment</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "remarks",
            "description": "<p>remarks when failed assignment</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name_of_receiver",
            "description": "<p>name of receiver of assignment</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "relationship_to_shipper",
            "description": "<p>relationship to shipper (for receiver details)</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "check_in_time",
            "description": "<p>check in time of assignment</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "check_out_time",
            "description": "<p>check out time of assignment</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "timestamp_of_unassignment_from_booking",
            "description": "<p>Timestamp of unassignment from booking</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "timestamp_of_completion",
            "description": "<p>Timestamp of completion</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the barangay is created</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "booking_id",
            "description": "<p>id of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "courier_id",
            "description": "<p>id of courier</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "dispatcher_id",
            "description": "<p>id of dispatcher</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Message",
            "description": "<p>assigned booking + id</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n    \"assignment\": {\n        \"id\": \"309c888d-67eb-40ff-9828-aff5de15e47b\",\n        \"created\": \"2018-07-12T05:52:20.000Z\",\n        \"timestamp_of_completion\": null,\n        \"status\": \"Served\",\n        \"check_in_time\": null,\n        \"check_out_time\": null,\n        \"remarks\": null,\n        \"name_of_receiver\": null,\n        \"relationship_to_shipper\": null,\n        \"timestamp_of_unassignment_from_booking\": \"2018-07-12T05:58:23.000Z\",\n        \"booking_id\": \"490e0c2b-138b-4770-b18f-235b0dc8f4b1\",\n        \"courier_id\": null\n        \"dispatcher_id\": \"13e7c5a8-6b49-49f5-9bb0-7ed0b25c1164\"\n    },\n    \"message\": \"assigned booking: 309c888d-67eb-40ff-9828-aff5de15e47b\",\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/AssignmentController.js",
    "groupTitle": "Assignment"
  },
  {
    "type": "put",
    "url": "/assignments/:id",
    "title": "updateAssignment",
    "group": "Assignment",
    "name": "updateAssignment",
    "parameter": {
      "fields": {
        "Body Params": [
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "status",
            "description": "<p>status of assignment</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "remarks",
            "description": "<p>remarks when failed assignment</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "name_of_receiver",
            "description": "<p>name of receiver of assignment</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "relationship_to_shipper",
            "description": "<p>relationship to shipper (for receiver details)</p>"
          },
          {
            "group": "Body Params",
            "type": "Timestamp",
            "optional": false,
            "field": "check_in_time",
            "description": "<p>check in time of assignment</p>"
          },
          {
            "group": "Body Params",
            "type": "Timestamp",
            "optional": false,
            "field": "check_out_time",
            "description": "<p>check out time of assignment</p>"
          },
          {
            "group": "Body Params",
            "type": "Timestamp",
            "optional": false,
            "field": "timestamp_of_unassignment_from_booking",
            "description": "<p>Timestamp of unassignment from booking</p>"
          },
          {
            "group": "Body Params",
            "type": "Timestamp",
            "optional": false,
            "field": "timestamp_of_completion",
            "description": "<p>Timestamp of completion</p>"
          },
          {
            "group": "Body Params",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the barangay is created</p>"
          },
          {
            "group": "Body Params",
            "type": "UUID",
            "optional": false,
            "field": "booking_id",
            "description": "<p>id of booking</p>"
          },
          {
            "group": "Body Params",
            "type": "UUID",
            "optional": false,
            "field": "courier_id",
            "description": "<p>id of courier</p>"
          },
          {
            "group": "Body Params",
            "type": "UUID",
            "optional": false,
            "field": "dispatcher_id",
            "description": "<p>id of dispatcher</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the assignment</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "status",
            "description": "<p>status of assignment</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "remarks",
            "description": "<p>remarks when failed assignment</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name_of_receiver",
            "description": "<p>name of receiver of assignment</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "relationship_to_shipper",
            "description": "<p>relationship to shipper (for receiver details)</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "check_in_time",
            "description": "<p>check in time of assignment</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "check_out_time",
            "description": "<p>check out time of assignment</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "timestamp_of_unassignment_from_booking",
            "description": "<p>Timestamp of unassignment from booking</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "timestamp_of_completion",
            "description": "<p>Timestamp of completion</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the barangay is created</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "booking_id",
            "description": "<p>id of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "courier_id",
            "description": "<p>id of courier</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "dispatcher_id",
            "description": "<p>id of dispatcher</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Message",
            "description": "<p>update assignment + id</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n {\n    \"assignment\": {\n        \"id\": \"309c888d-67eb-40ff-9828-aff5de15e47b\",\n        \"created\": \"2018-07-12T05:52:20.000Z\",\n        \"timestamp_of_completion\": null,\n        \"status\": \"Served\",\n        \"check_in_time\": null,\n        \"check_out_time\": null,\n        \"remarks\": null,\n        \"name_of_receiver\": null,\n        \"relationship_to_shipper\": null,\n        \"timestamp_of_unassignment_from_booking\": \"2018-07-12T05:58:23.000Z\",\n        \"booking_id\": \"490e0c2b-138b-4770-b18f-235b0dc8f4b1\",\n        \"courier_id\": null,\n        \"dispatcher_id\": null\n    },\n    \"message\": \"update assignment: 309c888d-67eb-40ff-9828-aff5de15e47b\",\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/AssignmentController.js",
    "groupTitle": "Assignment"
  },
  {
    "type": "post",
    "url": "/auth/reset-password",
    "title": "Reset password",
    "group": "Auth",
    "name": "Reset_password",
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "authorization",
            "description": "<p>jwt token ex: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoxLCJpYXQiOjE1MzEyODk2MDQsImV4cCI6MTUzMTI5OTYwNCwianRpIjoiMGU0Y2JiNDctYjk4Yy00MTMxLWFhMDAtNGIwNmZjYWZmMGQ0In0.6TgWivCAefsoMnmJ0uaeth8-1mW-Z8CLPc_V_rX37I0</p>"
          }
        ]
      }
    },
    "parameter": {
      "fields": {
        "Body Params": [
          {
            "group": "Body Params",
            "type": "string",
            "optional": false,
            "field": "email",
            "description": "<p>email</p>"
          },
          {
            "group": "Body Params",
            "type": "string",
            "optional": false,
            "field": "password",
            "description": "<p>current password</p>"
          },
          {
            "group": "Body Params",
            "type": "string",
            "optional": false,
            "field": "new_password",
            "description": "<p>new password</p>"
          },
          {
            "group": "Body Params",
            "type": "string",
            "optional": false,
            "field": "confirm_password",
            "description": "<p>verify password</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "user",
            "description": "<p>new user</p>"
          },
          {
            "group": "Success 200",
            "type": "Integer",
            "optional": false,
            "field": "user.id",
            "description": "<p>ID of user</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user.email",
            "description": "<p>email of user</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user.password",
            "description": "<p>encrypted password of user</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user.first_name",
            "description": "<p>first name of user</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user.middle_name",
            "description": "<p>middle name of user</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user.last_name",
            "description": "<p>last name of user</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user.contact_number",
            "description": "<p>contact_number of user</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "user.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "user.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "user.deleted",
            "description": "<p>timestamp of deletion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n    \"user\": {\n        \"id\": 3,\n        \"email\": \"jdelacruz@gmail.com\",\n        \"password\": \"$2b$10$/1JsJ2x9xaSeYtsgd3TE.OXkfz1z4apVvLWhJQwVKXlI0nUY4J1j2\",\n        \"first_name\": \"juan\",\n        \"last_name\": \"delacruz\",\n        \"middle_name\": \"reyes\",\n        \"contact_number\": null,\n        \"created\": \"2018-07-12T01:36:45.000Z\",\n        \"updated\": {\n            \"fn\": \"NOW\",\n            \"args\": []\n        },\n        \"deleted\": null,\n        \"createdAt\": \"2018-07-12T01:36:45.000Z\",\n        \"updatedAt\": \"2018-07-12T01:53:58.690Z\"\n    },\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/AuthController.js",
    "groupTitle": "Auth"
  },
  {
    "type": "post",
    "url": "/auth/sign-in",
    "title": "Sign in",
    "group": "Auth",
    "name": "Sign_in",
    "parameter": {
      "fields": {
        "Body Params": [
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "email",
            "description": "<p>email</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "password",
            "description": "<p>password</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "token",
            "description": "<p>valid token</p>"
          },
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "user",
            "description": "<p>new user</p>"
          },
          {
            "group": "Success 200",
            "type": "Integer",
            "optional": false,
            "field": "user.id",
            "description": "<p>ID of user</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user.email",
            "description": "<p>email of user</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user.password",
            "description": "<p>encrypted password of user</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user.first_name",
            "description": "<p>first name of user</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user.middle_name",
            "description": "<p>middle name of user</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user.last_name",
            "description": "<p>last name of user</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user.contact_number",
            "description": "<p>contact_number of user</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "user.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "user.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "user.deleted",
            "description": "<p>timestamp of deletion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n    \"token\": \"Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjozLCJpYXQiOjE1MzEzNTk0NjYsImV4cCI6MTUzMTM2OTQ2NiwianRpIjoiNzM1OTU4NjEtNjExMS00ZGZkLWEzODEtNWY2MTA1MzhmYjYxIn0.3b7P3MzHrr9LICXvfyKGdcPicZZAcm_-yVc2u5bEQeI\",\n    \"user\": {\n        \"id\": 3,\n        \"email\": \"jdelacruz@gmail.com\",\n        \"password\": \"$2b$10$e9wuucvYYcyxH0M5cYnOH.RDo7vL6ZZ3pVNBlxRJYCQ1lWtikZ8VW\",\n        \"first_name\": \"juan\",\n        \"last_name\": \"delacruz\",\n        \"middle_name\": \"reyes\",\n        \"contact_number\": null,\n        \"created\": \"2018-07-12T01:36:45.000Z\",\n        \"updated\": null,\n        \"deleted\": null,\n        \"createdAt\": \"2018-07-12T01:36:45.000Z\",\n        \"updatedAt\": \"2018-07-12T01:36:45.000Z\"\n    },\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/AuthController.js",
    "groupTitle": "Auth"
  },
  {
    "type": "post",
    "url": "/auth/sign-out",
    "title": "Sign out",
    "group": "Auth",
    "name": "Sign_out",
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "authorization",
            "description": "<p>jwt token ex: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoxLCJpYXQiOjE1MzEyODk2MDQsImV4cCI6MTUzMTI5OTYwNCwianRpIjoiMGU0Y2JiNDctYjk4Yy00MTMxLWFhMDAtNGIwNmZjYWZmMGQ0In0.6TgWivCAefsoMnmJ0uaeth8-1mW-Z8CLPc_V_rX37I0</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n    \"message\": \"logged out\",\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/AuthController.js",
    "groupTitle": "Auth"
  },
  {
    "type": "post",
    "url": "/barangays",
    "title": "addBarangay",
    "group": "Barangay",
    "name": "addBarangay",
    "parameter": {
      "fields": {
        "System Generated": [
          {
            "group": "System Generated",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of barangay</p>"
          }
        ],
        "Body Params": [
          {
            "group": "Body Params",
            "type": "Character",
            "optional": false,
            "field": "code",
            "description": "<p>code of barangay</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of barangay</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "district_id",
            "description": "<p>district_id of barangay referenced from district</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "sub_district_id",
            "description": "<p>sub_district_id of barangay referenced from sub_district</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "Character",
            "optional": false,
            "field": "code",
            "description": "<p>code of barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "district_id",
            "description": "<p>district_id of barangay referenced from district</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the barangay is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the barangay is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the barangay is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Message",
            "description": "<p>Successfully created new barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n   {\n       \"message\": \"Successfully created new barangay\",\n       \"barangay\": {\n           \"id\": \"89fc14b8-d853-4cb2-9f66-4cc8c08fc767\",\n           \"created\": {\n               \"val\": \"NOW()\"\n           },\n           \"district_id\": \"bf6e171c-c292-4626-95dc-b5698c7e281a\",\n           \"sub_district_id\": \"f72dfca7-8258-4ec5-b0f3-d46ceec478a8\",\n           \"code\": \"AN\",\n           \"name\": \"ANOS\"\n       },\n       \"success\": true\n   }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/BarangayController.js",
    "groupTitle": "Barangay"
  },
  {
    "type": "post",
    "url": "/zone-barangays",
    "title": "addZoneBarangay",
    "group": "Barangay",
    "name": "addZoneBarangay",
    "parameter": {
      "fields": {
        "System Generated": [
          {
            "group": "System Generated",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of zone barangay</p>"
          }
        ],
        "Body Params": [
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "zone_id",
            "description": "<p>zone_id of zone barangay referenced from zone</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "barangay_id",
            "description": "<p>barangay_id of zone barangay referenced from barangay</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of zone barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "zone_id",
            "description": "<p>zone_id of zone barangay referenced from zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "barangay_id",
            "description": "<p>barangay_id of zone barangay referenced from barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the zone barangay is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the zone barangay is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the zone barangay is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Message",
            "description": "<p>Successfully created new zone barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n   \"message\": \"Successfully created new zone barangay\",\n   \"zone_barangay\": {\n       \"id\": \"2638120d-2080-4705-b440-8cf71c255cb6\",\n       \"created\": {\n           \"val\": \"NOW()\"\n       },\n       \"zone_id\": \"2c933419-6a70-4139-b399-7930ad72ee10\",\n       \"barangay_id\": \"31f39813-9592-433c-ab93-d35de4b69c38\"\n   },\n   \"success\" : true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ZoneBarangayController.js",
    "groupTitle": "Barangay"
  },
  {
    "type": "deactivate",
    "url": "/barangays/:id/deactivate",
    "title": "deactivateBarangay",
    "group": "Barangay",
    "name": "deactivateBarangay",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "Character",
            "optional": false,
            "field": "code",
            "description": "<p>code of barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "district_id",
            "description": "<p>district_id of barangay referenced from district</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the barangay is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the barangay is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the barangay is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Message",
            "description": "<p>Deactivated Barangay + id</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n  {\n      \"barangay\": {\n          \"id\": \"89fc14b8-d853-4cb2-9f66-4cc8c08fc767\",\n          \"code\": \"MA\",\n          \"name\": \"MAAHAS\",\n          \"created\": \"2018-07-12T02:23:59.000Z\",\n          \"updated\": \"2018-07-12T02:50:41.000Z\",\n          \"deleted\": \"2018-07-12T02:53:28.000Z\",\n          \"district_id\": \"bf6e171c-c292-4626-95dc-b5698c7e281a\",\n          \"sub_district_id\": \"f72dfca7-8258-4ec5-b0f3-d46ceec478a8\"\n      },\n      \"message\": \"deactivated barangay: 89fc14b8-d853-4cb2-9f66-4cc8c08fc767\",\n      \"success\": true\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/BarangayController.js",
    "groupTitle": "Barangay"
  },
  {
    "type": "deactivate",
    "url": "/zone-barangays/:id/deactivate",
    "title": "deactivateZoneBarangay",
    "group": "Barangay",
    "name": "deactivateZoneBarangay",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of zone barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "zone_id",
            "description": "<p>zone_id of zone barangay referenced from zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "barangay_id",
            "description": "<p>barangay_id of zone barangay referenced from barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the zone barangay is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the zone barangay is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the zone barangay is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Message",
            "description": "<p>deactivated zone barangay + id</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n {\n    \"zone_barangay\": {\n        \"id\": \"2638120d-2080-4705-b440-8cf71c255cb6\",\n        \"created\": \"2018-07-12T03:17:43.000Z\",\n        \"updated\": \"2018-07-12T03:26:28.000Z\",\n        \"deleted\": \"2018-07-12T03:28:42.000Z\",\n        \"zone_id\": \"2c933419-6a70-4139-b399-7930ad72ee10\",\n        \"barangay_id\": \"31f39813-9592-433c-ab93-d35de4b69c38\"\n    },\n    \"message\": \"deactivated zone barangay: 2638120d-2080-4705-b440-8cf71c255cb6\",\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ZoneBarangayController.js",
    "groupTitle": "Barangay"
  },
  {
    "type": "get",
    "url": "/barangays",
    "title": "getBarangays",
    "group": "Barangay",
    "name": "getBarangays",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "Character",
            "optional": false,
            "field": "code",
            "description": "<p>code of barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "district_id",
            "description": "<p>district_id of barangay referenced from district</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the barangay is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the barangay is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the barangay is deleted.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n {\n    \"barangays\": [\n        {\n            \"id\": \"31f39813-9592-433c-ab93-d35de4b69c38\",\n            \"code\": \"BM\",\n            \"name\": \"batong malake\",\n            \"created\": \"2018-07-12T02:23:42.000Z\",\n            \"updated\": null,\n            \"deleted\": null,\n            \"district_id\": \"bf6e171c-c292-4626-95dc-b5698c7e281a\",\n            \"sub_district_id\": \"f72dfca7-8258-4ec5-b0f3-d46ceec478a8\",\n            \"sub_district\": {\n                \"id\": \"f72dfca7-8258-4ec5-b0f3-d46ceec478a8\",\n                \"code\": \"LB\",\n                \"name\": \"Los Banos\",\n                \"district\": {\n                    \"id\": \"bf6e171c-c292-4626-95dc-b5698c7e281a\",\n                    \"code\": \"D2\",\n                    \"name\": \"District2\",\n                    \"province\": {\n                        \"id\": \"d9991792-c27a-4639-a7be-66f5e7e8e470\",\n                        \"code\": \"LAG\",\n                        \"name\": \"Laguna\",\n                        \"region\": {\n                            \"id\": \"32205cd1-8f91-4c33-90a8-f334df890b15\",\n                            \"code\": \"CAL\",\n                            \"name\": \"CALABARZON\",\n                            \"country\": {\n                                \"id\": \"96055792-1044-472b-b058-b8012019d8a7\",\n                                \"code\": \"P\",\n                                \"name\": \"Philippines\"\n                            }\n                        }\n                    }\n                }\n            }\n        },\n        {\n            \"id\": \"89fc14b8-d853-4cb2-9f66-4cc8c08fc767\",\n            \"code\": \"AN\",\n            \"name\": \"ANOS\",\n            \"created\": \"2018-07-12T02:23:59.000Z\",\n            \"updated\": null,\n            \"deleted\": null,\n            \"district_id\": \"bf6e171c-c292-4626-95dc-b5698c7e281a\",\n            \"sub_district_id\": \"f72dfca7-8258-4ec5-b0f3-d46ceec478a8\",\n            \"sub_district\": {\n                \"id\": \"f72dfca7-8258-4ec5-b0f3-d46ceec478a8\",\n                \"code\": \"LB\",\n                \"name\": \"Los Banos\",\n                \"district\": {\n                    \"id\": \"bf6e171c-c292-4626-95dc-b5698c7e281a\",\n                    \"code\": \"D2\",\n                    \"name\": \"District2\",\n                    \"province\": {\n                        \"id\": \"d9991792-c27a-4639-a7be-66f5e7e8e470\",\n                        \"code\": \"LAG\",\n                        \"name\": \"Laguna\",\n                        \"region\": {\n                            \"id\": \"32205cd1-8f91-4c33-90a8-f334df890b15\",\n                            \"code\": \"CAL\",\n                            \"name\": \"CALABARZON\",\n                            \"country\": {\n                                \"id\": \"96055792-1044-472b-b058-b8012019d8a7\",\n                                \"code\": \"P\",\n                                \"name\": \"Philippines\"\n                            }\n                        }\n                    }\n                }\n            }\n        }\n    ],\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/BarangayController.js",
    "groupTitle": "Barangay"
  },
  {
    "type": "getOne",
    "url": "/barangays/:id",
    "title": "getOneBarangay",
    "group": "Barangay",
    "name": "getOneBarangay",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "Character",
            "optional": false,
            "field": "code",
            "description": "<p>code of barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "district_id",
            "description": "<p>district_id of barangay referenced from district</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the barangay is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the barangay is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the barangay is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n   {\n      \"barangay\": {\n          \"id\": \"31f39813-9592-433c-ab93-d35de4b69c38\",\n          \"code\": \"BM\",\n          \"name\": \"batong malake\",\n          \"created\": \"2018-07-12T02:23:42.000Z\",\n          \"updated\": null,\n          \"deleted\": null,\n          \"district_id\": \"bf6e171c-c292-4626-95dc-b5698c7e281a\",\n          \"sub_district_id\": \"f72dfca7-8258-4ec5-b0f3-d46ceec478a8\",\n          \"sub_district\": {\n              \"id\": \"f72dfca7-8258-4ec5-b0f3-d46ceec478a8\",\n              \"code\": \"LB\",\n              \"name\": \"Los Banos\",\n              \"district\": {\n                  \"id\": \"bf6e171c-c292-4626-95dc-b5698c7e281a\",\n                  \"code\": \"D2\",\n                  \"name\": \"District2\",\n                  \"province\": {\n                      \"id\": \"d9991792-c27a-4639-a7be-66f5e7e8e470\",\n                      \"code\": \"LAG\",\n                      \"name\": \"Laguna\",\n                      \"region\": {\n                          \"id\": \"32205cd1-8f91-4c33-90a8-f334df890b15\",\n                          \"code\": \"CAL\",\n                          \"name\": \"CALABARZON\",\n                          \"country\": {\n                              \"id\": \"96055792-1044-472b-b058-b8012019d8a7\",\n                              \"code\": \"P\",\n                              \"name\": \"Philippines\"\n                          }\n                      }\n                  }\n              }\n          }\n      },\n      \"success\": true\n   }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/BarangayController.js",
    "groupTitle": "Barangay"
  },
  {
    "type": "reactivate",
    "url": "/barangays/:id/reactivate",
    "title": "reactivateBarangay",
    "group": "Barangay",
    "name": "reactivateBarangay",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "Character",
            "optional": false,
            "field": "code",
            "description": "<p>code of barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "district_id",
            "description": "<p>district_id of barangay referenced from district</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the barangay is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the barangay is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the barangay is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Message",
            "description": "<p>reactivated barangay + id</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n{\n   \"barangay\": {\n       \"id\": \"89fc14b8-d853-4cb2-9f66-4cc8c08fc767\",\n       \"code\": \"MA\",\n       \"name\": \"MAAHAS\",\n       \"created\": \"2018-07-12T02:23:59.000Z\",\n       \"updated\": \"2018-07-12T02:50:41.000Z\",\n       \"deleted\": null,\n       \"district_id\": \"bf6e171c-c292-4626-95dc-b5698c7e281a\",\n       \"sub_district_id\": \"f72dfca7-8258-4ec5-b0f3-d46ceec478a8\"\n   },\n   \"message\": \"reactivated barangay: 89fc14b8-d853-4cb2-9f66-4cc8c08fc767\",\n   \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/BarangayController.js",
    "groupTitle": "Barangay"
  },
  {
    "type": "reactivate",
    "url": "/zone-barangays/:id/reactivate",
    "title": "reactivateZoneBarangay",
    "group": "Barangay",
    "name": "reactivateZoneBarangay",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of zone barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "zone_id",
            "description": "<p>zone_id of zone barangay referenced from zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "barangay_id",
            "description": "<p>barangay_id of zone barangay referenced from barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the zone barangay is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the zone barangay is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the zone barangay is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Message",
            "description": "<p>deactivated zone barangay + id</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n {\n    \"zone_barangay\": {\n        \"id\": \"2638120d-2080-4705-b440-8cf71c255cb6\",\n        \"created\": \"2018-07-12T03:17:43.000Z\",\n        \"updated\": \"2018-07-12T03:26:28.000Z\",\n        \"deleted\": null,\n        \"zone_id\": \"2c933419-6a70-4139-b399-7930ad72ee10\",\n        \"barangay_id\": \"31f39813-9592-433c-ab93-d35de4b69c38\"\n    },\n    \"message\": \"reactivated zone barangay: 2638120d-2080-4705-b440-8cf71c255cb6\",\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ZoneBarangayController.js",
    "groupTitle": "Barangay"
  },
  {
    "type": "search",
    "url": "/barangays/search",
    "title": "searchBarangay",
    "group": "Barangay",
    "name": "searchBarangay",
    "parameter": {
      "fields": {
        "Query Params": [
          {
            "group": "Query Params",
            "type": "UUID",
            "optional": false,
            "field": "ID",
            "description": "<p>id of barangay</p>"
          },
          {
            "group": "Query Params",
            "type": "Character",
            "optional": false,
            "field": "code",
            "description": "<p>code of barangay</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of barangay</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "district_id",
            "description": "<p>district_id of barangay referenced from district</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "sub_district_id",
            "description": "<p>sub_district_id of barangay referenced from sub_district</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "Character",
            "optional": false,
            "field": "code",
            "description": "<p>code of barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "district_id",
            "description": "<p>district_id of barangay referenced from district</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the barangay is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the barangay is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the barangay is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n   \"barangays\": [\n       {\n           \"id\": \"89fc14b8-d853-4cb2-9f66-4cc8c08fc767\",\n           \"code\": \"MA\",\n           \"name\": \"MAAHAS\",\n           \"created\": \"2018-07-12T02:23:59.000Z\",\n           \"updated\": \"2018-07-12T02:50:41.000Z\",\n           \"deleted\": null,\n           \"district_id\": \"bf6e171c-c292-4626-95dc-b5698c7e281a\",\n           \"sub_district_id\": \"f72dfca7-8258-4ec5-b0f3-d46ceec478a8\"\n       }\n   ],\n   \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/BarangayController.js",
    "groupTitle": "Barangay"
  },
  {
    "type": "search",
    "url": "/zone-barangays/search",
    "title": "searchZoneBarangay",
    "group": "Barangay",
    "name": "searchZoneBarangay",
    "parameter": {
      "fields": {
        "Query Params": [
          {
            "group": "Query Params",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of zone barangay</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "zone_id",
            "description": "<p>zone_id of zone barangay referenced from zone</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "barangay_id",
            "description": "<p>barangay_id of zone barangay referenced from barangay</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of zone barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "zone_id",
            "description": "<p>zone_id of zone barangay referenced from zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "barangay_id",
            "description": "<p>barangay_id of zone barangay referenced from barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the zone barangay is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the zone barangay is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the zone barangay is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Message",
            "description": "<p>Successfully created new zone barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n {\n    \"zone_barangays\": [\n        {\n            \"id\": \"258b59b7-7907-4d7e-a3bf-961bbdb97a3a\",\n            \"created\": \"2018-07-12T03:20:34.000Z\",\n            \"updated\": null,\n            \"deleted\": null,\n            \"zone_id\": \"2c933419-6a70-4139-b399-7930ad72ee10\",\n            \"barangay_id\": \"89fc14b8-d853-4cb2-9f66-4cc8c08fc767\"\n        },\n        {\n            \"id\": \"2638120d-2080-4705-b440-8cf71c255cb6\",\n            \"created\": \"2018-07-12T03:17:43.000Z\",\n            \"updated\": \"2018-07-12T03:26:28.000Z\",\n            \"deleted\": \"2018-07-12T03:37:18.000Z\",\n            \"zone_id\": \"2c933419-6a70-4139-b399-7930ad72ee10\",\n            \"barangay_id\": \"31f39813-9592-433c-ab93-d35de4b69c38\"\n        }\n    ],\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ZoneBarangayController.js",
    "groupTitle": "Barangay"
  },
  {
    "type": "put",
    "url": "/barangays/:id",
    "title": "updateBarangay",
    "group": "Barangay",
    "name": "updateBarangay",
    "parameter": {
      "fields": {
        "Body Params": [
          {
            "group": "Body Params",
            "type": "Character",
            "optional": false,
            "field": "code",
            "description": "<p>code of barangay</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of barangay</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "district_id",
            "description": "<p>district_id of barangay referenced from district</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "sub_district_id",
            "description": "<p>sub_district_id of barangay referenced from sub_district</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "Character",
            "optional": false,
            "field": "code",
            "description": "<p>code of barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "district_id",
            "description": "<p>district_id of barangay referenced from district</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the barangay is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the barangay is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the barangay is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Message",
            "description": "<p>update barangay + id</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n{\n   \"barangay\": {\n       \"id\": \"89fc14b8-d853-4cb2-9f66-4cc8c08fc767\",\n       \"code\": \"MA\",\n       \"name\": \"MAAHAS\",\n       \"created\": \"2018-07-12T02:23:59.000Z\",\n       \"updated\": \"2018-07-12T02:50:41.000Z\",\n       \"deleted\": null,\n       \"district_id\": \"bf6e171c-c292-4626-95dc-b5698c7e281a\",\n       \"sub_district_id\": \"f72dfca7-8258-4ec5-b0f3-d46ceec478a8\"\n   },\n   \"message\": \"update barangay: 89fc14b8-d853-4cb2-9f66-4cc8c08fc767\",\n   \"success\": true\n }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/BarangayController.js",
    "groupTitle": "Barangay"
  },
  {
    "type": "put",
    "url": "/zone-barangays/:id",
    "title": "updateZoneBarangay",
    "group": "Barangay",
    "name": "updateZoneBarangay",
    "parameter": {
      "fields": {
        "Body Params": [
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "zone_id",
            "description": "<p>zone_id of zone barangay referenced from zone</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "barangay_id",
            "description": "<p>barangay_id of zone barangay referenced from barangay</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of zone barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "zone_id",
            "description": "<p>zone_id of zone barangay referenced from zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "barangay_id",
            "description": "<p>barangay_id of zone barangay referenced from barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the zone barangay is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the zone barangay is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the zone barangay is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Message",
            "description": "<p>update zone barangay + id</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n    \"zone_barangay\": {\n        \"id\": \"2638120d-2080-4705-b440-8cf71c255cb6\",\n        \"created\": \"2018-07-12T03:17:43.000Z\",\n        \"updated\": \"2018-07-12T03:26:28.000Z\",\n        \"deleted\": null,\n        \"zone_id\": \"2c933419-6a70-4139-b399-7930ad72ee10\",\n        \"barangay_id\": \"31f39813-9592-433c-ab93-d35de4b69c38\"\n    },\n    \"message\": \"update zone_barangay: 2638120d-2080-4705-b440-8cf71c255cb6\",\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ZoneBarangayController.js",
    "groupTitle": "Barangay"
  },
  {
    "type": "post",
    "url": "/bookings",
    "title": "addBooking",
    "group": "Booking",
    "name": "addBooking",
    "parameter": {
      "fields": {
        "System Generated": [
          {
            "group": "System Generated",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of booking</p>"
          }
        ],
        "Body Params": [
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "shipper_name",
            "description": "<p>shipper_name of booking</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "pick_up_address",
            "description": "<p>pick_up_address of booking</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "contact_number",
            "description": "<p>contact_number of booking</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "email",
            "description": "<p>email of booking</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "product_type",
            "description": "<p>product_type of booking</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "cargo_type",
            "description": "<p>cargo_type of booking</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "mode_of_payment",
            "description": "<p>mode_of_payment of booking</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "client_account_number",
            "description": ""
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "shipper_name",
            "description": "<p>shipper_name of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "pick_up_address",
            "description": "<p>pick_up_address of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "contact_number",
            "description": "<p>contact_number of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "email",
            "description": "<p>email of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "product_type",
            "description": "<p>product_type of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "cargo_type",
            "description": "<p>cargo_type of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "mode_of_payment",
            "description": "<p>mode_of_payment of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "client_account_number",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the district is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the district is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the district is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Message",
            "description": "<p>Successfully created booking.</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n   \"message\": \"Successfully created booking.\",\n   \"booking\": {\n       \"id\": \"c5318d95-964a-4973-856f-a81da63c6320\",\n       \"created\": {\n           \"val\": \"NOW()\"\n       },\n       \"shipper_name\": \"Lazada\",\n       \"pick_up_address\": \"Ilag's Compound\",\n       \"contact_number\": \"09168679865\",\n       \"email\": \"ahabulan@gmail.com\",\n       \"product_type\": \"Apparel\",\n       \"cargo_type\": \"Dry bulk\",\n       \"mode_of_payment\": \"visa\",\n       \"client_account_number\" : null\n   },\n   \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/BookingController.js",
    "groupTitle": "Booking"
  },
  {
    "type": "assign",
    "url": "/bookings/:id/assign",
    "title": "assignBooking",
    "group": "Booking",
    "name": "assignBooking",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the district is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "status",
            "description": "<p>Status of booking apiSuccess  {Boolean} success true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n   \"message\": \"Successfully assigned booking\",\n   \"assignment\": {\n       \"id\": \"44097751-364e-422a-91de-0b4ce99c59be\",\n       \"created\": {\n           \"val\": \"NOW()\"\n       },\n       \"status\": \"Pending\",\n       \"booking_id\": \"c5318d95-964a-4973-856f-a81da63c6320\"\n   },\n   \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/BookingController.js",
    "groupTitle": "Booking"
  },
  {
    "type": "delete",
    "url": "/bookings/:id",
    "title": "cancelBooking",
    "group": "Booking",
    "name": "cancelBooking",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "shipper_name",
            "description": "<p>shipper_name of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "pick_up_address",
            "description": "<p>pick_up_address of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "contact_number",
            "description": "<p>contact_number of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "email",
            "description": "<p>email of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "product_type",
            "description": "<p>product_type of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "cargo_type",
            "description": "<p>cargo_type of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "mode_of_payment",
            "description": "<p>mode_of_payment of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "client_account_number",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the district is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the district is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the district is deleted.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n   \"message\": \"Successfully cancelled booking\",\n   \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/BookingController.js",
    "groupTitle": "Booking"
  },
  {
    "type": "get",
    "url": "/bookings",
    "title": "getBookings",
    "group": "Booking",
    "name": "getBookings",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "shipper_name",
            "description": "<p>shipper_name of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "pick_up_address",
            "description": "<p>pick_up_address of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "contact_number",
            "description": "<p>contact_number of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "email",
            "description": "<p>email of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "product_type",
            "description": "<p>product_type of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "cargo_type",
            "description": "<p>cargo_type of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "mode_of_payment",
            "description": "<p>mode_of_payment of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "client_account_number",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the district is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the district is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the district is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n {\n    \"bookings\": [\n        {\n            \"id\": \"490e0c2b-138b-4770-b18f-235b0dc8f4b1\",\n            \"shipper_name\": \"Lazada\",\n            \"pick_up_address\": \"Ilag's Compound, \",\n            \"contact_number\": \"09168679865\",\n            \"email\": \"ahabulan@gmail.com\",\n            \"product_type\": \"Apparel\",\n            \"cargo_type\": \"Dry bulk\",\n            \"mode_of_payment\": \"visa\",\n            \"created\": \"2018-07-12T03:49:15.000Z\",\n            \"updated\": null,\n            \"deleted\": null,\n            \"client_account_number\": null\n        },\n        {\n            \"id\": \"bd4ef8f7-ddea-4163-9bba-6c21dc87a61c\",\n            \"shipper_name\": \"Shoppee\",\n            \"pick_up_address\": \"Raymundo\",\n            \"contact_number\": \"09271234561\",\n            \"email\": \"kzarzoso@gmail.com\",\n            \"product_type\": \"Apparel\",\n            \"cargo_type\": \"Dry bulk\",\n            \"mode_of_payment\": \"visa\",\n            \"created\": \"2018-07-12T06:48:10.000Z\",\n            \"updated\": null,\n            \"deleted\": null,\n            \"client_account_number\": \"8b776f3f-63a9-4e38-a318-cab8a86ef7d4\"\n        }\n    ], \n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/BookingController.js",
    "groupTitle": "Booking"
  },
  {
    "type": "getOne",
    "url": "/bookings/:id",
    "title": "getOneBooking",
    "group": "Booking",
    "name": "getOneBooking",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "shipper_name",
            "description": "<p>shipper_name of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "pick_up_address",
            "description": "<p>pick_up_address of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "contact_number",
            "description": "<p>contact_number of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "email",
            "description": "<p>email of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "product_type",
            "description": "<p>product_type of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "cargo_type",
            "description": "<p>cargo_type of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "mode_of_payment",
            "description": "<p>mode_of_payment of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "client_account_number",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the district is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the district is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the district is deleted.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n   \"booking\": {\n       \"id\": \"490e0c2b-138b-4770-b18f-235b0dc8f4b1\",\n       \"shipper_name\": \"Lazada\",\n       \"pick_up_address\": \"Ilag's Compound, \",\n       \"contact_number\": \"09168679865\",\n       \"email\": \"ahabulan@gmail.com\",\n       \"product_type\": \"Apparel\",\n       \"cargo_type\": \"Dry bulk\",\n       \"mode_of_payment\": \"visa\",\n       \"created\": \"2018-07-12T03:49:15.000Z\",\n       \"updated\": null,\n       \"deleted\": null,\n       \"client_account_number\": null\n   },\n   \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/BookingController.js",
    "groupTitle": "Booking"
  },
  {
    "type": "search",
    "url": "/bookings",
    "title": "searchBooking",
    "group": "Booking",
    "name": "searchBooking",
    "parameter": {
      "fields": {
        "Query Params": [
          {
            "group": "Query Params",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of booking</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "shipper_name",
            "description": "<p>shipper_name of booking</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "pick_up_address",
            "description": "<p>pick_up_address of booking</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "contact_number",
            "description": "<p>contact_number of booking</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "email",
            "description": "<p>email of booking</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "product_type",
            "description": "<p>product_type of booking</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "cargo_type",
            "description": "<p>cargo_type of booking</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "mode_of_payment",
            "description": "<p>mode_of_payment of booking</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "client_account_number",
            "description": ""
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "shipper_name",
            "description": "<p>shipper_name of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "pick_up_address",
            "description": "<p>pick_up_address of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "contact_number",
            "description": "<p>contact_number of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "email",
            "description": "<p>email of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "product_type",
            "description": "<p>product_type of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "cargo_type",
            "description": "<p>cargo_type of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "mode_of_payment",
            "description": "<p>mode_of_payment of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "client_account_number",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the district is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the district is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the district is deleted.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n   \"bookings\": [\n       {\n           \"id\": \"490e0c2b-138b-4770-b18f-235b0dc8f4b1\",\n           \"shipper_name\": \"Lazada\",\n           \"pick_up_address\": \"Ilag's Compound, \",\n           \"contact_number\": \"09168679865\",\n           \"email\": \"ahabulan@gmail.com\",\n           \"product_type\": \"Apparel\",\n           \"cargo_type\": \"Dry bulk\",\n           \"mode_of_payment\": \"visa\",\n           \"created\": \"2018-07-12T03:49:15.000Z\",\n           \"updated\": null,\n           \"deleted\": null,\n           \"client_account_number\": null\n       }\n   ],\n       \"success\" : true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/BookingController.js",
    "groupTitle": "Booking"
  },
  {
    "type": "unassign",
    "url": "/bookings/:id/unassign",
    "title": "unassignBooking",
    "group": "Booking",
    "name": "unassignBooking",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "Timestamp",
            "description": "<p>timestamp of unassignment.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Message",
            "description": "<p>unassigned booking + id</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n   \"message\": \"Unassigned booking c5318d95-964a-4973-856f-a81da63c6320\",\n   \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/BookingController.js",
    "groupTitle": "Booking"
  },
  {
    "type": "put",
    "url": "/bookings/:id",
    "title": "updateBooking",
    "group": "Booking",
    "name": "updateBooking",
    "parameter": {
      "fields": {
        "Body Params": [
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "shipper_name",
            "description": "<p>shipper_name of booking</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "pick_up_address",
            "description": "<p>pick_up_address of booking</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "contact_number",
            "description": "<p>contact_number of booking</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "email",
            "description": "<p>email of booking</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "product_type",
            "description": "<p>product_type of booking</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "cargo_type",
            "description": "<p>cargo_type of booking</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "mode_of_payment",
            "description": "<p>mode_of_payment of booking</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "client_account_number",
            "description": ""
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "shipper_name",
            "description": "<p>shipper_name of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "pick_up_address",
            "description": "<p>pick_up_address of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "contact_number",
            "description": "<p>contact_number of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "email",
            "description": "<p>email of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "product_type",
            "description": "<p>product_type of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "cargo_type",
            "description": "<p>cargo_type of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "mode_of_payment",
            "description": "<p>mode_of_payment of booking</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "client_account_number",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the district is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the district is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the district is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n   \"booking\": {\n       \"id\": \"c5318d95-964a-4973-856f-a81da63c6320\",\n       \"shipper_name\": \"Lazada\",\n       \"pick_up_address\": \"Ilag's Compound\",\n       \"contact_number\": \"09168679812\",\n       \"email\": \"ahabulan@gmail.com\",\n       \"product_type\": \"Apparel\",\n       \"cargo_type\": \"Dry bulk\",\n       \"mode_of_payment\": \"visa\",\n       \"created\": \"2018-07-12T03:49:25.000Z\",\n       \"updated\": \"2018-07-12T03:51:15.000Z\",\n       \"deleted\": null,\n       \"client_account_number\": null\n   },\n   \"message\": \"update booking: c5318d95-964a-4973-856f-a81da63c6320\",\n   \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/BookingController.js",
    "groupTitle": "Booking"
  },
  {
    "type": "post",
    "url": "/v1/clients",
    "title": "Add Client",
    "group": "Client",
    "name": "Add_Client",
    "parameter": {
      "fields": {
        "Body Params": [
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "pick_up_address",
            "description": "<p>pick_up_address</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "ftp_address",
            "description": "<p>ftp_address</p>"
          },
          {
            "group": "Body Params",
            "type": "Integer",
            "optional": false,
            "field": "credit_term",
            "description": "<p>credit_term</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "mode_of_payment",
            "description": "<p>mode_of_payment</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "user_id",
            "description": "<p>client's user id (foreign key)</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "client",
            "description": "<p>new client</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "client.client_account_number",
            "description": "<p>account number of client</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "client.pick_up_address",
            "description": "<p>pick_up_address of client</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "client.ftp_address",
            "description": "<p>ftp_address of client</p>"
          },
          {
            "group": "Success 200",
            "type": "Integer",
            "optional": false,
            "field": "client.credit_term",
            "description": "<p>credit_term of client</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "client.mode_of_paymment",
            "description": "<p>mode_of_paymment of client</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "client.user_id",
            "description": "<p>user_id of client</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "client.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "client.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "client.deleted",
            "description": "<p>timestamp of deletion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n    \"client\": {\n        \"client_account_number\": \"d20060b1-6899-40d0-a299-d28fe0d862b0\",\n        \"created\": {\n            \"val\": \"NOW()\"\n        },\n        \"updated\": null,\n        \"deleted\": null,\n        \"pick_up_address\": \"Gatid Santa Cruz, Laguna\",\n        \"ftp_address\": \"\",\n        \"credit_term\": \"15\",\n        \"mode_of_payment\": \"cash\",\n        \"user_id\": \"3\"\n    },\n    \"message\": \"successfully created new client\",\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ClientController.js",
    "groupTitle": "Client"
  },
  {
    "type": "post",
    "url": "/v1/clients/:id/deactivate",
    "title": "Deactivate Client by ID",
    "group": "Client",
    "name": "Deactivate_Client_by_ID",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>Client's unique account number.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "client",
            "description": "<p>client</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "client.client_account_number",
            "description": "<p>account number of client</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "client.pick_up_address",
            "description": "<p>pick_up_address of client</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "client.ftp_address",
            "description": "<p>ftp_address of client</p>"
          },
          {
            "group": "Success 200",
            "type": "Integer",
            "optional": false,
            "field": "clienst.credit_term",
            "description": "<p>credit_term of client</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "client.mode_of_paymment",
            "description": "<p>mode_of_paymment of client</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "client.user_id",
            "description": "<p>user_id of client</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "client.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "client.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "client.deleted",
            "description": "<p>timestamp of deletion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n    \"message\": \"deactivated client\",\n    \"client\": {\n        \"client_account_number\": \"d20060b1-6899-40d0-a299-d28fe0d862b0\",\n        \"pick_up_address\": \"Gatid Santa Cruz, Laguna\",\n        \"ftp_address\": \"\",\n        \"credit_term\": 15,\n        \"mode_of_payment\": \"cash\",\n        \"created\": \"2018-07-12T03:04:07.000Z\",\n        \"updated\": null,\n        \"deleted\": \"2018-07-12T03:39:28.000Z\",\n        \"user_id\": 3\n    },\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ClientController.js",
    "groupTitle": "Client"
  },
  {
    "type": "get",
    "url": "/v1/clients/:id",
    "title": "Get Client by ID",
    "group": "Client",
    "name": "Get_Client_by_ID",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>Client's unique account number.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "client",
            "description": "<p>client</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "client.client_account_number",
            "description": "<p>account number of client</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "client.pick_up_address",
            "description": "<p>pick_up_address of client</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "client.ftp_address",
            "description": "<p>ftp_address of client</p>"
          },
          {
            "group": "Success 200",
            "type": "Integer",
            "optional": false,
            "field": "clienst.credit_term",
            "description": "<p>credit_term of client</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "client.mode_of_paymment",
            "description": "<p>mode_of_paymment of client</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "client.user_id",
            "description": "<p>user_id of client</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "client.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "client.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "client.deleted",
            "description": "<p>timestamp of deletion</p>"
          },
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "client.user",
            "description": "<p>more information about the client</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n    \"client\": {\n        \"client_account_number\": \"d20060b1-6899-40d0-a299-d28fe0d862b0\",\n        \"pick_up_address\": \"Gatid Santa Cruz, Laguna\",\n        \"ftp_address\": \"\",\n        \"credit_term\": 15,\n        \"mode_of_payment\": \"cash\",\n        \"created\": \"2018-07-12T03:04:07.000Z\",\n        \"updated\": null,\n        \"deleted\": null,\n        \"user_id\": 3,\n        \"User\": {\n            \"id\": 3,\n            \"email\": \"jdelacruz@gmail.com\",\n            \"first_name\": \"jose\",\n            \"middle_name\": \"reyes\",\n            \"last_name\": \"delacruz\",\n            \"contact_number\": \"09123456789\"\n        }\n    },\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ClientController.js",
    "groupTitle": "Client"
  },
  {
    "type": "get",
    "url": "/v1/clients",
    "title": "Get Clients",
    "group": "Client",
    "name": "Get_Clients",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object[]",
            "optional": false,
            "field": "clients",
            "description": "<p>array of clients</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "clients.client_account_number",
            "description": "<p>account number of client</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "clients.pick_up_address",
            "description": "<p>pick_up_address of client</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "clients.ftp_address",
            "description": "<p>ftp_address of client</p>"
          },
          {
            "group": "Success 200",
            "type": "Integer",
            "optional": false,
            "field": "clienst.credit_term",
            "description": "<p>credit_term of client</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "clients.mode_of_paymment",
            "description": "<p>mode_of_paymment of client</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "clients.user_id",
            "description": "<p>user_id of client</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "clients.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "clients.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "clients.deleted",
            "description": "<p>timestamp of deletion</p>"
          },
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "clients.user",
            "description": "<p>more information about the client</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n    \"client\": [\n        {\n            \"client_account_number\": \"d20060b1-6899-40d0-a299-d28fe0d862b0\",\n            \"pick_up_address\": \"Gatid Santa Cruz, Laguna\",\n            \"ftp_address\": \"\",\n            \"credit_term\": 15,\n            \"mode_of_payment\": \"cash\",\n            \"created\": \"2018-07-12T03:04:07.000Z\",\n            \"updated\": null,\n            \"deleted\": null,\n            \"user_id\": 3,\n            \"User\": {\n                \"id\": 3,\n                \"email\": \"jdelacruz@gmail.com\",\n                \"first_name\": \"jose\",\n                \"middle_name\": \"reyes\",\n                \"last_name\": \"delacruz\",\n                \"contact_number\": \"09123456789\"\n            }\n        },\n        {\n            \"client_account_number\": \"ba65f79c-bcf1-4cc9-8e3b-6bd597531af6\",\n            \"pick_up_address\": \"Calios Santa Cruz, Laguna\",\n            \"ftp_address\": \"\",\n            \"credit_term\": 30,\n            \"mode_of_payment\": \"cash\",\n            \"created\": \"2018-07-12T03:11:38.000Z\",\n            \"updated\": null,\n            \"deleted\": null,\n            \"user_id\": 4,\n            \"User\": {\n                \"id\": 4,\n                \"email\": \"aporca@gmail.com\",\n                \"first_name\": \"antonette\",\n                \"middle_name\": \"middle\",\n                \"last_name\": \"porca\",\n                \"contact_number\": \"09987654321\"\n            }\n        }\n    ],\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ClientController.js",
    "groupTitle": "Client"
  },
  {
    "type": "post",
    "url": "/v1/clients/:id/reactivate",
    "title": "Reactivate Client by ID",
    "group": "Client",
    "name": "Reactivate_Client_by_ID",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>Client's unique account number.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "client",
            "description": "<p>client</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "client.client_account_number",
            "description": "<p>account number of client</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "client.pick_up_address",
            "description": "<p>pick_up_address of client</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "client.ftp_address",
            "description": "<p>ftp_address of client</p>"
          },
          {
            "group": "Success 200",
            "type": "Integer",
            "optional": false,
            "field": "clienst.credit_term",
            "description": "<p>credit_term of client</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "client.mode_of_paymment",
            "description": "<p>mode_of_paymment of client</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "client.user_id",
            "description": "<p>user_id of client</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "client.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "client.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "client.deleted",
            "description": "<p>timestamp of deletion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n    \"message\": \"reactivated client\",\n    \"client\": {\n        \"client_account_number\": \"d20060b1-6899-40d0-a299-d28fe0d862b0\",\n        \"pick_up_address\": \"Gatid Santa Cruz, Laguna\",\n        \"ftp_address\": \"\",\n        \"credit_term\": 15,\n        \"mode_of_payment\": \"cash\",\n        \"created\": \"2018-07-12T03:04:07.000Z\",\n        \"updated\": null,\n        \"deleted\": null,\n        \"user_id\": 3\n    },\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ClientController.js",
    "groupTitle": "Client"
  },
  {
    "type": "get",
    "url": "/v1/clients",
    "title": "Search Clients",
    "group": "Client",
    "name": "Search_Clients",
    "parameter": {
      "fields": {
        "Params": [
          {
            "group": "Params",
            "type": "String",
            "optional": false,
            "field": "client_account_number",
            "description": "<p>client_account_number</p>"
          },
          {
            "group": "Params",
            "type": "String",
            "optional": false,
            "field": "pick_up_address",
            "description": "<p>pick_up_address</p>"
          },
          {
            "group": "Params",
            "type": "String",
            "optional": false,
            "field": "ftp_address",
            "description": "<p>ftp_address</p>"
          },
          {
            "group": "Params",
            "type": "Integer",
            "optional": false,
            "field": "credit_term",
            "description": "<p>credit_term</p>"
          },
          {
            "group": "Params",
            "type": "String",
            "optional": false,
            "field": "mode_of_payment",
            "description": "<p>mode_of_payment</p>"
          },
          {
            "group": "Params",
            "type": "String",
            "optional": false,
            "field": "user_id",
            "description": "<p>client's user id (foreign key)</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object[]",
            "optional": false,
            "field": "clients",
            "description": "<p>array of clients</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "clients.client_account_number",
            "description": "<p>account number of client</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "clients.pick_up_address",
            "description": "<p>pick_up_address of client</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "clients.ftp_address",
            "description": "<p>ftp_address of client</p>"
          },
          {
            "group": "Success 200",
            "type": "Integer",
            "optional": false,
            "field": "clienst.credit_term",
            "description": "<p>credit_term of client</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "clients.mode_of_paymment",
            "description": "<p>mode_of_paymment of client</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "clients.user_id",
            "description": "<p>user_id of client</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "clients.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "clients.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "clients.deleted",
            "description": "<p>timestamp of deletion</p>"
          },
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "clients.user",
            "description": "<p>more information about the client</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n    \"client\": [\n        {\n            \"client_account_number\": \"d20060b1-6899-40d0-a299-d28fe0d862b0\",\n            \"pick_up_address\": \"Gatid Santa Cruz, Laguna\",\n            \"ftp_address\": \"\",\n            \"credit_term\": 15,\n            \"mode_of_payment\": \"cash\",\n            \"created\": \"2018-07-12T03:04:07.000Z\",\n            \"updated\": null,\n            \"deleted\": null,\n            \"user_id\": 3\n        }\n    ],\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ClientController.js",
    "groupTitle": "Client"
  },
  {
    "type": "put",
    "url": "/v1/clients/:id",
    "title": "Update Client",
    "group": "Client",
    "name": "Update_Client",
    "parameter": {
      "fields": {
        "Body Params": [
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "pick_up_address",
            "description": "<p>pick_up_address</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "ftp_address",
            "description": "<p>ftp_address</p>"
          },
          {
            "group": "Body Params",
            "type": "Integer",
            "optional": false,
            "field": "credit_term",
            "description": "<p>credit_term</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "mode_of_payment",
            "description": "<p>mode_of_payment</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "user_id",
            "description": "<p>client's user id (foreign key)</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "client",
            "description": "<p>client</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "client.client_account_number",
            "description": "<p>account number of client</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "client.pick_up_address",
            "description": "<p>pick_up_address of client</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "client.ftp_address",
            "description": "<p>ftp_address of client</p>"
          },
          {
            "group": "Success 200",
            "type": "Integer",
            "optional": false,
            "field": "client.credit_term",
            "description": "<p>credit_term of client</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "client.mode_of_paymment",
            "description": "<p>mode_of_paymment of client</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "client.user_id",
            "description": "<p>user_id of client</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "client.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "client.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "client.deleted",
            "description": "<p>timestamp of deletion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n    \"client\": {\n        \"client_account_number\": \"d20060b1-6899-40d0-a299-d28fe0d862b0\",\n        \"pick_up_address\": \"Gatid Santa Cruz, Laguna\",\n        \"ftp_address\": \"\",\n        \"credit_term\": 90,\n        \"mode_of_payment\": \"cash\",\n        \"created\": \"2018-07-12T03:04:07.000Z\",\n        \"updated\": \"2018-07-12T03:45:42.000Z\",\n        \"deleted\": null,\n        \"user_id\": 3\n    },\n    \"message\": \"update client: d20060b1-6899-40d0-a299-d28fe0d862b0\",\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ClientController.js",
    "groupTitle": "Client"
  },
  {
    "type": "post",
    "url": "/clients/:id/schedules",
    "title": "Add Client Service Schedule",
    "name": "AddClientServiceSchedule",
    "group": "Client_Service_Schedule",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Client Account Number.</p>"
          }
        ],
        "Body Params": [
          {
            "group": "Body Params",
            "type": "Timestammp",
            "optional": false,
            "field": "pick_up_time",
            "description": "<p>Date and Time of Pick-up.</p>"
          },
          {
            "group": "Body Params",
            "type": "Timestammp",
            "optional": false,
            "field": "delivery_time",
            "description": "<p>Date and Time of Delivery.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "type",
            "description": "<p>Type of transaction.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Timestammp",
            "optional": false,
            "field": "pick_up_time",
            "description": "<p>Date and Time of Pick-up.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestammp",
            "optional": false,
            "field": "delivery_time",
            "description": "<p>Date and Time of Delivery.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "type",
            "description": "<p>Type of transaction.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "client_account_number",
            "description": "<p>Client Account Number referenced from Client.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Schedule is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Schedule is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Schedule is deleted. Client.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n      \"message\": \"successfully created new client service schedule\",\n      \"client service schedule\": {\n          \"id\": \"dea8f6af-28fd-46f1-8012-fb6ce2f6400d\",\n          \"created\": {\n              \"val\": \"NOW()\"\n          },\n          \"updated\": null,\n          \"client_account_number\": \"59e631e0-a9e8-40b9-a995-7d03cb608e52\",\n          \"delivery_time\" : null,\n          \"pick_up_time\": \"2018-07-01T22:05:17.000Z\",\n          \"type\": \"pickup\"\n      },\n      \"success\": true\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ClientServiceScheduleController.js",
    "groupTitle": "Client_Service_Schedule"
  },
  {
    "type": "delete",
    "url": "/schedules/:id",
    "title": "Delete Client Service Schedule By ID",
    "name": "DeleteClientServiceScheduleByID",
    "group": "Client_Service_Schedule",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Client Service Schedule ID.</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n       \"message\": \"deleted client service schedule\",\n       \"success\": true\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ClientServiceScheduleController.js",
    "groupTitle": "Client_Service_Schedule"
  },
  {
    "type": "get",
    "url": "/schedules/:id",
    "title": "Get Client Service Schedules",
    "name": "GetClientServiceSchedules",
    "group": "Client_Service_Schedule",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Client Service Schedule ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Timestammp",
            "optional": false,
            "field": "pick_up_time",
            "description": "<p>Date and Time of Pick-up.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestammp",
            "optional": false,
            "field": "delivery_time",
            "description": "<p>Date and Time of Delivery.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "type",
            "description": "<p>Type of transaction.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "client_account_number",
            "description": "<p>Client Account Number referenced from Client.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Schedule is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Schedule is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Schedule is deleted. Client.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n      \"client service schedules\": {\n          \"id\": \"dea8f6af-28fd-46f1-8012-fb6ce2f6400d\",\n          \"created\": {\n              \"val\": \"NOW()\"\n          },\n          \"updated\": null,\n          \"client_account_number\": \"59e631e0-a9e8-40b9-a995-7d03cb608e52\",\n          \"delivery_time\" : null,\n          \"pick_up_time\": \"2018-07-01T22:05:17.000Z\",\n          \"type\": \"pickup\"\n      },\n      \"success\": true\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ClientServiceScheduleController.js",
    "groupTitle": "Client_Service_Schedule"
  },
  {
    "type": "get",
    "url": "/clients/:id/schedules",
    "title": "Get Client Service Schedules By Client Account Number",
    "name": "GetClientServiceSchedulesByClientAccountNumber",
    "group": "Client_Service_Schedule",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Client Account Number.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Timestammp",
            "optional": false,
            "field": "pick_up_time",
            "description": "<p>Date and Time of Pick-up.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestammp",
            "optional": false,
            "field": "delivery_time",
            "description": "<p>Date and Time of Delivery.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "type",
            "description": "<p>Type of transaction.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "client_account_number",
            "description": "<p>Client Account Number referenced from Client.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Schedule is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Schedule is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Schedule is deleted. Client.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n {\n      \"client service schedules\": {\n          \"id\": \"dea8f6af-28fd-46f1-8012-fb6ce2f6400d\",\n          \"created\": {\n              \"val\": \"NOW()\"\n          },\n          \"updated\": null,\n          \"client_account_number\": \"59e631e0-a9e8-40b9-a995-7d03cb608e52\",\n          \"delivery_time\" : null,\n          \"pick_up_time\": \"2018-07-01T22:05:17.000Z\",\n          \"type\": \"pickup\"\n      },\n      \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ClientServiceScheduleController.js",
    "groupTitle": "Client_Service_Schedule"
  },
  {
    "type": "put",
    "url": "/schedules/:id",
    "title": "Update Client Service Schedule",
    "name": "UpdateClientServiceScheduleByID",
    "group": "Client_Service_Schedule",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Client Service Schedule ID.</p>"
          }
        ],
        "Body Params": [
          {
            "group": "Body Params",
            "type": "Timestammp",
            "optional": false,
            "field": "pick_up_time",
            "description": "<p>Date and Time of Pick-up.</p>"
          },
          {
            "group": "Body Params",
            "type": "Timestammp",
            "optional": false,
            "field": "delivery_time",
            "description": "<p>Date and Time of Delivery.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "type",
            "description": "<p>Type of transaction.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Timestammp",
            "optional": false,
            "field": "pick_up_time",
            "description": "<p>Date and Time of Pick-up.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestammp",
            "optional": false,
            "field": "delivery_time",
            "description": "<p>Date and Time of Delivery.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "type",
            "description": "<p>Type of transaction.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "client_account_number",
            "description": "<p>Client Account Number referenced from Client.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Schedule is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Schedule is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Schedule is deleted. Client.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n      \"client service schedule\": {\n          \"id\": \"dea8f6af-28fd-46f1-8012-fb6ce2f6400d\",\n          \"created\": {\n              \"val\": \"NOW()\"\n          },\n          \"updated\": \"2018-07-01T23:06:15.000Z\",\n          \"client_account_number\": \"59e631e0-a9e8-40b9-a995-7d03cb608e52\",\n          \"delivery_time\" : null,\n          \"pick_up_time\": \"2018-07-01T22:05:17.000Z\",\n          \"type\": \"pickup\"\n      },\n      \"message\": \"updated price: dea8f6af-28fd-46f1-8012-fb6ce2f6400d\",\n      \"success\": true\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ClientServiceScheduleController.js",
    "groupTitle": "Client_Service_Schedule"
  },
  {
    "type": "post",
    "url": "/countries",
    "title": "Add Country",
    "name": "AddCountry",
    "group": "Country",
    "parameter": {
      "fields": {
        "System Generated": [
          {
            "group": "System Generated",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Country unique ID</p>"
          }
        ],
        "Body Params": [
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>code of the Country</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of the Country</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Country ID.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>Code of the Country.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>Name of the Country.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Country is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Country is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Country is deleted.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n      \"message\": \"successfully created new country\",\n      \"country\": {\n          \"id\": \"0682ed71-3229-4fb6-b6a8-b515994a70b8\",\n          \"updated\": null,\n          \"deleted\": null,\n          \"code\": \"PH\",\n          \"name\": \"Philippines\",\n          \"created\": {\n              \"fn\": \"NOW\",\n              \"args\": []\n      }\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/CountryController.js",
    "groupTitle": "Country"
  },
  {
    "type": "post",
    "url": "/countries/:id/deactivate",
    "title": "Deactivate Country",
    "name": "DeactivateCountry",
    "group": "Country",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Country unique ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Country ID.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>Code of the Country.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>Name of the Country.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Country is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Country is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Country is deleted.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n      \"country\": {\n          \"id\": \"2fca2d08-a11b-4ad2-bc2d-79d4a4e6c796\",\n          \"code\": \"UK\",\n          \"name\": \"United Kingdom\",\n          \"created\": \"2018-07-10T07:17:39.000Z\",\n          \"updated\": \"2018-07-10T07:25:56.000Z\",\n          \"deleted\": \"2018-07-10T07:30:28.000Z\"\n      },\n      \"message\": \"deactivated country: 2fca2d08-a11b-4ad2-bc2d-79d4a4e6c796\"\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/CountryController.js",
    "groupTitle": "Country"
  },
  {
    "type": "get",
    "url": "/countries",
    "title": "Retrieve Countries",
    "name": "GetCountries",
    "group": "Country",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Country ID.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>Code of the Country.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>Name of the Country.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Country is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Country is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Country is deleted.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n      \"countries\": [\n          {\n              \"id\": \"2fca2d08-a11b-4ad2-bc2d-79d4a4e6c796\",\n              \"code\": \"USA\",\n              \"name\": \"United States of America\",\n              \"created\": \"2018-07-10T07:17:39.000Z\",\n              \"updated\": null,\n              \"deleted\": null\n          },\n          {\n              \"id\": \"406405a2-8255-48d0-86c6-7f1109d10e30\",\n              \"code\": \"PH\",\n              \"name\": \"Philippines\",\n              \"created\": \"2018-07-09T01:58:14.000Z\",\n              \"updated\": null,\n              \"deleted\": null\n          }\n      ],\n      \"success\": true\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/CountryController.js",
    "groupTitle": "Country"
  },
  {
    "type": "get",
    "url": "/countries/:id",
    "title": "Retrieve Country By ID",
    "name": "GetCountryByID",
    "group": "Country",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Country unique ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Country ID.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>Code of the Country.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>Name of the Country.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Country is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Country is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Country is deleted.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n      \"country\": {\n          \"id\": \"0682ed71-3229-4fb6-b6a8-b515994a70b8\",\n          \"code\": \"PH\",\n          \"name\": \"Philippines\",\n          \"created\": \"2018-07-10T06:54:10.000Z\",\n          \"updated\": null,\n          \"deleted\": null\n      },\n      \"success\": true\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/CountryController.js",
    "groupTitle": "Country"
  },
  {
    "type": "post",
    "url": "/countries/:id/reactivate",
    "title": "Reactivate Country",
    "name": "ReactivateCountry",
    "group": "Country",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Country unique ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Country ID.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>Code of the Country.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>Name of the Country.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Country is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Country is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Country is deleted.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n      \"country\": {\n          \"id\": \"2fca2d08-a11b-4ad2-bc2d-79d4a4e6c796\",\n          \"code\": \"UK\",\n          \"name\": \"United Kingdom\",\n          \"created\": \"2018-07-10T07:17:39.000Z\",\n          \"updated\": \"2018-07-10T07:25:56.000Z\",\n          \"deleted\": null\n      },\n      \"message\": \"reactivated country: 2fca2d08-a11b-4ad2-bc2d-79d4a4e6c796\"\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/CountryController.js",
    "groupTitle": "Country"
  },
  {
    "type": "get",
    "url": "/countries/search",
    "title": "Search Country",
    "name": "SearchCountry",
    "group": "Country",
    "parameter": {
      "fields": {
        "Query Params": [
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>code of the Country</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of the Country</p>"
          },
          {
            "group": "Query Params",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Country is created.</p>"
          },
          {
            "group": "Query Params",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Country is updated.</p>"
          },
          {
            "group": "Query Params",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Country is deleted.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Country ID.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>Code of the Country.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>Name of the Country.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Country is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Country is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Country is deleted.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n      \"countries\": [\n          {\n              \"id\": \"2fca2d08-a11b-4ad2-bc2d-79d4a4e6c796\",\n              \"code\": \"UK\",\n              \"name\": \"United Kingdom\",\n              \"created\": \"2018-07-10T07:17:39.000Z\",\n              \"updated\": \"2018-07-10T07:25:56.000Z\",\n              \"deleted\": null\n          }\n      ],\n      \"success\": true\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/CountryController.js",
    "groupTitle": "Country"
  },
  {
    "type": "put",
    "url": "/countries/:id",
    "title": "Update Country",
    "name": "UpdateCountryByID",
    "group": "Country",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Country unique ID.</p>"
          }
        ],
        "Body Params": [
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>code of the Country</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of the Country</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Country ID.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>Code of the Country.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>Name of the Country.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Country is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Country is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Country is deleted.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n      \"country\": {\n          \"id\": \"2fca2d08-a11b-4ad2-bc2d-79d4a4e6c796\",\n          \"code\": \"UK\",\n          \"name\": \"United Kingdom\",\n          \"created\": \"2018-07-10T07:17:39.000Z\",\n          \"updated\": \"2018-07-10T07:25:56.000Z\",\n          \"deleted\": null\n      },\n      \"message\": \"update country: 2fca2d08-a11b-4ad2-bc2d-79d4a4e6c796\"\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/CountryController.js",
    "groupTitle": "Country"
  },
  {
    "type": "post",
    "url": "/couriers",
    "title": "addCourier",
    "group": "Courier",
    "name": "addCourier",
    "parameter": {
      "fields": {
        "System Generated": [
          {
            "group": "System Generated",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of courier</p>"
          }
        ],
        "Body Params": [
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "zone_id",
            "description": "<p>zone_id of courier referenced from zone</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>distribution_center_id of courier referenced from distribution_center</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the courier</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "zone_id",
            "description": "<p>zone_id of courier referenced from zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>distribution_center_id of courier referenced from zone</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the courier is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the courier is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the courier is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Message",
            "description": "<p>Successfully created new courier.</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n    \"message\": \"Successfully created new courier\",\n    \"courier\": {\n        \"id\": \"8f573092-65f1-4b34-9542-a2a00355fae0\",\n        \"created\": {\n            \"val\": \"NOW()\"\n        },\n        \"user_id\": \"1\",\n        \"zone_id\": \"ec7bbf22-64f2-40f3-856d-ec5237fb2107\",\n        \"distribution_center_id\": \"1dbbeefc-b6a4-40e4-a85d-6c5362b4ec50\"\n    },\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "Error 500": [
          {
            "group": "Error 500",
            "type": "Number",
            "optional": false,
            "field": "status",
            "description": "<p>status code</p>"
          },
          {
            "group": "Error 500",
            "type": "String",
            "optional": false,
            "field": "message",
            "description": "<p>Error message</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Internal Server Error\n{\n  \"status\": 500,\n  \"message\": \"Internal server error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/CourierController.js",
    "groupTitle": "Courier"
  },
  {
    "type": "deactivate",
    "url": "/couriers/:id/deactivate",
    "title": "deactivateCourier",
    "group": "Courier",
    "name": "deactivateCourier",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the courier.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "zone_id",
            "description": "<p>zone_id of courier referenced from zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>distribution_center_id of courier referenced from distribution_center</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the courier is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the courier is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the courier is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "Message",
            "optional": false,
            "field": "Deactivated",
            "description": "<p>Courier</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n   \"courier\": {\n       \"id\": \"1032a869-edda-4610-bcd9-dc2b45abf74e\",\n       \"created\": \"2018-07-16T07:57:57.000Z\",\n       \"updated\": \"2018-07-16T08:20:45.000Z\",\n       \"deleted\": \"2018-07-16T08:25:03.000Z\",\n       \"zone_id\": \"ec7bbf22-64f2-40f3-856d-ec5237fb2107\",\n       \"distribution_center_id\": \"1dbbeefc-b6a4-40e4-a85d-6c5362b4ec50\",\n       \"user_id\": 2\n   },\n   \"message\": \"deactivated courier\",\n   \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/CourierController.js",
    "groupTitle": "Courier"
  },
  {
    "type": "getOne",
    "url": "/couriers/:id",
    "title": "getOneCourier",
    "group": "Courier",
    "name": "getCourier",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the courier.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "zone_id",
            "description": "<p>zone_id of courier referenced from zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>distribution_center_id of courier referenced from distribution_center</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the courier is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the courier is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the courier is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "email",
            "description": "<p>Email of courier.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "first_name",
            "description": "<p>First Name of courier.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "last_name",
            "description": "<p>Last Name of courier.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "middle_name",
            "description": "<p>Middle Name of courier.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "contact_number",
            "description": "<p>Contact Number of courier.</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n    \"courier\": {\n        \"id\": \"1032a869-edda-4610-bcd9-dc2b45abf74e\",\n        \"created\": \"2018-07-16T07:57:57.000Z\",\n        \"updated\": null,\n        \"deleted\": null,\n        \"zone_id\": \"ec7bbf22-64f2-40f3-856d-ec5237fb2107\",\n        \"distribution_center_id\": \"1dbbeefc-b6a4-40e4-a85d-6c5362b4ec50\",\n        \"user_id\": 1,\n        \"User\": {\n            \"id\": 1,\n            \"email\": \"ahabulan@gmail.com\",\n            \"first_name\": \"Aljay\",\n            \"last_name\": \"Habulan\",\n            \"middle_name\": \"Ranchez\",\n            \"contact_number\": \"09271238752\"\n        }\n    },\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/CourierController.js",
    "groupTitle": "Courier"
  },
  {
    "type": "get",
    "url": "/couriers",
    "title": "getCouriers",
    "group": "Courier",
    "name": "getCouriers",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the courier.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "zone_id",
            "description": "<p>zone_id of courier referenced from zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>distribution_center_id of courier referenced from distribution_center</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the courier is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the courier is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the courier is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "email",
            "description": "<p>Email of courier.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "first_name",
            "description": "<p>First Name of courier.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "last_name",
            "description": "<p>Last Name of courier.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "middle_name",
            "description": "<p>Middle Name of courier.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "contact_number",
            "description": "<p>Contact Number of courier.</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n    \"couriers\": [\n        {\n            \"id\": \"1032a869-edda-4610-bcd9-dc2b45abf74e\",\n            \"created\": \"2018-07-16T07:57:57.000Z\",\n            \"updated\": null,\n            \"deleted\": null,\n            \"zone_id\": \"ec7bbf22-64f2-40f3-856d-ec5237fb2107\",\n            \"distribution_center_id\": \"1dbbeefc-b6a4-40e4-a85d-6c5362b4ec50\",\n            \"user_id\": 1,\n            \"User\": {\n                \"id\": 1,\n                \"email\": \"ahabulan@gmail.com\",\n                \"first_name\": \"Aljay\",\n                \"last_name\": \"Habulan\",\n                \"middle_name\": \"Ranchez\",\n                \"contact_number\": \"09271238752\"\n            }\n        },\n        {\n            \"id\": \"1137023a-8ce8-45dd-8039-34abe5f71076\",\n            \"created\": \"2018-07-16T07:57:06.000Z\",\n            \"updated\": null,\n            \"deleted\": null,\n            \"zone_id\": \"ec7bbf22-64f2-40f3-856d-ec5237fb2107\",\n            \"distribution_center_id\": \"1dbbeefc-b6a4-40e4-a85d-6c5362b4ec50\",\n            \"user_id\": 2,\n            \"User\": {\n                \"id\": 1,\n                \"email\": \"kzarzoso@gmail.com\",\n                \"first_name\": \"Kiara\",\n                \"last_name\": \"Zarzoso\",\n                \"middle_name\": \"Calbera\",\n                \"contact_number\": \"092715428752\"\n            }\n        },\n    ],\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/CourierController.js",
    "groupTitle": "Courier"
  },
  {
    "type": "reactivate",
    "url": "/couriers/:id/reactivate",
    "title": "reactivateCourier",
    "group": "Courier",
    "name": "reactivateCourier",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the courier.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "zone_id",
            "description": "<p>zone_id of courier referenced from zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>distribution_center_id of courier referenced from distribution_center</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the courier is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the courier is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the courier is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "Message",
            "optional": false,
            "field": "Reactivated",
            "description": "<p>Courier</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n   \"courier\": {\n       \"id\": \"1032a869-edda-4610-bcd9-dc2b45abf74e\",\n       \"created\": \"2018-07-16T07:57:57.000Z\",\n       \"updated\": \"2018-07-16T08:20:45.000Z\",\n       \"deleted\": null,\n       \"zone_id\": \"ec7bbf22-64f2-40f3-856d-ec5237fb2107\",\n       \"distribution_center_id\": \"1dbbeefc-b6a4-40e4-a85d-6c5362b4ec50\",\n       \"user_id\": 2\n   },\n   \"message\": \"reactivated courier : 1032a869-edda-4610-bcd9-dc2b45abf74e\",\n   \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/CourierController.js",
    "groupTitle": "Courier"
  },
  {
    "type": "search",
    "url": "/couriers/search",
    "title": "searchCourier",
    "group": "Courier",
    "name": "searchCourier",
    "parameter": {
      "fields": {
        "Query Params": [
          {
            "group": "Query Params",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of courier</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "zone_id",
            "description": "<p>zone_id of courier referenced from zone</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>distribution_center_id of courier referenced from distribution_center</p>"
          },
          {
            "group": "Query Params",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the courier is created</p>"
          },
          {
            "group": "Query Params",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the courier is updated</p>"
          },
          {
            "group": "Query Params",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the courier is deleted</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the courier</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "zone_id",
            "description": "<p>zone_id of courier referenced from zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>distribution_center_id of courier referenced from zone</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the courier is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the courier is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the courier is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n   \"courier\": {\n       \"id\": \"1032a869-edda-4610-bcd9-dc2b45abf74e\",\n       \"created\": \"2018-07-16T07:57:57.000Z\",\n       \"updated\": \"2018-07-16T08:20:45.000Z\",\n       \"deleted\": null,\n       \"zone_id\": \"ec7bbf22-64f2-40f3-856d-ec5237fb2107\",\n       \"distribution_center_id\": \"1dbbeefc-b6a4-40e4-a85d-6c5362b4ec50\",\n       \"user_id\": 2,\n       \"User\": {\n           \"id\": 2,\n           \"email\": \"kzarzoso@gmail.com\",\n           \"first_name\": \"Kiara\",\n           \"last_name\": \"Zarzoso\",\n           \"middle_name\": \"Calbera\",\n           \"contact_number\": \"09271542752\"\n       }\n   },\n   \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/CourierController.js",
    "groupTitle": "Courier"
  },
  {
    "type": "put",
    "url": "/couriers/:id",
    "title": "updateCourier",
    "group": "Courier",
    "name": "updateCourier",
    "parameter": {
      "fields": {
        "Body Params": [
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "zone_id",
            "description": "<p>zone_id of courier referenced from zone</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>distribution_center_id of courier referenced from distribution_center</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the courier.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "zone_id",
            "description": "<p>zone_id of courier referenced from zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>distribution_center_id of courier referenced from distribution_center</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the courier is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the courier is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the courier is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Message",
            "description": "<p>Update courier</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n {\n    \"courier\": {\n        \"id\": \"1032a869-edda-4610-bcd9-dc2b45abf74e\",\n        \"created\": \"2018-07-16T07:57:57.000Z\",\n        \"updated\": \"2018-07-16T08:20:45.000Z\",\n        \"deleted\": null,\n        \"zone_id\": \"ec7bbf22-64f2-40f3-856d-ec5237fb2107\",\n        \"distribution_center_id\": \"1dbbeefc-b6a4-40e4-a85d-6c5362b4ec50\",\n        \"user_id\": 2\n    },\n    \"message\": \"update courier: 1032a869-edda-4610-bcd9-dc2b45abf74e\",\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/CourierController.js",
    "groupTitle": "Courier"
  },
  {
    "type": "post",
    "url": "/customer-supports",
    "title": "Add Customer Support",
    "name": "AddCustomerSupport",
    "group": "Customer_Support",
    "parameter": {
      "fields": {
        "System Generated": [
          {
            "group": "System Generated",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Customer Support unique ID.</p>"
          }
        ],
        "Body Params": [
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "user_id",
            "description": "<p>User ID.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "hub_id",
            "description": "<p>Hub ID.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>Distribution Center ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Customer Support is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Customer Support is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Customer Support is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id",
            "description": "<p>User ID referenced from User.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hub_id",
            "description": "<p>Hub ID referenced from Hub.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>Distribution Center ID referenced from Distribution Center.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n      \"message\": \"successfully created new dispatcher\",\n      \"dispatcher\": {\n          \"id\": \"9bff837f-b416-49c8-9000-62ec09e2ff3d\",\n          \"created\": {\n              \"val\": \"NOW()\"\n          },\n          \"updated\": null,\n          \"deleted\": null,\n          \"user_id\": \"1\",\n          \"hub_id\": \"5ca82e33-f401-4985-a329-33c62f791c23\",\n          \"distribution_center_id\": \"cc5c5aa7-16c0-4173-87f2-f9172661cafc\"\n      },\n      \"success\": true\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/CustomerSupportController.js",
    "groupTitle": "Customer_Support"
  },
  {
    "type": "post",
    "url": "/customer-supports/:id/deactivate",
    "title": "Deactivate Customer Support",
    "name": "DeactivateCustomerSupport",
    "group": "Customer_Support",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Customer Support unique ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Customer Support is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Customer Support is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Customer Support is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id",
            "description": "<p>User ID referenced from User.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hub_id",
            "description": "<p>Hub ID referenced from Hub.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>Distribution Center ID referenced from Distribution Center.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n      \"customer_support\": {\n          \"id\": \"19de5e99-27ab-476b-a815-e8edabc881e7\",\n          \"created\": \"2018-07-12T02:14:01.000Z\",\n          \"updated\": null,\n          \"deleted\": \"2018-07-12T02:55:58.000Z\",\n          \"user_id\": 1,\n          \"hub_id\": \"5ca82e33-f401-4985-a329-33c62f791c23\",\n          \"distribution_center_id\": \"cc5c5aa7-16c0-4173-87f2-f9172661cafc\"\n      },\n      \"message\": \"deactivated customer_support: 19de5e99-27ab-476b-a815-e8edabc881e7\",\n      \"success\": true\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/CustomerSupportController.js",
    "groupTitle": "Customer_Support"
  },
  {
    "type": "get",
    "url": "/customer-supports/:id",
    "title": "Retrieve Customer Support By ID",
    "name": "GetCustomerSupportByID",
    "group": "Customer_Support",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Customer Support unique ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Customer Support ID.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Customer Support is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Customer Support is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Customer Support is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hub_id",
            "description": "<p>Hub ID referenced from Hub.</p>"
          },
          {
            "group": "Success 200",
            "type": "Float",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>Distribution Center ID referenced from Distribution Center.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id",
            "description": "<p>User ID referenced from User.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id.email",
            "description": "<p>Email Address of the Customer Support.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id.first_name",
            "description": "<p>First Name of the Customer Support.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id.last_name",
            "description": "<p>Last Name of the Customer Support.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id.middle_name",
            "description": "<p>Middle Name of the Customer Support.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id.contact_number",
            "description": "<p>Contact Number of the Customer Support.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n      \"customer_support\": {\n          \"id\": \"19de5e99-27ab-476b-a815-e8edabc881e7\",\n          \"created\": \"2018-07-12T02:14:01.000Z\",\n          \"updated\": null,\n          \"deleted\": null,\n          \"user_id\": 1,\n          \"hub_id\": \"5ca82e33-f401-4985-a329-33c62f791c23\",\n          \"distribution_center_id\": \"cc5c5aa7-16c0-4173-87f2-f9172661cafc\",\n          \"User\": {\n              \"email\": \"jdelacruz@gmail.com\",\n              \"first_name\": \"Juan\",\n              \"last_name\": \"Dela Cruz\",\n              \"middle_name\": \"Reyes\",\n              \"contact_number\": \"09096755833\"\n          }\n      },\n      \"success\": true\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/CustomerSupportController.js",
    "groupTitle": "Customer_Support"
  },
  {
    "type": "get",
    "url": "/customer-supports",
    "title": "Retrieve Customer Supports",
    "name": "GetCustomerSupports",
    "group": "Customer_Support",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Customer Support ID.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Customer Support is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Customer Support is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Customer Support is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hub_id",
            "description": "<p>Hub ID referenced from Hub.</p>"
          },
          {
            "group": "Success 200",
            "type": "Float",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>Distribution Center ID referenced from Distribution Center.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id",
            "description": "<p>User ID referenced from User.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id.email",
            "description": "<p>Email Address of the Customer Support.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id.first_name",
            "description": "<p>First Name of the Customer Support.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id.last_name",
            "description": "<p>Last Name of the Customer Support.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id.middle_name",
            "description": "<p>Middle Name of the Customer Support.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id.contact_number",
            "description": "<p>Contact Number of the Customer Support.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n      \"customer_supports\": [\n          {\n              \"id\": \"19de5e99-27ab-476b-a815-e8edabc881e7\",\n              \"created\": \"2018-07-12T02:14:01.000Z\",\n              \"updated\": null,\n              \"deleted\": null,\n              \"user_id\": 1,\n              \"hub_id\": \"5ca82e33-f401-4985-a329-33c62f791c23\",\n              \"distribution_center_id\": \"cc5c5aa7-16c0-4173-87f2-f9172661cafc\",\n              \"User\": {\n                  \"email\": \"jdelacruz@gmail.com\",\n                  \"first_name\": \"Juan\",\n                  \"last_name\": \"Dela Cruz\",\n                  \"middle_name\": \"Reyes\",\n                  \"contact_number\": \"09096755833\"\n              }\n          }\n      ],\n      \"success\": true\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/CustomerSupportController.js",
    "groupTitle": "Customer_Support"
  },
  {
    "type": "post",
    "url": "/customer-supports/:id/reactivate",
    "title": "Reactivate Customer Support",
    "name": "ReactivateCustomerSupport",
    "group": "Customer_Support",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Customer Support unique ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Customer Support is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Customer Support is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Customer Support is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id",
            "description": "<p>User ID referenced from User.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hub_id",
            "description": "<p>Hub ID referenced from Hub.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>Distribution Center ID referenced from Distribution Center.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n      \"customer_support\": {\n          \"id\": \"19de5e99-27ab-476b-a815-e8edabc881e7\",\n          \"created\": \"2018-07-12T02:14:01.000Z\",\n          \"updated\": null,\n          \"deleted\": \"2018-07-12T02:55:58.000Z\",\n          \"user_id\": 1,\n          \"hub_id\": \"5ca82e33-f401-4985-a329-33c62f791c23\",\n          \"distribution_center_id\": \"cc5c5aa7-16c0-4173-87f2-f9172661cafc\"\n      },\n      \"message\": \"reactivated customer_support: 19de5e99-27ab-476b-a815-e8edabc881e7\",\n      \"success\": true\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/CustomerSupportController.js",
    "groupTitle": "Customer_Support"
  },
  {
    "type": "get",
    "url": "/customer-supports/search",
    "title": "Search Customer Support",
    "name": "SearchCustomerSupport",
    "group": "Customer_Support",
    "parameter": {
      "fields": {
        "Body Params": [
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "user_id",
            "description": "<p>User ID.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "hub_id",
            "description": "<p>Hub ID.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>Distribution Center ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Customer Support is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Customer Support is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Customer Support is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hub_id",
            "description": "<p>Hub ID referenced from Hub.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>Distribution Center ID referenced from Distribution Center.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id",
            "description": "<p>User ID referenced from User.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id.email",
            "description": "<p>Email Address of the Customer Support.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id.first_name",
            "description": "<p>First Name of the Customer Support.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id.last_name",
            "description": "<p>Last Name of the Customer Support.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id.middle_name",
            "description": "<p>Middle Name of the Customer Support.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id.contact_number",
            "description": "<p>Contact Number of the Customer Support.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n      \"customer supports\": [\n          {\n              \"id\": \"19de5e99-27ab-476b-a815-e8edabc881e7\",\n              \"created\": \"2018-07-12T02:14:01.000Z\",\n              \"updated\": null,\n              \"deleted\": null,\n              \"user_id\": 1,\n              \"hub_id\": \"5ca82e33-f401-4985-a329-33c62f791c23\",\n              \"distribution_center_id\": \"cc5c5aa7-16c0-4173-87f2-f9172661cafc\",\n              \"User\": {\n                  \"email\": \"jdelacruz@gmail.com\",\n                  \"first_name\": \"Juan\",\n                  \"last_name\": \"Dela Cruz\",\n                  \"middle_name\": \"Reyes\",\n                  \"contact_number\": \"09096755833\"\n              }\n          }\n      ],\n      \"success\": true\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/CustomerSupportController.js",
    "groupTitle": "Customer_Support"
  },
  {
    "type": "put",
    "url": "/customer-supports/:id",
    "title": "Update Customer Support",
    "name": "UpdateCustomerSupportByID",
    "group": "Customer_Support",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Customer Support unique ID.</p>"
          }
        ],
        "Body Params": [
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "user_id",
            "description": "<p>User ID.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "hub_id",
            "description": "<p>Hub ID.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>Distribution Center ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Customer Support is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Customer Support is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Customer Support is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id",
            "description": "<p>User ID referenced from User.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hub_id",
            "description": "<p>Hub ID referenced from Hub.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>Distribution Center ID referenced from Distribution Center.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n      \"customer_support\": {\n          \"id\": \"19de5e99-27ab-476b-a815-e8edabc881e7\",\n          \"created\": \"2018-07-12T02:14:01.000Z\",\n          \"updated\": null,\n          \"deleted\": null,\n          \"user_id\": 1,\n          \"hub_id\": \"5ca82e33-f401-4985-a329-33c62f791c23\",\n          \"distribution_center_id\": \"cc5c5aa7-16c0-4173-87f2-f9172661cafc\"\n      },\n      \"message\": \"update customer_support: 19de5e99-27ab-476b-a815-e8edabc881e7\",\n      \"success\": true\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/CustomerSupportController.js",
    "groupTitle": "Customer_Support"
  },
  {
    "type": "post",
    "url": "/dispatchers",
    "title": "Add Dispatcher",
    "name": "AddDispatcher",
    "group": "Dispatcher",
    "parameter": {
      "fields": {
        "System Generated": [
          {
            "group": "System Generated",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Dispatcher unique ID.</p>"
          }
        ],
        "Body Params": [
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "user_id",
            "description": "<p>User ID.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "hub_id",
            "description": "<p>Hub ID.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>Distribution Center ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Dispatcher is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Dispatcher is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Dispatcher is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id",
            "description": "<p>User ID referenced from User.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hub_id",
            "description": "<p>Hub ID referenced from Hub.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>Distribution Center ID referenced from Distribution Center.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n      \"message\": \"successfully created new dispatcher\",\n      \"dispatcher\": {\n          \"id\": \"9bff837f-b416-49c8-9000-62ec09e2ff3d\",\n          \"created\": {\n              \"val\": \"NOW()\"\n          },\n          \"updated\": null,\n          \"deleted\": null,\n          \"user_id\": \"1\",\n          \"hub_id\": \"5ca82e33-f401-4985-a329-33c62f791c23\",\n          \"distribution_center_id\": \"cc5c5aa7-16c0-4173-87f2-f9172661cafc\"\n      },\n      \"success\": true\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/DispatcherController.js",
    "groupTitle": "Dispatcher"
  },
  {
    "type": "post",
    "url": "/dispatchers/:id/deactivate",
    "title": "Deactivate Dispatcher",
    "name": "DeactivateDispatcher",
    "group": "Dispatcher",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Dispatcher unique ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Dispatcher ID.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Dispatcher is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Dispatcher is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Dispatcher is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id",
            "description": "<p>User ID referenced from User.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hub_id",
            "description": "<p>Hub ID referenced from Hub.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>Distribution Center ID referenced from Distribution Center.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n      \"dispatcher\": {\n          \"id\": \"2e4dca57-d5dd-4a71-b04f-b9ee404d33df\",\n          \"created\": \"2018-07-11T08:30:16.000Z\",\n          \"updated\": null,\n          \"deleted\": \"2018-07-12T01:13:37.000Z\",\n          \"user_id\": 1,\n          \"hub_id\": \"61b54974-015f-4ac9-b8e0-17b3bca537a1\",\n          \"distribution_center_id\": \"1046eed9-c0be-408c-a685-1faa08f9760e\"\n      },\n      \"message\": \"deactivated dispatcher: 2e4dca57-d5dd-4a71-b04f-b9ee404d33df\",\n      \"success\": true\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/DispatcherController.js",
    "groupTitle": "Dispatcher"
  },
  {
    "type": "get",
    "url": "/dispatchers/:id",
    "title": "Retrieve Dispatcher By ID",
    "name": "GetDispatcherByID",
    "group": "Dispatcher",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Dispatcher unique ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Dispatcher ID.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Dispatcher is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Dispatcher is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Dispatcher is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hub_id",
            "description": "<p>Hub ID referenced from Hub.</p>"
          },
          {
            "group": "Success 200",
            "type": "Float",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>Distribution Center ID referenced from Distribution Center.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id",
            "description": "<p>User ID referenced from User.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id.email",
            "description": "<p>Email Address of the Dispatcher.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id.first_name",
            "description": "<p>First Name of the Dispatcher.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id.last_name",
            "description": "<p>Last Name of the Dispatcher.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id.middle_name",
            "description": "<p>Middle Name of the Dispatcher.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id.contact_number",
            "description": "<p>Contact Number of the Dispatcher.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n      \"dispatcher\": {\n          \"id\": \"9bff837f-b416-49c8-9000-62ec09e2ff3d\",\n          \"created\": \"2018-07-12T01:47:22.000Z\",\n          \"updated\": null,\n          \"deleted\": null,\n          \"user_id\": 1,\n          \"hub_id\": \"5ca82e33-f401-4985-a329-33c62f791c23\",\n          \"distribution_center_id\": \"cc5c5aa7-16c0-4173-87f2-f9172661cafc\",\n          \"User\": {\n              \"email\": \"jdelacruz@gmail.com\",\n              \"first_name\": \"Juan\",\n              \"last_name\": \"Dela Cruz\",\n              \"middle_name\": \"Reyes\",\n              \"contact_number\": \"09096755833\"\n          }\n      },\n      \"success\": true\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/DispatcherController.js",
    "groupTitle": "Dispatcher"
  },
  {
    "type": "get",
    "url": "/dispatchers",
    "title": "Retrieve Dispatchers",
    "name": "GetDispatchers",
    "group": "Dispatcher",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Dispatcher ID.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Dispatcher is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Dispatcher is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Dispatcher is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hub_id",
            "description": "<p>Hub ID referenced from Hub.</p>"
          },
          {
            "group": "Success 200",
            "type": "Float",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>Distribution Center ID referenced from Distribution Center.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id",
            "description": "<p>User ID referenced from User.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id.email",
            "description": "<p>Email Address of the Dispatcher.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id.first_name",
            "description": "<p>First Name of the Dispatcher.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id.last_name",
            "description": "<p>Last Name of the Dispatcher.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id.middle_name",
            "description": "<p>Middle Name of the Dispatcher.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id.contact_number",
            "description": "<p>Contact Number of the Dispatcher.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n      \"dispatchers\": [\n          {\n              \"id\": \"9bff837f-b416-49c8-9000-62ec09e2ff3d\",\n              \"created\": \"2018-07-12T01:47:22.000Z\",\n              \"updated\": null,\n              \"deleted\": null,\n              \"user_id\": 1,\n              \"hub_id\": \"5ca82e33-f401-4985-a329-33c62f791c23\",\n              \"distribution_center_id\": \"cc5c5aa7-16c0-4173-87f2-f9172661cafc\",\n              \"User\": {\n                  \"email\": \"jdelacruz@gmail.com\",\n                  \"first_name\": \"Juan\",\n                  \"last_name\": \"Dela Cruz\",\n                  \"middle_name\": \"Reyes\",\n                  \"contact_number\": \"09096755833\"\n              }\n          }\n      ],\n      \"success\": true\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/DispatcherController.js",
    "groupTitle": "Dispatcher"
  },
  {
    "type": "post",
    "url": "/dispatchers/:id/reactivate",
    "title": "Reactivate Dispatcher",
    "name": "ReactivateDispatcher",
    "group": "Dispatcher",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Dispatcher unique ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Dispatcher ID.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Dispatcher is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Dispatcher is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Dispatcher is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id",
            "description": "<p>User ID referenced from User.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hub_id",
            "description": "<p>Hub ID referenced from Hub.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>Distribution Center ID referenced from Distribution Center.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n      \"dispatcher\": {\n          \"id\": \"2e4dca57-d5dd-4a71-b04f-b9ee404d33df\",\n          \"created\": \"2018-07-11T08:30:16.000Z\",\n          \"updated\": null,\n          \"deleted\": null,\n          \"user_id\": 1,\n          \"hub_id\": \"61b54974-015f-4ac9-b8e0-17b3bca537a1\",\n          \"distribution_center_id\": \"1046eed9-c0be-408c-a685-1faa08f9760e\"\n      },\n      \"message\": \"reactivated dispatcher: 2e4dca57-d5dd-4a71-b04f-b9ee404d33df\",\n      \"success\": true\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/DispatcherController.js",
    "groupTitle": "Dispatcher"
  },
  {
    "type": "get",
    "url": "/dispatchers/search",
    "title": "Search Dispatcher",
    "name": "SearchDispatcher",
    "group": "Dispatcher",
    "parameter": {
      "fields": {
        "Query Params": [
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "user_id",
            "description": "<p>User ID.</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "hub_id",
            "description": "<p>Hub ID.</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>Distribution Center ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Dispatcher ID.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Dispatcher is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Dispatcher is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Dispatcher is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hub_id",
            "description": "<p>Hub ID referenced from Hub.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>Distribution Center ID referenced from Distribution Center.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id",
            "description": "<p>User ID referenced from User.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id.email",
            "description": "<p>Email Address of the Dispatcher.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id.first_name",
            "description": "<p>First Name of the Dispatcher.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id.last_name",
            "description": "<p>Last Name of the Dispatcher.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id.middle_name",
            "description": "<p>Middle Name of the Dispatcher.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id.contact_number",
            "description": "<p>Contact Number of the Dispatcher.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n       \"dispatchers\": [\n          {\n              \"id\": \"9bff837f-b416-49c8-9000-62ec09e2ff3d\",\n              \"created\": \"2018-07-12T01:47:22.000Z\",\n              \"updated\": null,\n              \"deleted\": null,\n              \"user_id\": 1,\n              \"hub_id\": \"5ca82e33-f401-4985-a329-33c62f791c23\",\n              \"distribution_center_id\": \"cc5c5aa7-16c0-4173-87f2-f9172661cafc\",\n              \"User\": {\n                  \"email\": \"jdelacruz@gmail.com\",\n                  \"first_name\": \"Juan\",\n                  \"last_name\": \"Dela Cruz\",\n                  \"middle_name\": \"Reyes\",\n                  \"contact_number\": \"09096755833\"\n              }\n          }\n      ],\n      \"success\": true\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/DispatcherController.js",
    "groupTitle": "Dispatcher"
  },
  {
    "type": "put",
    "url": "/dispatchers/:id",
    "title": "Update Dispatcher",
    "name": "UpdateDispatcherByID",
    "group": "Dispatcher",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Dispatcher unique ID.</p>"
          }
        ],
        "Body Params": [
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "user_id",
            "description": "<p>User ID.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "hub_id",
            "description": "<p>Hub ID.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>Distribution Center ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Dispatcher ID.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Dispatcher is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Dispatcher is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Dispatcher is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user_id",
            "description": "<p>User ID referenced from User.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hub_id",
            "description": "<p>Hub ID referenced from Hub.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>Distribution Center ID referenced from Distribution Center.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n      \"dispatcher\": {\n          \"id\": \"2e4dca57-d5dd-4a71-b04f-b9ee404d33df\",\n          \"created\": \"2018-07-11T08:30:16.000Z\",\n          \"updated\": null,\n          \"deleted\": null,\n          \"user_id\": 1,\n          \"hub_id\": \"61b54974-015f-4ac9-b8e0-17b3bca537a1\",\n          \"distribution_center_id\": \"1046eed9-c0be-408c-a685-1faa08f9760e\"\n      },\n      \"message\": \"update dispatcher: 2e4dca57-d5dd-4a71-b04f-b9ee404d33df\",\n      \"success\": true\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/DispatcherController.js",
    "groupTitle": "Dispatcher"
  },
  {
    "type": "post",
    "url": "/v1/distribution-centers",
    "title": "Add Distribution Center",
    "group": "Distribution_Center",
    "name": "Add_Distribution_Center",
    "parameter": {
      "fields": {
        "System Generated": [
          {
            "group": "System Generated",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>unique ID</p>"
          }
        ],
        "Body Params": [
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>unique code for each distribution center</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "hub_id",
            "description": "<p>ID of the Hub the Distribution Center belongs to (foreign key)</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of distribution center</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "address",
            "description": "<p>address of the distribution center</p>"
          },
          {
            "group": "Body Params",
            "type": "char",
            "optional": false,
            "field": "country",
            "description": "<p>country</p>"
          },
          {
            "group": "Body Params",
            "type": "char",
            "optional": false,
            "field": "region",
            "description": "<p>region</p>"
          },
          {
            "group": "Body Params",
            "type": "char",
            "optional": false,
            "field": "province",
            "description": "<p>province</p>"
          },
          {
            "group": "Body Params",
            "type": "char",
            "optional": false,
            "field": "district",
            "description": "<p>district</p>"
          },
          {
            "group": "Body Params",
            "type": "char",
            "optional": false,
            "field": "sub_district",
            "description": "<p>sub_district</p>"
          },
          {
            "group": "Body Params",
            "type": "char",
            "optional": false,
            "field": "barangay",
            "description": "<p>barangay</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "distribution_center",
            "description": "<p>new distribution_center</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "distribution_center.id",
            "description": "<p>ID of distribution_center</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center.code",
            "description": "<p>code of distribution_center</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center.name",
            "description": "<p>name of distribution_center</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center.address",
            "description": "<p>address of distribution_center</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "distribution_center.country",
            "description": "<p>country</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "distribution_center.region",
            "description": "<p>region</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "distribution_center.province",
            "description": "<p>province</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "distribution_center.district",
            "description": "<p>district</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "distribution_center.sub_district",
            "description": "<p>sub_district</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "distribution_center.barangay",
            "description": "<p>barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "distribution_center.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "distribution_center.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "distribution_center.deleted",
            "description": "<p>timestamp of deletion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n      \"message\": \"successfully created new distribution_center\",\n      \"distribution_center\": {\n          \"id\": \"9da7a22e-9acf-44fc-8c5f-30107b334993\",\n          \"created\": {\n              \"val\": \"NOW()\"\n          },\n          \"updated\": null,\n          \"deleted\": null,\n          \"code\": \"SXZA1\",\n          \"hub_id\": \"8cf19a0b-c6fd-45f7-8859-678535befc60\",\n          \"name\": \"Los Banos Distribution Center\",\n          \"address\": \"Los Banos\",\n          \"country\": \"PHL\",\n          \"region\": \"4A\",\n          \"province\": \"LGN\",\n          \"district\": \"4\",\n          \"sub_district\": \"\",\n          \"barangay\": \"Anos\"\n      },\n      \"success\": true\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/DistributionCenterController.js",
    "groupTitle": "Distribution_Center"
  },
  {
    "type": "post",
    "url": "/v1/distribution-centers/:id/deactivate",
    "title": "Deactivate Distribution Center by ID",
    "name": "Deactivate_Distribution_Center_by_ID",
    "group": "Distribution_Center",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>Distribution Center's unique ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "distribution_center",
            "description": "<p>new distribution_center</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "distribution_center.id",
            "description": "<p>ID of distribution_center</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center.code",
            "description": "<p>code of distribution_center</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center.name",
            "description": "<p>name of distribution_center</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center.address",
            "description": "<p>address of distribution_center</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "distribution_center.country",
            "description": "<p>country</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "distribution_center.region",
            "description": "<p>region</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "distribution_center.province",
            "description": "<p>province</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "distribution_center.district",
            "description": "<p>district</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "distribution_center.sub_district",
            "description": "<p>sub_district</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "distribution_center.barangay",
            "description": "<p>barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "distribution_center.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "distribution_center.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "distribution_center.deleted",
            "description": "<p>timestamp of deletion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n    \"message\": \"deactivated distribution_center\",\n    \"destination\": {\n        \"id\": \"e5673532-de5b-4886-a24e-a447a58b4782\",\n        \"code\": \"SCDC\",\n        \"name\": \"Santa Cruz Distribution Center\",\n        \"address\": \"Santa Cruz\",\n        \"country\": \"PHL\",\n        \"region\": \"4A\",\n        \"province\": \"LGN\",\n        \"district\": \"4\",\n        \"sub_district\": \"\",\n        \"barangay\": \"Bagumbayan\",\n        \"created\": \"2018-07-11T00:27:45.000Z\",\n        \"updated\": null,\n        \"deleted\": \"2018-07-11T01:20:04.000Z\",\n        \"hub_id\": \"d3d16b9f-e0ea-46e7-9a15-d2cdcfdd484e\"\n    },\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/DistributionCenterController.js",
    "groupTitle": "Distribution_Center"
  },
  {
    "type": "get",
    "url": "/v1/distribution-centers/:id",
    "title": "Get Distribution Center by ID",
    "group": "Distribution_Center",
    "name": "Get_Distribution_Center_by_ID",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>Users unique ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "distribution_center",
            "description": "<p>new distribution_center</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "distribution_center.id",
            "description": "<p>ID of distribution_center</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center.code",
            "description": "<p>code of distribution_center</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center.name",
            "description": "<p>name of distribution_center</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center.address",
            "description": "<p>address of distribution_center</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "distribution_center.country",
            "description": "<p>country</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "distribution_center.region",
            "description": "<p>region</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "distribution_center.province",
            "description": "<p>province</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "distribution_center.district",
            "description": "<p>district</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "distribution_center.sub_district",
            "description": "<p>sub_district</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "distribution_center.barangay",
            "description": "<p>barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "distribution_center.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "distribution_center.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "distribution_center.deleted",
            "description": "<p>timestamp of deletion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n     \"distribution_center\": {\n         \"id\": \"e5673532-de5b-4886-a24e-a447a58b4782\",\n         \"code\": \"SCDC\",\n         \"name\": \"Santa Cruz Distribution Center\",\n         \"address\": \"Santa Cruz\",\n         \"country\": \"PHL\",\n         \"region\": \"4A\",\n         \"province\": \"LGN\",\n         \"district\": \"4\",\n         \"sub_district\": \"\",\n         \"barangay\": \"Bagumbayan\",\n         \"created\": \"2018-07-11T00:27:45.000Z\",\n         \"updated\": null,\n         \"deleted\": null,\n         \"hub_id\": \"d3d16b9f-e0ea-46e7-9a15-d2cdcfdd484e\"\n     },\n     \"success\": true\n }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/DistributionCenterController.js",
    "groupTitle": "Distribution_Center"
  },
  {
    "type": "get",
    "url": "/v1/distribution-centers",
    "title": "Get Distribution Centers",
    "group": "Distribution_Center",
    "name": "Get_Distribution_Centers",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object[]",
            "optional": false,
            "field": "distribution_centers",
            "description": "<p>array of distribution centers</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "distribution_centers.id",
            "description": "<p>ID of distribution center</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_centers.code",
            "description": "<p>code of distribution center</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_centers.name",
            "description": "<p>name of distribution center</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_centers.address",
            "description": "<p>address of distribution center</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "distribution_centers.country",
            "description": "<p>country</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "distribution_centers.region",
            "description": "<p>region</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "distribution_centers.province",
            "description": "<p>province</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "distribution_centers.district",
            "description": "<p>district</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "distribution_centers.sub_district",
            "description": "<p>sub_district</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "distribution_centers.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "distribution_centers.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "distribution_centers.deleted",
            "description": "<p>timestamp of deletion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n    \"distribution_centers\": [\n        {\n            \"id\": \"9da7a22e-9acf-44fc-8c5f-30107b334993\",\n            \"code\": \"SXZA1\",\n            \"name\": \"Los Banos Distribution Center\",\n            \"address\": \"Los Banos\",\n            \"country\": \"PHL\",\n            \"region\": \"4A\",\n            \"province\": \"LGN\",\n            \"district\": \"4\",\n            \"sub_district\": \"\",\n            \"barangay\": \"Anos\",\n            \"created\": \"2018-07-11T00:25:17.000Z\",\n            \"updated\": null,\n            \"deleted\": null,\n            \"hub_id\": \"8cf19a0b-c6fd-45f7-8859-678535befc60\"\n        },\n        {\n            \"id\": \"e5673532-de5b-4886-a24e-a447a58b4782\",\n            \"code\": \"SCDC\",\n            \"name\": \"Santa Cruz Distribution Center\",\n            \"address\": \"Santa Cruz\",\n            \"country\": \"PHL\",\n            \"region\": \"4A\",\n            \"province\": \"LGN\",\n            \"district\": \"4\",\n            \"sub_district\": \"\",\n            \"barangay\": \"Bagumbayan\",\n            \"created\": \"2018-07-11T00:27:45.000Z\",\n            \"updated\": null,\n            \"deleted\": null,\n            \"hub_id\": \"d3d16b9f-e0ea-46e7-9a15-d2cdcfdd484e\"\n        }\n    ],\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/DistributionCenterController.js",
    "groupTitle": "Distribution_Center"
  },
  {
    "type": "post",
    "url": "/v1/distribution-centers/:id/reactivate",
    "title": "Reactivate Distribution Center by ID",
    "name": "Reactivate_Distribution_Center_by_ID",
    "group": "Distribution_Center",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>Distribution Center's unique ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "distribution_center",
            "description": "<p>new distribution_center</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "distribution_center.id",
            "description": "<p>ID of distribution_center</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center.code",
            "description": "<p>code of distribution_center</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center.name",
            "description": "<p>name of distribution_center</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center.address",
            "description": "<p>address of distribution_center</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "distribution_center.country",
            "description": "<p>country</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "distribution_center.region",
            "description": "<p>region</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "distribution_center.province",
            "description": "<p>province</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "distribution_center.district",
            "description": "<p>district</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "distribution_center.sub_district",
            "description": "<p>sub_district</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "distribution_center.barangay",
            "description": "<p>barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "distribution_center.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "distribution_center.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "distribution_center.deleted",
            "description": "<p>timestamp of deletion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n    \"message\": \"reactivated distribution_center\",\n    \"destination\": {\n        \"id\": \"e5673532-de5b-4886-a24e-a447a58b4782\",\n        \"code\": \"SCDC\",\n        \"name\": \"Santa Cruz Distribution Center\",\n        \"address\": \"Santa Cruz\",\n        \"country\": \"PHL\",\n        \"region\": \"4A\",\n        \"province\": \"LGN\",\n        \"district\": \"4\",\n        \"sub_district\": \"\",\n        \"barangay\": \"Bagumbayan\",\n        \"created\": \"2018-07-11T00:27:45.000Z\",\n        \"updated\": null,\n        \"deleted\": null,\n        \"hub_id\": \"d3d16b9f-e0ea-46e7-9a15-d2cdcfdd484e\"\n    },\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/DistributionCenterController.js",
    "groupTitle": "Distribution_Center"
  },
  {
    "type": "get",
    "url": "/v1/distribution-centers/search",
    "title": "Search Distribution Center",
    "name": "Search_Distribution_Center",
    "group": "Distribution_Center",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>Distribution Center's unique ID</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>unique code for each distribution center</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "hub_id",
            "description": "<p>ID of the Hub the Distribution Center belongs to (foreign key)</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of distribution center</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "address",
            "description": "<p>address of the distribution center</p>"
          },
          {
            "group": "Parameter",
            "type": "char",
            "optional": false,
            "field": "country",
            "description": "<p>country</p>"
          },
          {
            "group": "Parameter",
            "type": "char",
            "optional": false,
            "field": "region",
            "description": "<p>region</p>"
          },
          {
            "group": "Parameter",
            "type": "char",
            "optional": false,
            "field": "province",
            "description": "<p>province</p>"
          },
          {
            "group": "Parameter",
            "type": "char",
            "optional": false,
            "field": "district",
            "description": "<p>district</p>"
          },
          {
            "group": "Parameter",
            "type": "char",
            "optional": false,
            "field": "sub_district",
            "description": "<p>sub_district</p>"
          },
          {
            "group": "Parameter",
            "type": "char",
            "optional": false,
            "field": "barangay",
            "description": "<p>barangay</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object[]",
            "optional": false,
            "field": "distribution_centers",
            "description": "<p>array of distribution centers</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "distribution_centers.id",
            "description": "<p>ID of distribution center</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_centers.code",
            "description": "<p>code of distribution center</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_centers.name",
            "description": "<p>name of distribution center</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_centers.address",
            "description": "<p>address of distribution center</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "distribution_centers.country",
            "description": "<p>country</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "distribution_centers.region",
            "description": "<p>region</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "distribution_centers.province",
            "description": "<p>province</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "distribution_centers.district",
            "description": "<p>district</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "distribution_centers.sub_district",
            "description": "<p>sub_district</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "distribution_centers.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "distribution_centers.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "distribution_centers.deleted",
            "description": "<p>timestamp of deletion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n    \"distribution_center\": [\n        {\n            \"id\": \"e5673532-de5b-4886-a24e-a447a58b4782\",\n            \"code\": \"SCDC\",\n            \"name\": \"Santa Cruz Distribution Center\",\n            \"address\": \"Santa Cruz\",\n            \"country\": \"PHL\",\n            \"region\": \"4A\",\n            \"province\": \"LGN\",\n            \"district\": \"4\",\n            \"sub_district\": \"\",\n            \"barangay\": \"Bagumbayan\",\n            \"created\": \"2018-07-11T00:27:45.000Z\",\n            \"updated\": null,\n            \"deleted\": null,\n            \"hub_id\": \"d3d16b9f-e0ea-46e7-9a15-d2cdcfdd484e\"\n        }\n    ],\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/DistributionCenterController.js",
    "groupTitle": "Distribution_Center"
  },
  {
    "type": "put",
    "url": "/v1/distribution-centers/:id",
    "title": "Update Distribution Center by ID",
    "name": "Update_Distribution_Center_by_ID",
    "group": "Distribution_Center",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>Distribution Center's unique ID.</p>"
          }
        ],
        "Body Params": [
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>unique code for each distribution center</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "hub_id",
            "description": "<p>ID of the Hub the Distribution Center belongs to (foreign key)</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of distribution center</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "address",
            "description": "<p>address of the distribution center</p>"
          },
          {
            "group": "Body Params",
            "type": "char",
            "optional": false,
            "field": "country",
            "description": "<p>country</p>"
          },
          {
            "group": "Body Params",
            "type": "char",
            "optional": false,
            "field": "region",
            "description": "<p>region</p>"
          },
          {
            "group": "Body Params",
            "type": "char",
            "optional": false,
            "field": "province",
            "description": "<p>province</p>"
          },
          {
            "group": "Body Params",
            "type": "char",
            "optional": false,
            "field": "district",
            "description": "<p>district</p>"
          },
          {
            "group": "Body Params",
            "type": "char",
            "optional": false,
            "field": "sub_district",
            "description": "<p>sub_district</p>"
          },
          {
            "group": "Body Params",
            "type": "char",
            "optional": false,
            "field": "barangay",
            "description": "<p>barangay</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "distribution_center",
            "description": "<p>new distribution_center</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "distribution_center.id",
            "description": "<p>ID of distribution_center</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center.code",
            "description": "<p>code of distribution_center</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center.name",
            "description": "<p>name of distribution_center</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center.address",
            "description": "<p>address of distribution_center</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "distribution_center.country",
            "description": "<p>country</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "distribution_center.region",
            "description": "<p>region</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "distribution_center.province",
            "description": "<p>province</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "distribution_center.district",
            "description": "<p>district</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "distribution_center.sub_district",
            "description": "<p>sub_district</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "distribution_center.barangay",
            "description": "<p>barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "distribution_center.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "distribution_center.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "distribution_center.deleted",
            "description": "<p>timestamp of deletion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n    \"distribution_center\": {\n        \"id\": \"9da7a22e-9acf-44fc-8c5f-30107b334993\",\n        \"code\": \"\",\n        \"name\": \"\",\n        \"address\": \"\",\n        \"country\": \"\",\n        \"region\": \"\",\n        \"province\": \"\",\n        \"district\": \"\",\n        \"sub_district\": \"1\",\n        \"barangay\": \"\",\n        \"created\": \"2018-07-11T00:25:17.000Z\",\n        \"updated\": \"2018-07-11T00:52:43.000Z\",\n        \"deleted\": null,\n        \"hub_id\": \"8cf19a0b-c6fd-45f7-8859-678535befc60\"\n    },\n    \"message\": \"update distribution_center: 9da7a22e-9acf-44fc-8c5f-30107b334993\",\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/DistributionCenterController.js",
    "groupTitle": "Distribution_Center"
  },
  {
    "type": "post",
    "url": "/districts",
    "title": "addDistrict",
    "group": "District",
    "name": "addDistrict",
    "parameter": {
      "fields": {
        "System Generated": [
          {
            "group": "System Generated",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of district</p>"
          }
        ],
        "Body Params": [
          {
            "group": "Body Params",
            "type": "Character",
            "optional": false,
            "field": "code",
            "description": "<p>code of district</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of district</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "province_id",
            "description": "<p>province_id of district referenced from province</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the district</p>"
          },
          {
            "group": "Success 200",
            "type": "Character",
            "optional": false,
            "field": "code",
            "description": "<p>code of district</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of district</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "province_id",
            "description": "<p>province_id of district referenced from province</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the district is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the district is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the district is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Message",
            "description": "<p>Successfully created new district</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n{\n    \"message\": \"Successfully created new district\",\n    \"district\": {\n    \"id\": \"7db0be44-a06f-4e27-a8be-81fa7078075e\",\n    \"created\": {\n        \"val\": \"NOW()\"\n    },\n    \"updated\": null,\n    \"deleted\": null,\n    \"province_id\": \"3390ede7-e509-4f06-97b2-8580c29dfb3c\",\n    \"code\": \"D2\",\n    \"name\": \"District2\"\n    },\n    \"success\" : true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/DistrictController.js",
    "groupTitle": "District"
  },
  {
    "type": "deactivate",
    "url": "/districts/:id/deactivate",
    "title": "deactivateDistrict",
    "group": "District",
    "name": "deactivateDistrict",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the district</p>"
          },
          {
            "group": "Success 200",
            "type": "Character",
            "optional": false,
            "field": "code",
            "description": "<p>code of district</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of district</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "province_id",
            "description": "<p>province_id of district referenced from province</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the district is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the district is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the district is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Message",
            "description": "<p>deactivated district + id</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n{\n    \"districts\": [\n        {\n            \"id\": \"7db0be44-a06f-4e27-a8be-81fa7078075e\",\n            \"code\": \"D2\",\n            \"name\": \"District2\",\n            \"created\": \"2018-07-11T00:58:36.000Z\",\n            \"updated\": null,\n            \"deleted\": \"2018-07-11T01:18:46.000Z\",\n            \"province_id\": \"3390ede7-e509-4f06-97b2-8580c29dfb3c\"\n        }\n    ],\n    \"message\" : deactivated district 7db0be44-a06f-4e27-a8be-81fa7078075e,\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/DistrictController.js",
    "groupTitle": "District"
  },
  {
    "type": "get",
    "url": "/districts",
    "title": "getDistricts",
    "group": "District",
    "name": "getDistricts",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the district</p>"
          },
          {
            "group": "Success 200",
            "type": "Character",
            "optional": false,
            "field": "code",
            "description": "<p>code of district</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of district</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "province_id",
            "description": "<p>province_id of district referenced from province</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the district is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the district is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the district is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n{\n    \"districts\": [\n      {\n           \"id\": \"7db0be44-a06f-4e27-a8be-81fa7078075e\",\n           \"code\": \"D2\",\n           \"name\": \"District2\",\n           \"created\": \"2018-07-11T00:58:36.000Z\",\n           \"updated\": \"2018-07-11T02:03:54.000Z\",\n           \"deleted\": null,\n           \"province_id\": \"3390ede7-e509-4f06-97b2-8580c29dfb3c\",\n           \"province\": {\n               \"id\": \"3390ede7-e509-4f06-97b2-8580c29dfb3c\",\n               \"code\": \"LAG\",\n               \"name\": \"Laguna\",\n               \"region\": {\n                   \"id\": \"84d0f129-a195-486e-8c63-012857af6f1a\",\n                   \"code\": \"CAL\",\n                   \"name\": \"Calabarzon\",\n                   \"country\": {\n                       \"id\": \"79dd673a-3c03-47bc-8957-c47ffcb33ef2\",\n                       \"code\": \"PH\",\n                       \"name\": \"Philippines\"\n                   }\n               }\n           }\n       },\n       {\n           \"id\": \"d9ea75ae-1f3c-48d3-8b18-d2c30c84c38d\",\n           \"code\": \"D3\",\n           \"name\": \"District3\",\n           \"created\": \"2018-07-11T01:02:30.000Z\",\n           \"updated\": \"2018-07-11T02:02:59.000Z\",\n           \"deleted\": \"2018-07-11T01:18:46.000Z\",\n           \"province_id\": \"3390ede7-e509-4f06-97b2-8580c29dfb3c\",\n           \"province\": {\n               \"id\": \"3390ede7-e509-4f06-97b2-8580c29dfb3c\",\n               \"code\": \"LAG\",\n               \"name\": \"Laguna\",\n               \"region\": {\n                   \"id\": \"84d0f129-a195-486e-8c63-012857af6f1a\",\n                   \"code\": \"CAL\",\n                   \"name\": \"CALABARZON\",\n                   \"country\": {\n                       \"id\": \"79dd673a-3c03-47bc-8957-c47ffcb33ef2\",\n                       \"code\": \"PH\",\n                       \"name\": \"Philippines\"\n                   }\n               }\n           }\n       }\n    ],\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/DistrictController.js",
    "groupTitle": "District"
  },
  {
    "type": "getOne",
    "url": "/districts/:id",
    "title": "getOneDistrict",
    "group": "District",
    "name": "getOneDistrict",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the district</p>"
          },
          {
            "group": "Success 200",
            "type": "Character",
            "optional": false,
            "field": "code",
            "description": "<p>code of district</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of district</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "province_id",
            "description": "<p>province_id of district referenced from province</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the district is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the district is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the district is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n{\n    \"district\": \n       {\n           \"id\": \"d9ea75ae-1f3c-48d3-8b18-d2c30c84c38d\",\n           \"code\": \"D3\",\n           \"name\": \"District3\",\n           \"created\": \"2018-07-11T01:02:30.000Z\",\n           \"updated\": \"2018-07-11T02:02:59.000Z\",\n           \"deleted\": \"2018-07-11T01:18:46.000Z\",\n           \"province_id\": \"3390ede7-e509-4f06-97b2-8580c29dfb3c\",\n           \"province\": {\n               \"id\": \"3390ede7-e509-4f06-97b2-8580c29dfb3c\",\n               \"code\": \"LAG\",\n               \"name\": \"Laguna\",\n               \"region\": {\n                   \"id\": \"84d0f129-a195-486e-8c63-012857af6f1a\",\n                   \"code\": \"CAL\",\n                   \"name\": \"Calabarzon\",\n                   \"country\": {\n                       \"id\": \"79dd673a-3c03-47bc-8957-c47ffcb33ef2\",\n                       \"code\": \"PH\",\n                       \"name\": \"Philippines\"\n                   }\n               }\n           }\n       },\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/DistrictController.js",
    "groupTitle": "District"
  },
  {
    "type": "reactivate",
    "url": "/districts/:id/reactivate",
    "title": "reactivateDistrict",
    "group": "District",
    "name": "reactivateDistrict",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the district</p>"
          },
          {
            "group": "Success 200",
            "type": "Character",
            "optional": false,
            "field": "code",
            "description": "<p>code of district</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of district</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "province_id",
            "description": "<p>province_id of district referenced from province</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the district is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the district is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the district is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Message",
            "description": "<p>reactivated district + id</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n{\n    \"districts\": [\n        {\n            \"id\": \"7db0be44-a06f-4e27-a8be-81fa7078075e\",\n            \"code\": \"D2\",\n            \"name\": \"District2\",\n            \"created\": \"2018-07-11T00:58:36.000Z\",\n            \"updated\": null,\n            \"deleted\": null,\n            \"province_id\": \"3390ede7-e509-4f06-97b2-8580c29dfb3c\"\n        }\n    ],\n    \"message\" : reactivated district 7db0be44-a06f-4e27-a8be-81fa7078075e,\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/DistrictController.js",
    "groupTitle": "District"
  },
  {
    "type": "search",
    "url": "/districts/search",
    "title": "searchDistrict",
    "group": "District",
    "name": "searchDistrict",
    "parameter": {
      "fields": {
        "Query Params": [
          {
            "group": "Query Params",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of district</p>"
          },
          {
            "group": "Query Params",
            "type": "Character",
            "optional": false,
            "field": "code",
            "description": "<p>code of district</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of district</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "province_id",
            "description": "<p>province_id of district referenced from province</p>"
          },
          {
            "group": "Query Params",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the district is created</p>"
          },
          {
            "group": "Query Params",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the district is updated</p>"
          },
          {
            "group": "Query Params",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the district is deleted</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the district</p>"
          },
          {
            "group": "Success 200",
            "type": "Character",
            "optional": false,
            "field": "code",
            "description": "<p>code of district</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of district</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "province_id",
            "description": "<p>province_id of district referenced from province</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the district is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the district is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the district is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n{\n     \"district\": [ \n        {\n            \"id\": \"d9ea75ae-1f3c-48d3-8b18-d2c30c84c38d\",\n            \"code\": \"D3\",\n            \"name\": \"District3\",\n            \"created\": \"2018-07-11T01:02:30.000Z\",\n            \"updated\": \"2018-07-11T01:09:50.000Z\",\n            \"deleted\": null,\n            \"province_id\": \"3390ede7-e509-4f06-97b2-8580c29dfb3c\"\n         }\n       ],\n       \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/DistrictController.js",
    "groupTitle": "District"
  },
  {
    "type": "put",
    "url": "/districts/:id",
    "title": "updateDistrict",
    "group": "District",
    "name": "updateDistrict",
    "parameter": {
      "fields": {
        "Body Params": [
          {
            "group": "Body Params",
            "type": "Character",
            "optional": false,
            "field": "code",
            "description": "<p>code of district</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of district</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "province_id",
            "description": "<p>province_id of district referenced from province</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the district</p>"
          },
          {
            "group": "Success 200",
            "type": "Character",
            "optional": false,
            "field": "code",
            "description": "<p>code of district</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of district</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "province_id",
            "description": "<p>province_id of district referenced from province</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the district is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the district is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the district is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Message",
            "description": "<p>update district + id</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n{\n     \"district\": \n        {\n           \"id\": \"d9ea75ae-1f3c-48d3-8b18-d2c30c84c38d\",\n           \"code\": \"D3\",\n           \"name\": \"District3\",\n           \"created\": \"2018-07-11T01:02:30.000Z\",\n           \"updated\": \"2018-07-11T01:09:50.000Z\",\n           \"deleted\": null,\n           \"province_id\": \"3390ede7-e509-4f06-97b2-8580c29dfb3c\"\n       },\n       \"message\": \"update district: d9ea75ae-1f3c-48d3-8b18-d2c30c84c38d\",\n       \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/DistrictController.js",
    "groupTitle": "District"
  },
  {
    "type": "post",
    "url": "/v1/hubs",
    "title": "Add Hub",
    "group": "Hub",
    "name": "Add_Hub",
    "parameter": {
      "fields": {
        "System Generated": [
          {
            "group": "System Generated",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>unique ID</p>"
          }
        ],
        "Body Params": [
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>unique code for each hub</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of hub</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "address",
            "description": "<p>address of the hub</p>"
          },
          {
            "group": "Body Params",
            "type": "char",
            "optional": false,
            "field": "country",
            "description": "<p>country</p>"
          },
          {
            "group": "Body Params",
            "type": "char",
            "optional": false,
            "field": "region",
            "description": "<p>region</p>"
          },
          {
            "group": "Body Params",
            "type": "char",
            "optional": false,
            "field": "province",
            "description": "<p>province</p>"
          },
          {
            "group": "Body Params",
            "type": "char",
            "optional": false,
            "field": "district",
            "description": "<p>district</p>"
          },
          {
            "group": "Body Params",
            "type": "char",
            "optional": false,
            "field": "sub_district",
            "description": "<p>sub_district</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "hub",
            "description": "<p>new Hub</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "hub.id",
            "description": "<p>ID of Hub</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hub.code",
            "description": "<p>code of Hub</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hub.name",
            "description": "<p>name of Hub</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hub.address",
            "description": "<p>address of Hub</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "hub.country",
            "description": "<p>country</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "hub.region",
            "description": "<p>region</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "hub.province",
            "description": "<p>province</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "hub.district",
            "description": "<p>district</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "hub.sub_district",
            "description": "<p>sub_district</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "hub.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "hub.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "hub.deleted",
            "description": "<p>timestamp of deletion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " {\n \"message\": \"successfully created new hub\",\n \"hub\": {\n     \"id\": \"8cf19a0b-c6fd-45f7-8859-678535befc60\",\n     \"created\": {\n         \"val\": \"NOW()\"\n     },\n     \"updated\": null,\n     \"deleted\": null,\n     \"code\": \"code\",\n     \"name\": \"Laguna Hub\",\n     \"address\": \"Cabuyao\",\n     \"country\": \"PHL\",\n     \"region\": \"4A\",\n     \"province\": \"LGN\",\n     \"district\": \"4\",\n    \"sub_district\": null\n },\n \n \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/HubController.js",
    "groupTitle": "Hub"
  },
  {
    "type": "post",
    "url": "/v1/hubs/:id/deactivate",
    "title": "Deactivate Hub by ID",
    "name": "Deactivate_Hub_by_ID",
    "group": "Hub",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>Hub's unique ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "hub",
            "description": "<p>new Hub</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "hub.id",
            "description": "<p>ID of Hub</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hub.code",
            "description": "<p>code of Hub</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hub.name",
            "description": "<p>name of Hub</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hub.address",
            "description": "<p>address of Hub</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "hub.country",
            "description": "<p>country</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "hub.region",
            "description": "<p>region</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "hub.province",
            "description": "<p>province</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "hub.district",
            "description": "<p>district</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "hub.sub_district",
            "description": "<p>sub_district</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "hub.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "hub.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "hub.deleted",
            "description": "<p>timestamp of deletion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n    \"message\": \"deactivated hub\",\n    \"hub\": {\n        \"id\": \"8cf19a0b-c6fd-45f7-8859-678535befc60\",\n        \"code\": \"QWK1\",\n        \"name\": \"Cabuyao Hub\",\n        \"address\": \"Cabuyao\",\n        \"country\": \"PHL\",\n        \"region\": \"4A\",\n        \"province\": \"LGN\",\n        \"district\": \"2\",\n        \"sub_district\": \"1\",\n        \"created\": \"2018-07-10T06:17:12.000Z\",\n        \"updated\": \"2018-07-10T07:49:58.000Z\",\n        \"deleted\": \"2018-07-10T08:04:16.000Z\"\n    },\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/HubController.js",
    "groupTitle": "Hub"
  },
  {
    "type": "get",
    "url": "/v1/hubs/:id",
    "title": "Get Hub by ID",
    "group": "Hub",
    "name": "Get_Hub_by_ID",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>Hub's unique ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "hub",
            "description": "<p>new Hub</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "hub.id",
            "description": "<p>ID of Hub</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hub.code",
            "description": "<p>code of Hub</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hub.name",
            "description": "<p>name of Hub</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hub.address",
            "description": "<p>address of Hub</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "hub.country",
            "description": "<p>country</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "hub.region",
            "description": "<p>region</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "hub.province",
            "description": "<p>province</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "hub.district",
            "description": "<p>district</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "hub.sub_district",
            "description": "<p>sub_district</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "hub.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "hub.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "hub.deleted",
            "description": "<p>timestamp of deletion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " {\n \"hub\": {\n      \"id\": \"8cf19a0b-c6fd-45f7-8859-678535befc60\",\n      \"code\": \"QWK2\",\n      \"name\": \"Cabuyao Hub\",\n      \"address\": \"Cabuyao\",\n      \"country\": \"PHL\",\n      \"region\": \"4A\",\n      \"province\": \"LGN\",\n      \"district\": \"4A\",\n      \"sub_district\": \"1\",\n      \"created\": \"2018-07-10T06:17:12.000Z\",\n      \"updated\": null,\n      \"deleted\": null\n },\n \n \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/HubController.js",
    "groupTitle": "Hub"
  },
  {
    "type": "get",
    "url": "/v1/hubs",
    "title": "Get Hubs",
    "group": "Hub",
    "name": "Get_Hubs",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object[]",
            "optional": false,
            "field": "hubs",
            "description": "<p>array of hubs</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "hubs.id",
            "description": "<p>ID of Hub</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hubs.code",
            "description": "<p>code of Hub</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hubs.name",
            "description": "<p>name of Hub</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hubs.address",
            "description": "<p>address of Hub</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "hubs.country",
            "description": "<p>country</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "hubs.region",
            "description": "<p>region</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "hubs.province",
            "description": "<p>province</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "hubs.district",
            "description": "<p>district</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "hubs.sub_district",
            "description": "<p>sub_district</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "hubs.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "hubs.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "hubs.deleted",
            "description": "<p>timestamp of deletion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n    \"hubs\": [\n        {\n            \"id\": \"8cf19a0b-c6fd-45f7-8859-678535befc60\",\n            \"code\": \"QWK2\",\n            \"name\": \"Cabuyao Hub\",\n            \"address\": \"Cabuyao\",\n            \"country\": \"PHL\",\n            \"region\": \"4A\",\n            \"province\": \"LGN\",\n            \"district\": \"4A\",\n            \"sub_district\": \"1\",\n            \"created\": \"2018-07-10T06:17:12.000Z\",\n            \"updated\": null,\n            \"deleted\": null\n        },\n        {\n            \"id\": \"d3d16b9f-e0ea-46e7-9a15-d2cdcfdd484e\",\n            \"code\": \"QAXS1\",\n            \"name\": \"Calamba Hub\",\n            \"address\": \"Calamba\",\n            \"country\": \"PHL\",\n            \"region\": \"4A\",\n            \"province\": \"LGN\",\n            \"district\": \"4\",\n            \"sub_district\": \"1\",\n            \"created\": \"2018-07-10T07:27:00.000Z\",\n            \"updated\": null,\n            \"deleted\": null\n        }\n    ],\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/HubController.js",
    "groupTitle": "Hub"
  },
  {
    "type": "post",
    "url": "/v1/hubs/:id/reactivate",
    "title": "Reactivate Hub by ID",
    "name": "Reactivate_Hub_by_ID",
    "group": "Hub",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>Hub's unique ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "hub",
            "description": "<p>new Hub</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "hub.id",
            "description": "<p>ID of Hub</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hub.code",
            "description": "<p>code of Hub</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hub.name",
            "description": "<p>name of Hub</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hub.address",
            "description": "<p>address of Hub</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "hub.country",
            "description": "<p>country</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "hub.region",
            "description": "<p>region</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "hub.province",
            "description": "<p>province</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "hub.district",
            "description": "<p>district</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "hub.sub_district",
            "description": "<p>sub_district</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "hub.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "hub.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "hub.deleted",
            "description": "<p>timestamp of deletion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n    \"message\": \"reactivated hub\",\n    \"hub\": {\n        \"id\": \"8cf19a0b-c6fd-45f7-8859-678535befc60\",\n        \"code\": \"QWK1\",\n        \"name\": \"Cabuyao Hub\",\n        \"address\": \"Cabuyao\",\n        \"country\": \"PHL\",\n        \"region\": \"4A\",\n        \"province\": \"LGN\",\n        \"district\": \"2\",\n        \"sub_district\": \"1\",\n        \"created\": \"2018-07-10T06:17:12.000Z\",\n        \"updated\": \"2018-07-10T07:49:58.000Z\",\n        \"deleted\": null\n    },\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/HubController.js",
    "groupTitle": "Hub"
  },
  {
    "type": "get",
    "url": "/v1/hubs/search",
    "title": "Search Hub",
    "name": "Search_Hub",
    "group": "Hub",
    "parameter": {
      "fields": {
        "Paramater": [
          {
            "group": "Paramater",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>Hub's unique ID</p>"
          },
          {
            "group": "Paramater",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>unique code for each hub</p>"
          },
          {
            "group": "Paramater",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of hub</p>"
          },
          {
            "group": "Paramater",
            "type": "String",
            "optional": false,
            "field": "address",
            "description": "<p>address of the hub</p>"
          },
          {
            "group": "Paramater",
            "type": "char",
            "optional": false,
            "field": "country",
            "description": "<p>country</p>"
          },
          {
            "group": "Paramater",
            "type": "char",
            "optional": false,
            "field": "region",
            "description": "<p>region</p>"
          },
          {
            "group": "Paramater",
            "type": "char",
            "optional": false,
            "field": "province",
            "description": "<p>province</p>"
          },
          {
            "group": "Paramater",
            "type": "char",
            "optional": false,
            "field": "district",
            "description": "<p>district</p>"
          },
          {
            "group": "Paramater",
            "type": "char",
            "optional": false,
            "field": "sub_district",
            "description": "<p>sub_district</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object[]",
            "optional": false,
            "field": "hubs",
            "description": "<p>array of hubs</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "hubs.id",
            "description": "<p>ID of Hub</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hubs.code",
            "description": "<p>code of Hub</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hubs.name",
            "description": "<p>name of Hub</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hubs.address",
            "description": "<p>address of Hub</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "hubs.country",
            "description": "<p>country</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "hubs.region",
            "description": "<p>region</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "hubs.province",
            "description": "<p>province</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "hubs.district",
            "description": "<p>district</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "hubs.sub_district",
            "description": "<p>sub_district</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "hubs.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "hubs.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "hubs.deleted",
            "description": "<p>timestamp of deletion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n    \"hubs\": [\n        {\n            \"id\": \"8cf19a0b-c6fd-45f7-8859-678535befc60\",\n            \"code\": \"QWK1\",\n            \"name\": \"Cabuyao Hub\",\n            \"address\": \"Cabuyao\",\n            \"country\": \"PHL\",\n            \"region\": \"4A\",\n            \"province\": \"LGN\",\n            \"district\": \"2\",\n            \"sub_district\": \"1\",\n            \"created\": \"2018-07-10T06:17:12.000Z\",\n            \"updated\": \"2018-07-10T07:49:58.000Z\",\n            \"deleted\": null\n        }\n    ],\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/HubController.js",
    "groupTitle": "Hub"
  },
  {
    "type": "put",
    "url": "/v1/hubs/:id",
    "title": "Update Hub by ID",
    "name": "Update_Hub_by_ID",
    "group": "Hub",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>Hub's unique ID.</p>"
          }
        ],
        "Body Params": [
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>unique code for each hub</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of hub</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "address",
            "description": "<p>address of the hub</p>"
          },
          {
            "group": "Body Params",
            "type": "char",
            "optional": false,
            "field": "country",
            "description": "<p>country</p>"
          },
          {
            "group": "Body Params",
            "type": "char",
            "optional": false,
            "field": "region",
            "description": "<p>region</p>"
          },
          {
            "group": "Body Params",
            "type": "char",
            "optional": false,
            "field": "province",
            "description": "<p>province</p>"
          },
          {
            "group": "Body Params",
            "type": "char",
            "optional": false,
            "field": "district",
            "description": "<p>district</p>"
          },
          {
            "group": "Body Params",
            "type": "char",
            "optional": false,
            "field": "sub_district",
            "description": "<p>sub_district</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "hub",
            "description": "<p>new Hub</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "hub.id",
            "description": "<p>ID of Hub</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hub.code",
            "description": "<p>code of Hub</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hub.name",
            "description": "<p>name of Hub</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hub.address",
            "description": "<p>address of Hub</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "hub.country",
            "description": "<p>country</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "hub.region",
            "description": "<p>region</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "hub.province",
            "description": "<p>province</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "hub.district",
            "description": "<p>district</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "hub.sub_district",
            "description": "<p>sub_district</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "hub.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "hub.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "hub.deleted",
            "description": "<p>timestamp of deletion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n    \"hub\": {\n        \"id\": \"8cf19a0b-c6fd-45f7-8859-678535befc60\",\n        \"code\": \"QWK1\",\n        \"name\": \"Cabuyao Hub\",\n        \"address\": \"Cabuyao\",\n        \"country\": \"PHL\",\n        \"region\": \"4A\",\n        \"province\": \"LGN\",\n        \"district\": \"2\",\n        \"sub_district\": \"1\",\n        \"created\": \"2018-07-10T06:17:12.000Z\",\n        \"updated\": \"2018-07-10T07:49:58.000Z\",\n        \"deleted\": null\n    },\n    \"message\": \"update hub: 8cf19a0b-c6fd-45f7-8859-678535befc60\",\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/HubController.js",
    "groupTitle": "Hub"
  },
  {
    "type": "post",
    "url": "/inbound-officers",
    "title": "addInboundOfficer",
    "group": "InboundOfficer",
    "name": "addInboundOfficer",
    "parameter": {
      "fields": {
        "System Generated": [
          {
            "group": "System Generated",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of inbound officer</p>"
          }
        ],
        "Body Params": [
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "hub_id",
            "description": "<p>hub_id of inbound officer referenced from hub</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>distribution_center_id of inbound officer referenced from distribution_center</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the inbound officer</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hub_id",
            "description": "<p>hub_id of inbound officer referenced from hub</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>distribution_center_id of inbound officer referenced from hub</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the inbound officer is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the inbound officer is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the inbound officer is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Message",
            "description": "<p>Successfully created new inbound officer.</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n{\n    \"message\": \"Successfully created new inbound officer\",\n    \"inbound_officer\": {\n        \"id\": \"0ca114d4-ad64-4b76-977e-97bcf58e6d4d\",\n        \"created\": {\n            \"val\": \"NOW()\"\n        },\n        \"user_id\": \"1\",\n        \"hub_id\": \"12b356bd-0877-4b82-9c2a-fc5d26489bd4\",\n        \"distribution_center_id\": \"da6d1764-a3c7-4e58-946a-7ab0fb4bf75c\"\n    },\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/InboundOfficerController.js",
    "groupTitle": "InboundOfficer"
  },
  {
    "type": "deactivate",
    "url": "/inbound-officers/:id/deactivate",
    "title": "deactivateInboundOfficer",
    "group": "InboundOfficer",
    "name": "deactivateInboundOfficer",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the inbound officer.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hub_id",
            "description": "<p>hub_id of inbound officer referenced from hub</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>distribution_center_id of inbound officer referenced from distribution_center</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the inbound officer is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the inbound officer is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the inbound officer is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "Message",
            "optional": false,
            "field": "Deactivated",
            "description": "<p>Inbound Officer</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n   \"inbound officer\": {\n       \"id\": \"7c484cbd-3ffe-4d77-8b0a-958da424d4ea\",\n       \"hub_id\": \"12b356bd-0877-4b82-9c2a-fc5d26489bd4\",\n       \"distribution_center_id\": \"da6d1764-a3c7-4e58-946a-7ab0fb4bf75c\",\n       \"created\": \"2018-07-04T07:15:23.000Z\",\n       \"updated\": null,\n       \"deleted\": \"2018-07-10T08:25:35.000Z\",\n       \"user_id\": 1\n   },\n   \"message\": \"deactivated inbound officer\",\n   \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/InboundOfficerController.js",
    "groupTitle": "InboundOfficer"
  },
  {
    "type": "getOne",
    "url": "/inbound-officers/:id",
    "title": "getOneInboundOfficer",
    "group": "InboundOfficer",
    "name": "getInboundOfficer",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the inbound officer.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hub_id",
            "description": "<p>hub_id of inbound officer referenced from hub</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>distribution_center_id of inbound officer referenced from distribution_center</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the inbound officer is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the inbound officer is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the inbound officer is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "email",
            "description": "<p>Email of inbound officer.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "first_name",
            "description": "<p>First Name of inbound officer.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "last_name",
            "description": "<p>Last Name of inbound officer.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "middle_name",
            "description": "<p>Middle Name of inbound officer.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "contact_number",
            "description": "<p>Contact Number of inbound officer.</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n   {\n       \"inbound_officer\": {\n           \"id\": \"cab79e6e-e364-4c95-bd44-faefeee9ce41\",\n           \"hub_id\": \"797439a8-d074-46a3-bfb8-50e6af677857\",\n           \"distribution_center_id\": \"e6cb457e-653a-44e6-87d9-7eeab7c8448c\",\n           \"created\": \"2018-07-12T01:22:47.000Z\",\n           \"updated\": null,\n           \"deleted\": null,\n           \"user_id\": 1,\n           \"User\": {\n               \"id\": 1,\n               \"email\": \"ahabulan@gmail.com\",\n               \"first_name\": \"Aljay\",\n               \"last_name\": \"Habulan\",\n               \"middle_name\": \"Ranchez\",\n               \"contact_number\": \"09271238752\"\n           }\n       },\n       \"success\": true\n   }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/InboundOfficerController.js",
    "groupTitle": "InboundOfficer"
  },
  {
    "type": "get",
    "url": "/inbound-officers",
    "title": "getInboundOfficers",
    "group": "InboundOfficer",
    "name": "getInboundOfficers",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the inbound officer.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hub_id",
            "description": "<p>hub_id of inbound officer referenced from hub</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>distribution_center_id of inbound officer referenced from distribution_center</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the inbound officer is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the inbound officer is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the inbound officer is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "email",
            "description": "<p>Email of inbound officer.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "first_name",
            "description": "<p>First Name of inbound officer.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "last_name",
            "description": "<p>Last Name of inbound officer.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "middle_name",
            "description": "<p>Middle Name of inbound officer.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "contact_number",
            "description": "<p>Contact Number of inbound officer.</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n   {\n      \"inbound_officers\": [\n          {\n              \"id\": \"cab79e6e-e364-4c95-bd44-faefeee9ce41\",\n              \"hub_id\": \"797439a8-d074-46a3-bfb8-50e6af677857\",\n              \"distribution_center_id\": \"e6cb457e-653a-44e6-87d9-7eeab7c8448c\",\n              \"created\": \"2018-07-12T01:22:47.000Z\",\n              \"updated\": null,\n              \"deleted\": null,\n              \"user_id\": 1,\n              \"User\": {\n                  \"id\": 1,\n                  \"email\": \"ahabulan@gmail.com\",\n                  \"first_name\": \"Aljay\",\n                  \"last_name\": \"Habulan\",\n                  \"middle_name\": \"Ranchez\",\n                  \"contact_number\": \"09271238752\"\n              }\n          },\n          {\n               \"id\": \"cdbb4dc8-6dfe-482d-a00b-15ac3192397a\",\n               \"hub_id\": \"797439a8-d074-46a3-bfb8-50e6af677857\",\n               \"distribution_center_id\": \"e6cb457e-653a-44e6-87d9-7eeab7c8448c\",\n               \"created\": \"2018-07-12T01:31:57.000Z\",\n               \"updated\": null,\n               \"deleted\": null,\n               \"user_id\": 2,\n               \"User\": {\n                   \"id\": 2,\n                   \"email\": \"asdfghjkl111@gmail.com\",\n                   \"first_name\": \"A\",\n                   \"last_name\": \"B\",\n                   \"middle_name\": \"C\",\n                   \"contact_number\": \"091111111\"\n               }\n           }\n      ],\n      \"success\": true\n   }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/InboundOfficerController.js",
    "groupTitle": "InboundOfficer"
  },
  {
    "type": "reactivate",
    "url": "/inbound-officers/:id/reactivate",
    "title": "reactivateInboundOfficer",
    "group": "InboundOfficer",
    "name": "reactivateInboundOfficer",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the inbound officer.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hub_id",
            "description": "<p>hub_id of inbound officer referenced from hub</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>distribution_center_id of inbound officer referenced from distribution_center</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the inbound officer is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the inbound officer is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the inbound officer is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "Message",
            "optional": false,
            "field": "Reactivated",
            "description": "<p>Inbound Officer</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n   \"inbound officer\": {\n       \"id\": \"7c484cbd-3ffe-4d77-8b0a-958da424d4ea\",\n       \"hub_id\": \"12b356bd-0877-4b82-9c2a-fc5d26489bd4\",\n       \"distribution_center_id\": \"da6d1764-a3c7-4e58-946a-7ab0fb4bf75c\",\n       \"created\": \"2018-07-04T07:15:23.000Z\",\n       \"updated\": null,\n       \"deleted\": null,\n       \"user_id\": 1\n   },\n   \"message\": \"reactivated inbound officer\",\n   \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/InboundOfficerController.js",
    "groupTitle": "InboundOfficer"
  },
  {
    "type": "search",
    "url": "/inbound-officers/search",
    "title": "searchInboundOfficer",
    "group": "InboundOfficer",
    "name": "searchInboundOfficer",
    "parameter": {
      "fields": {
        "Query Params": [
          {
            "group": "Query Params",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of inbound officer</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "hub_id",
            "description": "<p>hub_id of inbound officer referenced from hub</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>distribution_center_id of inbound officer referenced from distribution_center</p>"
          },
          {
            "group": "Query Params",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the inbound officer is created</p>"
          },
          {
            "group": "Query Params",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the inbound officer is updated</p>"
          },
          {
            "group": "Query Params",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the inbound officer is deleted</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the inbound officer</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hub_id",
            "description": "<p>hub_id of inbound officer referenced from hub</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>distribution_center_id of inbound officer referenced from hub</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the inbound officer is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the inbound officer is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the inbound officer is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n{\n    \"inbound_officer\": [\n        {\n            \"id\": \"7c484cbd-3ffe-4d77-8b0a-958da424d4ea\",\n            \"hub_id\": \"12b356bd-0877-4b82-9c2a-fc5d26489bd4\",\n            \"distribution_center_id\": \"da6d1764-a3c7-4e58-946a-7ab0fb4bf75c\",\n            \"created\": \"2018-07-04T07:15:23.000Z\",\n            \"updated\": null,\n            \"deleted\": \"2018-07-10T08:25:35.000Z\",\n            \"user_id\": 1\n        }\n    ],\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/InboundOfficerController.js",
    "groupTitle": "InboundOfficer"
  },
  {
    "type": "put",
    "url": "/inbound-officers/:id",
    "title": "updateInboundOfficer",
    "group": "InboundOfficer",
    "name": "updateInboundOfficer",
    "parameter": {
      "fields": {
        "Body Params": [
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "hub_id",
            "description": "<p>hub_id of inbound officer referenced from hub</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>distribution_center_id of inbound officer referenced from distribution_center</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the inbound officer.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "hub_id",
            "description": "<p>hub_id of inbound officer referenced from hub</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>distribution_center_id of inbound officer referenced from distribution_center</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the inbound officer is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the inbound officer is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the inbound officer is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Message",
            "description": "<p>Update inbound officer</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n{\n    \"message\": \"Update inbound officer 7c484cbd-3ffe-4d77-8b0a-958da424d4ea\",\n    \"inbound_officer\": {\n        \"id\": \"7c484cbd-3ffe-4d77-8b0a-958da424d4ea\",\n        \"created\": {\n            \"val\": \"NOW()\"\n        },\n        \"user_id\": \"2\",\n        \"hub_id\": \"12b356bd-0877-4b82-9c2a-fc5d26489bd4\",\n        \"distribution_center_id\": \"da6d1764-a3c7-4e58-946a-7ab0fb4bf75c\"\n    },\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/InboundOfficerController.js",
    "groupTitle": "InboundOfficer"
  },
  {
    "type": "post",
    "url": "/items",
    "title": "Add Item",
    "name": "AddItem",
    "group": "Item",
    "parameter": {
      "fields": {
        "System Generated": [
          {
            "group": "System Generated",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Item unique ID.</p>"
          }
        ],
        "Body Params": [
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Item ID.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "consignee_address",
            "description": "<p>Address of the Consignee.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "consignee_country",
            "description": "<p>Country of the Consignee.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "consignee_region",
            "description": "<p>Region of the Consignee.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "consignee_province",
            "description": "<p>Province of the Consignee.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "consignee_district",
            "description": "<p>District of the Consignee.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "consignee_sub_district",
            "description": "<p>Subdistrict of the Consignee.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "consignee_barangay",
            "description": "<p>Barangay of the Consignee.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "consignee_first_name",
            "description": "<p>First name of the Consignee.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "consignee_last_name",
            "description": "<p>Last name the Consignee.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "consignee_contact_number",
            "description": "<p>Contact number of the Consignee.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "consignee_email",
            "description": "<p>email of the Consignee.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "weight",
            "description": "<p>Weight of the Item.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "height",
            "description": "<p>Height of the Item.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "length",
            "description": "<p>Length the Item.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "width",
            "description": "<p>Width of the Item.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "package_type",
            "description": "<p>Package Type of the Item.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "tracking_number",
            "description": "<p>Tracking Number of the Item.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "airway_bill",
            "description": "<p>Airway Bill of the Item.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "courier_id",
            "description": "<p>Courier ID referenced to Courier.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "inbound_officer_id",
            "description": "<p>Inbound Officer ID referenced to Inbound Officer.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Item ID.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_address",
            "description": "<p>Address of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_country",
            "description": "<p>Country of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_region",
            "description": "<p>Region of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_province",
            "description": "<p>Province of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_district",
            "description": "<p>District of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_sub_district",
            "description": "<p>Subdistrict of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_barangay",
            "description": "<p>Barangay of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_first_name",
            "description": "<p>First name of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_last_name",
            "description": "<p>Last name the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_contact_number",
            "description": "<p>Contact number of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_email",
            "description": "<p>email of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "weight",
            "description": "<p>Weight of the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "height",
            "description": "<p>Height of the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "length",
            "description": "<p>Length the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "width",
            "description": "<p>Width of the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "package_type",
            "description": "<p>Package Type of the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "tracking_number",
            "description": "<p>Tracking Number of the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "airway_bill",
            "description": "<p>Airway Bill of the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "timestamp_of_receiving",
            "description": "<p>Date and Time the Item is received by the Inbound Officer.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and time the Item is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "courier_id",
            "description": "<p>Courier ID referenced to Courier.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "inbound_officer_id",
            "description": "<p>Inbound Officer ID referenced to Inbound Officer.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n      \"message\": \"successfully created new item\",\n      \"item\": {\n          \"id\": \"17f6b912-e99a-49be-9a5d-bd7da5c5c552\",\n          \"timestamp_of_receiving\": {\n              \"val\": \"NOW()\"\n          },\n          \"updated\": null,\n          \"courier_id\": null,\n          \"consignee_address\": \"51 Kanlaon St. Palar Village Brgy. Southside Makati City\",\n          \"consignee_country\": \"Philippines\",\n          \"consignee_region\": \"National Capital Region\",\n          \"consignee_province\": \"\",\n          \"consignee_district\": \"\",\n          \"consignee_sub_district\": \"\",\n          \"consignee_barangay\": \"Southside\",\n          \"consignee_first_name\": \"Juan\",\n          \"consignee_last_name\": \"Dela Cruz\",\n          \"consignee_contact_number\": \"Dela Cruz\",\n          \"consignee_email\": \"jdelacruz@gmail.com\",\n          \"weight\": \"30.5\",\n          \"height\": \"0.5\",\n          \"length\": \"1.5\",\n          \"width\": \"2\",\n          \"package_type\": \"Medium Box\",\n          \"tracking_number\": \"swsde35-posnwh\",\n          \"airway_bill\": \"ddcr45-plkm87u\",\n          \"status\": \"Pending\",\n          \"value\": \"800.00\",\n          \"inbound_officer_id\": \"67956a52-c9d5-495a-8cca-2a5d00e19b6c\"\n      },\n      \"success\": true\n  }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Internal Server Error\n{\n  \"status\": 500,\n  \"message\": \"Internal server error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ItemController.js",
    "groupTitle": "Item"
  },
  {
    "type": "delete",
    "url": "/items/:id",
    "title": "Delete Item By ID",
    "name": "DeleteItemByID",
    "group": "Item",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Item unique ID.</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n       \"message\": \"deleted item\",\n       \"success\": true\n  }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Internal Server Error\n{\n  \"status\": 500,\n  \"message\": \"Internal server error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ItemController.js",
    "groupTitle": "Item"
  },
  {
    "type": "get",
    "url": "/items/:id",
    "title": "Retrieve Item By ID",
    "name": "GetItemByID",
    "group": "Item",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Item unique ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Item ID.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_address",
            "description": "<p>Address of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_country",
            "description": "<p>Country of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_region",
            "description": "<p>Region of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_province",
            "description": "<p>Province of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_district",
            "description": "<p>District of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_sub_district",
            "description": "<p>Subdistrict of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_barangay",
            "description": "<p>Barangay of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_first_name",
            "description": "<p>First name of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_last_name",
            "description": "<p>Last name the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_contact_number",
            "description": "<p>Contact number of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_email",
            "description": "<p>email of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "weight",
            "description": "<p>Weight of the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "height",
            "description": "<p>Height of the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "length",
            "description": "<p>Length the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "width",
            "description": "<p>Width of the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "package_type",
            "description": "<p>Package Type of the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "tracking_number",
            "description": "<p>Tracking Number of the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "airway_bill",
            "description": "<p>Airway Bill of the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "timestamp_of_receiving",
            "description": "<p>Date and Time the Item is received by the Inbound Officer.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and time the Item is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "courier_id",
            "description": "<p>Courier ID referenced to Courier.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "inbound_officer_id",
            "description": "<p>Inbound Officer ID referenced to Inbound Officer.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n       \"items\": [\n          {\n              \"id\": \"5e1fafc0-ed0f-4446-a4df-0e09f2d2466c\",\n              \"consignee_address\": \"51 Kanlaon St. Palar Village Brgy. Southside Makati City\",\n              \"consignee_country\": \"Philippines\",\n              \"consignee_region\": \"National Capital Region\",\n              \"consignee_province\": \"\",\n              \"consignee_district\": \"\",\n              \"consignee_sub_district\": \"\",\n              \"consignee_barangay\": \"Southside\",\n              \"consignee_first_name\": \"Juan\",\n              \"consignee_last_name\": \"Dela Cruz\",\n              \"consignee_contact_number\": \"Dela Cruz\",\n              \"consignee_email\": \"jdelacruz@gmail.com\",\n              \"weight\": 30.5,\n              \"height\": 0.5,\n              \"length\": 1.5,\n              \"width\": 2,\n              \"package_type\": \"Medium Box\",\n              \"tracking_number\": \"swsde35-posnwh\",\n              \"airway_bill\": \"ddcr45-plkm87u\",\n              \"status\": \"Pending\",\n              \"value\": 900,\n              \"timestamp_of_receiving\": \"2018-07-11T01:46:28.000Z\",\n              \"updated\": null,\n              \"courier_id\": null,\n              \"inbound_officer_id\": \"67956a52-c9d5-495a-8cca-2a5d00e19b6c\"\n          }\n      ],\n      \"success\": true\n  }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Internal Server Error\n{\n  \"status\": 500,\n  \"message\": \"Internal server error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ItemController.js",
    "groupTitle": "Item"
  },
  {
    "type": "get",
    "url": "/items",
    "title": "Retrieve Items",
    "name": "GetItems",
    "group": "Item",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Item ID.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_address",
            "description": "<p>Address of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_country",
            "description": "<p>Country of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_region",
            "description": "<p>Region of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_province",
            "description": "<p>Province of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_district",
            "description": "<p>District of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_sub_district",
            "description": "<p>Subdistrict of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_barangay",
            "description": "<p>Barangay of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_first_name",
            "description": "<p>First name of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_last_name",
            "description": "<p>Last name the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_contact_number",
            "description": "<p>Contact number of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_email",
            "description": "<p>email of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "weight",
            "description": "<p>Weight of the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "height",
            "description": "<p>Height of the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "length",
            "description": "<p>Length the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "width",
            "description": "<p>Width of the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "package_type",
            "description": "<p>Package Type of the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "tracking_number",
            "description": "<p>Tracking Number of the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "airway_bill",
            "description": "<p>Airway Bill of the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "timestamp_of_receiving",
            "description": "<p>Date and Time the Item is received by the Inbound Officer.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and time the Item is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "courier_id",
            "description": "<p>Courier ID referenced to Courier.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "inbound_officer_id",
            "description": "<p>Inbound Officer ID referenced to Inbound Officer.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n       \"items\": [\n          {\n              \"id\": \"5e1fafc0-ed0f-4446-a4df-0e09f2d2466c\",\n              \"consignee_address\": \"51 Kanlaon St. Palar Village Brgy. Southside Makati City\",\n              \"consignee_country\": \"Philippines\",\n              \"consignee_region\": \"National Capital Region\",\n              \"consignee_province\": \"\",\n              \"consignee_district\": \"\",\n              \"consignee_sub_district\": \"\",\n              \"consignee_barangay\": \"Southside\",\n              \"consignee_first_name\": \"Juan\",\n              \"consignee_last_name\": \"Dela Cruz\",\n              \"consignee_contact_number\": \"Dela Cruz\",\n              \"consignee_email\": \"jdelacruz@gmail.com\",\n              \"weight\": 30.5,\n              \"height\": 0.5,\n              \"length\": 1.5,\n              \"width\": 2,\n              \"package_type\": \"Medium Box\",\n              \"tracking_number\": \"swsde35-posnwh\",\n              \"airway_bill\": \"ddcr45-plkm87u\",\n              \"status\": \"Pending\",\n              \"value\": 900,\n              \"timestamp_of_receiving\": \"2018-07-11T01:46:28.000Z\",\n              \"updated\": null,\n              \"courier_id\": null,\n              \"inbound_officer_id\": \"67956a52-c9d5-495a-8cca-2a5d00e19b6c\"\n          }\n      ],\n      \"success\": true\n  }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Internal Server Error\n{\n  \"status\": 500,\n  \"message\": \"Internal server error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ItemController.js",
    "groupTitle": "Item"
  },
  {
    "type": "get",
    "url": "/items/search",
    "title": "Search Item",
    "name": "SearchItem",
    "group": "Item",
    "parameter": {
      "fields": {
        "Query Params": [
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "consignee_address",
            "description": "<p>Address of the Consignee.</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "consignee_country",
            "description": "<p>Country of the Consignee.</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "consignee_region",
            "description": "<p>Region of the Consignee.</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "consignee_province",
            "description": "<p>Province of the Consignee.</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "consignee_district",
            "description": "<p>District of the Consignee.</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "consignee_sub_district",
            "description": "<p>Subdistrict of the Consignee.</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "consignee_barangay",
            "description": "<p>Barangay of the Consignee.</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "consignee_first_name",
            "description": "<p>First name of the Consignee.</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "consignee_last_name",
            "description": "<p>Last name the Consignee.</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "consignee_contact_number",
            "description": "<p>Contact number of the Consignee.</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "consignee_email",
            "description": "<p>email of the Consignee.</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "weight",
            "description": "<p>Weight of the Item.</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "height",
            "description": "<p>Height of the Item.</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "length",
            "description": "<p>Length the Item.</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "width",
            "description": "<p>Width of the Item.</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "package_type",
            "description": "<p>Package Type of the Item.</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "tracking_number",
            "description": "<p>Tracking Number of the Item.</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "airway_bill",
            "description": "<p>Airway Bill of the Item.</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "courier_id",
            "description": "<p>Courier ID referenced to Courier.</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "inbound_officer_id",
            "description": "<p>Inbound Officer ID referenced to Inbound Officer.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Item ID.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_address",
            "description": "<p>Address of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_country",
            "description": "<p>Country of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_region",
            "description": "<p>Region of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_province",
            "description": "<p>Province of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_district",
            "description": "<p>District of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_sub_district",
            "description": "<p>Subdistrict of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_barangay",
            "description": "<p>Barangay of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_first_name",
            "description": "<p>First name of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_last_name",
            "description": "<p>Last name the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_contact_number",
            "description": "<p>Contact number of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_email",
            "description": "<p>email of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "weight",
            "description": "<p>Weight of the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "height",
            "description": "<p>Height of the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "length",
            "description": "<p>Length the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "width",
            "description": "<p>Width of the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "package_type",
            "description": "<p>Package Type of the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "tracking_number",
            "description": "<p>Tracking Number of the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "airway_bill",
            "description": "<p>Airway Bill of the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "timestamp_of_receiving",
            "description": "<p>Date and Time the Item is received by the Inbound Officer.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and time the Item is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "courier_id",
            "description": "<p>Courier ID referenced to Courier.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "inbound_officer_id",
            "description": "<p>Inbound Officer ID referenced to Inbound Officer.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n       \"items\": [\n          {\n              \"id\": \"5e1fafc0-ed0f-4446-a4df-0e09f2d2466c\",\n              \"consignee_address\": \"51 Kanlaon St. Palar Village Brgy. Southside Makati City\",\n              \"consignee_country\": \"Philippines\",\n              \"consignee_region\": \"National Capital Region\",\n              \"consignee_province\": \"\",\n              \"consignee_district\": \"\",\n              \"consignee_sub_district\": \"\",\n              \"consignee_barangay\": \"Southside\",\n              \"consignee_first_name\": \"Juan\",\n              \"consignee_last_name\": \"Dela Cruz\",\n              \"consignee_contact_number\": \"Dela Cruz\",\n              \"consignee_email\": \"jdelacruz@gmail.com\",\n              \"weight\": 30.5,\n              \"height\": 0.5,\n              \"length\": 1.5,\n              \"width\": 2,\n              \"package_type\": \"Medium Box\",\n              \"tracking_number\": \"swsde35-posnwh\",\n              \"airway_bill\": \"ddcr45-plkm87u\",\n              \"status\": \"Pending\",\n              \"value\": 900,\n              \"timestamp_of_receiving\": \"2018-07-11T01:46:28.000Z\",\n              \"updated\": \"2018-07-11T01:49:18.000Z\",\n              \"courier_id\": null,\n              \"inbound_officer_id\": \"67956a52-c9d5-495a-8cca-2a5d00e19b6c\"\n          }\n      ],\n      \"success\": true\n  }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Internal Server Error\n{\n  \"status\": 500,\n  \"message\": \"Internal server error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ItemController.js",
    "groupTitle": "Item"
  },
  {
    "type": "put",
    "url": "/items/:id",
    "title": "Update Item",
    "name": "UpdateItem",
    "group": "Item",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Item unique ID.</p>"
          }
        ],
        "Body Params": [
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Item ID.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "consignee_address",
            "description": "<p>Address of the Consignee.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "consignee_country",
            "description": "<p>Country of the Consignee.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "consignee_region",
            "description": "<p>Region of the Consignee.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "consignee_province",
            "description": "<p>Province of the Consignee.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "consignee_district",
            "description": "<p>District of the Consignee.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "consignee_sub_district",
            "description": "<p>Subdistrict of the Consignee.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "consignee_barangay",
            "description": "<p>Barangay of the Consignee.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "consignee_first_name",
            "description": "<p>First name of the Consignee.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "consignee_last_name",
            "description": "<p>Last name the Consignee.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "consignee_contact_number",
            "description": "<p>Contact number of the Consignee.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "consignee_email",
            "description": "<p>email of the Consignee.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "weight",
            "description": "<p>Weight of the Item.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "height",
            "description": "<p>Height of the Item.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "length",
            "description": "<p>Length the Item.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "width",
            "description": "<p>Width of the Item.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "package_type",
            "description": "<p>Package Type of the Item.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "tracking_number",
            "description": "<p>Tracking Number of the Item.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "airway_bill",
            "description": "<p>Airway Bill of the Item.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "courier_id",
            "description": "<p>Courier ID referenced to Courier.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "inbound_officer_id",
            "description": "<p>Inbound Officer ID referenced to Inbound Officer.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Item ID.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_address",
            "description": "<p>Address of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_country",
            "description": "<p>Country of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_region",
            "description": "<p>Region of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_province",
            "description": "<p>Province of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_district",
            "description": "<p>District of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_sub_district",
            "description": "<p>Subdistrict of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_barangay",
            "description": "<p>Barangay of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_first_name",
            "description": "<p>First name of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_last_name",
            "description": "<p>Last name the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_contact_number",
            "description": "<p>Contact number of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "consignee_email",
            "description": "<p>email of the Consignee.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "weight",
            "description": "<p>Weight of the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "height",
            "description": "<p>Height of the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "length",
            "description": "<p>Length the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "width",
            "description": "<p>Width of the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "package_type",
            "description": "<p>Package Type of the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "tracking_number",
            "description": "<p>Tracking Number of the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "airway_bill",
            "description": "<p>Airway Bill of the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "timestamp_of_receiving",
            "description": "<p>Date and Time the Item is received by the Inbound Officer.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and time the Item is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "courier_id",
            "description": "<p>Courier ID referenced to Courier.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "inbound_officer_id",
            "description": "<p>Inbound Officer ID referenced to Inbound Officer.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n      \"item\": {\n          \"id\": \"5e1fafc0-ed0f-4446-a4df-0e09f2d2466c\",\n          \"consignee_address\": \"51 Kanlaon St. Palar Village Brgy. Southside Makati City\",\n          \"consignee_country\": \"Philippines\",\n          \"consignee_region\": \"National Capital Region\",\n          \"consignee_province\": \"\",\n          \"consignee_district\": \"\",\n          \"consignee_sub_district\": \"\",\n          \"consignee_barangay\": \"Southside\",\n          \"consignee_first_name\": \"Juan\",\n          \"consignee_last_name\": \"Dela Cruz\",\n          \"consignee_contact_number\": \"Dela Cruz\",\n          \"consignee_email\": \"jdelacruz@gmail.com\",\n          \"weight\": 30.5,\n          \"height\": 0.5,\n          \"length\": 1.5,\n          \"width\": 2,\n          \"package_type\": \"Medium Box\",\n          \"tracking_number\": \"swsde35-posnwh\",\n          \"airway_bill\": \"ddcr45-plkm87u\",\n          \"status\": \"Pending\",\n          \"value\": 900,\n          \"timestamp_of_receiving\": \"2018-07-11T01:46:28.000Z\",\n          \"updated\": \"2018-07-11T01:49:18.000Z\",\n          \"courier_id\": null,\n          \"inbound_officer_id\": \"67956a52-c9d5-495a-8cca-2a5d00e19b6c\"\n      },\n      \"message\": \"updated item: 5e1fafc0-ed0f-4446-a4df-0e09f2d2466c\",\n      \"success\": true\n  }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Internal Server Error\n{\n  \"status\": 500,\n  \"message\": \"Internal server error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ItemController.js",
    "groupTitle": "Item"
  },
  {
    "type": "post",
    "url": "/item-volumes",
    "title": "addItemVolume",
    "group": "ItemVolume",
    "name": "addItemVolume",
    "parameter": {
      "fields": {
        "Body Params": [
          {
            "group": "Body Params",
            "type": "Float",
            "optional": false,
            "field": "length",
            "description": "<p>length of item volume</p>"
          },
          {
            "group": "Body Params",
            "type": "Float",
            "optional": false,
            "field": "height",
            "description": "<p>height of item volume</p>"
          },
          {
            "group": "Body Params",
            "type": "Float",
            "optional": false,
            "field": "width",
            "description": "<p>width of item volume</p>"
          },
          {
            "group": "Body Params",
            "type": "Float",
            "optional": false,
            "field": "volume",
            "description": "<p>volume of item volume</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of item volume</p>"
          },
          {
            "group": "Success 200",
            "type": "Float",
            "optional": false,
            "field": "length",
            "description": "<p>length of item volume</p>"
          },
          {
            "group": "Success 200",
            "type": "Float",
            "optional": false,
            "field": "height",
            "description": "<p>height of item volume</p>"
          },
          {
            "group": "Success 200",
            "type": "Float",
            "optional": false,
            "field": "width",
            "description": "<p>width of item volume</p>"
          },
          {
            "group": "Success 200",
            "type": "Float",
            "optional": false,
            "field": "volume",
            "description": "<p>volume of item volume</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the item volume is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the item volume is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the item volume is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Message",
            "description": "<p>Successfully created new item volume</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n   \"message\": \"Successfully created new item_volume\",\n   \"item_volume\": {\n       \"id\": \"25fb351f-7ceb-46bc-b8c8-7f4a075e6f77\",\n       \"created\": {\n           \"val\": \"NOW()\"\n       },\n       \"length\": \"2.5\",\n       \"height\": \"3.5\",\n       \"width\": \"4.2\",\n       \"volume\": \"23.3\"\n   },\n   \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ItemVolumeController.js",
    "groupTitle": "ItemVolume"
  },
  {
    "type": "deactivate",
    "url": "/item-volumes/:id/deactivate",
    "title": "deactivateItemVolume",
    "group": "ItemVolume",
    "name": "deactivateItemVolume",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of item volume</p>"
          },
          {
            "group": "Success 200",
            "type": "Float",
            "optional": false,
            "field": "length",
            "description": "<p>length of item volume</p>"
          },
          {
            "group": "Success 200",
            "type": "Float",
            "optional": false,
            "field": "height",
            "description": "<p>height of item volume</p>"
          },
          {
            "group": "Success 200",
            "type": "Float",
            "optional": false,
            "field": "width",
            "description": "<p>width of item volume</p>"
          },
          {
            "group": "Success 200",
            "type": "Float",
            "optional": false,
            "field": "volume",
            "description": "<p>volume of item volume</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the item volume is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the item volume is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the item volume is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n {\n    \"item_volume\": {\n        \"id\": \"25fb351f-7ceb-46bc-b8c8-7f4a075e6f77\",\n        \"length\": 2.2,\n        \"height\": 8.9,\n        \"width\": 4.2,\n        \"volume\": 56.2,\n        \"created\": \"2018-07-12T08:50:21.000Z\",\n        \"updated\": \"2018-07-12T08:53:38.000Z\",\n        \"deleted\": \"2018-07-12T08:55:16.000Z\"\n    },\n    \"message\": \"deactivated item volume: 25fb351f-7ceb-46bc-b8c8-7f4a075e6f77\",\n    \"log\": {\n        \"id\": \"d2e562e9-935f-49a2-8310-eaf305d1ec4f\",\n        \"created\": {\n            \"val\": \"NOW()\"\n        },\n        \"route\": \"/item-volumes/25fb351f-7ceb-46bc-b8c8-7f4a075e6f77/deactivate\",\n        \"body\": {\n            \"id\": \"25fb351f-7ceb-46bc-b8c8-7f4a075e6f77\",\n            \"length\": 2.2,\n            \"height\": 8.9,\n            \"width\": 4.2,\n            \"volume\": 56.2,\n            \"created\": \"2018-07-12T08:50:21.000Z\",\n            \"updated\": \"2018-07-12T08:53:38.000Z\",\n            \"deleted\": \"2018-07-12T08:55:16.000Z\"\n        },\n        \"result\": \"201\",\n        \"actor\": 1\n    },\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ItemVolumeController.js",
    "groupTitle": "ItemVolume"
  },
  {
    "type": "get",
    "url": "/item-volumes",
    "title": "getItemVolumes",
    "group": "ItemVolume",
    "name": "getItemVolumes",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of item volume</p>"
          },
          {
            "group": "Success 200",
            "type": "Float",
            "optional": false,
            "field": "length",
            "description": "<p>length of item volume</p>"
          },
          {
            "group": "Success 200",
            "type": "Float",
            "optional": false,
            "field": "height",
            "description": "<p>height of item volume</p>"
          },
          {
            "group": "Success 200",
            "type": "Float",
            "optional": false,
            "field": "width",
            "description": "<p>width of item volume</p>"
          },
          {
            "group": "Success 200",
            "type": "Float",
            "optional": false,
            "field": "volume",
            "description": "<p>volume of item volume</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the item volume is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the item volume is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the item volume is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n    \"item_volumes\": [\n        {\n            \"id\": \"25fb351f-7ceb-46bc-b8c8-7f4a075e6f77\",\n            \"length\": 2.5,\n            \"height\": 3.5,\n            \"width\": 4.2,\n            \"volume\": 23.3,\n            \"created\": \"2018-07-12T08:50:21.000Z\",\n            \"updated\": null,\n            \"deleted\": null\n        },\n        {\n            \"id\": \"ab1c7311-d79b-4cbe-aa91-f0c375c1aa4e\",\n            \"length\": 2.2,\n            \"height\": 3.1,\n            \"width\": 4.2,\n            \"volume\": 23.3,\n            \"created\": \"2018-07-12T08:51:37.000Z\",\n            \"updated\": null,\n            \"deleted\": null\n        }\n    ],\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ItemVolumeController.js",
    "groupTitle": "ItemVolume"
  },
  {
    "type": "getOne",
    "url": "/item-volumes/:id",
    "title": "getOneItemVolume",
    "group": "ItemVolume",
    "name": "getOneItemVolume",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of item volume</p>"
          },
          {
            "group": "Success 200",
            "type": "Float",
            "optional": false,
            "field": "length",
            "description": "<p>length of item volume</p>"
          },
          {
            "group": "Success 200",
            "type": "Float",
            "optional": false,
            "field": "height",
            "description": "<p>height of item volume</p>"
          },
          {
            "group": "Success 200",
            "type": "Float",
            "optional": false,
            "field": "width",
            "description": "<p>width of item volume</p>"
          },
          {
            "group": "Success 200",
            "type": "Float",
            "optional": false,
            "field": "volume",
            "description": "<p>volume of item volume</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the item volume is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the item volume is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the item volume is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n    \"item_volumes\": \n        {\n            \"id\": \"25fb351f-7ceb-46bc-b8c8-7f4a075e6f77\",\n            \"length\": 2.5,\n            \"height\": 3.5,\n            \"width\": 4.2,\n            \"volume\": 23.3,\n            \"created\": \"2018-07-12T08:50:21.000Z\",\n            \"updated\": null,\n            \"deleted\": null\n        }\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ItemVolumeController.js",
    "groupTitle": "ItemVolume"
  },
  {
    "type": "reactivate",
    "url": "/item-volumes/:id/reactivate",
    "title": "reactivateItemVolume",
    "group": "ItemVolume",
    "name": "reactivateItemVolume",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of item volume</p>"
          },
          {
            "group": "Success 200",
            "type": "Float",
            "optional": false,
            "field": "length",
            "description": "<p>length of item volume</p>"
          },
          {
            "group": "Success 200",
            "type": "Float",
            "optional": false,
            "field": "height",
            "description": "<p>height of item volume</p>"
          },
          {
            "group": "Success 200",
            "type": "Float",
            "optional": false,
            "field": "width",
            "description": "<p>width of item volume</p>"
          },
          {
            "group": "Success 200",
            "type": "Float",
            "optional": false,
            "field": "volume",
            "description": "<p>volume of item volume</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the item volume is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the item volume is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the item volume is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n {\n    \"item_volume\": {\n        \"id\": \"25fb351f-7ceb-46bc-b8c8-7f4a075e6f77\",\n        \"length\": 2.2,\n        \"height\": 8.9,\n        \"width\": 4.2,\n        \"volume\": 56.2,\n        \"created\": \"2018-07-12T08:50:21.000Z\",\n        \"updated\": \"2018-07-12T08:53:38.000Z\",\n        \"deleted\": null\n    },\n    \"message\": \"reactivate item_volume: 25fb351f-7ceb-46bc-b8c8-7f4a075e6f77\",\n    \"log\": {\n        \"id\": \"c924fd12-c19f-4296-bfed-3e087ba7aef2\",\n        \"created\": {\n            \"val\": \"NOW()\"\n        },\n        \"route\": \"/item-volumes/25fb351f-7ceb-46bc-b8c8-7f4a075e6f77/reactivate\",\n        \"body\": {\n            \"id\": \"25fb351f-7ceb-46bc-b8c8-7f4a075e6f77\",\n            \"length\": 2.2,\n            \"height\": 8.9,\n            \"width\": 4.2,\n            \"volume\": 56.2,\n            \"created\": \"2018-07-12T08:50:21.000Z\",\n            \"updated\": \"2018-07-12T08:53:38.000Z\",\n            \"deleted\": null\n        },\n        \"result\": \"201\",\n        \"actor\": 1\n    },\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ItemVolumeController.js",
    "groupTitle": "ItemVolume"
  },
  {
    "type": "search",
    "url": "/item-volumes/search",
    "title": "searchItemVolume",
    "group": "ItemVolume",
    "name": "searchItemVolume",
    "parameter": {
      "fields": {
        "Query Params": [
          {
            "group": "Query Params",
            "type": "Float",
            "optional": false,
            "field": "length",
            "description": "<p>length of item volume</p>"
          },
          {
            "group": "Query Params",
            "type": "Float",
            "optional": false,
            "field": "height",
            "description": "<p>height of item volume</p>"
          },
          {
            "group": "Query Params",
            "type": "Float",
            "optional": false,
            "field": "width",
            "description": "<p>width of item volume</p>"
          },
          {
            "group": "Query Params",
            "type": "Float",
            "optional": false,
            "field": "volume",
            "description": "<p>volume of item volume</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of item volume</p>"
          },
          {
            "group": "Success 200",
            "type": "Float",
            "optional": false,
            "field": "length",
            "description": "<p>length of item volume</p>"
          },
          {
            "group": "Success 200",
            "type": "Float",
            "optional": false,
            "field": "height",
            "description": "<p>height of item volume</p>"
          },
          {
            "group": "Success 200",
            "type": "Float",
            "optional": false,
            "field": "width",
            "description": "<p>width of item volume</p>"
          },
          {
            "group": "Success 200",
            "type": "Float",
            "optional": false,
            "field": "volume",
            "description": "<p>volume of item volume</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the item volume is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the item volume is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the item volume is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Message",
            "description": "<p>updated item_volume + id</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n {\n    \"item_volumes\": [\n        {\n            \"id\": \"25fb351f-7ceb-46bc-b8c8-7f4a075e6f77\",\n            \"length\": 2.2,\n            \"height\": 8.9,\n            \"width\": 4.2,\n            \"volume\": 56.2,\n            \"created\": \"2018-07-12T08:50:21.000Z\",\n            \"updated\": \"2018-07-12T08:53:38.000Z\",\n            \"deleted\": null\n        },\n        {\n            \"id\": \"ab1c7311-d79b-4cbe-aa91-f0c375c1aa4e\",\n            \"length\": 2.2,\n            \"height\": 3.1,\n            \"width\": 4.2,\n            \"volume\": 23.3,\n            \"created\": \"2018-07-12T08:51:37.000Z\",\n            \"updated\": null,\n            \"deleted\": null\n        }\n    ],\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ItemVolumeController.js",
    "groupTitle": "ItemVolume"
  },
  {
    "type": "put",
    "url": "/item-volumes/:id",
    "title": "updateItemVolume",
    "group": "ItemVolume",
    "name": "updateItemVolume",
    "parameter": {
      "fields": {
        "Body Params": [
          {
            "group": "Body Params",
            "type": "Float",
            "optional": false,
            "field": "length",
            "description": "<p>length of item volume</p>"
          },
          {
            "group": "Body Params",
            "type": "Float",
            "optional": false,
            "field": "height",
            "description": "<p>height of item volume</p>"
          },
          {
            "group": "Body Params",
            "type": "Float",
            "optional": false,
            "field": "width",
            "description": "<p>width of item volume</p>"
          },
          {
            "group": "Body Params",
            "type": "Float",
            "optional": false,
            "field": "volume",
            "description": "<p>volume of item volume</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of item volume</p>"
          },
          {
            "group": "Success 200",
            "type": "Float",
            "optional": false,
            "field": "length",
            "description": "<p>length of item volume</p>"
          },
          {
            "group": "Success 200",
            "type": "Float",
            "optional": false,
            "field": "height",
            "description": "<p>height of item volume</p>"
          },
          {
            "group": "Success 200",
            "type": "Float",
            "optional": false,
            "field": "width",
            "description": "<p>width of item volume</p>"
          },
          {
            "group": "Success 200",
            "type": "Float",
            "optional": false,
            "field": "volume",
            "description": "<p>volume of item volume</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the item volume is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the item volume is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the item volume is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Message",
            "description": "<p>updated item_volume + id</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n    \"item_volume\": {\n        \"id\": \"25fb351f-7ceb-46bc-b8c8-7f4a075e6f77\",\n        \"length\": 2.2,\n        \"height\": 8.9,\n        \"width\": 4.2,\n        \"volume\": 56.2,\n        \"created\": \"2018-07-12T08:50:21.000Z\",\n        \"updated\": \"2018-07-12T08:53:38.000Z\",\n        \"deleted\": null\n    },\n    \"message\": \"update item_volume: 25fb351f-7ceb-46bc-b8c8-7f4a075e6f77\",\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ItemVolumeController.js",
    "groupTitle": "ItemVolume"
  },
  {
    "type": "post",
    "url": "/logs",
    "title": "addLog",
    "group": "Log",
    "name": "addLog",
    "parameter": {
      "fields": {
        "Body Params": [
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "actor",
            "description": "<p>actor of the event</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "route",
            "description": "<p>route of the event</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "body",
            "description": "<p>body of the event</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "result",
            "description": "<p>result of the event</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of log</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "actor",
            "description": "<p>actor of the event</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "route",
            "description": "<p>route of the event</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "body",
            "description": "<p>body of the event</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "result",
            "description": "<p>result of the event</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the log is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n {\n  \"logs\": [\n      {\n          \"id\": \"0e6b2193-8ef1-4d5b-b4e6-c6bd249dfb2e\",\n          \"actor\": \"1\",\n          \"route\": \"/zone-barangays\",\n          \"body\": {\n              \"id\": \"258b59b7-7907-4d7e-a3bf-961bbdb97a3a\",\n              \"created\": {\n                  \"val\": \"NOW()\"\n              },\n              \"zone_id\": \"2c933419-6a70-4139-b399-7930ad72ee10\",\n              \"barangay_id\": \"89fc14b8-d853-4cb2-9f66-4cc8c08fc767\"\n          },\n          \"result\": \"201\",\n          \"created\": \"2018-07-12T03:20:34.000Z\"\n      },\n      {\n          \"id\": \"0e871986-5a9b-4abe-bd52-989abd04a5d0\",\n          \"actor\": \"1\",\n          \"route\": \"/users/1\",\n          \"body\": {\n              \"id\": 1,\n              \"email\": \"kzarzoso@gmail.com\",\n              \"created\": \"2018-07-11T08:22:25.000Z\",\n              \"deleted\": null,\n              \"updated\": null,\n              \"password\": \"$2b$10$Ncvq8cVr15.TE1alWaOcWe13.Bip4wJLSdjWN43z05jC7vqb.xxyq\",\n              \"createdAt\": \"2018-07-11T08:22:25.000Z\",\n              \"last_name\": \"Zarzoso\",\n              \"updatedAt\": \"2018-07-12T01:21:13.742Z\",\n              \"first_name\": \"Kiara\",\n              \"middle_name\": \"Calbera\",\n              \"contact_number\": \"09168650222\"\n          },\n          \"result\": \"201\",\n          \"created\": \"2018-07-12T01:21:13.000Z\"\n      }\n    ],\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/LogController.js",
    "groupTitle": "Log"
  },
  {
    "type": "get",
    "url": "/logs",
    "title": "getLogs",
    "group": "Log",
    "name": "getLogs",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of log</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "actor",
            "description": "<p>actor of the event</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "route",
            "description": "<p>route of the event</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "body",
            "description": "<p>body of the event</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "result",
            "description": "<p>result of the event</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the log is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n {\n  \"logs\": [\n      {\n          \"id\": \"0e6b2193-8ef1-4d5b-b4e6-c6bd249dfb2e\",\n          \"actor\": \"1\",\n          \"route\": \"/zone-barangays\",\n          \"body\": {\n              \"id\": \"258b59b7-7907-4d7e-a3bf-961bbdb97a3a\",\n              \"created\": {\n                  \"val\": \"NOW()\"\n              },\n              \"zone_id\": \"2c933419-6a70-4139-b399-7930ad72ee10\",\n              \"barangay_id\": \"89fc14b8-d853-4cb2-9f66-4cc8c08fc767\"\n          },\n          \"result\": \"201\",\n          \"created\": \"2018-07-12T03:20:34.000Z\"\n      },\n      {\n          \"id\": \"0e871986-5a9b-4abe-bd52-989abd04a5d0\",\n          \"actor\": \"1\",\n          \"route\": \"/users/1\",\n          \"body\": {\n              \"id\": 1,\n              \"email\": \"kzarzoso@gmail.com\",\n              \"created\": \"2018-07-11T08:22:25.000Z\",\n              \"deleted\": null,\n              \"updated\": null,\n              \"password\": \"$2b$10$Ncvq8cVr15.TE1alWaOcWe13.Bip4wJLSdjWN43z05jC7vqb.xxyq\",\n              \"createdAt\": \"2018-07-11T08:22:25.000Z\",\n              \"last_name\": \"Zarzoso\",\n              \"updatedAt\": \"2018-07-12T01:21:13.742Z\",\n              \"first_name\": \"Kiara\",\n              \"middle_name\": \"Calbera\",\n              \"contact_number\": \"09168650222\"\n          },\n          \"result\": \"201\",\n          \"created\": \"2018-07-12T01:21:13.000Z\"\n      }\n    ],\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/LogController.js",
    "groupTitle": "Log"
  },
  {
    "type": "getOne",
    "url": "/logs/:id",
    "title": "getOneLog",
    "group": "Log",
    "name": "getOneLog",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of log</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "actor",
            "description": "<p>actor of the event</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "route",
            "description": "<p>route of the event</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "body",
            "description": "<p>body of the event</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "result",
            "description": "<p>result of the event</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the log is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n {\n  \"log\": \n      {\n          \"id\": \"0e6b2193-8ef1-4d5b-b4e6-c6bd249dfb2e\",\n          \"actor\": \"1\",\n          \"route\": \"/zone-barangays\",\n          \"body\": {\n              \"id\": \"258b59b7-7907-4d7e-a3bf-961bbdb97a3a\",\n              \"created\": {\n                  \"val\": \"NOW()\"\n              },\n              \"zone_id\": \"2c933419-6a70-4139-b399-7930ad72ee10\",\n              \"barangay_id\": \"89fc14b8-d853-4cb2-9f66-4cc8c08fc767\"\n          },\n          \"result\": \"201\",\n          \"created\": \"2018-07-12T03:20:34.000Z\"\n      },\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/LogController.js",
    "groupTitle": "Log"
  },
  {
    "type": "post",
    "url": "/v1/forgot-password",
    "title": "Forgot Password",
    "name": "Forgot_Password",
    "group": "Password",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "email",
            "description": "<p>User's email</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n    \"user\": {\n        \"id\": 1,\n        \"email\": \"email@gmail.com\",\n        \"password\": \"$2b$10$xGfCsiLBFDam/5chkodHL.Ijle4mk07TB2TFsAuTsFK6HgnD62jfq\",\n        \"createdAt\": \"2018-07-09T07:23:52.000Z\",\n        \"updatedAt\": \"2018-07-09T07:23:52.000Z\"\n    },\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/PasswordController.js",
    "groupTitle": "Password"
  },
  {
    "type": "post",
    "url": "/v1/ports",
    "title": "Add Port",
    "group": "Port",
    "name": "Add_Port",
    "parameter": {
      "fields": {
        "System Generated": [
          {
            "group": "System Generated",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>unique ID</p>"
          }
        ],
        "Body Params": [
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>unique code for each port</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of port</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "address",
            "description": "<p>address of the port</p>"
          },
          {
            "group": "Body Params",
            "type": "char",
            "optional": false,
            "field": "country",
            "description": "<p>country</p>"
          },
          {
            "group": "Body Params",
            "type": "char",
            "optional": false,
            "field": "region",
            "description": "<p>region</p>"
          },
          {
            "group": "Body Params",
            "type": "char",
            "optional": false,
            "field": "province",
            "description": "<p>province</p>"
          },
          {
            "group": "Body Params",
            "type": "char",
            "optional": false,
            "field": "district",
            "description": "<p>district</p>"
          },
          {
            "group": "Body Params",
            "type": "char",
            "optional": false,
            "field": "sub_district",
            "description": "<p>sub_district</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "port",
            "description": "<p>new port</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "port.id",
            "description": "<p>ID of port</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "port.code",
            "description": "<p>code of port</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "port.name",
            "description": "<p>name of port</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "port.address",
            "description": "<p>address of port</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "port.country",
            "description": "<p>country</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "port.region",
            "description": "<p>region</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "port.province",
            "description": "<p>province</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "port.district",
            "description": "<p>district</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "port.sub_district",
            "description": "<p>sub_district</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "port.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "port.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "port.deleted",
            "description": "<p>timestamp of deletion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n    \"message\": \"successfully created new port\",\n    \"port\": {\n        \"id\": \"b2145f97-8985-42f6-8b43-3cd290872a69\",\n        \"created\": {\n            \"val\": \"NOW()\"\n        },\n        \"updated\": null,\n        \"deleted\": null,\n        \"code\": \"MNL\",\n        \"name\": \"Manila Port\",\n        \"address\": \"Manila\",\n        \"country\": \"PHL\",\n        \"region\": \"NCR\",\n        \"province\": \"n/a\",\n        \"district\": \"1\",\n       \"sub_district\": \"\"\n    },\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/PortController.js",
    "groupTitle": "Port"
  },
  {
    "type": "post",
    "url": "/v1/ports/:id/deactivate",
    "title": "Deactivate Port by ID",
    "name": "Deactivate_Port_by_ID",
    "group": "Port",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>Port's unique ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "port",
            "description": "<p>new port</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "port.id",
            "description": "<p>ID of port</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "port.code",
            "description": "<p>code of port</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "port.name",
            "description": "<p>name of port</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "port.address",
            "description": "<p>address of port</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "port.country",
            "description": "<p>country</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "port.region",
            "description": "<p>region</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "port.province",
            "description": "<p>province</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "port.district",
            "description": "<p>district</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "port.sub_district",
            "description": "<p>sub_district</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "port.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "port.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "port.deleted",
            "description": "<p>timestamp of deletion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n    \"message\": \"deactivated port\",\n    \"port\": {\n        \"id\": \"b2145f97-8985-42f6-8b43-3cd290872a69\",\n        \"code\": \"MNL\",\n        \"name\": \"Manila Port\",\n        \"address\": \"Manila\",\n        \"country\": \"PHL\",\n        \"region\": \"NCR\",\n        \"province\": \"n/a\",\n        \"district\": \"1\",\n        \"sub_district\": \"1\",\n        \"created\": \"2018-07-11T02:17:53.000Z\",\n        \"updated\": \"2018-07-11T02:33:17.000Z\",\n        \"deleted\": \"2018-07-11T02:37:45.000Z\"\n    },\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/PortController.js",
    "groupTitle": "Port"
  },
  {
    "type": "get",
    "url": "/v1/ports/:id",
    "title": "Get Port by ID",
    "group": "Port",
    "name": "Get_Port_by_ID",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>Port's unique ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "port",
            "description": "<p>new port</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "port.id",
            "description": "<p>ID of port</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "port.code",
            "description": "<p>code of port</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "port.name",
            "description": "<p>name of port</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "port.address",
            "description": "<p>address of port</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "port.country",
            "description": "<p>country</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "port.region",
            "description": "<p>region</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "port.province",
            "description": "<p>province</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "port.district",
            "description": "<p>district</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "port.sub_district",
            "description": "<p>sub_district</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "port.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "port.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "port.deleted",
            "description": "<p>timestamp of deletion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n    \"port\": {\n        \"id\": \"b2145f97-8985-42f6-8b43-3cd290872a69\",\n        \"code\": \"MNL\",\n        \"name\": \"Manila Port\",\n        \"address\": \"Manila\",\n        \"country\": \"PHL\",\n        \"region\": \"NCR\",\n        \"province\": \"n/a\",\n        \"district\": \"1\",\n        \"sub_district\": \"\",\n        \"created\": \"2018-07-11T02:17:53.000Z\",\n        \"updated\": null,\n        \"deleted\": null\n    },\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/PortController.js",
    "groupTitle": "Port"
  },
  {
    "type": "get",
    "url": "/v1/ports",
    "title": "Get Ports",
    "group": "Port",
    "name": "Get_Ports",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object[]",
            "optional": false,
            "field": "ports",
            "description": "<p>array of ports</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "ports.id",
            "description": "<p>ID of port</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "ports.code",
            "description": "<p>code of port</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "ports.name",
            "description": "<p>name of port</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "ports.address",
            "description": "<p>address of port</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "ports.country",
            "description": "<p>country</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "ports.region",
            "description": "<p>region</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "ports.province",
            "description": "<p>province</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "ports.district",
            "description": "<p>district</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "ports.sub_district",
            "description": "<p>sub_district</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "ports.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "ports.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "ports.deleted",
            "description": "<p>timestamp of deletion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n    \"ports\": [\n        {\n            \"id\": \"8a94d745-1768-4ec8-8eff-7bbc8b889c26\",\n            \"code\": \"CEB\",\n            \"name\": \"Cebu Port\",\n            \"address\": \"Cebu\",\n            \"country\": \"PHL\",\n            \"region\": \"8\",\n            \"province\": \"n/a\",\n            \"district\": \"1\",\n            \"sub_district\": \"\",\n            \"created\": \"2018-07-11T02:24:08.000Z\",\n            \"updated\": null,\n            \"deleted\": null\n        },\n        {\n            \"id\": \"b2145f97-8985-42f6-8b43-3cd290872a69\",\n            \"code\": \"MNL\",\n            \"name\": \"Manila Port\",\n            \"address\": \"Manila\",\n            \"country\": \"PHL\",\n            \"region\": \"NCR\",\n            \"province\": \"n/a\",\n            \"district\": \"1\",\n            \"sub_district\": \"\",\n            \"created\": \"2018-07-11T02:17:53.000Z\",\n            \"updated\": null,\n            \"deleted\": null\n        }\n    ],\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/PortController.js",
    "groupTitle": "Port"
  },
  {
    "type": "post",
    "url": "/v1/ports/:id/reactivate",
    "title": "Reactivate Port by ID",
    "name": "Reactivate_Port_by_ID",
    "group": "Port",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>Port's unique ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "port",
            "description": "<p>new port</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "port.id",
            "description": "<p>ID of port</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "port.code",
            "description": "<p>code of port</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "port.name",
            "description": "<p>name of port</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "port.address",
            "description": "<p>address of port</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "port.country",
            "description": "<p>country</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "port.region",
            "description": "<p>region</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "port.province",
            "description": "<p>province</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "port.district",
            "description": "<p>district</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "port.sub_district",
            "description": "<p>sub_district</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "port.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "port.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "port.deleted",
            "description": "<p>timestamp of deletion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n    \"message\": \"reactivated port\",\n    \"port\": {\n        \"id\": \"b2145f97-8985-42f6-8b43-3cd290872a69\",\n        \"code\": \"MNL\",\n        \"name\": \"Manila Port\",\n        \"address\": \"Manila\",\n        \"country\": \"PHL\",\n        \"region\": \"NCR\",\n        \"province\": \"n/a\",\n        \"district\": \"1\",\n        \"sub_district\": \"1\",\n        \"created\": \"2018-07-11T02:17:53.000Z\",\n        \"updated\": \"2018-07-11T02:33:17.000Z\",\n        \"deleted\": null\n    },\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/PortController.js",
    "groupTitle": "Port"
  },
  {
    "type": "put",
    "url": "/v1/ports/:id",
    "title": "Update Port by ID",
    "name": "Update_Port_by_ID",
    "group": "Port",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>Port's unique ID.</p>"
          }
        ],
        "Body Params": [
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>unique code for each port</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of port</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "address",
            "description": "<p>address of the port</p>"
          },
          {
            "group": "Body Params",
            "type": "char",
            "optional": false,
            "field": "country",
            "description": "<p>country</p>"
          },
          {
            "group": "Body Params",
            "type": "char",
            "optional": false,
            "field": "region",
            "description": "<p>region</p>"
          },
          {
            "group": "Body Params",
            "type": "char",
            "optional": false,
            "field": "province",
            "description": "<p>province</p>"
          },
          {
            "group": "Body Params",
            "type": "char",
            "optional": false,
            "field": "district",
            "description": "<p>district</p>"
          },
          {
            "group": "Body Params",
            "type": "char",
            "optional": false,
            "field": "sub_district",
            "description": "<p>sub_district</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "port",
            "description": "<p>new port</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "port.id",
            "description": "<p>ID of port</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "port.code",
            "description": "<p>code of port</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "port.name",
            "description": "<p>name of port</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "port.address",
            "description": "<p>address of port</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "port.country",
            "description": "<p>country</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "port.region",
            "description": "<p>region</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "port.province",
            "description": "<p>province</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "port.district",
            "description": "<p>district</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "port.sub_district",
            "description": "<p>sub_district</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "port.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "port.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "port.deleted",
            "description": "<p>timestamp of deletion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n    \"port\": {\n        \"id\": \"b2145f97-8985-42f6-8b43-3cd290872a69\",\n        \"code\": \"MNL\",\n        \"name\": \"Manila Port\",\n        \"address\": \"Manila\",\n        \"country\": \"PHL\",\n        \"region\": \"NCR\",\n       \"province\": \"n/a\",\n        \"district\": \"1\",\n        \"sub_district\": \"1\",\n        \"created\": \"2018-07-11T02:17:53.000Z\",\n        \"updated\": \"2018-07-11T02:33:17.000Z\",\n        \"deleted\": null\n    },\n    \"message\": \"update port: b2145f97-8985-42f6-8b43-3cd290872a69\",\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/PortController.js",
    "groupTitle": "Port"
  },
  {
    "type": "put",
    "url": "/v1/vehicles/:id",
    "title": "Update Port by ID",
    "name": "Update_Port_by_ID",
    "group": "Port",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>Port's unique ID.</p>"
          }
        ],
        "Body Params": [
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "plate_number",
            "description": "<p>plate number of vehicle</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "type",
            "description": "<p>type of vehicle</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "model",
            "description": "<p>model of vehicle</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "vehicle",
            "description": "<p>new vehicle</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "vehicle.id",
            "description": "<p>ID of vehicle</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "vehicle.code",
            "description": "<p>code of vehicle</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "vehicle.name",
            "description": "<p>name of vehicle</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "vehicle.address",
            "description": "<p>address of vehicle</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "vehicle.country",
            "description": "<p>country</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "vehicle.region",
            "description": "<p>region</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "vehicle.province",
            "description": "<p>province</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "vehicle.district",
            "description": "<p>district</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "vehicle.sub_district",
            "description": "<p>sub_district</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "vehicle.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "vehicle.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "vehicle.deleted",
            "description": "<p>timestamp of deletion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n    \"vehicle\": {\n        \"id\": \"ed7b7aa2-aa55-4486-bcb7-725b9c558bd3\",\n        \"plate_number\": \"TRX 1221\",\n        \"type\": \"truck\",\n        \"model\": \"Nissan Navara\",\n        \"created\": \"2018-07-11T02:59:39.000Z\",\n        \"updated\": null,\n        \"deleted\": null\n    },\n    \"message\": \"update vehicle: ed7b7aa2-aa55-4486-bcb7-725b9c558bd3\",\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "Error 422": [
          {
            "group": "Error 422",
            "type": "Number",
            "optional": false,
            "field": "status",
            "description": "<p>status code</p>"
          },
          {
            "group": "Error 422",
            "type": "String",
            "optional": false,
            "field": "message",
            "description": "<p>Error message</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "./controllers/VehicleController.js",
    "groupTitle": "Port"
  },
  {
    "type": "post",
    "url": "/prices",
    "title": "Add Price",
    "name": "AddPrice",
    "group": "Price",
    "parameter": {
      "fields": {
        "System Generated": [
          {
            "group": "System Generated",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Price ID.</p>"
          }
        ],
        "Body Params": [
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "package_type",
            "description": "<p>Package Type of Item.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "origin",
            "description": "<p>Origin of the Item.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "destination",
            "description": "<p>Destination of the Item.</p>"
          },
          {
            "group": "Body Params",
            "type": "Float",
            "optional": false,
            "field": "price",
            "description": "<p>Price for the transaction.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "client_account_number",
            "description": "<p>Client ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "package_type",
            "description": "<p>Package Type of Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "origin",
            "description": "<p>Origin of the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "destination",
            "description": "<p>Destination of the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "Float",
            "optional": false,
            "field": "price",
            "description": "<p>Price for the transaction.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Price is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Price is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Price is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "client_account_number",
            "description": "<p>Client ID referenced from Client.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n      \"message\": \"successfully created new price\",\n      \"price\": {\n          \"id\": \"ad478f28-09c3-49af-86bb-210ed6ae3309\",\n          \"created\": {\n              \"val\": \"NOW()\"\n          },\n          \"updated\": null,\n          \"deleted\": null,\n          \"client_account_number\": \"59e631e0-a9e8-40b9-a995-7d03cb608e52\",\n          \"package_type\": \"Small Box\",\n          \"origin\": \"LB\",\n          \"destination\": \"MNL\",\n          \"price\": \"234.75\"\n      },\n      \"success\": true\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/PriceController.js",
    "groupTitle": "Price"
  },
  {
    "type": "post",
    "url": "/prices/:id/deactivate",
    "title": "Deactivate Price",
    "name": "DeactivatePrice",
    "group": "Price",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Price unique ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "package_type",
            "description": "<p>Package Type of Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "origin",
            "description": "<p>Origin of the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "destination",
            "description": "<p>Destination of the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "Float",
            "optional": false,
            "field": "price",
            "description": "<p>Price for the transaction.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Price is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Price is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Price is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "client_account_number",
            "description": "<p>Client ID referenced from Client.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n      \"price\": {\n          \"id\": \"ad478f28-09c3-49af-86bb-210ed6ae3309\",\n          \"package_type\": \"Medium Box\",\n          \"origin\": \"MNL\",\n          \"destination\": \"LB\",\n          \"price\": 450,\n          \"created\": \"2018-07-11T03:04:58.000Z\",\n          \"updated\": \"2018-07-11T03:20:37.000Z\",\n          \"deleted\": \"2018-07-11T03:22:34.000Z\",\n          \"client_account_number\": \"59e631e0-a9e8-40b9-a995-7d03cb608e52\"\n      },\n      \"message\": \"deactivated price: ad478f28-09c3-49af-86bb-210ed6ae3309\",\n      \"success\": true\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/PriceController.js",
    "groupTitle": "Price"
  },
  {
    "type": "get",
    "url": "/prices/:id",
    "title": "Retrieve Price By ID",
    "name": "GetPriceByID",
    "group": "Price",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Price unique ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "package_type",
            "description": "<p>Package Type of Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "origin",
            "description": "<p>Origin of the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "destination",
            "description": "<p>Destination of the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "Float",
            "optional": false,
            "field": "price",
            "description": "<p>Price for the transaction.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Price is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Price is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Price is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "client_account_number",
            "description": "<p>Client ID referenced from Client.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n      \"price\":\n      {\n          \"id\": \"ad478f28-09c3-49af-86bb-210ed6ae3309\",\n          \"package_type\": \"Small Box\",\n          \"origin\": \"LB\",\n          \"destination\": \"MNL\",\n          \"price\": 234.75,\n          \"created\": \"2018-07-11T03:04:58.000Z\",\n          \"updated\": null,\n          \"deleted\": null,\n          \"client_account_number\": \"59e631e0-a9e8-40b9-a995-7d03cb608e52\"\n      }\n      \"success\": true\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/PriceController.js",
    "groupTitle": "Price"
  },
  {
    "type": "get",
    "url": "/prices",
    "title": "Retrieve Prices",
    "name": "GetPrices",
    "group": "Price",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Price ID.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "package_type",
            "description": "<p>Package Type of Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "origin",
            "description": "<p>Origin of the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "destination",
            "description": "<p>Destination of the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "Float",
            "optional": false,
            "field": "price",
            "description": "<p>Price for the transaction.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Price is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Price is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Price is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "client_account_number",
            "description": "<p>Client ID referenced from Client.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n      \"prices\": [\n          {\n              \"id\": \"ad478f28-09c3-49af-86bb-210ed6ae3309\",\n              \"package_type\": \"Small Box\",\n              \"origin\": \"LB\",\n              \"destination\": \"MNL\",\n              \"price\": 234.75,\n              \"created\": \"2018-07-11T03:04:58.000Z\",\n              \"updated\": null,\n              \"deleted\": null,\n              \"client_account_number\": \"59e631e0-a9e8-40b9-a995-7d03cb608e52\"\n          },\n          {\n              \"id\": \"d63e324f-aa0e-4627-878e-99fd6fda069a\",\n              \"package_type\": \"Large Box\",\n              \"origin\": \"MKT\",\n              \"destination\": \"PSG\",\n              \"price\": 550,\n              \"created\": \"2018-07-10T08:03:43.000Z\",\n              \"updated\": null,\n              \"deleted\": null,\n              \"client_account_number\": \"59e631e0-a9e8-40b9-a995-7d03cb608e52\"\n          }\n      ],\n      \"success\": true\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/PriceController.js",
    "groupTitle": "Price"
  },
  {
    "type": "post",
    "url": "/prices/:id/reactivate",
    "title": "Reactivate Price",
    "name": "ReactivatePrice",
    "group": "Price",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Price unique ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "package_type",
            "description": "<p>Package Type of Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "origin",
            "description": "<p>Origin of the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "destination",
            "description": "<p>Destination of the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "Float",
            "optional": false,
            "field": "price",
            "description": "<p>Price for the transaction.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Price is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Price is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Price is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "client_account_number",
            "description": "<p>Client ID referenced from Client.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n      \"price\": {\n          \"id\": \"ad478f28-09c3-49af-86bb-210ed6ae3309\",\n          \"package_type\": \"Medium Box\",\n          \"origin\": \"MNL\",\n          \"destination\": \"LB\",\n          \"price\": 450,\n          \"created\": \"2018-07-11T03:04:58.000Z\",\n          \"updated\": \"2018-07-11T03:20:37.000Z\",\n          \"deleted\": null,\n          \"client_account_number\": \"59e631e0-a9e8-40b9-a995-7d03cb608e52\"\n      },\n      \"message\": \"reactivated price: ad478f28-09c3-49af-86bb-210ed6ae3309\",\n      \"success\": true\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/PriceController.js",
    "groupTitle": "Price"
  },
  {
    "type": "put",
    "url": "/prices/:id",
    "title": "Update Price",
    "name": "UpdatePriceByID",
    "group": "Price",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Price unique ID.</p>"
          }
        ],
        "Body Params": [
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "package_type",
            "description": "<p>Package Type of Item.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "origin",
            "description": "<p>Origin of the Item.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "destination",
            "description": "<p>Destination of the Item.</p>"
          },
          {
            "group": "Body Params",
            "type": "Float",
            "optional": false,
            "field": "price",
            "description": "<p>Price for the transaction.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "client_account_number",
            "description": "<p>Client ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "package_type",
            "description": "<p>Package Type of Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "origin",
            "description": "<p>Origin of the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "destination",
            "description": "<p>Destination of the Item.</p>"
          },
          {
            "group": "Success 200",
            "type": "Float",
            "optional": false,
            "field": "price",
            "description": "<p>Price for the transaction.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Price is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Price is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Price is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "client_account_number",
            "description": "<p>Client ID referenced from Client.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n      \"price\": {\n          \"id\": \"ad478f28-09c3-49af-86bb-210ed6ae3309\",\n          \"package_type\": \"Medium Box\",\n          \"origin\": \"MNL\",\n          \"destination\": \"LB\",\n          \"price\": 450,\n          \"created\": \"2018-07-11T03:04:58.000Z\",\n          \"updated\": \"2018-07-11T03:20:37.000Z\",\n          \"deleted\": null,\n          \"client_account_number\": \"59e631e0-a9e8-40b9-a995-7d03cb608e52\"\n      },\n      \"message\": \"updated price: ad478f28-09c3-49af-86bb-210ed6ae3309\",\n      \"success\": true\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/PriceController.js",
    "groupTitle": "Price"
  },
  {
    "type": "post",
    "url": "/provinces",
    "title": "Add Province",
    "name": "AddProvince",
    "group": "Province",
    "parameter": {
      "fields": {
        "System Generated": [
          {
            "group": "System Generated",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Province unique ID.</p>"
          }
        ],
        "Body Params": [
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>code of the Province.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of the Province.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "region_id",
            "description": "<p>Region ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Province ID.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>Code of the Province.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>Name of the Province.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Province is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Province is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Province is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "region_id",
            "description": "<p>Region ID referenced from Region.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n      \"message\": \"successfully created new province\",\n      \"province\": {\n          \"id\": \"58b66509-40d8-4600-9b32-56619fc6c0b5\",\n          \"created\": {\n              \"val\": \"NOW()\"\n          },\n          \"updated\": null,\n          \"deleted\": null,\n          \"region_id\": \"8c0d476e-ed0b-4e8f-9f6c-fe54ba4d6be4\",\n          \"code\": \"QZN\",\n          \"name\": \"Quezon\"\n      }\n      \"success\": true\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ProvinceController.js",
    "groupTitle": "Province"
  },
  {
    "type": "post",
    "url": "/provinces/:id/deactivate",
    "title": "Deactivate Province",
    "name": "DeactivateProvince",
    "group": "Province",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Province unique ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Province ID.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>Code of the Province.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>Name of the Province.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Province is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Province is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Province is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "region_id",
            "description": "<p>Region ID referenced from Region.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n      \"province\": {\n          \"id\": \"58b66509-40d8-4600-9b32-56619fc6c0b5\",\n          \"code\": \"CAV\",\n          \"name\": \"Cavite\",\n          \"created\": \"2018-07-11T00:58:10.000Z\",\n          \"updated\": \"2018-07-11T01:01:34.000Z\",\n          \"deleted\": \"2018-07-11T01:05:23.000Z\",\n          \"region_id\": \"8c0d476e-ed0b-4e8f-9f6c-fe54ba4d6be4\"\n      }\n      \"message\": \"deactivated province: 58b66509-40d8-4600-9b32-56619fc6c0b5\",\n      \"success\": true\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ProvinceController.js",
    "groupTitle": "Province"
  },
  {
    "type": "get",
    "url": "/provinces/:id",
    "title": "Retrieve Province By ID",
    "name": "GetProvinceByID",
    "group": "Province",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Province unique ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Province ID.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>Code of the Province.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>Name of the Province.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Province is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Province is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Province is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "region_id",
            "description": "<p>Region ID referenced from Region.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "region_id.id",
            "description": "<p>Region ID.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "region_id.code",
            "description": "<p>Code of the Region.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "region_id.name",
            "description": "<p>Code of the Region.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "country_id",
            "description": "<p>Country ID referenced from Country.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "country_id.id",
            "description": "<p>Country ID.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "country_id.code",
            "description": "<p>Code of the Country.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "country_id.name",
            "description": "<p>Code of the Country.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n      \"province\": {\n          \"id\": \"a91c7fdc-7b5a-42ae-8342-d578a57a1b46\",\n          \"code\": \"LAG\",\n          \"name\": \"Laguna\",\n          \"created\": \"2018-07-11T00:43:43.000Z\",\n          \"updated\": null,\n          \"deleted\": null,\n          \"region_id\": \"b157ed7b-1060-4a35-ae24-67aa0a14e20f\",\n          \"region\": {\n              \"id\": \"b157ed7b-1060-4a35-ae24-67aa0a14e20f\",\n              \"code\": \"CAL\",\n              \"name\": \"Calabarzon\",\n              \"country\": {\n                  \"id\": \"406405a2-8255-48d0-86c6-7f1109d10e30\",\n                  \"code\": \"PH\",\n                  \"name\": \"Philippines\"\n              }\n          }\n      },\n      \"success\": true\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ProvinceController.js",
    "groupTitle": "Province"
  },
  {
    "type": "get",
    "url": "/provinces",
    "title": "Retrieve Provinces",
    "name": "GetProvinces",
    "group": "Province",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Province ID.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>Code of the Province.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>Name of the Province.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Province is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Province is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Province is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "region_id",
            "description": "<p>Region ID referenced from Region.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "region_id.id",
            "description": "<p>Region ID.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "region_id.code",
            "description": "<p>Code of the Region.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "region_id.name",
            "description": "<p>Code of the Region.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "country_id",
            "description": "<p>Country ID referenced from Country.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "country_id.id",
            "description": "<p>Country ID.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "country_id.code",
            "description": "<p>Code of the Country.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "country_id.name",
            "description": "<p>Code of the Country.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n       \"provinces\": [\n          {\n              \"id\": \"a91c7fdc-7b5a-42ae-8342-d578a57a1b46\",\n              \"code\": \"LAG\",\n              \"name\": \"Laguna\",\n              \"created\": \"2018-07-11T00:43:43.000Z\",\n              \"updated\": null,\n              \"deleted\": null,\n              \"region_id\": \"b157ed7b-1060-4a35-ae24-67aa0a14e20f\",\n              \"region\": {\n                  \"id\": \"b157ed7b-1060-4a35-ae24-67aa0a14e20f\",\n                  \"code\": \"CAL\",\n                  \"name\": \"Calabarzon\",\n                  \"country\": {\n                      \"id\": \"406405a2-8255-48d0-86c6-7f1109d10e30\",\n                      \"code\": \"PH\",\n                      \"name\": \"Philippines\"\n                  }\n              }\n          },\n          {\n              \"id\": \"e6dd2897-81e1-46da-8401-6f01cd1738db\",\n              \"code\": \"RZL\",\n              \"name\": \"Rizal\",\n              \"created\": \"2018-07-09T01:59:18.000Z\",\n              \"updated\": null,\n              \"deleted\": null,\n              \"region_id\": \"b157ed7b-1060-4a35-ae24-67aa0a14e20f\",\n              \"region\": {\n                  \"id\": \"b157ed7b-1060-4a35-ae24-67aa0a14e20f\",\n                  \"code\": \"CAL\",\n                  \"name\": \"Calabarzon\",\n                  \"country\": {\n                      \"id\": \"406405a2-8255-48d0-86c6-7f1109d10e30\",\n                      \"code\": \"PH\",\n                      \"name\": \"Philippines\"\n                  }\n              }\n          }\n      ],\n      \"success\": true\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ProvinceController.js",
    "groupTitle": "Province"
  },
  {
    "type": "post",
    "url": "/provinces/:id/reactivate",
    "title": "Reactivate Province",
    "name": "ReactivateProvince",
    "group": "Province",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Province unique ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Province ID.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>Code of the Province.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>Name of the Province.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Province is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Province is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Province is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "region_id",
            "description": "<p>Region ID referenced from Region.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n      \"province\": {\n          \"id\": \"58b66509-40d8-4600-9b32-56619fc6c0b5\",\n          \"code\": \"CAV\",\n          \"name\": \"Cavite\",\n          \"created\": \"2018-07-11T00:58:10.000Z\",\n          \"updated\": \"2018-07-11T01:01:34.000Z\",\n          \"deleted\": null,\n          \"region_id\": \"8c0d476e-ed0b-4e8f-9f6c-fe54ba4d6be4\"\n      }\n      \"message\": \"reactivated province: 58b66509-40d8-4600-9b32-56619fc6c0b5\",\n      \"success\": true\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ProvinceController.js",
    "groupTitle": "Province"
  },
  {
    "type": "get",
    "url": "/provinces/search",
    "title": "Search Province",
    "name": "SearchProvince",
    "group": "Province",
    "parameter": {
      "fields": {
        "Query Params": [
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>code of the Province</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of the Province</p>"
          },
          {
            "group": "Query Params",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Province is created.</p>"
          },
          {
            "group": "Query Params",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Province is updated.</p>"
          },
          {
            "group": "Query Params",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Province is deleted.</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "region_id",
            "description": "<p>Region ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Province ID.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>Code of the Province.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>Name of the Province.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Province is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Province is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Province is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "region_id",
            "description": "<p>Region ID referenced from Region.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n     \"provinces\": [\n          {\n              \"id\": \"58b66509-40d8-4600-9b32-56619fc6c0b5\",\n              \"code\": \"CAV\",\n              \"name\": \"Cavite\",\n              \"created\": \"2018-07-11T00:58:10.000Z\",\n              \"updated\": \"2018-07-11T01:01:34.000Z\",\n              \"deleted\": \"2018-07-11T01:05:23.000Z\",\n              \"region_id\": \"8c0d476e-ed0b-4e8f-9f6c-fe54ba4d6be4\"\n          }\n      ],\n      \"success\": true\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ProvinceController.js",
    "groupTitle": "Province"
  },
  {
    "type": "put",
    "url": "/provinces/:id",
    "title": "Update Province",
    "name": "UpdateProvince",
    "group": "Province",
    "parameter": {
      "fields": {
        "System Generated": [
          {
            "group": "System Generated",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Province unique ID.</p>"
          }
        ],
        "Body Params": [
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>code of the Province.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of the Province.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "region_id",
            "description": "<p>Region ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Province ID.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>Code of the Province.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>Name of the Province.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Province is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Province is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Province is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "region_id",
            "description": "<p>Region ID referenced from Region.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n      \"province\": {\n          \"id\": \"58b66509-40d8-4600-9b32-56619fc6c0b5\",\n          \"code\": \"CAV\",\n          \"name\": \"Cavite\",\n          \"created\": \"2018-07-11T00:58:10.000Z\",\n          \"updated\": \"2018-07-11T01:01:34.000Z\",\n          \"deleted\": null,\n          \"region_id\": \"8c0d476e-ed0b-4e8f-9f6c-fe54ba4d6be4\"\n      }\n      \"success\": true\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ProvinceController.js",
    "groupTitle": "Province"
  },
  {
    "type": "post",
    "url": "/regions",
    "title": "Add Region",
    "name": "AddRegion",
    "group": "Region",
    "parameter": {
      "fields": {
        "System Generated": [
          {
            "group": "System Generated",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Region unique ID.</p>"
          }
        ],
        "Body Params": [
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>Code of the Region.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>Name of the Region.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "country_id",
            "description": "<p>Country ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Region ID.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>Code of the Region.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>Name of the Region.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Region is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Region is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Region is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "country_id",
            "description": "<p>Country ID referenced from Country.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n      \"message\": \"successfully created new region\",\n      \"region\": {\n          \"id\": \"8c0d476e-ed0b-4e8f-9f6c-fe54ba4d6be4\",\n          \"created\": {\n              \"val\": \"NOW()\"\n          },\n          \"updated\": null,\n          \"deleted\": null,\n          \"country_id\": \"cb86f578-06b9-4298-9256-1a5552854435\",\n          \"code\": \"NCR\",\n          \"name\": \"National Capital Region\"\n      }\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/RegionController.js",
    "groupTitle": "Region"
  },
  {
    "type": "post",
    "url": "/regions/:id/deactivate",
    "title": "Deactivate Region",
    "name": "DeactivateRegion",
    "group": "Region",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Region unique ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Region ID.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>Code of the Region.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>Name of the Region.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Region is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Region is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Region is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "country_id",
            "description": "<p>Country ID referenced from Country.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n     \"region\": {\n          \"id\": \"8c0d476e-ed0b-4e8f-9f6c-fe54ba4d6be4\",\n          \"code\": \"CAL\",\n          \"name\": \"Calabarzon\",\n          \"created\": \"2018-07-10T08:09:27.000Z\",\n          \"updated\": \"2018-07-10T08:14:29.000Z\",\n          \"deleted\": \"2018-07-10T08:18:19.000Z\",\n          \"country_id\": \"cb86f578-06b9-4298-9256-1a5552854435\"\n      },\n      \"message\": \"deactivated region: 8c0d476e-ed0b-4e8f-9f6c-fe54ba4d6be4\"\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/RegionController.js",
    "groupTitle": "Region"
  },
  {
    "type": "get",
    "url": "/regions/:id",
    "title": "Retrieve Region By ID",
    "name": "GetRegionByID",
    "group": "Region",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Region unique ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Region ID.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>Code of the Region.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>Name of the Region.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Region is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Region is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Region is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "country_id",
            "description": "<p>Country ID referenced from Country.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "country_id.id",
            "description": "<p>Country ID.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "country_id.code",
            "description": "<p>Code of the Country.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "country_id.name",
            "description": "<p>Code of the Country.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n      \"region\": [\n          {\n              \"id\": \"b157ed7b-1060-4a35-ae24-67aa0a14e20f\",\n              \"code\": \"NCR\",\n              \"name\": \"National Capital Region\",\n              \"created\": \"2018-07-09T01:58:49.000Z\",\n              \"updated\": null,\n              \"deleted\": null,\n              \"country_id\": \"406405a2-8255-48d0-86c6-7f1109d10e30\",\n              \"country\": {\n                  \"id\": \"406405a2-8255-48d0-86c6-7f1109d10e30\",\n                  \"code\": \"PH\",\n                  \"name\": \"Philippines\"\n              }\n          }\n      ],\n      \"success\": true\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/RegionController.js",
    "groupTitle": "Region"
  },
  {
    "type": "get",
    "url": "/regions",
    "title": "Retrieve Regions",
    "name": "GetRegions",
    "group": "Region",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Region ID.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>Code of the Region.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>Name of the Region.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Region is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Region is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Region is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "country_id",
            "description": "<p>Country ID referenced from Country.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "country_id.id",
            "description": "<p>Country ID.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "country_id.code",
            "description": "<p>Code of the Country.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "country_id.name",
            "description": "<p>Code of the Country.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n      \"regions\": [\n          {\n              \"id\": \"b157ed7b-1060-4a35-ae24-67aa0a14e20f\",\n              \"code\": \"NCR\",\n              \"name\": \"National Capital Region\",\n              \"created\": \"2018-07-09T01:58:49.000Z\",\n              \"updated\": null,\n              \"deleted\": null,\n              \"country_id\": \"406405a2-8255-48d0-86c6-7f1109d10e30\",\n              \"country\": {\n                  \"id\": \"406405a2-8255-48d0-86c6-7f1109d10e30\",\n                  \"code\": \"PH\",\n                  \"name\": \"Philippines\"\n              }\n          }\n      ],\n      \"success\": true\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/RegionController.js",
    "groupTitle": "Region"
  },
  {
    "type": "post",
    "url": "/regions/:id/reactivate",
    "title": "Reactivate Region",
    "name": "ReactivateRegion",
    "group": "Region",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Region unique ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Region ID.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>Code of the Region.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>Name of the Region.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Region is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Region is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Region is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "country_id",
            "description": "<p>Country ID referenced from Country.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n     \n      \"region\": {\n          \"id\": \"8c0d476e-ed0b-4e8f-9f6c-fe54ba4d6be4\",\n          \"code\": \"CAL\",\n          \"name\": \"Calabarzon\",\n          \"created\": \"2018-07-10T08:09:27.000Z\",\n          \"updated\": \"2018-07-10T08:14:29.000Z\",\n          \"deleted\": null,\n          \"country_id\": \"cb86f578-06b9-4298-9256-1a5552854435\"\n      },\n      \"message\": \"reactivated region: 8c0d476e-ed0b-4e8f-9f6c-fe54ba4d6be4\"\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/RegionController.js",
    "groupTitle": "Region"
  },
  {
    "type": "get",
    "url": "/regions/search",
    "title": "Search Region",
    "name": "SearchRegion",
    "group": "Region",
    "parameter": {
      "fields": {
        "Query Params": [
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>code of the Region</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of the Region</p>"
          },
          {
            "group": "Query Params",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Region is created.</p>"
          },
          {
            "group": "Query Params",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Region is updated.</p>"
          },
          {
            "group": "Query Params",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Region is deleted.</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "country_id",
            "description": "<p>Country ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Region ID.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>Code of the Region.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>Name of the Region.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Region is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Region is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Region is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "country_id",
            "description": "<p>Country ID referenced from Country.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n     \"regions\": [\n          {\n              \"id\": \"8c0d476e-ed0b-4e8f-9f6c-fe54ba4d6be4\",\n              \"code\": \"CAL\",\n              \"name\": \"Calabarzon\",\n              \"created\": \"2018-07-10T08:09:27.000Z\",\n              \"updated\": \"2018-07-10T08:14:29.000Z\",\n              \"deleted\": null,\n              \"country_id\": \"cb86f578-06b9-4298-9256-1a5552854435\"\n          }\n      ],\n      \"success\": true\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/RegionController.js",
    "groupTitle": "Region"
  },
  {
    "type": "put",
    "url": "/regions/:id",
    "title": "Update Region",
    "name": "UpdateRegionByID",
    "group": "Region",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Region unique ID.</p>"
          }
        ],
        "Body Params": [
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>code of the Country.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of the Country.</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "country_id",
            "description": "<p>Country ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Region ID.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>Code of the Region.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>Name of the Region.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the Region is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the Region is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the Region is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "country_id",
            "description": "<p>Country ID referenced from Country.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n     \"region\": {\n          \"id\": \"8c0d476e-ed0b-4e8f-9f6c-fe54ba4d6be4\",\n          \"code\": \"CAL\",\n          \"name\": \"Calabarzon\",\n          \"created\": \"2018-07-10T08:09:27.000Z\",\n          \"updated\": \"2018-07-10T08:14:29.000Z\",\n          \"deleted\": null,\n          \"country_id\": \"cb86f578-06b9-4298-9256-1a5552854435\"\n      },\n      \"message\": \"updated region: 8c0d476e-ed0b-4e8f-9f6c-fe54ba4d6be4\"\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/RegionController.js",
    "groupTitle": "Region"
  },
  {
    "type": "post",
    "url": "/sub-districts",
    "title": "addSubDistrict",
    "group": "SubDistrict",
    "name": "addSubDistrict",
    "parameter": {
      "fields": {
        "System Generated": [
          {
            "group": "System Generated",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of subdistrict</p>"
          }
        ],
        "Body Params": [
          {
            "group": "Body Params",
            "type": "Character",
            "optional": false,
            "field": "code",
            "description": "<p>code of subdistrict</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of subdistrict</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "district_id",
            "description": "<p>district_id of subdistrict referenced from district</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the sub-district</p>"
          },
          {
            "group": "Success 200",
            "type": "Character",
            "optional": false,
            "field": "code",
            "description": "<p>code of sub-district</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of sub-district</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "district_id",
            "description": "<p>district_id of sub-district referenced from district</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the sub-district is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the sub-district is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the sub-district is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Message",
            "description": "<p>Successfully created new sub_district</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n{\n    \"message\": \"Successfully created new sub_district\",\n    \"sub_district\": {\n        \"id\": \"53d3ac42-675b-49bd-bb51-b0a000f196f1\",\n        \"created\": {\n            \"val\": \"NOW()\"\n        },\n        \"updated\": null,\n        \"deleted\": null,\n        \"district_id\": \"7db0be44-a06f-4e27-a8be-81fa7078075e\",\n        \"code\": \"LB\",\n        \"name\": \"Los Banos\"\n    },\n    \"success\" : true\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "Error 500": [
          {
            "group": "Error 500",
            "type": "Number",
            "optional": false,
            "field": "status",
            "description": "<p>status code</p>"
          },
          {
            "group": "Error 500",
            "type": "String",
            "optional": false,
            "field": "message",
            "description": "<p>Error message</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Internal Server Error\n{\n  \"status\": 500,\n  \"message\": \"Internal server error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/SubDistrictController.js",
    "groupTitle": "SubDistrict"
  },
  {
    "type": "deactivate",
    "url": "/sub-districts/:id/deactivate",
    "title": "deactivateSubDistrict",
    "group": "SubDistrict",
    "name": "deactivateSubDistrict",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the sub-district</p>"
          },
          {
            "group": "Success 200",
            "type": "Character",
            "optional": false,
            "field": "code",
            "description": "<p>code of sub-district</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of sub-district</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "district_id",
            "description": "<p>district_id of sub-district referenced from district</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the sub-district is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the sub-district is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the sub-district is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Message",
            "description": "<p>deactivated subdistrict + id</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n{\n    \"sub_district\": {\n           \"id\": \"68d365f7-354f-4437-9b7d-7c616b8883f6\",\n           \"code\": \"SP\",\n           \"name\": \"San Pablo City\",\n           \"created\": \"2018-07-11T02:17:08.000Z\",\n           \"updated\": \"2018-07-11T02:20:11.000Z\",\n           \"deleted\": \"2018-07-11T02:23:34.000Z\",\n           \"district_id\": \"d9ea75ae-1f3c-48d3-8b18-d2c30c84c38d\"\n       },\n    \"message\": \"deactivated sub_district: 68d365f7-354f-4437-9b7d-7c616b8883f6\",\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/SubDistrictController.js",
    "groupTitle": "SubDistrict"
  },
  {
    "type": "getOne",
    "url": "/sub-districts/:id",
    "title": "getOneSubDistrict",
    "group": "SubDistrict",
    "name": "getOneSubDistrict",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the sub-district</p>"
          },
          {
            "group": "Success 200",
            "type": "Character",
            "optional": false,
            "field": "code",
            "description": "<p>code of sub-district</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of sub-district</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "district_id",
            "description": "<p>district_id of sub-district referenced from district</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the sub-district is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the sub-district is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the sub-district is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n{\n    \"sub_district\": \n        {\n         \"id\": \"53d3ac42-675b-49bd-bb51-b0a000f196f1\",\n         \"code\": \"LB\",\n         \"name\": \"Los Banos\",\n         \"created\": \"2018-07-11T02:07:01.000Z\",\n         \"updated\": null,\n         \"deleted\": null,\n         \"district_id\": \"7db0be44-a06f-4e27-a8be-81fa7078075e\",\n         \"district\": {\n             \"id\": \"7db0be44-a06f-4e27-a8be-81fa7078075e\",\n             \"code\": \"D2\",\n             \"name\": \"District2\",\n             \"province\": {\n                 \"id\": \"3390ede7-e509-4f06-97b2-8580c29dfb3c\",\n                 \"code\": \"p\",\n                 \"name\": \"province\",\n                 \"region\": {\n                     \"id\": \"84d0f129-a195-486e-8c63-012857af6f1a\",\n                     \"code\": \"NCR\",\n                     \"name\": \"National Capital Region\",\n                     \"country\": {\n                         \"id\": \"79dd673a-3c03-47bc-8957-c47ffcb33ef2\",\n                         \"code\": \"PH\",\n                         \"name\": \"Philippines\"\n                     }\n                 }\n             }\n         }\n     },\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/SubDistrictController.js",
    "groupTitle": "SubDistrict"
  },
  {
    "type": "get",
    "url": "/sub-districts",
    "title": "getSubDistricts",
    "group": "SubDistrict",
    "name": "getSubDistricts",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the sub-district</p>"
          },
          {
            "group": "Success 200",
            "type": "Character",
            "optional": false,
            "field": "code",
            "description": "<p>code of sub-district</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of sub-district</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "district_id",
            "description": "<p>district_id of sub-district referenced from district</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the sub-district is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the sub-district is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the sub-district is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n{\n \"sub_districts\": [\n       {\n           \"id\": \"53d3ac42-675b-49bd-bb51-b0a000f196f1\",\n           \"code\": \"LB\",\n           \"name\": \"Los Banos\",\n           \"created\": \"2018-07-11T02:07:01.000Z\",\n           \"updated\": null,\n           \"deleted\": null,\n           \"district_id\": \"7db0be44-a06f-4e27-a8be-81fa7078075e\",\n           \"district\": {\n               \"id\": \"7db0be44-a06f-4e27-a8be-81fa7078075e\",\n               \"code\": \"D2\",\n               \"name\": \"District2\",\n               \"province\": {\n                   \"id\": \"3390ede7-e509-4f06-97b2-8580c29dfb3c\",\n                   \"code\": \"p\",\n                   \"name\": \"province\",\n                   \"region\": {\n                       \"id\": \"84d0f129-a195-486e-8c63-012857af6f1a\",\n                       \"code\": \"NCR\",\n                       \"name\": \"National Capital Region\",\n                       \"country\": {\n                           \"id\": \"79dd673a-3c03-47bc-8957-c47ffcb33ef2\",\n                           \"code\": \"PH\",\n                           \"name\": \"Philippines\"\n                       }\n                   }\n               }\n           }\n       },\n       {\n           \"id\": \"68d365f7-354f-4437-9b7d-7c616b8883f6\",\n           \"code\": \"SP\",\n           \"name\": \"San Pablo City\",\n           \"created\": \"2018-07-11T02:17:08.000Z\",\n           \"updated\": \"2018-07-11T02:20:11.000Z\",\n           \"deleted\": null,\n           \"district_id\": \"d9ea75ae-1f3c-48d3-8b18-d2c30c84c38d\",\n           \"district\": {\n               \"id\": \"d9ea75ae-1f3c-48d3-8b18-d2c30c84c38d\",\n               \"code\": \"D3\",\n               \"name\": \"District Three\",\n               \"province\": {\n                   \"id\": \"3390ede7-e509-4f06-97b2-8580c29dfb3c\",\n                   \"code\": \"p\",\n                   \"name\": \"province\",\n                   \"region\": {\n                       \"id\": \"84d0f129-a195-486e-8c63-012857af6f1a\",\n                       \"code\": \"NCR\",\n                       \"name\": \"National Capital Region\",\n                       \"country\": {\n                           \"id\": \"79dd673a-3c03-47bc-8957-c47ffcb33ef2\",\n                           \"code\": \"PH\",\n                           \"name\": \"Philippines\"\n                       }\n                   }\n               }\n           }\n       },\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "Error 500": [
          {
            "group": "Error 500",
            "type": "Number",
            "optional": false,
            "field": "status",
            "description": "<p>status code</p>"
          },
          {
            "group": "Error 500",
            "type": "String",
            "optional": false,
            "field": "message",
            "description": "<p>Error message</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Internal Server Error\n{\n  \"status\": 500,\n  \"message\": \"Internal server error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/SubDistrictController.js",
    "groupTitle": "SubDistrict"
  },
  {
    "type": "reactivate",
    "url": "/sub-districts/:id/reactivate",
    "title": "reactivateSubDistrict",
    "group": "SubDistrict",
    "name": "reactivateSubDistrict",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the sub-district</p>"
          },
          {
            "group": "Success 200",
            "type": "Character",
            "optional": false,
            "field": "code",
            "description": "<p>code of sub-district</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of sub-district</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "district_id",
            "description": "<p>district_id of sub-district referenced from district</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the sub-district is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the sub-district is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the sub-district is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Message",
            "description": "<p>reactivated sub_district + id</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n{\n    \"sub_district\": {\n           \"id\": \"68d365f7-354f-4437-9b7d-7c616b8883f6\",\n           \"code\": \"SP\",\n           \"name\": \"San Pablo City\",\n           \"created\": \"2018-07-11T02:17:08.000Z\",\n           \"updated\": \"2018-07-11T02:20:11.000Z\",\n           \"deleted\": null,\n           \"district_id\": \"d9ea75ae-1f3c-48d3-8b18-d2c30c84c38d\"\n       },\n    \"message\": \"reactivated sub_district: 68d365f7-354f-4437-9b7d-7c616b8883f6\",\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/SubDistrictController.js",
    "groupTitle": "SubDistrict"
  },
  {
    "type": "search",
    "url": "/sub-district/:id",
    "title": "searchSubDistrict",
    "group": "SubDistrict",
    "name": "searchSubDistrict",
    "parameter": {
      "fields": {
        "Query Params": [
          {
            "group": "Query Params",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of sub-district</p>"
          },
          {
            "group": "Query Params",
            "type": "Character",
            "optional": false,
            "field": "code",
            "description": "<p>code of sub-district</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of sub-district</p>"
          },
          {
            "group": "Query Params",
            "type": "String",
            "optional": false,
            "field": "district_id",
            "description": "<p>district_id of sub-district referenced from district</p>"
          },
          {
            "group": "Query Params",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the sub-district is created</p>"
          },
          {
            "group": "Query Params",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the sub-district is updated</p>"
          },
          {
            "group": "Query Params",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the sub-district is deleted</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the sub-district</p>"
          },
          {
            "group": "Success 200",
            "type": "Character",
            "optional": false,
            "field": "code",
            "description": "<p>code of sub-district</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of sub-district</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "district_id",
            "description": "<p>district_id of sub-district referenced from district</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the sub-district is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the sub-district is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the sub-district is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n{\n    \"sub_districts\": [\n        {\n            \"id\": \"68d365f7-354f-4437-9b7d-7c616b8883f6\",\n            \"code\": \"SP\",\n            \"name\": \"San Pablo City\",\n            \"created\": \"2018-07-11T02:17:08.000Z\",\n            \"updated\": \"2018-07-11T02:20:11.000Z\",\n            \"deleted\": null,\n            \"district_id\": \"d9ea75ae-1f3c-48d3-8b18-d2c30c84c38d\"\n        }\n    ],\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/SubDistrictController.js",
    "groupTitle": "SubDistrict"
  },
  {
    "type": "put",
    "url": "/sub-districts/:id",
    "title": "updateSubDistrict",
    "group": "SubDistrict",
    "name": "updateSubDistrict",
    "parameter": {
      "fields": {
        "Body Params": [
          {
            "group": "Body Params",
            "type": "Character",
            "optional": false,
            "field": "code",
            "description": "<p>code of sub-district</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of sub-district</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "district_id",
            "description": "<p>district_id of sub-district referenced from district</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the sub-district</p>"
          },
          {
            "group": "Success 200",
            "type": "Character",
            "optional": false,
            "field": "code",
            "description": "<p>code of sub-district</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of sub-district</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "district_id",
            "description": "<p>district_id of sub-district referenced from district</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the sub-district is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the sub-district is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the sub-district is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Message",
            "description": "<p>update sub-district + id</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n{\n    \"sub_district\": \n        {\n            \"id\": \"53d3ac42-675b-49bd-bb51-b0a000f196f1\",\n            \"code\": \"LB\",\n            \"name\": \"Los Banos Sub District\",\n            \"created\": \"2018-07-11T02:07:01.000Z\",\n            \"updated\": \"2018-07-11T02:20:11.000Z\",\n            \"deleted\": null,\n            \"district_id\": \"7db0be44-a06f-4e27-a8be-81fa7078075e\"\n        },\n       \"message\": \"update sub-district: 53d3ac42-675b-49bd-bb51-b0a000f196f1\",\n       \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/SubDistrictController.js",
    "groupTitle": "SubDistrict"
  },
  {
    "type": "post",
    "url": "/v1/users",
    "title": "Add User",
    "group": "User",
    "name": "Add_User",
    "parameter": {
      "fields": {
        "System Generated": [
          {
            "group": "System Generated",
            "type": "Integer",
            "optional": false,
            "field": "id",
            "description": "<p>unique ID</p>"
          }
        ],
        "Body Params": [
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "email",
            "description": "<p>email of user</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "password",
            "description": "<p>password of user</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "first_name",
            "description": "<p>first_name</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "middle_name",
            "description": "<p>middle_name</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "last_name",
            "description": "<p>last_name</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "contact_number",
            "description": "<p>contact number</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "user",
            "description": "<p>new user</p>"
          },
          {
            "group": "Success 200",
            "type": "Integer",
            "optional": false,
            "field": "user.id",
            "description": "<p>ID of user</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user.email",
            "description": "<p>email of user</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user.password",
            "description": "<p>encrypted password of user</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user.first_name",
            "description": "<p>first name of user</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user.middle_name",
            "description": "<p>middle name of user</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user.last_name",
            "description": "<p>last name of user</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user.contact_number",
            "description": "<p>contact_number of user</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "user.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "user.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "user.deleted",
            "description": "<p>timestamp of deletion</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "token",
            "description": "<p>valid token</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n    \"message\": \"successfully created new user\",\n    \"user\": {\n        \"created\": {\n            \"val\": \"NOW()\"\n        },\n        \"updated\": null,\n        \"deleted\": null,\n        \"id\": 4,\n        \"email\": \"aporca@gmail.com\",\n        \"password\": \"$2b$10$Vmkh7/x2v6O7I9dtdSOzSusCeo3oRE1bgacgsMEA7ZqNQXOcUb3fq\",\n        \"first_name\": \"antonette\",\n        \"middle_name\": \"middle\",\n        \"last_name\": \"porca\",\n        \"updatedAt\": \"2018-07-12T02:02:21.947Z\",\n        \"createdAt\": \"2018-07-12T02:02:21.947Z\"\n    },\n    \"token\": \"Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjo0LCJpYXQiOjE1MzEzNjA5NDIsImV4cCI6MTUzMTM3MDk0MiwianRpIjoiMTk5NjcwM2YtNDIyZi00NTRhLThiNjItOTFlZDdiMWYyMmUxIn0.LK1B0buga_TQGAv2F6-izTiEMI3818O09Skt6Cp6DqM\",\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/UserController.js",
    "groupTitle": "User"
  },
  {
    "type": "get",
    "url": "/v1/users",
    "title": "Get User",
    "group": "User",
    "name": "Get_User",
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "authorization",
            "description": "<p>jwt token ex: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoxLCJpYXQiOjE1MzEyODk2MDQsImV4cCI6MTUzMTI5OTYwNCwianRpIjoiMGU0Y2JiNDctYjk4Yy00MTMxLWFhMDAtNGIwNmZjYWZmMGQ0In0.6TgWivCAefsoMnmJ0uaeth8-1mW-Z8CLPc_V_rX37I0</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "user",
            "description": "<p>new user</p>"
          },
          {
            "group": "Success 200",
            "type": "Integer",
            "optional": false,
            "field": "user.id",
            "description": "<p>ID of user</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user.email",
            "description": "<p>email of user</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user.password",
            "description": "<p>encrypted password of user</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user.first_name",
            "description": "<p>first name of user</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user.middle_name",
            "description": "<p>middle name of user</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user.last_name",
            "description": "<p>last name of user</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user.contact_number",
            "description": "<p>contact_number of user</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "user.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "user.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "user.deleted",
            "description": "<p>timestamp of deletion</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "token",
            "description": "<p>valid token</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n    \"user\": {\n        \"id\": 3,\n        \"email\": \"jdelacruz@gmail.com\",\n        \"password\": \"$2b$10$/1JsJ2x9xaSeYtsgd3TE.OXkfz1z4apVvLWhJQwVKXlI0nUY4J1j2\",\n        \"first_name\": \"juan\",\n        \"last_name\": \"delacruz\",\n        \"middle_name\": \"reyes\",\n        \"contact_number\": null,\n        \"created\": \"2018-07-12T01:36:45.000Z\",\n        \"updated\": \"2018-07-12T01:53:58.000Z\",\n        \"deleted\": null,\n        \"createdAt\": \"2018-07-12T01:36:45.000Z\",\n        \"updatedAt\": \"2018-07-12T01:53:58.000Z\"\n    },\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/UserController.js",
    "groupTitle": "User"
  },
  {
    "type": "post",
    "url": "/users/login",
    "title": "Log in",
    "group": "User",
    "name": "Log_in",
    "parameter": {
      "fields": {
        "Body Params": [
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "email",
            "description": "<p>email</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "password",
            "description": "<p>password</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "token",
            "description": "<p>valid token</p>"
          },
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "user",
            "description": "<p>new user</p>"
          },
          {
            "group": "Success 200",
            "type": "Integer",
            "optional": false,
            "field": "user.id",
            "description": "<p>ID of user</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user.email",
            "description": "<p>email of user</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user.password",
            "description": "<p>encrypted password of user</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user.first_name",
            "description": "<p>first name of user</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user.middle_name",
            "description": "<p>middle name of user</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user.last_name",
            "description": "<p>last name of user</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "user.contact_number",
            "description": "<p>contact_number of user</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "user.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "user.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "user.deleted",
            "description": "<p>timestamp of deletion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n    \"token\": \"Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjozLCJpYXQiOjE1MzEzNTk0NjYsImV4cCI6MTUzMTM2OTQ2NiwianRpIjoiNzM1OTU4NjEtNjExMS00ZGZkLWEzODEtNWY2MTA1MzhmYjYxIn0.3b7P3MzHrr9LICXvfyKGdcPicZZAcm_-yVc2u5bEQeI\",\n    \"user\": {\n        \"id\": 3,\n        \"email\": \"jdelacruz@gmail.com\",\n        \"password\": \"$2b$10$e9wuucvYYcyxH0M5cYnOH.RDo7vL6ZZ3pVNBlxRJYCQ1lWtikZ8VW\",\n        \"first_name\": \"juan\",\n        \"last_name\": \"delacruz\",\n        \"middle_name\": \"reyes\",\n        \"contact_number\": null,\n        \"created\": \"2018-07-12T01:36:45.000Z\",\n        \"updated\": null,\n        \"deleted\": null,\n        \"createdAt\": \"2018-07-12T01:36:45.000Z\",\n        \"updatedAt\": \"2018-07-12T01:36:45.000Z\"\n    },\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/UserController.js",
    "groupTitle": "User"
  },
  {
    "type": "del",
    "url": "/v1/users",
    "title": "Remove User",
    "group": "User",
    "name": "Remove_User",
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "authorization",
            "description": "<p>jwt token ex: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoxLCJpYXQiOjE1MzEyODk2MDQsImV4cCI6MTUzMTI5OTYwNCwianRpIjoiMGU0Y2JiNDctYjk4Yy00MTMxLWFhMDAtNGIwNmZjYWZmMGQ0In0.6TgWivCAefsoMnmJ0uaeth8-1mW-Z8CLPc_V_rX37I0</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n    \"message\": \"deleted user\",\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/UserController.js",
    "groupTitle": "User"
  },
  {
    "type": "put",
    "url": "/v1/users",
    "title": "Update User",
    "group": "User",
    "name": "Update_User",
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "authorization",
            "description": "<p>jwt token ex: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoxLCJpYXQiOjE1MzEyODk2MDQsImV4cCI6MTUzMTI5OTYwNCwianRpIjoiMGU0Y2JiNDctYjk4Yy00MTMxLWFhMDAtNGIwNmZjYWZmMGQ0In0.6TgWivCAefsoMnmJ0uaeth8-1mW-Z8CLPc_V_rX37I0</p>"
          }
        ]
      }
    },
    "parameter": {
      "fields": {
        "Body Params": [
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "first_name",
            "description": "<p>first_name</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "middle_name",
            "description": "<p>middle_name</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "last_name",
            "description": "<p>last_name</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "contact_number",
            "description": "<p>contact number</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n    \"message\": \"update user: jdelacruz@gmail.com\",\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/UserController.js",
    "groupTitle": "User"
  },
  {
    "type": "post",
    "url": "/v1/vehicles",
    "title": "Add Vehicle",
    "group": "Vehicle",
    "name": "Add_Vehicle",
    "parameter": {
      "fields": {
        "System Generated": [
          {
            "group": "System Generated",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>unique ID</p>"
          }
        ],
        "Body Params": [
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "plate_number",
            "description": "<p>plate number of vehicle</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "type",
            "description": "<p>type of vehicle</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "model",
            "description": "<p>model of vehicle</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "vehicle",
            "description": "<p>new vehicle</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "vehicle.id",
            "description": "<p>ID of vehicle</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "vehicle.code",
            "description": "<p>code of vehicle</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "vehicle.name",
            "description": "<p>name of vehicle</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "vehicle.address",
            "description": "<p>address of vehicle</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "vehicle.country",
            "description": "<p>country</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "vehicle.region",
            "description": "<p>region</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "vehicle.province",
            "description": "<p>province</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "vehicle.district",
            "description": "<p>district</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "vehicle.sub_district",
            "description": "<p>sub_district</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "vehicle.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "vehicle.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "vehicle.deleted",
            "description": "<p>timestamp of deletion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n    \"message\": \"successfully created new vehicle\",\n    \"vehicle\": {\n        \"id\": \"fe4a9a8e-4454-4b7b-b855-ba785efa0c04\",\n        \"created\": {\n            \"val\": \"NOW()\"\n        },\n        \"updated\": null,\n        \"deleted\": null,\n        \"plate_number\": \"LTO 1234\",\n        \"type\": \"motorcycle\",\n        \"model\": \"Honda Wave\"\n    },\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "Error 422": [
          {
            "group": "Error 422",
            "type": "Number",
            "optional": false,
            "field": "status",
            "description": "<p>status code</p>"
          },
          {
            "group": "Error 422",
            "type": "String",
            "optional": false,
            "field": "message",
            "description": "<p>Error message</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "./controllers/VehicleController.js",
    "groupTitle": "Vehicle"
  },
  {
    "type": "post",
    "url": "/v1/vehicles/:id/deactivate",
    "title": "Deactivate Vehicle by ID",
    "name": "Deactivate_Vehicle_by_ID",
    "group": "Vehicle",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>Vehicle's unique ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "vehicle",
            "description": "<p>new vehicle</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "vehicle.id",
            "description": "<p>ID of vehicle</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "vehicle.code",
            "description": "<p>code of vehicle</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "vehicle.name",
            "description": "<p>name of vehicle</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "vehicle.address",
            "description": "<p>address of vehicle</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "vehicle.country",
            "description": "<p>country</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "vehicle.region",
            "description": "<p>region</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "vehicle.province",
            "description": "<p>province</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "vehicle.district",
            "description": "<p>district</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "vehicle.sub_district",
            "description": "<p>sub_district</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "vehicle.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "vehicle.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "vehicle.deleted",
            "description": "<p>timestamp of deletion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n    \"message\": \"deactivated vehicle\",\n   \"vehicle\": {\n        \"id\": \"fe4a9a8e-4454-4b7b-b855-ba785efa0c04\",\n        \"plate_number\": \"LTO 1234\",\n        \"type\": \"motorcycle\",\n        \"model\": \"Honda Wave\",\n        \"created\": \"2018-07-11T02:56:29.000Z\",\n        \"updated\": null,\n        \"deleted\": \"2018-07-11T03:25:32.000Z\"\n    },\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "Error 422": [
          {
            "group": "Error 422",
            "type": "Number",
            "optional": false,
            "field": "status",
            "description": "<p>status code</p>"
          },
          {
            "group": "Error 422",
            "type": "String",
            "optional": false,
            "field": "message",
            "description": "<p>Error message</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "./controllers/VehicleController.js",
    "groupTitle": "Vehicle"
  },
  {
    "type": "get",
    "url": "/v1/vehicles/:id",
    "title": "Get Vehicle by ID",
    "group": "Vehicle",
    "name": "Get_Vehicle_by_ID",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>Vehicle's unique ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "vehicle",
            "description": "<p>new vehicle</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "vehicle.id",
            "description": "<p>ID of vehicle</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "vehicle.code",
            "description": "<p>code of vehicle</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "vehicle.name",
            "description": "<p>name of vehicle</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "vehicle.address",
            "description": "<p>address of vehicle</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "vehicle.country",
            "description": "<p>country</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "vehicle.region",
            "description": "<p>region</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "vehicle.province",
            "description": "<p>province</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "vehicle.district",
            "description": "<p>district</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "vehicle.sub_district",
            "description": "<p>sub_district</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "vehicle.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "vehicle.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "vehicle.deleted",
            "description": "<p>timestamp of deletion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n   \"vehicle\": {\n     \"id\": \"ed7b7aa2-aa55-4486-bcb7-725b9c558bd3\",\n     \"plate_number\": \"TRX 1221\",\n     \"type\": \"truck\",\n     \"model\": \"Nissan Navara\",\n    \"created\": \"2018-07-11T02:59:39.000Z\",\n    \"updated\": null,\n     \"deleted\": null\n }\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "Error 422": [
          {
            "group": "Error 422",
            "type": "Number",
            "optional": false,
            "field": "status",
            "description": "<p>status code</p>"
          },
          {
            "group": "Error 422",
            "type": "String",
            "optional": false,
            "field": "message",
            "description": "<p>Error message</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "./controllers/VehicleController.js",
    "groupTitle": "Vehicle"
  },
  {
    "type": "get",
    "url": "/v1/vehicles",
    "title": "Get Vehicles",
    "group": "Vehicle",
    "name": "Get_Vehicles",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object[]",
            "optional": false,
            "field": "vehicles",
            "description": "<p>array of vehicles</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "vehicles.id",
            "description": "<p>ID of vehicle</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "vehicles.code",
            "description": "<p>code of vehicle</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "vehicles.name",
            "description": "<p>name of vehicle</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "vehicles.address",
            "description": "<p>address of vehicle</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "vehicles.country",
            "description": "<p>country</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "vehicles.region",
            "description": "<p>region</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "vehicles.province",
            "description": "<p>province</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "vehicles.district",
            "description": "<p>district</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "vehicles.sub_district",
            "description": "<p>sub_district</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "vehicles.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "vehicles.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "vehicles.deleted",
            "description": "<p>timestamp of deletion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n   \"vehicles\": [\n       {\n           \"id\": \"ed7b7aa2-aa55-4486-bcb7-725b9c558bd3\",\n           \"plate_number\": \"TRX 1221\",\n           \"type\": \"truck\",\n           \"model\": \"Nissan Navara\",\n           \"created\": \"2018-07-11T02:59:39.000Z\",\n           \"updated\": null,\n           \"deleted\": null\n       },\n       {\n           \"id\": \"fe4a9a8e-4454-4b7b-b855-ba785efa0c04\",\n           \"plate_number\": \"LTO 1234\",\n           \"type\": \"motorcycle\",\n           \"model\": \"Honda Wave\",\n           \"created\": \"2018-07-11T02:56:29.000Z\",\n           \"updated\": null,\n           \"deleted\": null\n       }\n   ],\n   \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "Error 422": [
          {
            "group": "Error 422",
            "type": "Number",
            "optional": false,
            "field": "status",
            "description": "<p>status code</p>"
          },
          {
            "group": "Error 422",
            "type": "String",
            "optional": false,
            "field": "message",
            "description": "<p>Error message</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "./controllers/VehicleController.js",
    "groupTitle": "Vehicle"
  },
  {
    "type": "post",
    "url": "/v1/vehicles/:id/reactivate",
    "title": "Reactivate Vehicle by ID",
    "name": "Reactivate_Vehicle_by_ID",
    "group": "Vehicle",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>Vehicle's unique ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "vehicle",
            "description": "<p>new vehicle</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "vehicle.id",
            "description": "<p>ID of vehicle</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "vehicle.code",
            "description": "<p>code of vehicle</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "vehicle.name",
            "description": "<p>name of vehicle</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "vehicle.address",
            "description": "<p>address of vehicle</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "vehicle.country",
            "description": "<p>country</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "vehicle.region",
            "description": "<p>region</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "vehicle.province",
            "description": "<p>province</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "vehicle.district",
            "description": "<p>district</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "vehicle.sub_district",
            "description": "<p>sub_district</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "vehicle.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "vehicle.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "vehicle.deleted",
            "description": "<p>timestamp of deletion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n    \"message\": \"reactivated vehicle\",\n    \"vehicle\": {\n        \"id\": \"fe4a9a8e-4454-4b7b-b855-ba785efa0c04\",\n        \"plate_number\": \"LTO 1234\",\n        \"type\": \"motorcycle\",\n        \"model\": \"Honda Wave\",\n        \"created\": \"2018-07-11T02:56:29.000Z\",\n        \"updated\": null,\n        \"deleted\": null\n    },\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "Error 422": [
          {
            "group": "Error 422",
            "type": "Number",
            "optional": false,
            "field": "status",
            "description": "<p>status code</p>"
          },
          {
            "group": "Error 422",
            "type": "String",
            "optional": false,
            "field": "message",
            "description": "<p>Error message</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "./controllers/VehicleController.js",
    "groupTitle": "Vehicle"
  },
  {
    "type": "get",
    "url": "/v1/ports/search",
    "title": "Search Vehicle",
    "name": "Search_Vehicle",
    "group": "Vehicle",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>unique ID</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "plate_number",
            "description": "<p>plate number of vehicle</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "type",
            "description": "<p>type of vehicle</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "model",
            "description": "<p>model of vehicle</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object[]",
            "optional": false,
            "field": "vehicles",
            "description": "<p>array of vehicles</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "vehicles.id",
            "description": "<p>ID of vehicle</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "vehicles.plate_number",
            "description": "<p>plate_number of vehicle</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "vehicles.type",
            "description": "<p>type of vehicle</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "vehicles.model",
            "description": "<p>model of vehicle</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "vehicles.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "vehicles.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "vehicles.deleted",
            "description": "<p>timestamp of deletion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n    \"vehicle\": [\n        {\n            \"id\": \"05778e25-498a-4738-96ac-243f7b7f27f9\",\n            \"plate_number\": \"PPG 1221\",\n            \"type\": \"truck\",\n            \"model\": \"Nissan Navara\",\n            \"created\": \"2018-07-12T06:33:17.000Z\",\n            \"updated\": null,\n            \"deleted\": null\n        }\n    ],\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "Error 422": [
          {
            "group": "Error 422",
            "type": "Number",
            "optional": false,
            "field": "status",
            "description": "<p>status code</p>"
          },
          {
            "group": "Error 422",
            "type": "String",
            "optional": false,
            "field": "message",
            "description": "<p>Error message</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "./controllers/VehicleController.js",
    "groupTitle": "Vehicle"
  },
  {
    "type": "post",
    "url": "/v1/zones",
    "title": "Add Zone",
    "group": "Zone",
    "name": "Add_Zone",
    "parameter": {
      "fields": {
        "System Generated": [
          {
            "group": "System Generated",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>unique ID</p>"
          }
        ],
        "Body Params": [
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>unique code for each zone</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>ID of the distribution center the zone belongs to (foreign key)</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of zone</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "address",
            "description": "<p>address of the zone</p>"
          },
          {
            "group": "Body Params",
            "type": "char",
            "optional": false,
            "field": "country",
            "description": "<p>country</p>"
          },
          {
            "group": "Body Params",
            "type": "char",
            "optional": false,
            "field": "region",
            "description": "<p>region</p>"
          },
          {
            "group": "Body Params",
            "type": "char",
            "optional": false,
            "field": "province",
            "description": "<p>province</p>"
          },
          {
            "group": "Body Params",
            "type": "char",
            "optional": false,
            "field": "district",
            "description": "<p>district</p>"
          },
          {
            "group": "Body Params",
            "type": "char",
            "optional": false,
            "field": "sub_district",
            "description": "<p>sub_district</p>"
          },
          {
            "group": "Body Params",
            "type": "char",
            "optional": false,
            "field": "barangay",
            "description": "<p>barangay</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "zone",
            "description": "<p>new zone</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "zone.id",
            "description": "<p>ID of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "zone.code",
            "description": "<p>code of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "zone.name",
            "description": "<p>name of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "zone.address",
            "description": "<p>address of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "zone.country",
            "description": "<p>country</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "zone.region",
            "description": "<p>region</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "zone.province",
            "description": "<p>province</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "zone.district",
            "description": "<p>district</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "zone.sub_district",
            "description": "<p>sub_district</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "zone.barangay",
            "description": "<p>barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "zone.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "zone.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "zone.deleted",
            "description": "<p>timestamp of deletion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n    \"message\": \"successfully created new zone\",\n    \"zone\": {\n        \"id\": \"47af714f-cfd9-47e0-ae60-b71cd8ce4856\",\n        \"created\": {\n            \"val\": \"NOW()\"\n        },\n        \"updated\": null,\n        \"deleted\": null,\n        \"distribution_center_id\": \"e5673532-de5b-4886-a24e-a447a58b4782\",\n        \"code\": \"ZN1\",\n        \"name\": \"Zone 1\",\n        \"address\": \"Los Banos\",\n        \"country\": \"PHL\",\n        \"region\": \"4A\",\n        \"province\": \"LGN\",\n        \"district\": \"3\",\n        \"sub_district\": \"\",\n        \"barangay\": \"Maahas\"\n    },\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ZoneController.js",
    "groupTitle": "Zone"
  },
  {
    "type": "getOne",
    "url": "/zone-barangays/:id",
    "title": "getOneZoneBarangay",
    "group": "ZoneBarangay",
    "name": "getOneZoneBarangay",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of zone barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "zone_id",
            "description": "<p>zone_id of zone barangay referenced from zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "barangay_id",
            "description": "<p>barangay_id of zone barangay referenced from barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>code of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "address",
            "description": "<p>address of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "country",
            "description": "<p>country of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "region",
            "description": "<p>region of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "province",
            "description": "<p>province of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "district",
            "description": "<p>district of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "sub_district",
            "description": "<p>sub_district of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "Stirng",
            "optional": false,
            "field": "barangay",
            "description": "<p>barangay of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the zone barangay is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the zone barangay is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the zone barangay is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n {\n    \"zone_barangays\": [\n        {\n            \"id\": \"258b59b7-7907-4d7e-a3bf-961bbdb97a3a\",\n            \"created\": \"2018-07-12T03:20:34.000Z\",\n            \"updated\": null,\n            \"deleted\": null,\n            \"zone_id\": \"2c933419-6a70-4139-b399-7930ad72ee10\",\n            \"barangay_id\": \"89fc14b8-d853-4cb2-9f66-4cc8c08fc767\",\n            \"zone\": {\n                \"code\": \"z1\",\n                \"name\": \"Zone 1\",\n                \"address\": \"Ilag's Compound, Los Banos, Laguna\",\n                \"country\": \"Philippines\",\n                \"region\": \"Calabarzon\",\n                \"province\": \"Laguna\",\n                \"district\": \"District 2\",\n                \"sub_district\": \"Los Banos\",\n                \"barangay\": \"Batong Malake\"\n            },\n            \"barangay\": {\n                \"code\": \"MA\",\n                \"name\": \"MAAHAS\"\n            }\n        }\n    ],\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ZoneBarangayController.js",
    "groupTitle": "ZoneBarangay"
  },
  {
    "type": "get",
    "url": "/zone-barangays",
    "title": "getZoneBarangays",
    "group": "ZoneBarangay",
    "name": "getZoneBarangays",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>ID of zone barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "zone_id",
            "description": "<p>zone_id of zone barangay referenced from zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "barangay_id",
            "description": "<p>barangay_id of zone barangay referenced from barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>code of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "address",
            "description": "<p>address of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "country",
            "description": "<p>country of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "region",
            "description": "<p>region of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "province",
            "description": "<p>province of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "district",
            "description": "<p>district of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "sub_district",
            "description": "<p>sub_district of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "Stirng",
            "optional": false,
            "field": "barangay",
            "description": "<p>barangay of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "created",
            "description": "<p>Date and Time the zone barangay is created.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "updated",
            "description": "<p>Date and Time the zone barangay is updated.</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "deleted",
            "description": "<p>Date and Time the zone barangay is deleted.</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "success",
            "description": "<p>true</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n {\n    \"zone_barangays\": [\n        {\n            \"id\": \"258b59b7-7907-4d7e-a3bf-961bbdb97a3a\",\n            \"created\": \"2018-07-12T03:20:34.000Z\",\n            \"updated\": null,\n            \"deleted\": null,\n            \"zone_id\": \"2c933419-6a70-4139-b399-7930ad72ee10\",\n            \"barangay_id\": \"89fc14b8-d853-4cb2-9f66-4cc8c08fc767\",\n            \"zone\": {\n                \"code\": \"z1\",\n                \"name\": \"Zone 1\",\n                \"address\": \"Ilag's Compound, Los Banos, Laguna\",\n                \"country\": \"Philippines\",\n                \"region\": \"Calabarzon\",\n                \"province\": \"Laguna\",\n                \"district\": \"District 2\",\n                \"sub_district\": \"Los Banos\",\n                \"barangay\": \"Batong Malake\"\n            },\n            \"barangay\": {\n                \"code\": \"MA\",\n                \"name\": \"MAAHAS\"\n            }\n        },\n        {\n            \"id\": \"2638120d-2080-4705-b440-8cf71c255cb6\",\n            \"created\": \"2018-07-12T03:17:43.000Z\",\n            \"updated\": null,\n            \"deleted\": null,\n            \"zone_id\": \"2c933419-6a70-4139-b399-7930ad72ee10\",\n            \"barangay_id\": \"31f39813-9592-433c-ab93-d35de4b69c38\",\n            \"zone\": {\n                \"code\": \"z1\",\n                \"name\": \"Zone 1\",\n                \"address\": \"Ilag's Compound, Los Banos, Laguna\",\n                \"country\": \"Philippines\",\n                \"region\": \"Calabarzon\",\n                \"province\": \"Laguna\",\n                \"district\": \"District 2\",\n                \"sub_district\": \"Los Banos\",\n                \"barangay\": \"Batong Malake\"\n            },\n            \"barangay\": {\n                \"code\": \"BM\",\n                \"name\": \"batong malake\"\n            }\n        }\n    ],\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ZoneBarangayController.js",
    "groupTitle": "ZoneBarangay"
  },
  {
    "type": "post",
    "url": "/v1/zones/:id/deactivate",
    "title": "Deactivate Zone by ID",
    "name": "Deactivate_Zone_by_ID",
    "group": "Zone",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>Zone's unique ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "zone",
            "description": "<p>new zone</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "zone.id",
            "description": "<p>ID of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "zone.code",
            "description": "<p>code of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "zone.name",
            "description": "<p>name of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "zone.address",
            "description": "<p>address of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "zone.country",
            "description": "<p>country</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "zone.region",
            "description": "<p>region</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "zone.province",
            "description": "<p>province</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "zone.district",
            "description": "<p>district</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "zone.sub_district",
            "description": "<p>sub_district</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "zone.barangay",
            "description": "<p>barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "zone.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "zone.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "zone.deleted",
            "description": "<p>timestamp of deletion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "\t{\n       \"message\": \"deactivated zone\",\n       \"zone\": {\n           \"id\": \"47af714f-cfd9-47e0-ae60-b71cd8ce4856\",\n           \"code\": \"ZN1\",\n           \"name\": \"Zone 1\",\n           \"address\": \"Los Banos\",\n           \"country\": \"PHL\",\n           \"region\": \"4A\",\n           \"province\": \"LGN\",\n           \"district\": \"3\",\n           \"sub_district\": null,\n           \"barangay\": \"Bayog\",\n           \"created\": \"2018-07-11T01:33:34.000Z\",\n           \"updated\": \"2018-07-11T01:46:50.000Z\",\n           \"deleted\": \"2018-07-11T01:59:42.000Z\",\n           \"distribution_center_id\": \"e5673532-de5b-4886-a24e-a447a58b4782\"\n       },\n       \"success\": true\n   }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ZoneController.js",
    "groupTitle": "Zone"
  },
  {
    "type": "get",
    "url": "/v1/xones/:id",
    "title": "Get Zone by ID",
    "group": "Zone",
    "name": "Get_Zone_by_ID",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>Users unique ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "zone",
            "description": "<p>new zone</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "zone.id",
            "description": "<p>ID of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "zone.code",
            "description": "<p>code of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "zone.name",
            "description": "<p>name of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "zone.address",
            "description": "<p>address of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "zone.country",
            "description": "<p>country</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "zone.region",
            "description": "<p>region</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "zone.province",
            "description": "<p>province</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "zone.district",
            "description": "<p>district</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "zone.sub_district",
            "description": "<p>sub_district</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "zone.barangay",
            "description": "<p>barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "zone.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "zone.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "zone.deleted",
            "description": "<p>timestamp of deletion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n    \"zone\": {\n        \"id\": \"47af714f-cfd9-47e0-ae60-b71cd8ce4856\",\n        \"code\": \"ZN1\",\n        \"name\": \"Zone 1\",\n        \"address\": \"Los Banos\",\n        \"country\": \"PHL\",\n        \"region\": \"4A\",\n        \"province\": \"LGN\",\n        \"district\": \"3\",\n        \"sub_district\": \"\",\n        \"barangay\": \"Maahas\",\n        \"created\": \"2018-07-11T01:33:34.000Z\",\n        \"updated\": null,\n        \"deleted\": null,\n        \"distribution_center_id\": \"e5673532-de5b-4886-a24e-a447a58b4782\"\n    },\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ZoneController.js",
    "groupTitle": "Zone"
  },
  {
    "type": "get",
    "url": "/v1/zones",
    "title": "Get Zones",
    "group": "Zone",
    "name": "Get_Zones",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object[]",
            "optional": false,
            "field": "zones",
            "description": "<p>array of zones</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "zones.id",
            "description": "<p>ID of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "zones.code",
            "description": "<p>code of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "zones.name",
            "description": "<p>name of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "zones.address",
            "description": "<p>address of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "zones.country",
            "description": "<p>country</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "zones.region",
            "description": "<p>region</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "zones.province",
            "description": "<p>province</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "zones.district",
            "description": "<p>district</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "zones.sub_district",
            "description": "<p>sub_district</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "zones.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "zones.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "zones.deleted",
            "description": "<p>timestamp of deletion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n    \"zones\": [\n        {\n            \"id\": \"47af714f-cfd9-47e0-ae60-b71cd8ce4856\",\n            \"code\": \"ZN1\",\n            \"name\": \"Zone 1\",\n            \"address\": \"Los Banos\",\n            \"country\": \"PHL\",\n            \"region\": \"4A\",\n            \"province\": \"LGN\",\n            \"district\": \"3\",\n            \"sub_district\": \"\",\n            \"barangay\": \"Maahas\",\n            \"created\": \"2018-07-11T01:33:34.000Z\",\n            \"updated\": null,\n            \"deleted\": null,\n            \"distribution_center_id\": \"e5673532-de5b-4886-a24e-a447a58b4782\"\n        },\n        {\n            \"id\": \"9d1d9327-9b86-49c6-8f76-478b1e06bfcf\",\n            \"code\": \"ZN2\",\n            \"name\": \"Zone 2\",\n            \"address\": \"Los Banos\",\n            \"country\": \"PHL\",\n            \"region\": \"4A\",\n            \"province\": \"LGN\",\n            \"district\": \"3\",\n            \"sub_district\": \"\",\n            \"barangay\": \"Anos\",\n            \"created\": \"2018-07-11T01:35:30.000Z\",\n            \"updated\": null,\n            \"deleted\": null,\n            \"distribution_center_id\": \"e5673532-de5b-4886-a24e-a447a58b4782\"\n        }\n    ],\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ZoneController.js",
    "groupTitle": "Zone"
  },
  {
    "type": "post",
    "url": "/v1/zones/:id/reactivate",
    "title": "Reactivate Zone by ID",
    "name": "Reactivate_Zone_by_ID",
    "group": "Zone",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>Zone's unique ID.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "zone",
            "description": "<p>new zone</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "zone.id",
            "description": "<p>ID of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "zone.code",
            "description": "<p>code of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "zone.name",
            "description": "<p>name of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "zone.address",
            "description": "<p>address of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "zone.country",
            "description": "<p>country</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "zone.region",
            "description": "<p>region</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "zone.province",
            "description": "<p>province</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "zone.district",
            "description": "<p>district</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "zone.sub_district",
            "description": "<p>sub_district</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "zone.barangay",
            "description": "<p>barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "zone.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "zone.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "zone.deleted",
            "description": "<p>timestamp of deletion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "\t{\n       \"message\": \"reactivated zone\",\n       \"zone\": {\n           \"id\": \"47af714f-cfd9-47e0-ae60-b71cd8ce4856\",\n           \"code\": \"ZN1\",\n           \"name\": \"Zone 1\",\n           \"address\": \"Los Banos\",\n           \"country\": \"PHL\",\n           \"region\": \"4A\",\n           \"province\": \"LGN\",\n           \"district\": \"3\",\n           \"sub_district\": null,\n           \"barangay\": \"Bayog\",\n           \"created\": \"2018-07-11T01:33:34.000Z\",\n           \"updated\": \"2018-07-11T01:46:50.000Z\",\n           \"deleted\": null,\n           \"distribution_center_id\": \"e5673532-de5b-4886-a24e-a447a58b4782\"\n       },\n       \"success\": true\n   }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ZoneController.js",
    "groupTitle": "Zone"
  },
  {
    "type": "get",
    "url": "/v1/zones/search",
    "title": "Search Zone",
    "name": "Search_Zone",
    "group": "Zone",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>Zone's unique ID</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>unique code for each Zone</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>ID of the distribution center the Zone belongs to (foreign key)</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of Zone</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "address",
            "description": "<p>address of the Zone</p>"
          },
          {
            "group": "Parameter",
            "type": "char",
            "optional": false,
            "field": "country",
            "description": "<p>country</p>"
          },
          {
            "group": "Parameter",
            "type": "char",
            "optional": false,
            "field": "region",
            "description": "<p>region</p>"
          },
          {
            "group": "Parameter",
            "type": "char",
            "optional": false,
            "field": "province",
            "description": "<p>province</p>"
          },
          {
            "group": "Parameter",
            "type": "char",
            "optional": false,
            "field": "district",
            "description": "<p>district</p>"
          },
          {
            "group": "Parameter",
            "type": "char",
            "optional": false,
            "field": "sub_district",
            "description": "<p>sub_district</p>"
          },
          {
            "group": "Parameter",
            "type": "char",
            "optional": false,
            "field": "barangay",
            "description": "<p>barangay</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object[]",
            "optional": false,
            "field": "zones",
            "description": "<p>array of zones</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "zones.id",
            "description": "<p>ID of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "zones.code",
            "description": "<p>code of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "zones.name",
            "description": "<p>name of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "zones.address",
            "description": "<p>address of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "zones.country",
            "description": "<p>country</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "zones.region",
            "description": "<p>region</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "zones.province",
            "description": "<p>province</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "zones.district",
            "description": "<p>district</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "zones.sub_district",
            "description": "<p>sub_district</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "zones.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "zones.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "zones.deleted",
            "description": "<p>timestamp of deletion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n    \"zone\": [\n        {\n            \"id\": \"47af714f-cfd9-47e0-ae60-b71cd8ce4856\",\n            \"code\": \"ZN1\",\n            \"name\": \"Zone 1\",\n            \"address\": \"Los Banos\",\n            \"country\": \"PHL\",\n            \"region\": \"4A\",\n            \"province\": \"LGN\",\n            \"district\": \"3\",\n            \"sub_district\": null,\n            \"barangay\": \"Bayog\",\n            \"created\": \"2018-07-11T01:33:34.000Z\",\n            \"updated\": \"2018-07-11T01:46:50.000Z\",\n            \"deleted\": null,\n            \"distribution_center_id\": \"e5673532-de5b-4886-a24e-a447a58b4782\"\n        }\n    ],\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ZoneController.js",
    "groupTitle": "Zone"
  },
  {
    "type": "put",
    "url": "/v1/zones/:id",
    "title": "Update Zone by ID",
    "name": "Update_Zone_by_ID",
    "group": "Zone",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "UUID",
            "optional": false,
            "field": "id",
            "description": "<p>Zone's unique ID.</p>"
          }
        ],
        "Body Params": [
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>unique code for each zone</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "distribution_center_id",
            "description": "<p>ID of the distribution center the zone belongs to (foreign key)</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>name of zone</p>"
          },
          {
            "group": "Body Params",
            "type": "String",
            "optional": false,
            "field": "address",
            "description": "<p>address of the zone</p>"
          },
          {
            "group": "Body Params",
            "type": "char",
            "optional": false,
            "field": "country",
            "description": "<p>country</p>"
          },
          {
            "group": "Body Params",
            "type": "char",
            "optional": false,
            "field": "region",
            "description": "<p>region</p>"
          },
          {
            "group": "Body Params",
            "type": "char",
            "optional": false,
            "field": "province",
            "description": "<p>province</p>"
          },
          {
            "group": "Body Params",
            "type": "char",
            "optional": false,
            "field": "district",
            "description": "<p>district</p>"
          },
          {
            "group": "Body Params",
            "type": "char",
            "optional": false,
            "field": "sub_district",
            "description": "<p>sub_district</p>"
          },
          {
            "group": "Body Params",
            "type": "char",
            "optional": false,
            "field": "barangay",
            "description": "<p>barangay</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "zone",
            "description": "<p>new zone</p>"
          },
          {
            "group": "Success 200",
            "type": "UUID",
            "optional": false,
            "field": "zone.id",
            "description": "<p>ID of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "zone.code",
            "description": "<p>code of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "zone.name",
            "description": "<p>name of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "zone.address",
            "description": "<p>address of zone</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "zone.country",
            "description": "<p>country</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "zone.region",
            "description": "<p>region</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "zone.province",
            "description": "<p>province</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "zone.district",
            "description": "<p>district</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "zone.sub_district",
            "description": "<p>sub_district</p>"
          },
          {
            "group": "Success 200",
            "type": "char",
            "optional": false,
            "field": "zone.barangay",
            "description": "<p>barangay</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "zone.created",
            "description": "<p>timestamp of creation</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "zone.updated",
            "description": "<p>timestamp when updated</p>"
          },
          {
            "group": "Success 200",
            "type": "Timestamp",
            "optional": false,
            "field": "zone.deleted",
            "description": "<p>timestamp of deletion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n    \"zone\": {\n        \"id\": \"47af714f-cfd9-47e0-ae60-b71cd8ce4856\",\n        \"code\": \"ZN1\",\n        \"name\": \"Zone 1\",\n        \"address\": \"Los Banos\",\n        \"country\": \"PHL\",\n        \"region\": \"4A\",\n        \"province\": \"LGN\",\n        \"district\": \"3\",\n        \"sub_district\": null,\n        \"barangay\": \"Bayog\",\n        \"created\": \"2018-07-11T01:33:34.000Z\",\n        \"updated\": \"2018-07-11T01:46:50.000Z\",\n        \"deleted\": null,\n        \"distribution_center_id\": \"e5673532-de5b-4886-a24e-a447a58b4782\"\n    },\n    \"message\": \"update zone: 47af714f-cfd9-47e0-ae60-b71cd8ce4856\",\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./controllers/ZoneController.js",
    "groupTitle": "Zone"
  },
  {
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "optional": false,
            "field": "varname1",
            "description": "<p>No type.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "varname2",
            "description": "<p>With type.</p>"
          }
        ]
      }
    },
    "type": "",
    "url": "",
    "version": "0.0.0",
    "filename": "./apidoc/main.js",
    "group": "_home_cdi4_Desktop_radagast_backend_apidoc_main_js",
    "groupTitle": "_home_cdi4_Desktop_radagast_backend_apidoc_main_js",
    "name": ""
  }
] });
