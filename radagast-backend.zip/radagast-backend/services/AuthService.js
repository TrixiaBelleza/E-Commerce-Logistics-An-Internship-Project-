const User      = require('./../models').User;
const validator = require('validator');
const jwt       = require('jsonwebtoken');

const getUniqueKeyFromBody = (body) => {
    let unique_key = body.unique_key;
    if (typeof unique_key === 'undefined') {
        if (typeof body.email !== 'undefined') {
            unique_key = body.email;
        } else if (typeof body.phone !== 'undefined') {
            unique_key = body.phone;
        } else {
            unique_key = null;
        }
    }
    return unique_key;
};


const createUser = async (userInfo) => {
    let unique_key, auth_info, err;
    auth_info = {};
    auth_info.status = 'create';
    unique_key = getUniqueKeyFromBody(userInfo);
    if (!unique_key) {
        TE('email address or phone number was not specified');
    }
    if (validator.isEmail(unique_key)) {
        auth_info.method = 'email';
        userInfo.email = unique_key;
        [err, user] = await to(User.create(userInfo));
        if (err) {
            TE('user already exists with that email');
        }
        return user;
    } else if (validator.isMobilePhone(unique_key, 'any')) {
        auth_info.method = 'phone';
        userInfo.phone = unique_key;
        [err, user] = await to(User.create(userInfo));
        if (err) {
            TE('user already exists with that phone number');
        }
        return user;
    } else {
        TE('a valid email address or phone number was not specified');
    }
};


const authUser = async (userInfo) => {
    let unique_key;
    let auth_info = {};
    auth_info_status = 'login';
    unique_key = getUniqueKeyFromBody(userInfo);
    if(!unique_key) {
        TE('enter an email address or phone number to login');
    }
    if (!userInfo.password) {
        TE('enter password to login');   
    }
    let user;
    if (validator.isEmail(unique_key)) {
        auth_info.method = 'email';
        [err, user] = await to(User.findOne({
            'where': {'email': unique_key}
        }));
        if (err) {
            TE(err.message);
        }
    } else if (validator.isMobilePhone(unique_key, 'any')) {
        auth_info.method = 'phone';
        [err, user] = await to(User.findOne({
            'where': {'phone': unique_key}
        }));
        if (err) {
            TE(err.message);
        }
    } else {
        TE('a valid email address or phone number was not specified')
    }
    if (!user) {
        TE('not registered');
    }
    [err, user] = await to(user.comparePassword(userInfo.password));
    if (err) {
        TE(err.message);
    }
    return user;
}

const get_jti = async (header) => {

    const token = header.split(" ");
    console.log(token[1]);
    if (token[1]) {
        var decoded;
        try {
            decoded = jwt.verify(token[1], CONFIG.jwt_encryption);
        } catch (e) {
            return e;
        }
        var jti = decoded.jti;
        return jti;
    }else{
        TE('sign in first');
    }
}


module.exports = {
    'getUniqueKeyFromBody'  : getUniqueKeyFromBody,
    'createUser'            : createUser,
    'authUser'              : authUser,
    'get_jti'               : get_jti
}