'use strict';

module.exports = (sequelize, DataTypes) => {
    const Model = sequelize.define('booking', {
        'id' : {
            type : DataTypes.UUID,
            defaultValue : DataTypes.UUIDV4,
            primaryKey : true,
            allowNull : false
        },
        'shipper_name' : {
            type : DataTypes.STRING,
            allowNull : false
        },
        'pick_up_address' : {
            type : DataTypes.STRING,
            allowNull : false
        },
        'contact_number' : {
            type : DataTypes.STRING,
            allowNull : false
        },
        'email' : {
            type : DataTypes.STRING, 
            allowNull : true
        },
        'product_type' : {
            type : DataTypes.STRING,
            allowNull : false
        },
        'cargo_type' : {
            type : DataTypes.STRING,
            allowNull : false
        },
        'mode_of_payment' : {
            type : DataTypes.STRING,
            allowNull : true
        },
        'created' : {
            type : DataTypes.DATE,
            allowNull : false,
            defaultValue: sequelize.literal('NOW()')
        },
        'updated' : {
            type : DataTypes.DATE,
            allowNull : true
        },
        'deleted' : {
            type : DataTypes.DATE,
            allowNull : true
        }
    },
    {
        freezeTableName : true,
        timestamps : false
    });   

    Model.associate = (models) => {
        Model.belongsTo(models.client, {
            foreignKey : {
                name : 'client_account_number',
                allowNull : true
            }
        });
    }

    Model.prototype.toWeb = function (pw) {
        let json = this.toJSON();
        return json;
    }

    return Model;
};