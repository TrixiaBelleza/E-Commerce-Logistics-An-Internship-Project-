'use strict'

module.exports = (sequelize, DataTypes) => {
    const Model = sequelize.define('log', {
        'id' : {
            type : DataTypes.UUID,
            defaultValue : DataTypes.UUIDV4,
            primaryKey : true,
            allowNull : false
        },
        'actor' : {
            type : DataTypes.STRING,
            allowNull : true
        },
        'route' : {
            type : DataTypes.STRING,
            allowNull : true
        },
        'body' : {
            type : DataTypes.JSON
        },
        'result' : {
            type : DataTypes.STRING,
            allowNull : true
        },
        'created' : {
            type : DataTypes.DATE,
            allowNull : false,
            defaultValue : sequelize.literal('NOW()')
        }
    },
    {
        freezeTableName : true,
        timestamps : false
    });

    Model.prototype.toWeb = function (pw) {
        let json = this.toJSON();
        return json;
    }

    return Model;

};
