'use strict';

const bcrypt    = require('bcrypt');
const bcrypt_p  = require('bcrypt-promise');
const jwt       = require('jsonwebtoken');
const Sequelize = require('sequelize');
const uuidv4    = require('uuid/v4');

module.exports = (sequelize, DataTypes) => {
    const Model = sequelize.define('User', {
        'email'   : {
            'type': DataTypes.STRING, 
            'unique': true, 
            'validate': {'isEmail': {'msg': 'Email invalid'}}
        },
        'password': {
            type : DataTypes.STRING,
            allowNull : false
        },
        'first_name' : {
            type : DataTypes.STRING,
            allowNull : false
        },
        'last_name' : {
            type : DataTypes.STRING,
            allowNull : false
        },
        'middle_name' : {
            type : DataTypes.STRING,
            allowNull : true
        },
        'contact_number' : {
            type : DataTypes.STRING,
            allowNull : true
        },
        'created' : {
            type : DataTypes.DATE,
            allowNull : false,
            defaultValue: sequelize.literal('NOW()')
        },
        'updated' : {
            type: DataTypes.DATE,
            allowNull: true,
            defaultValue: null
        },
        'deleted' : {
            type : DataTypes.DATE,
            allowNull : true,
            defaultValue: null
        }
    });

    Model.beforeSave(async(user, options) => {
        let err;
        if (user.changed('password')) {
            let salt, hash;
            console.log(user.changed('password'));
            [err, salt] = await to(bcrypt.genSalt(10));
            if (err) {
                TE(err.message, true);
            }
            [err, hash] = await to(bcrypt.hash(user.password, salt));
            if (err) {
                TE(err.message, true); 
            }
            user.password = hash;
        }
    });

    Model.prototype.comparePassword = async function(pw) {
        let err, pass;
        if (!this.password) {
            TE('password not set');
        }
        [err, pass] = await to(bcrypt_p.compare(pw, this.password));
        if (err) {
            TE(err);
        }
        if (!pass) {
            TE('invalid password');
        }
        return this;
    };

    Model.prototype.getJWT = function() {
        let expiration_time = parseInt(CONFIG.jwt_expiration);
        const identifier = uuidv4();
        return "Bearer " + jwt.sign({'user_id': this.id}, CONFIG.jwt_encryption, {'expiresIn': expiration_time,'jwtid': identifier});
    }

    Model.prototype.toWeb = function (pw) {
        let json = this.toJSON();
        return json;
    }



    return Model;
};