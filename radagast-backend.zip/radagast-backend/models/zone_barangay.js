'use strict';

module.exports = (sequelize, DataTypes) => {
    const Model = sequelize.define('zone_barangay', {
        'id' : {
            type : DataTypes.UUID,
            defaultValue : DataTypes.UUIDV4,
            primaryKey : true,
            allowNull : false
        },
        'created' : {
            type : DataTypes.DATE,
            allowNull : false,
            defaultValue : sequelize.literal('NOW()')
        },
        'updated' :  {
            type : DataTypes.DATE,
            allowNull : true
        },
        'deleted' : {
            type : DataTypes.DATE,
            allowNull : true
        }
    },
    {
        freezeTableName : true,
        timestamps : false
    });

    Model.associate = (models) => {
        Model.belongsTo(models.zone, {
            foreignKey : {
                name : 'zone_id',
                allowNull : true
            }
        });
        Model.belongsTo(models.barangay, {
            foreignKey : {
                name : 'barangay_id',
                allowNull : true
            }
        });
    }

    Model.prototype.toWeb = function (pw) {
        let json = this.toJSON();
        return json;
    }
    return Model;
}