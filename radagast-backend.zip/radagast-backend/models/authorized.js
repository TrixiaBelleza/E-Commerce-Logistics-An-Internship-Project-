'use strict';

module.exports = (sequelize, DataTypes) => {
    const Model = sequelize.define('authorized', {
            'token_id'      : {
                              type: DataTypes.STRING,
                              primaryKey: true,
                              notNull : true
            }
            
        },
        
        {
            freezeTableName : true,
            timestamps: false

        }
    );

    Model.prototype.toWeb = function (pw) {
        let json = this.toJSON();
        return json;
    }

    return Model;
};