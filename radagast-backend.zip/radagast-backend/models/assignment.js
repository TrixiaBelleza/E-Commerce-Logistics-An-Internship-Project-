'use strict';

module.exports = (sequelize, DataTypes) => {
    const Model = sequelize.define('assignment', {
        'id' : {
            type : DataTypes.UUID,
            defaultValue : DataTypes.UUIDV4,
            primaryKey : true,
            allowNull : false
        },
        'created' : {
            type: DataTypes.DATE,
            allowNull : false,
            defaultValue : sequelize.literal('NOW()')
        },
        'timestamp_of_completion' : {
            type : DataTypes.DATE,
            allowNull : true
        },
        'status' : {
            type : DataTypes.STRING,
            allowNull : false,
            defaultValue : 'Pending'
        },
        'check_in_time' : {
            type : DataTypes.DATE,
            allowNull : true
        },
        'check_out_time' : {
            type : DataTypes.DATE,
            allowNull : true
        },
        'remarks' : {
            type : DataTypes.STRING,
            allowNull : true
        },
        'name_of_receiver' : {
            type : DataTypes.STRING,
            allowNull : true
        },
        'relationship_to_shipper' : {
            type : DataTypes.STRING,
            allowNull : true
        },
        'timestamp_of_unassignment_from_booking' : {
            type : DataTypes.DATE,
            allowNull : true
        }
    },
    {
        freezeTableName : true,
        timestamps : false
    });

    Model.associate = (models) => {
        Model.belongsTo(models.booking, {
            foreignKey : {
                name : 'booking_id',
                allowNull : true
            }
        });
        Model.belongsTo(models.Courier, {
            foreignKey : {
                name : 'courier_id',
                allowNull : true
            }
        });
        Model.belongsTo(models.dispatcher, {
            foreignKey : {
                name : 'dispatcher_id',
                allowNull : true
            }
        });
    }

    Model.prototype.toWeb = function (pw) {
        let json = this.toJSON();
        return json;
    }
    return Model;
}