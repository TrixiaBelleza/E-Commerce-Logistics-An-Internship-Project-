'use strict';

module.exports = (sequelize, DataTypes) => {
    const Model = sequelize.define('item', {
            'id': {
                type: DataTypes.UUID,
                defaultValue : DataTypes.UUIDV4,
                primaryKey: true,
                notNull : true
            },
            'consignee_address' : {
                    type: DataTypes.STRING,
                    allowNull: false
            },
            'consignee_country' : {
                    type: DataTypes.STRING,
                    allowNull: true
            },
            'consignee_region' : {
                    type: DataTypes.STRING,
                    allowNull: true
            },
            'consignee_province' : {
                    type: DataTypes.STRING,
                    allowNull: true
            },
            'consignee_district' : {
                    type: DataTypes.STRING,
                    allowNull: true
            },
            'consignee_sub_district' : {
                    type: DataTypes.STRING,
                    allowNull: true
            },
            'consignee_barangay' : {
                    type: DataTypes.STRING,
                    allowNull: true
            },
            'consignee_first_name' : {
                    type: DataTypes.STRING,
                    allowNull: false
            },
            'consignee_last_name' : {
                    type: DataTypes.STRING,
                    allowNull: false
            },
            'consignee_contact_number' : {
                    type: DataTypes.STRING,
                    allowNull: false
            },
            'consignee_email' : {
                    type: DataTypes.STRING,
                    allowNull: false
            },
            'weight' : {
                    type: DataTypes.FLOAT,
                    allowNull: false
            },
            'height' : {
                    type: DataTypes.FLOAT,
                    allowNull: false
            },
            'length' : {
                    type: DataTypes.FLOAT,
                    allowNull: false
            },
            'width' : {
                    type: DataTypes.FLOAT,
                    allowNull: false
            },
            'package_type' : {
                    type: DataTypes.STRING,
                    allowNull: false
            },
            'tracking_number' : {
                    type: DataTypes.STRING,
                    allowNull: false
            },
            'airway_bill' : {
                    type: DataTypes.STRING,
                    allowNull: false
            },
            'status' : {
                    type: DataTypes.STRING,
                    allowNull: false
            },
            'value' : {
                    type: DataTypes.FLOAT,
                    allowNull: true
            },
            'timestamp_of_receiving'              : {
                    type: DataTypes.DATE,
                    allowNull: false,
                    defaultValue: sequelize.literal('NOW()')
            },
            'updated'              : {
                    type: DataTypes.DATE,
                    allowNull: true,
                    defaultValue: null
            }
        },
        
        {
            freezeTableName : true,
            timestamps: false

        }
    );

    Model.associate = (models)=>{
        Model.belongsTo(models.Courier,{
          foreignKey : {
            name : 'courier_id',
            allowNull : true
          }
        });

         Model.belongsTo(models.inbound_officer,{
          foreignKey : {
            name : 'inbound_officer_id',
            allowNull : true
          }
        });
    }

    Model.prototype.toWeb = function (pw) {
        let json = this.toJSON();
        return json;
    }
    
    return Model;
};