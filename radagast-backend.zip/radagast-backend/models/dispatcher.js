'use strict';

module.exports = (sequelize, DataTypes) => {
    const Model = sequelize.define('dispatcher', {
            'id': {
                type: DataTypes.UUID,
                defaultValue : DataTypes.UUIDV4,
                primaryKey: true,
                notNull : true
              },
            'created'              : {
                    type: DataTypes.DATE,
                    allowNull: false,
                    defaultValue: sequelize.literal('NOW()')
              },
            'updated'              : {
                    type: DataTypes.DATE,
                    allowNull: true,
                    defaultValue: null
            },
            'deleted'              : {
                    type : DataTypes.DATE,
                    allowNull : true,
                    defaultValue: null
            }
        },
        
        {
            freezeTableName : true,
            timestamps: false

        }
    );

    Model.associate = (models)=>{
        Model.belongsTo(models.User,{
          foreignKey : {
            name : 'user_id',
            allowNull : false
          }
        });

         Model.belongsTo(models.hub,{
          foreignKey : {
            name : 'hub_id',
            allowNull : false
          }
        });

        Model.belongsTo(models.distribution_center,{
          foreignKey : {
            name : 'distribution_center_id',
            allowNull : true
          }
        });
    }

    Model.prototype.toWeb = function (pw) {
        let json = this.toJSON();
        return json;
    }
    
    return Model;
};