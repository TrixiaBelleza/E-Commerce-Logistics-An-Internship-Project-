'use strict';

module.exports = (sequelize, DataTypes) => {
    const Model = sequelize.define('area_manager', {
        'id' : {
            type : DataTypes.UUID,
            defaultValue : DataTypes.UUIDV4,
            primaryKey : true,
            allowNull : false
        },
        'hub_id' : {
            type : DataTypes.STRING,
            allowNull : true
        },
        'distribution_center_id' : {
            type : DataTypes.STRING,
            allowNull : true
        },
        'created' : {
            type : DataTypes.DATE,
            allowNull : false,
            defaultValue: sequelize.literal('NOW()')
        },
        'updated' : {
            type : DataTypes.DATE,
            allowNull : true
        },
        'deleted' : {
            type : DataTypes.DATE,
            allowNull : true
        }
    }, 
    {
        freezeTableName : true,
        timestamps : false
    });

    Model.associate = (models)=>{
        Model.belongsTo(models.User,{
          foreignKey : {
            name : 'user_id',
            allowNull : false
          }
        });
    }

    Model.prototype.toWeb = function (pw) {
        let json = this.toJSON();
        return json;
    }
    return Model;
}