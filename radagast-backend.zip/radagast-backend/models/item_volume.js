'use strict';

module.exports = (sequelize, DataTypes) => {
    const Model = sequelize.define('item_volume', {
        'id' : {
            type : DataTypes.UUID,
            allowNull : false,
            primaryKey : true,
            defaultValue : DataTypes.UUIDV4
        },
        'length' : {
            type : DataTypes.FLOAT,
            allowNull : false
        },
        'height' : {
            type : DataTypes.FLOAT,
            allowNull : false
        },
        'width' : {
            type : DataTypes.FLOAT,
            allowNull : false
        },
        'volume' : {
            type : DataTypes.FLOAT,
            allowNull : true
        },
        'created' : {
            type : DataTypes.DATE,
            allowNull : false,
            defaultValue: sequelize.literal('NOW()')
        },
        'updated' : {
            type : DataTypes.DATE,
            allowNull : true
        },
        'deleted' : {
            type : DataTypes.DATE,
            allowNull : true
        }
    }, 
    {
        freezeTableName : true,
        timestamps : false
    });

    Model.prototype.toWeb = function (pw) {
        let json = this.toJSON();
        return json;
    }
    return Model;
}