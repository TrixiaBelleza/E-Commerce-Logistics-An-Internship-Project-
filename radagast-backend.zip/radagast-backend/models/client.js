'use strict';

module.exports = (sequelize, DataTypes) => {
    const Model = sequelize.define('client', {
            'client_account_number' : {
                    type: DataTypes.UUID,
                    defaultValue : DataTypes.UUIDV4,
                    primaryKey: true,
                    notNull : true
            },
            'pick_up_address'  : DataTypes.STRING,
          
            'ftp_address' :  DataTypes.STRING,
            
            'credit_term' :   DataTypes.INTEGER,
            
            'mode_of_payment' : DataTypes.STRING,

            'created' : {
                type: DataTypes.DATE,
                allowNull: false,
                defaultValue: sequelize.literal('NOW()')
            },
            'updated' : {
                type: DataTypes.DATE,
                allowNull: true,
                defaultValue: null
            },
            'deleted' : {
                type : DataTypes.DATE,
                allowNull : true,
                defaultValue: null
            }
        },
        
        {
            freezeTableName : true,
            timestamps: false

        }
    );

    Model.associate = (models)=>{
        Model.belongsTo(models.User,{
          foreignKey : {
            name : 'user_id',
            allowNull : false
          }
        });

    }

    Model.prototype.toWeb = function (pw) {
        let json = this.toJSON();
        return json;
    }

    return Model;
};