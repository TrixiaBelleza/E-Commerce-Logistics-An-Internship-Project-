'use strict';

module.exports = (sequelize, DataTypes) => {
    const Model = sequelize.define('price', {
            'id': {
                type: DataTypes.UUID,
                defaultValue : DataTypes.UUIDV4,
                primaryKey: true,
                allowNull : false
              },
            'package_type' : {
                    type: DataTypes.STRING,
                    allowNull: true,
                    defaultValue: null
            },
            'origin' : {
                    type : DataTypes.STRING,
                    allowNull : true,
                    defaultValue: null
            },
            'destination' : {
                    type : DataTypes.STRING,
                    allowNull : true,
                    defaultValue: null
            },
            'price' : {
                    type : DataTypes.FLOAT,
                    allowNull : false
            },
            'created'              : {
                    type: DataTypes.DATE,
                    allowNull: false,
                    defaultValue: sequelize.literal('NOW()')
              },
            'updated'              : {
                    type: DataTypes.DATE,
                    allowNull: true,
                    defaultValue: null
            },
            'deleted'              : {
                    type : DataTypes.DATE,
                    allowNull : true,
                    defaultValue: null
            }
        },
        
        {
            freezeTableName : true,
            timestamps: false

        }
    );

    Model.associate = (models)=>{
        Model.belongsTo(models.client,{
          foreignKey : {
            name : 'client_account_number',
            allowNull : false
          }
        });

    }

    Model.prototype.toWeb = function (pw) {
        let json = this.toJSON();
        return json;
    }

    return Model;
};