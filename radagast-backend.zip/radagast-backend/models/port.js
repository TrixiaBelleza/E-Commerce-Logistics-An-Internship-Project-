'use strict';

module.exports = (sequelize, DataTypes) => {
    const Model = sequelize.define('port', {
            'id'                   : {
                                      type: DataTypes.STRING,
                                      defaultValue : DataTypes.UUIDV4,
                                      primaryKey: true,
                                      notNull : true
            },
            'code'                 : {
                                        type : DataTypes.STRING,
                                        notNull : true,
                                        unique : true
           },  

            'name'                 : {
                                        type : DataTypes.STRING,
                                        notNull : true
            },
            'address'              : {
                                        type : DataTypes.STRING,
                                        notNull : true
            },
            'country'              : {
                                        type: DataTypes.CHAR,
                                        defaultValue: 'PHL',
                                        notNull:true
            },
            'region'               : {
                                        type : DataTypes.CHAR,
                                        notNull: null
            },
            'province'             : {
                                        type : DataTypes.CHAR,
                                        notNull: null
            },
            'district'             : {
                                        type : DataTypes.CHAR,
                                        notNull: null
            },
            'sub_district'         : {
                                        type: DataTypes.CHAR,
                                        allowNull: true,
                                        defaultValue: null
            },
            
            'created'               : {
                                        type: DataTypes.DATE,
                                        allowNull: false,
                                        defaultValue: sequelize.literal('NOW()')
              },
            'updated'               : {
                                        type: DataTypes.DATE,
                                        allowNull: true,
                                        defaultValue: null
            },
            'deleted'               : {
                                        type : DataTypes.DATE,
                                        allowNull : true,
                                         defaultValue: null
            }
        },
        
        {
            freezeTableName : true,
            timestamps: false

        }
    );

    Model.prototype.toWeb = function (pw) {
        let json = this.toJSON();
        return json;
    }

    return Model;
};