'use strict';

module.exports = (sequelize, DataTypes) => {
    const Model = sequelize.define('district', {
        'id' : {
            type : DataTypes.UUID,
            defaultValue : DataTypes.UUIDV4,
            primaryKey : true,
            allowNull : false
            },
        'code' : {
            type: DataTypes.CHAR,
            allowNull : false
        },
        'name' : {
            type : DataTypes.STRING,
            allowNull : false
        },
        'created' : {
            type: DataTypes.DATE,
            allowNull: false,
            defaultValue: sequelize.literal('NOW()')
              },
        'updated' : {
            type: DataTypes.DATE,
            allowNull: true,
            defaultValue: null
        },
        'deleted' : {
            type : DataTypes.DATE,
            allowNull : true,
            defaultValue: null
        }
    },
    {
        freezeTableName : true,
        timestamps : false,
        paranoid : true
    });


    Model.associate = (models)=>{
        Model.belongsTo(models.province,{
          foreignKey : {
            name : 'province_id',
            allowNull : false
          }
        });
    }

    Model.prototype.toWeb = function (pw) {
        let json = this.toJSON();
        return json;
    }
    return Model;
};