'use strict';

module.exports = (sequelize, DataTypes) => {
    const Model = sequelize.define('province', {
            'id': {
                type: DataTypes.UUID,
                defaultValue : DataTypes.UUIDV4,
                primaryKey: true,
                allowNull : false
            },
            'code' : {
                type: DataTypes.STRING,
                allowNull : false
            },
            'name' : {
                type: DataTypes.STRING,
                allowNull : false
            },
            'created' : {
                    type: DataTypes.DATE,
                    allowNull: false,
                    defaultValue: sequelize.literal('NOW()')
              },
            'updated' : {
                    type: DataTypes.DATE,
                    allowNull: true,
                    defaultValue: null
            },
            'deleted' : {
                    type : DataTypes.DATE,
                    allowNull : true,
                    defaultValue: null
            }
        },

        {
            freezeTableName: true,
            timestamps: false
        }

    );

    Model.associate = (models)=>{
        Model.belongsTo(models.region,{
          foreignKey : {
            name : 'region_id',
            allowNull : false
          }
        });
    }

    Model.prototype.toWeb = function (pw) {
        let json = this.toJSON();
        return json;
    }

    return Model;
};