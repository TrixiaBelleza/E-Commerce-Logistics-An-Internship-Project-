'use strict';

module.exports = (sequelize, DataTypes) => {
  const Model = sequelize.define('vehicle', {
    'id': {
            type: DataTypes.UUID,
            defaultValue: DataTypes.UUIDV4,
            primaryKey: true
    },
    'plate_number' : {
            type : DataTypes.STRING,
            allowNull : false
    },
    'type' : {
              type : DataTypes.STRING,
              allowNull : false,
              len : {
                      args : [1,64]
              }
    },
    'model' : {
                type : DataTypes.STRING,
                allowNull : true,
                len : {
                  args : [1,128]
                }
    },
    'created': {
                type: DataTypes.DATE,
                allowNull: false,
                defaultValue: sequelize.literal('NOW()')
    },
    'updated': {
                type: DataTypes.DATE,
                allowNull: true,
                defaultValue: null
    },
    'deleted': {
                type: DataTypes.DATE,
                allowNull: true,
                defaultValue: null
    }
  },
    {
      freezeTableName: true,
      timestamps: false

    }
  );

  Model.prototype.toWeb = function (pw) {
    let json = this.toJSON();
    return json;
  }

  return Model;
}