'use strict';

module.exports = (sequelize, DataTypes) => {
    const Model = sequelize.define('client_service_schedule', {
            'id': {
                type: DataTypes.UUID,
                defaultValue : DataTypes.UUIDV4,
                primaryKey: true,
                allowNull : false
              },
            'pick_up_time' : {
                type: DataTypes.DATE,
                allowNull : true
             },
             'delivery_time' : {
                type: DataTypes.DATE,
                allowNull : true
             },
            'type'              : {
                type: DataTypes.STRING,
                allowNull : false
              },
            'created'              : {
                    type: DataTypes.DATE,
                    allowNull: false,
                    defaultValue: sequelize.literal('NOW()')
              },
            'updated'              : {
                    type: DataTypes.DATE,
                    allowNull: true,
                    defaultValue: null
            }
        },
        
        {
            freezeTableName : true,
            timestamps: false

        }
    );

    Model.associate = (models)=>{
        Model.belongsTo(models.client,{
          foreignKey : {
            name : 'client_account_number',
            allowNull : false
          }
        });

    }

    Model.prototype.toWeb = function (pw) {
        let json = this.toJSON();
        return json;
    }
    
    return Model;
};