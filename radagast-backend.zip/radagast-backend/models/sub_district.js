'use strict';

module.exports = (sequelize, DataTypes) => {
    const Model = sequelize.define('sub_district', {
        'id' : {
            type : DataTypes.UUID,
            defaultValue : DataTypes.UUIDV4,
            primaryKey : true,
            notNull : true
            },
        'code' : {
            type: DataTypes.CHAR,
            notNull : true
        },
        'name' : {
            type : DataTypes.STRING,
            notNull : true
        },
        'created' : {
                    type: DataTypes.DATE,
                    allowNull: false,
                    defaultValue: sequelize.literal('NOW()')
              },
        'updated' : {
                    type: DataTypes.DATE,
                    allowNull: true,
                    defaultValue: null
        },
        'deleted' : {
                    type : DataTypes.DATE,
                    allowNull : true,
                    defaultValue: null
        }
    },
    {
        freezeTableName : true,
        timestamps : false
    });


    Model.associate = (models)=>{
        Model.belongsTo(models.district,{
          foreignKey : {
            name : 'district_id',
            allowNull : false
          }
        });
    }

    Model.prototype.toWeb = function (pw) {
        let json = this.toJSON();
        return json;
    }
    return Model;
};