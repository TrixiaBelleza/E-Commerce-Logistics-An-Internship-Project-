'use strict';

module.exports = (sequelize, DataTypes) => {
    const Model = sequelize.define('country', {
	        'id': {
		        type: DataTypes.UUID,
		        primaryKey: true,
				defaultValue : DataTypes.UUIDV4,
				allowNull : false
		      },
	        'code': {
		        type: DataTypes.STRING,
		        allowNull : false
		     },
	        'name': {
		        type: DataTypes.STRING,
		        allowNull : false
		      },
	        'created'              : {
                    type: DataTypes.DATE,
                    allowNull: false
              },
            'updated'              : {
                    type: DataTypes.DATE,
                    allowNull: true,
                    defaultValue: null
            },
            'deleted'              : {
                    type : DataTypes.DATE,
                    allowNull : true,
                    defaultValue: null
            }
    	},
    	
    	{
    		freezeTableName : true,
    		timestamps: false

    	}
    );

    Model.prototype.toWeb = function (pw) {
        let json = this.toJSON();
        return json;
    }

    return Model;
};