require('./config/config');
require('./global_functions');

const express       = require('express');
const logger        = require('morgan');
const bodyParser    = require('body-parser');
const passport      = require('passport');

const v1_lookups           = require('./routes/v1_lookups');
const v1_data_management   = require('./routes/v1_data_management');
const v1_auth              = require('./routes/v1_auth');
const models               = require('./models');

const app = express();

app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({'extended': false}));

app.use(passport.initialize());
models.sequelize.authenticate().then(() => {
    console.log('connected to the database');
})
.catch(err => {
    console.error('unable to connect to the database: ', err);
});
if(CONFIG.app === 'dev') {
    models.sequelize.sync({'force': false});
}

app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With, content-type, Authorization, Content-Type');
    res.setHeader('Access-Control-Allow-Credentials', true);
    next();
});

app.use('/v1/lookups', v1_lookups);
app.use('/v1', v1_data_management);
app.use('/v1/auth',v1_auth);

app.use('/', (req, res, next) => {
    res.statusCode = 200;
    res.json({'status': 'success', 'message': 'Parcel Pending API', 'data': {}});
});

app.use((req, res, next) => {
    const err = new Error('Not Found');
    err.status = 404;
    next(err);
});

app.use((err, req, res, next) => {
    res.locals.message = err.message;
    res.locals.error = req.app.get('env') === 'dev' ? err : {};
    res.status(err.status || 500);
    res.render('error');
});

module.exports = app;