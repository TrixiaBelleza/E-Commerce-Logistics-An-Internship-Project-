# ECL-backend
type @ terminal : 
nano .env

then copy this to .env

PP=dev
PORT=3000

DB_DIALECT=mysql
DB_HOST=localhost
DB_PORT=3306
DB_NAME=radagast_db
DB_USER=radagast
DB_PASSWORD=pwd@radagast33

JWT_ENCRYPTION=SHA1
JWT_EXPIRATION=10000


then @ mysql 
create user 'radagast'@'localhost' identified by 'pwd@radagast33';
GRANT ALL PRIVILEGES ON *.* TO 'radagast'@'localhost';

To view docs: 

type this @ terminal: 
apidoc -o apidoc/ -e ./node_modules

then go to 
radagast-backend/apidoc

then click on index.html
